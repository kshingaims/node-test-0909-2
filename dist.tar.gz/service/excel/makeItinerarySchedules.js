/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { convertAllNullToMark, format, formatDateTime, formatUtcDateTime, getLocalDate, joinStr, replaceLF, showDifferentDateMark, } from '../../utils/index.js';
import { copyWorksheet, getWorksheet, getWorksheetByName, openExcelFromTemplateFile, writeBuffer } from '../../utils/excel.js';
import { getLangValue } from '../../utils/lang.js';
import { addHours } from 'date-fns';
import { find, orderBy } from 'lodash-es';
import { getTransportationModeLabel, getTransportationsForExcelDownload, } from '../../service/transportation/transportationService.js';
import { getHotelsForExcelDownload, hasCheckIn, hasCheckOut, } from '../../service/hotel/hotelService.js';
import { getCompanyCarsForExcelDownload } from '../../service/companyCar/companyCarService.js';
import { Define } from '../../utils/define.js';
import { getItineraryIndividualList } from '../../service/itinerary/itineraryService.js';
import { getFlightsForExcelDownload } from '../../service/flight/flightService.js';
import { getEventsForExcelDownload } from '../../service/event/eventService.js';
const RETURN = '\n';
const PARTICIPATE = '✓';
const NO_PARTICIPATE = '';
function setHotelInfo(schedules, schedHotels, lang) {
    if (!schedules) {
        return;
    }
    for (const data of schedHotels) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const schedHotel = data;
        if (!schedHotel) {
            continue;
        }
        const checkInDateTime = schedHotel.checkInDateTime;
        const checkOutDateTime = schedHotel.checkOutDateTime;
        const timezone = schedHotel.timezone;
        if (!checkInDateTime || !checkOutDateTime || !timezone) {
            continue;
        }
        const remark = schedHotel.remark || '';
        const name = schedHotel.name;
        const address = schedHotel.address;
        const gmtStart = new Date(checkInDateTime);
        const gmtEnd = new Date(checkOutDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // チェックイン時刻が分かっている場合
        if (hasCheckIn(schedHotel)) {
            // ホテルチェックイン予定
            schedules.push({
                type: 'hotelStart',
                gmtStart,
                gmtEnd: gmtStart,
                date: formatUtcDateTime(localStart, 'yyyy/M/d'),
                day: formatUtcDateTime(localStart, 'EEE'),
                start: formatUtcDateTime(localStart, 'HH:mm'),
                startTimezone: timezone,
                end: '',
                endTimezone: '',
                schedule: name,
                place: address,
                memo: replaceLF(remark),
                flgArrgtStatus: getFlgArrgtStatusValue(lang, schedHotel.flgArrgt || false),
                companions: schedHotel.schedHotelIndividuals,
            });
        }
        else {
            // チェックイン時刻がないので、その日の23:59:59の予定としておく(その日の一番最後の予定となる想定)
            const newGmtStart = formatUtcDateTime(localStart, 'yyyy-MM-dd') + 'T23:59:59' + timezone;
            schedules.push({
                type: 'hotelStart',
                gmtStart: new Date(newGmtStart),
                gmtEnd: new Date(newGmtStart),
                date: formatUtcDateTime(localStart, 'yyyy/M/d'),
                day: formatUtcDateTime(localStart, 'EEE'),
                start: '',
                startTimezone: '',
                end: '',
                endTimezone: '',
                schedule: name,
                place: address,
                memo: replaceLF(remark),
                flgArrgtStatus: getFlgArrgtStatusValue(lang, schedHotel.flgArrgt || false),
                companions: schedHotel.schedHotelIndividuals,
            });
        }
        if (hasCheckOut(schedHotel)) {
            // ホテルチェックアウト予定
            schedules.push({
                type: 'hotelEnd',
                gmtStart: gmtEnd,
                gmtEnd,
                date: formatUtcDateTime(localEnd, 'yyyy/M/d'),
                day: formatUtcDateTime(localEnd, 'EEE'),
                start: '',
                startTimezone: '',
                end: formatUtcDateTime(localEnd, 'HH:mm'),
                endTimezone: timezone,
                schedule: name,
                place: address,
                memo: getLangValue('excelDownload.hotel.checkOut', lang),
                flgArrgtStatus: getFlgArrgtStatusValue(lang, schedHotel.flgArrgt || false),
                companions: schedHotel.schedHotelIndividuals,
            });
        }
    }
}
function setFlightInfo(schedules, schedFlights, lang) {
    if (!schedules) {
        return;
    }
    for (const data of schedFlights) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const schedFlight = data;
        if (!schedFlight) {
            continue;
        }
        const departureDateTime = schedFlight.departureDateTime;
        const arrivalDateTime = schedFlight.arrivalDateTime;
        const departureTimezone = schedFlight.departureTimezone;
        const arrivalTimezone = schedFlight.arrivalTimezone;
        if (!departureDateTime || !arrivalDateTime || !departureTimezone || !arrivalTimezone) {
            continue;
        }
        const remark = joinStr([schedFlight.flightNumber, schedFlight.remark], RETURN);
        let place = joinStr([
            joinStr([schedFlight.departureCity, schedFlight.departureAirport], '/'),
            joinStr([schedFlight.arrivalCity, schedFlight.arrivalAirport], '/'),
        ], '→', true);
        if (place === '→') {
            place = '';
        }
        const gmtStart = new Date(departureDateTime);
        const gmtEnd = new Date(arrivalDateTime);
        const localStart = getLocalDate(gmtStart, departureTimezone);
        const localEnd = getLocalDate(gmtEnd, arrivalTimezone);
        // フライト予定
        schedules.push({
            type: 'flight',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: departureTimezone,
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: arrivalTimezone,
            schedule: getLangValue('excelDownload.title.flight', lang),
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: getFlgArrgtStatusValue(lang, schedFlight.flgArrgt || false),
            companions: schedFlight.schedFlightIndividuals,
        });
    }
}
function setTransportationInfo(schedules, schedTransportations, lang) {
    if (!schedules) {
        return;
    }
    for (const data of schedTransportations) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const schedTransportation = data;
        if (!schedTransportation) {
            continue;
        }
        const departureDateTime = schedTransportation.departureDateTime;
        const arrivalDateTime = schedTransportation.arrivalDateTime;
        const timezone = schedTransportation.timezone;
        if (!departureDateTime || !arrivalDateTime || !timezone) {
            continue;
        }
        const schedule = format(getLangValue('excelDownload.title.transportation', lang), {
            transportationMode: getTransportationModeLabel(schedTransportation.transportationMode, lang),
        });
        const remark = schedTransportation.remark || '';
        let place = joinStr([schedTransportation.departureLocation, schedTransportation.arrivalLocation], '→', true);
        if (place === '→') {
            place = '';
        }
        const gmtStart = new Date(departureDateTime);
        const gmtEnd = new Date(arrivalDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // 各種移動予定
        schedules.push({
            type: 'transportation',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: timezone,
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: timezone,
            schedule,
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: '',
            companions: schedTransportation.schedTransportationIndividuals,
        });
    }
}
function setEventInfo(schedules, schedEvents) {
    if (!schedules) {
        return;
    }
    for (const data of schedEvents) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const schedEvent = data;
        if (!schedEvent) {
            continue;
        }
        const startDateTime = schedEvent.startDateTime;
        const endDateTime = schedEvent.endDateTime;
        const timezone = schedEvent.timezone;
        if (!startDateTime || !endDateTime || !timezone) {
            continue;
        }
        const schedule = schedEvent.name;
        const remark = schedEvent.remark || '';
        const place = schedEvent.location;
        const gmtStart = new Date(startDateTime);
        const gmtEnd = new Date(endDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // 各種イベント予定
        schedules.push({
            type: 'transportation',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: timezone,
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: timezone,
            schedule,
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: '',
            companions: schedEvent.schedEventIndividuals,
        });
    }
}
function setCompanyCarInfo(schedules, schedCompanyCars, lang) {
    if (!schedules) {
        return;
    }
    for (const data of schedCompanyCars) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const schedCompanyCar = data;
        if (!schedCompanyCar) {
            continue;
        }
        const startDateTime = schedCompanyCar.startDateTime;
        const endDateTime = schedCompanyCar.endDateTime;
        const timezone = schedCompanyCar.timezone;
        if (!timezone || !endDateTime || !startDateTime) {
            continue;
        }
        const remark = joinStr([schedCompanyCar.driverName, schedCompanyCar.driverTel, schedCompanyCar.carno, schedCompanyCar.remark], RETURN);
        let place = joinStr([schedCompanyCar.departureLocation, ''], '→', true);
        if (place === '→') {
            place = '';
        }
        const gmtStart = new Date(startDateTime);
        const gmtEnd = new Date(endDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // 社有車予定
        schedules.push({
            type: 'companyCar',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: timezone,
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: timezone,
            schedule: getLangValue('excelDownload.title.companyCar', lang),
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: getFlgArrgtStatusValue(lang, schedCompanyCar.flgArrgt || false),
            companions: schedCompanyCar.schedCompanyCarIndividuals,
        });
    }
}
export async function makeItinerarySchedulesExcel(itineraryInfo, lang) {
    const workbook = await openExcelFromTemplateFile('itinerary_shedules.xlsx');
    let schedules = [];
    // 予定情報から、Excel出力実施する情報のみの抽出処理実施
    setFlightInfo(schedules, itineraryInfo.schedFlights, lang);
    setHotelInfo(schedules, itineraryInfo.schedHotels, lang);
    setTransportationInfo(schedules, itineraryInfo.schedTransportations, lang);
    setEventInfo(schedules, itineraryInfo.schedEvents);
    setCompanyCarInfo(schedules, itineraryInfo.schedCompanyCars, lang);
    // 予定を世界標準時で並び替え。1:start時間 ASC、2:end時間 ASC
    schedules = orderBy(schedules, ['gmtStart', 'gmtEnd'], ['asc', 'asc']);
    let worksheet = getWorksheetByName(workbook, 'template');
    if (worksheet) {
        const users = itineraryInfo.itinerary.itinerary.itineraryIndividuals;
        const sheetName = 'business_trip';
        // 旅程に紐つく全ての同行者の数
        const userCount = users.length;
        // シートコピー作成
        worksheet = copyWorksheet(workbook, worksheet, sheetName);
        // テンプレート状態での特定セル位置情報
        const ROW_START = 2;
        const COL_DATE = 1;
        const COL_DAY = 2;
        const COL_START = 3;
        const COL_END = 4;
        const COL_SCHEDULE = 5;
        const COL_ARRANGED = 6;
        const COL_PLACE = 7;
        const COL_MEMO = 8;
        const COL_USER_MAP = {};
        // 旅程に紐つく全ての同行者の予定参加状況の記述
        let userIndex = 1;
        for (const userObj of users) {
            const user = userObj.user;
            // ヘッダー(1行目)に名前を入れる
            const name = lang === 'ja'
                ? user.lastNameKanji + RETURN + user.firstNameKanji
                : user.firstNameRoma + RETURN + user.lastNameRoma;
            writeHeaderCell(worksheet, 1, COL_MEMO + userIndex, name);
            // PID毎に、何列目に記述することになるかの情報を保持する
            COL_USER_MAP[user.pid] = COL_MEMO + userIndex;
            userIndex++;
        }
        // 高さの再計算を強制するために一度高さを設定してから解除
        worksheet.getRow(1).height = 40;
        worksheet.getRow(1).height = 0;
        // 現在処理中の現地日時情報
        let presentDate = '';
        let count = 0;
        let sameDateScheduleCount = 0;
        for (const schedule of schedules) {
            // この予定の参加者となっているPID一覧
            const participatePids = getParticipatePids(schedule.companions);
            convertAllNullToMark(schedule);
            const date = schedule.date;
            // この予定が現地の現地日の最初の予定となっている
            if (presentDate !== date) {
                presentDate = date;
                sameDateScheduleCount = 1;
            }
            else {
                sameDateScheduleCount++;
            }
            if (sameDateScheduleCount === 1) {
                // その日の最初の予定の場合
                let isSetDate = false;
                if (!isSetDate) {
                    // 日付情報をExcelにセット
                    writeCell(worksheet, ROW_START + count, COL_DATE, date, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_DAY, schedule.day, sameDateScheduleCount);
                    isSetDate = true;
                }
                else {
                    writeCell(worksheet, ROW_START + count, COL_DATE, '', sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_DAY, '', sameDateScheduleCount);
                }
                writeCell(worksheet, ROW_START + count, COL_START, getTime(schedule.start, schedule.startTimezone), sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_END, getTime(schedule.end, schedule.endTimezone), sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_SCHEDULE, schedule.schedule, sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_ARRANGED, schedule.flgArrgtStatus, sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_PLACE, schedule.place, sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_MEMO, schedule.memo, sameDateScheduleCount);
                // 同行者の参加有無情報
                for (const userObj of users) {
                    const pid = userObj.user.pid;
                    const mark = participatePids.includes(pid) ? PARTICIPATE : NO_PARTICIPATE;
                    writeCell(worksheet, ROW_START + count, COL_USER_MAP[pid], mark, sameDateScheduleCount, true);
                }
            }
            else {
                // その日の二番目移行の予定
                writeCell(worksheet, ROW_START + count, COL_DATE, '', sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_DAY, '', sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_START, getTime(schedule.start, schedule.startTimezone), sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_END, getTime(schedule.end, schedule.endTimezone), sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_SCHEDULE, schedule.schedule, sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_ARRANGED, schedule.flgArrgtStatus, sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_PLACE, schedule.place, sameDateScheduleCount);
                writeCell(worksheet, ROW_START + count, COL_MEMO, schedule.memo, sameDateScheduleCount);
                // 同行者の参加有無情報
                for (const userObj of users) {
                    const pid = userObj.user.pid;
                    const mark = participatePids.includes(pid) ? PARTICIPATE : NO_PARTICIPATE;
                    writeCell(worksheet, ROW_START + count, COL_USER_MAP[pid], mark, sameDateScheduleCount, true);
                }
            }
            count++;
        }
        // 最終行の罫線の調整実施
        for (let i = COL_DATE; i <= COL_MEMO + userCount; i++) {
            writeBottomTopThin(worksheet, ROW_START + count, i);
        }
    }
    // テンプレート用シートの削除
    workbook.removeWorksheet('template');
    // await writeFile(workbook, 'sche.xlsx');
    return (await writeBuffer(workbook));
}
function setHotelInfoOld(schedules, schedHotels, lang) {
    if (!schedules) {
        return;
    }
    for (const schedHotelIndividual of schedHotels) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data = schedHotelIndividual;
        const schedHotel = data.schedHotel;
        if (!schedHotel) {
            continue;
        }
        const checkInDateTime = schedHotel.checkInDateTime;
        const checkOutDateTime = schedHotel.checkOutDateTime;
        const timezone = schedHotel.timezone;
        if (!checkInDateTime || !checkOutDateTime || !timezone) {
            continue;
        }
        const remark = schedHotel.remark || '';
        const name = schedHotel.name;
        const address = schedHotel.address;
        const gmtStart = new Date(checkInDateTime);
        const gmtEnd = new Date(checkOutDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // チェックイン時刻が分かっている場合
        if (hasCheckIn(schedHotel)) {
            // ホテルチェックイン予定
            schedules.push({
                type: 'hotelStart',
                gmtStart,
                gmtEnd: gmtStart,
                date: formatUtcDateTime(localStart, 'yyyy/M/d'),
                day: formatUtcDateTime(localStart, 'EEE'),
                start: formatUtcDateTime(localStart, 'HH:mm'),
                startTimezone: '',
                end: '',
                endTimezone: '',
                schedule: name,
                place: address,
                memo: replaceLF(remark),
                flgArrgtStatus: getFlgArrgtStatusValue(lang, schedHotel.flgArrgt || false),
                companions: [],
            });
        }
        else {
            // チェックイン時刻がないので、その日の23:59:59の予定としておく(その日の一番最後の予定となる想定)
            const newGmtStart = formatUtcDateTime(localStart, 'yyyy-MM-dd') + 'T23:59:59' + timezone;
            schedules.push({
                type: 'hotelStart',
                gmtStart: new Date(newGmtStart),
                gmtEnd: new Date(newGmtStart),
                date: formatUtcDateTime(localStart, 'yyyy/M/d'),
                day: formatUtcDateTime(localStart, 'EEE'),
                start: '',
                startTimezone: '',
                end: '',
                endTimezone: '',
                schedule: name,
                place: address,
                memo: replaceLF(remark),
                flgArrgtStatus: getFlgArrgtStatusValue(lang, schedHotel.flgArrgt || false),
                companions: [],
            });
        }
        if (hasCheckOut(schedHotel)) {
            // ホテルチェックアウト予定
            schedules.push({
                type: 'hotelEnd',
                gmtStart: gmtEnd,
                gmtEnd,
                date: formatUtcDateTime(localEnd, 'yyyy/M/d'),
                day: formatUtcDateTime(localEnd, 'EEE'),
                start: '',
                startTimezone: '',
                end: formatUtcDateTime(localEnd, 'HH:mm'),
                endTimezone: '',
                schedule: name,
                place: address,
                memo: getLangValue('excelDownload.hotel.checkOut', lang),
                flgArrgtStatus: getFlgArrgtStatusValue(lang, schedHotel.flgArrgt || false),
                companions: [],
            });
        }
    }
}
function setFlightInfoOld(schedules, schedFlights, lang) {
    if (!schedules) {
        return;
    }
    for (const schedFlightIndividual of schedFlights) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data = schedFlightIndividual;
        const schedFlight = data.schedFlight;
        if (!schedFlight) {
            continue;
        }
        const departureDateTime = schedFlight.departureDateTime;
        const arrivalDateTime = schedFlight.arrivalDateTime;
        const departureTimezone = schedFlight.departureTimezone;
        const arrivalTimezone = schedFlight.arrivalTimezone;
        if (!departureDateTime || !arrivalDateTime || !departureTimezone || !arrivalTimezone) {
            continue;
        }
        const remark = joinStr([schedFlight.flightNumber, schedFlight.remark], RETURN);
        let place = joinStr([
            joinStr([schedFlight.departureCity, schedFlight.departureAirport], '/'),
            joinStr([schedFlight.arrivalCity, schedFlight.arrivalAirport], '/'),
        ], '→', true);
        if (place === '→') {
            place = '';
        }
        const gmtStart = new Date(departureDateTime);
        const gmtEnd = new Date(arrivalDateTime);
        const localStart = getLocalDate(gmtStart, departureTimezone);
        const localEnd = getLocalDate(gmtEnd, arrivalTimezone);
        // フライト予定
        schedules.push({
            type: 'flight',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: '',
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: '',
            schedule: getLangValue('excelDownload.title.flight', lang),
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: getFlgArrgtStatusValue(lang, schedFlight.flgArrgt || false),
            companions: [],
        });
    }
}
function setTransportationInfoOld(schedules, schedTransportations, lang) {
    if (!schedules) {
        return;
    }
    for (const schedTransportationIndividual of schedTransportations) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data = schedTransportationIndividual;
        const schedTransportation = data.schedTransportation;
        if (!schedTransportation) {
            continue;
        }
        const departureDateTime = schedTransportation.departureDateTime;
        const arrivalDateTime = schedTransportation.arrivalDateTime;
        const timezone = schedTransportation.timezone;
        if (!departureDateTime || !arrivalDateTime || !timezone) {
            continue;
        }
        const schedule = format(getLangValue('excelDownload.title.transportation', lang), {
            transportationMode: getTransportationModeLabel(schedTransportation.transportationMode, lang),
        });
        const remark = schedTransportation.remark || '';
        let place = joinStr([schedTransportation.departureLocation, schedTransportation.arrivalLocation], '→', true);
        if (place === '→') {
            place = '';
        }
        const gmtStart = new Date(departureDateTime);
        const gmtEnd = new Date(arrivalDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // 各種移動予定
        schedules.push({
            type: 'transportation',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: '',
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: '',
            schedule,
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: '',
            companions: [],
        });
    }
}
function setEventInfoOld(schedules, schedEvents) {
    if (!schedules) {
        return;
    }
    for (const schedEventIndividual of schedEvents) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data = schedEventIndividual;
        const schedEvent = data.schedEvent;
        if (!schedEvent) {
            continue;
        }
        const startDateTime = schedEvent.startDateTime;
        const endDateTime = schedEvent.endDateTime;
        const timezone = schedEvent.timezone;
        if (!startDateTime || !endDateTime || !timezone) {
            continue;
        }
        const schedule = schedEvent.name;
        const remark = schedEvent.remark || '';
        const place = schedEvent.location;
        const gmtStart = new Date(startDateTime);
        const gmtEnd = new Date(endDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // 各種イベント予定
        schedules.push({
            type: 'transportation',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: '',
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: '',
            schedule,
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: '',
            companions: [],
        });
    }
}
function setCompanyCarInfoOld(schedules, schedCompanyCars, lang) {
    if (!schedules) {
        return;
    }
    for (const schedCompanyCarIndividual of schedCompanyCars) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data = schedCompanyCarIndividual;
        const schedCompanyCar = data.schedCompanyCar;
        if (!schedCompanyCar) {
            continue;
        }
        const startDateTime = schedCompanyCar.startDateTime;
        const endDateTime = schedCompanyCar.endDateTime;
        const timezone = schedCompanyCar.timezone;
        if (!timezone || !endDateTime || !startDateTime) {
            continue;
        }
        const remark = joinStr([schedCompanyCar.driverName, schedCompanyCar.driverTel, schedCompanyCar.carno, schedCompanyCar.remark], RETURN);
        let place = joinStr([schedCompanyCar.departureLocation, ''], '→', true);
        if (place === '→') {
            place = '';
        }
        const gmtStart = new Date(startDateTime);
        const gmtEnd = new Date(endDateTime);
        const localStart = getLocalDate(gmtStart, timezone);
        const localEnd = getLocalDate(gmtEnd, timezone);
        // 社有車予定
        schedules.push({
            type: 'companyCar',
            gmtStart,
            gmtEnd,
            date: formatUtcDateTime(localStart, 'yyyy/M/d'),
            day: formatUtcDateTime(localStart, 'EEE'),
            start: formatUtcDateTime(localStart, 'HH:mm'),
            startTimezone: '',
            end: formatUtcDateTime(localEnd, 'HH:mm') + showDifferentDateMark(localStart, localEnd, { before: '(', after: ')' }),
            endTimezone: '',
            schedule: getLangValue('excelDownload.title.companyCar', lang),
            place,
            memo: replaceLF(remark),
            flgArrgtStatus: getFlgArrgtStatusValue(lang, schedCompanyCar.flgArrgt || false),
            companions: [],
        });
    }
}
export async function makeItinerarySchedulesExcelOld(targetPids, itineraries, lang) {
    const workbook = await openExcelFromTemplateFile('itinerary_shedules.xlsx');
    let excelCount = 0;
    for (const itinerary of itineraries) {
        let schedules = [];
        // 予定情報から、Excel出力実施する情報のみの抽出処理実施
        setFlightInfoOld(schedules, itinerary.schedFlights, lang);
        setHotelInfoOld(schedules, itinerary.schedHotels, lang);
        setTransportationInfoOld(schedules, itinerary.schedTransportations, lang);
        setEventInfoOld(schedules, itinerary.schedEvents);
        setCompanyCarInfoOld(schedules, itinerary.schedCompanyCars, lang);
        // 予定を世界標準時で並び替え。1:start時間 ASC、2:end時間 ASC
        schedules = orderBy(schedules, ['gmtStart', 'gmtEnd'], ['asc', 'asc']);
        let worksheet = getWorksheetByName(workbook, 'template');
        if (worksheet) {
            const user = find(itinerary.itinerary.itinerary.itineraryIndividuals, { user: { pid: targetPids[excelCount] } });
            const sheetName = `${user?.user.lastNameRoma}${user?.user.firstNameRoma}`;
            // シートコピー作成
            worksheet = copyWorksheet(workbook, worksheet, sheetName);
            // テンプレート状態での特定セル位置情報
            const ROW_START = 2;
            const COL_DATE = 1;
            const COL_DAY = 2;
            const COL_START = 3;
            const COL_END = 4;
            const COL_SCHEDULE = 5;
            const COL_ARRANGED = 6;
            const COL_PLACE = 7;
            const COL_MEMO = 8;
            // 現在処理中の現地日時情報
            let presentDate = '';
            let count = 0;
            let sameDateScheduleCount = 0;
            for (const schedule of schedules) {
                convertAllNullToMark(schedule);
                const date = schedule.date;
                // この予定が現地の現地日の最初の予定となっている
                if (presentDate !== date) {
                    presentDate = date;
                    sameDateScheduleCount = 1;
                }
                else {
                    sameDateScheduleCount++;
                }
                if (sameDateScheduleCount === 1) {
                    // その日の最初の予定の場合
                    let isSetDate = false;
                    if (!isSetDate) {
                        // 日付情報をExcelにセット
                        writeCell(worksheet, ROW_START + count, COL_DATE, date, sameDateScheduleCount);
                        writeCell(worksheet, ROW_START + count, COL_DAY, schedule.day, sameDateScheduleCount);
                        isSetDate = true;
                    }
                    else {
                        writeCell(worksheet, ROW_START + count, COL_DATE, '', sameDateScheduleCount);
                        writeCell(worksheet, ROW_START + count, COL_DAY, '', sameDateScheduleCount);
                    }
                    writeCell(worksheet, ROW_START + count, COL_START, getTime(schedule.start, schedule.startTimezone), sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_END, getTime(schedule.end, schedule.endTimezone), sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_SCHEDULE, schedule.schedule, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_ARRANGED, schedule.flgArrgtStatus, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_PLACE, schedule.place, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_MEMO, schedule.memo, sameDateScheduleCount);
                }
                else {
                    // その日の二番目移行の予定
                    writeCell(worksheet, ROW_START + count, COL_DATE, '', sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_DAY, '', sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_START, getTime(schedule.start, schedule.startTimezone), sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_END, getTime(schedule.end, schedule.endTimezone), sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_SCHEDULE, schedule.schedule, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_ARRANGED, schedule.flgArrgtStatus, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_PLACE, schedule.place, sameDateScheduleCount);
                    writeCell(worksheet, ROW_START + count, COL_MEMO, schedule.memo, sameDateScheduleCount);
                }
                count++;
            }
            // 最終行の罫線の調整実施
            for (let i = COL_DATE; i <= COL_MEMO; i++) {
                writeBottomTopThin(worksheet, ROW_START + count, i);
            }
        }
        excelCount++;
    }
    // テンプレート用シートの削除
    workbook.removeWorksheet('template');
    // await writeFile(workbook, 'sche.xlsx');
    return (await writeBuffer(workbook));
}
function writeCell(worksheet, row, col, target, sameDateScheduleCount, isCentered = false) {
    const cell = worksheet.getCell(row, col);
    if (target) {
        cell.value = target;
        cell.alignment = { wrapText: true, vertical: isCentered ? 'middle' : 'top' };
        if (isCentered) {
            cell.alignment.horizontal = 'center';
        }
    }
    const borderStyles = {
        right: { style: 'thin' },
    };
    if (sameDateScheduleCount === 1) {
        borderStyles.top = { style: 'thin' };
    }
    if (col === 1) {
        borderStyles.left = { style: 'thin' };
    }
    if (col >= 3) {
        borderStyles.bottom = { style: 'dotted' };
    }
    cell.border = borderStyles;
}
function writeHeaderCell(worksheet, row, col, target) {
    const cell = worksheet.getCell(row, col);
    if (target) {
        cell.value = target;
    }
    cell.alignment = { wrapText: true, vertical: 'top', horizontal: 'center' };
    const borderStyles = {
        right: { style: 'thin' },
    };
    if (col === 1) {
        borderStyles.left = { style: 'thin' };
    }
    if (col >= 3) {
        borderStyles.top = { style: 'thin' };
    }
    cell.border = borderStyles;
}
function writeBottomTopThin(worksheet, row, col) {
    worksheet.getCell(row, col).border = {
        top: { style: 'thin' },
    };
}
export async function makeTestExcel() {
    const workbook = await openExcelFromTemplateFile('test_template.xlsx');
    const copySheetNames = ['テストユーザー①', 'テストユーザー②', 'テストユーザー③', 'テストユーザー④', 'テスト⑤'];
    for (const copySheetName of copySheetNames) {
        let worksheet = getWorksheet(workbook, 0);
        if (worksheet) {
            // シートコピー作成
            worksheet = copyWorksheet(workbook, worksheet, copySheetName);
            // テンプレート状態での特定セル位置情報
            const ROW_TIMEZONE = 11;
            const ROW_ITINERARY = 9;
            const ROW_SCHEDULE = 15;
            // exceljsは、行挿入でマクロの行位置の自動調整が動かないので、最初に行挿入を実施してから処理が必要。
            const placeCount = 3;
            const planCount = 15;
            // 出張先の数だけ、出張先情報を記述
            worksheet.duplicateRow(ROW_ITINERARY, placeCount - 1, true);
            // 旅程追加後の補正位置情報
            const rowTimezone = ROW_TIMEZONE + placeCount - 1;
            const rowScheduleStart = ROW_SCHEDULE + placeCount - 1;
            // 行数分だけ、動的に行を挿入
            worksheet.duplicateRow(rowScheduleStart, planCount - 1, true);
            worksheet.getCell(2, 1).value = copySheetName;
            for (let i = ROW_ITINERARY; i < ROW_ITINERARY + placeCount; i++) {
                worksheet.getCell(i, 2).value = `2023/12/${i - 1}-2023/12/${i}`;
                worksheet.getCell(i, 3).value = '国名' + i;
                worksheet.unMergeCells(i, 3, i, 6);
                worksheet.mergeCells(i, 3, i, 6);
            }
            worksheet.getCell(`F${rowTimezone}`).value = '+09:00';
            // タイムゾーンのdata validation指定
            worksheet.getCell(`F${rowTimezone}`).dataValidation = {
                type: 'list',
                allowBlank: true,
                formulae: [`"${TIMEZONES.join(',')}"`],
            };
            for (let i = rowScheduleStart; i < rowScheduleStart + planCount; i++) {
                worksheet.getCell(i, 4).value = '予定の名称が入る' + i;
                worksheet.mergeCells(i, 4, i, 8);
                worksheet.getCell(i, 10).value = formatDateTime(addHours(new Date('2023-12-09 00:00:00Z'), i * 2));
                worksheet.getCell(i, 11).value = formatDateTime(addHours(new Date(`2023-12-09 01:${i}:00Z`), i * 2));
                worksheet.getCell(i, 12).value = {
                    formula: `IF(MIDB(F${rowTimezone},1,1)="-",DATEVALUE(MIDB(J${i},1,10))+TIMEVALUE(MIDB(J${i},12,8))-TIME(VALUE(MIDB(F${rowTimezone},2,2)),VALUE(MIDB(F${rowTimezone},5,2)),0),DATEVALUE(MIDB(J${i},1,10))+TIMEVALUE(MIDB(J${i},12,8))+TIME(VALUE(MIDB(F${rowTimezone},2,2)),VALUE(MIDB(F${rowTimezone},5,2)),0))`,
                };
                worksheet.getCell(i, 13).value = {
                    formula: `IF(MIDB(F${rowTimezone},1,1)="-",DATEVALUE(MIDB(K${i},1,10))+TIMEVALUE(MIDB(K${i},12,8))-TIME(VALUE(MIDB(F${rowTimezone},2,2)),VALUE(MIDB(F${rowTimezone},5,2)),0),DATEVALUE(MIDB(K${i},1,10))+TIMEVALUE(MIDB(K${i},12,8))+TIME(VALUE(MIDB(F${rowTimezone},2,2)),VALUE(MIDB(F${rowTimezone},5,2)),0))`,
                };
                worksheet.getCell(i, 1).value = { formula: `L${i}` };
                worksheet.getCell(i, 1).formulaType;
                worksheet.getCell(i, 2).value = { formula: `L${i}` };
                worksheet.getCell(i, 3).value = { formula: `M${i}` };
            }
        }
    }
    // テンプレート用シートの削除
    workbook.removeWorksheet('template');
    return (await writeBuffer(workbook));
}
export async function getExcelDownloadItineraryInfo(prisma, pid, itineraryId) {
    const itList = await getItineraryIndividualList(prisma, pid, [itineraryId], false);
    if (!itList || itList.length !== 1) {
        return { error: { code: Define.ERROR_CODES.W00109, status: 400 } };
    }
    return {
        itinerary: itList[0],
        schedFlights: await getFlightsForExcelDownload(prisma, itineraryId),
        schedHotels: await getHotelsForExcelDownload(prisma, itineraryId),
        schedCompanyCars: await getCompanyCarsForExcelDownload(prisma, itineraryId),
        schedTransportations: await getTransportationsForExcelDownload(prisma, itineraryId),
        schedEvents: await getEventsForExcelDownload(prisma, itineraryId),
    };
}
export function addplanedSchedCompanyCars(target, planedScheds) {
    for (const planedSched of planedScheds) {
        const schedCompanyCarIndividuals = planedSched.companions?.map((companion) => {
            return { user: { pid: companion.pid } };
        }) || [];
        target.push({
            startDateTime: new Date(planedSched.startDateTime),
            endDateTime: new Date(planedSched.endDateTime),
            timezone: planedSched.timezone,
            departureLocation: planedSched.departureLocation || '',
            schedCompanyCarIndividuals,
        });
    }
}
export function addplanedSchedHotels(target, planedScheds, dbHotelMastersMap) {
    for (const planedSched of planedScheds) {
        const schedHotelIndividuals = planedSched.companions?.map((companion) => {
            return { user: { pid: companion.pid } };
        }) || [];
        const masterHotel = planedSched.hotelId ? dbHotelMastersMap[planedSched.hotelId] : {};
        target.push({
            checkInDateTime: new Date(planedSched.checkInDateTime),
            checkOutDateTime: new Date(planedSched.checkOutDateTime),
            timezone: planedSched.timezone,
            checkinOutInputStatus: planedSched.checkinOutInputStatus,
            name: masterHotel.name || null,
            address: masterHotel.address || null,
            remark: null,
            schedHotelIndividuals,
        });
    }
}
// export function addplanedSchedCompanyCarsOld<
//   T extends {
//     schedCompanyCar: Pick<SchedCompanyCar, 'startDateTime' | 'endDateTime' | 'timezone' | 'departureLocation'>;
//   }
// >(
//   target: T[],
//   planedScheds: Pick<SchedCompanyCarProps, 'startDateTime' | 'endDateTime' | 'timezone' | 'departureLocation'>[]
// ): void {
//   for (const planedSched of planedScheds) {
//     target.push({
//       schedCompanyCar: {
//         startDateTime: new Date(planedSched.startDateTime),
//         endDateTime: new Date(planedSched.endDateTime),
//         timezone: planedSched.timezone,
//         departureLocation: planedSched.departureLocation || '',
//       },
//     } as T);
//   }
// }
// export function addplanedSchedHotelsOld<
//   T extends {
//     schedHotel: Pick<
//       SchedHotel,
//       'checkInDateTime' | 'checkOutDateTime' | 'timezone' | 'checkinOutInputStatus' | 'name' | 'address' | 'remark'
//     >;
//   }
// >(
//   target: T[],
//   planedScheds: Pick<
//     HotelArrgtCreateSchedHotelProps,
//     'checkInDateTime' | 'checkOutDateTime' | 'timezone' | 'checkinOutInputStatus' | 'hotelId'
//   >[],
//   dbHotelMastersMap: { [hotelId: number]: HotelMaster }
// ): void {
//   for (const planedSched of planedScheds) {
//     const masterHotel = planedSched.hotelId ? dbHotelMastersMap[planedSched.hotelId] : ({} as HotelMaster);
//     target.push({
//       schedHotel: {
//         checkInDateTime: new Date(planedSched.checkInDateTime),
//         checkOutDateTime: new Date(planedSched.checkOutDateTime),
//         timezone: planedSched.timezone,
//         checkinOutInputStatus: planedSched.checkinOutInputStatus,
//         name: masterHotel.name || null,
//         address: masterHotel.address || null,
//         remark: null,
//       },
//     } as T);
//   }
// }
function getFlgArrgtStatusValue(lang, flgArrgt) {
    if (flgArrgt == null) {
        return '';
    }
    else if (flgArrgt) {
        return getLangValue('flgArrgt.arranged', lang);
    }
    else {
        return getLangValue('flgArrgt.notArranged', lang);
    }
}
function getTime(time, timezone) {
    if (time && time !== '-') {
        return joinStr([time, `(${timezone})`], RETURN);
    }
    else {
        return time;
    }
}
function getParticipatePids(companions) {
    const result = [];
    for (const companion of companions) {
        if (companion.flgDelete || companion.flgReject) {
            continue;
        }
        result.push(companion.user.pid);
    }
    return result;
}
const TIMEZONES = [
    '+13:00',
    '+12:00',
    '+11:00',
    '+10:00',
    '+09:30',
    '+09:00',
    '+08:00',
    '+07:00',
    '+06:30',
    '+06:00',
    '+05:45',
    '+05:30',
    '+05:00',
    '+04:30',
    '+04:00',
    '+03:30',
    '+03:00',
    '+02:00',
    '+01:00',
    '+00:00',
    '-01:00',
    '-02:00',
    '-03:00',
    '-03:30',
    '-04:00',
    '-04:30',
    '-05:00',
    '-06:00',
    '-07:00',
    '-08:00',
    '-09:00',
    '-10:00',
    '-11:00',
];
//# sourceMappingURL=makeItinerarySchedules.js.map