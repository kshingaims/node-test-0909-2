import { Define } from '../../utils/define.js';
const noExternalIntegration = Define.DEBUG.noExternalIntegration;
export async function getUserPhone(users) {
    if (noExternalIntegration) {
        // ダミーで電話番号を設定する
        let count = 0;
        for (const user of users) {
            if (count % 2 === 0) {
                user.mobilephone = '080-1234-5678';
            }
            count++;
        }
    }
    else {
        // TODO snowflakeで電話番号を取得する
    }
}
//# sourceMappingURL=snowflakeService.js.map