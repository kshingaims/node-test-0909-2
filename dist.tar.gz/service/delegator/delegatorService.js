import { Define } from '../../utils/define.js';
import { format, replaceCRLF } from '../../utils/index.js';
import { getNotificationSettingById } from '../../service/notification/notificationSettingService.js';
import { getUserByPid } from '../../service/user/userService.js';
import { sendSmtpMail } from '../../utils/smtpMail.js';
/**
 * 委任者一覧を返す
 * @param prisma
 * @param pid
 * @returns
 */
export async function getUsersDelegatorList(prisma, pid) {
    return await prisma.usersDelegator.findMany({
        where: { assignerPid: pid, delegator: { flgDelete: false } },
        select: {
            expiredAt: true,
            delegator: {
                select: {
                    pid: true,
                    firstNameRoma: true,
                    lastNameRoma: true,
                    firstNameKanji: true,
                    lastNameKanji: true,
                    firstNameKana: true,
                    lastNameKana: true,
                    email: true,
                },
            },
        },
    });
}
/**
 * 委任者を新たに追加・更新する。
 * 指定した委任者が未作成状態の場合は、新規作成を実施し、指定した委任者が作成済の場合は更新を実施する。
 * @param prisma
 * @param user 作業実施者(この作業は委任者による代理作業不可)
 * @param delegatorPid 新規追加・更新する委任者ID
 * @param expiredAt 有効期限
 * @returns 新規作成 or 更新したユーザ_委任者情報
 */
export async function upsert(prisma, user, delegatorPid, expiredAt) {
    const result = await prisma.usersDelegator.upsert({
        create: {
            assignerPid: user.pid,
            delegatorPid: delegatorPid,
            expiredAt: expiredAt,
            updatedBy: user.pid,
        },
        update: {
            assignerPid: user.pid,
            delegatorPid: delegatorPid,
            expiredAt: expiredAt,
            updatedBy: user.pid,
        },
        where: {
            assignerPid_delegatorPid: {
                assignerPid: user.pid,
                delegatorPid: delegatorPid,
            },
        },
    });
    return result;
}
/**
 * ログインユーザが設定している委任者を解除(物理削除)する。
 * @param prisma
 * @param user 作業実施者(この作業は委任者による代理作業不可)
 * @param props DelegatorDeleteProps (delegatorPid 新規追加・更新する委任者ID)
 * @returns 削除したユーザ_委任者情報
 */
export async function deleteUsersDelegator(prisma, user, props) {
    const result = await prisma.usersDelegator.delete({
        where: {
            assignerPid_delegatorPid: {
                assignerPid: user.pid,
                delegatorPid: props.delegatorPid,
            },
        },
    });
    return result;
}
/**
 * delegatorPidとassignerPid(ログイン実施者のpid)で定義されているPKが、DBテーブル上に存在するかチェック。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param pids
 * @returns
 */
export async function isExistsUsersDelegators(prisma, delegatorPid, assignerPid) {
    const usersDelegator = await prisma.usersDelegator.findUnique({
        select: { assignerPid: true, delegatorPid: true },
        where: {
            assignerPid_delegatorPid: {
                assignerPid,
                delegatorPid,
            },
        },
    });
    if (!usersDelegator) {
        return { code: Define.ERROR_CODES.W00106, status: 200 };
    }
    else {
        return undefined;
    }
}
export async function sendSmtpMailToDelegator(log, prisma, targetPid, loginUser) {
    // 旅程の同行者へのメール通知実施用のテンプレート取得
    const smtpSetting = await getNotificationSettingById(prisma, 'delegator_assign_mail');
    if (!smtpSetting.title || !smtpSetting.content || !smtpSetting.linkUrl) {
        throw new Error('title, content linkUrl is necessary.');
    }
    const user = await getUserByPid(prisma, targetPid);
    if (!user || !user.email) {
        throw new Error(`user or user.email must be exist. [pid: ${targetPid}]`);
    }
    // リンクURL整形
    const linkUrl = format(smtpSetting.linkUrl, { domain: Define.DOMAIN });
    // メール本文整形
    const body = replaceCRLF(format(smtpSetting.content, { loginUser, linkUrl }));
    // メール送信
    sendSmtpMail(log, { to: [user.email], title: smtpSetting.title, body });
}
//# sourceMappingURL=delegatorService.js.map