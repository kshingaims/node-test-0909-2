import { isString, omit, merge, uniq } from 'lodash-es';
import { Define } from '../../utils/define.js';
export const MC_SYOZOKU_CD_2_KETA_JAPAN = ['01', '02', '03', '04'];
export const MC_SYOZOKU_CD_2_KETA_FOREIGN = ['05', '06'];
export const USER_BUNRUI_MC = '1111111';
export const CORP_CD_MC = '0100000';
export const USER_BUNRUI_NOT_MC_JAPAN_STAFFS = ['6110000', '6010000', 'UG10000'];
export const USER_BUNRUI_NOT_MC_FOREIGN_STAFFS = ['UW10000', 'UW20000'];
/**
 * 指定したPIDに合致するユーザ情報を取得する
 * @param prisma
 * @param pid パーソナルID
 */
export async function getUserByPid(prisma, pid) {
    const where = {
        flgDelete: false,
        pid,
    };
    const dbUser = await prisma.user.findFirst({
        select: {
            pid: true,
            flgAdmin: true,
            firstNameRoma: true,
            lastNameRoma: true,
            firstNameKanji: true,
            lastNameKanji: true,
            mcSyozokuGrpCd: true,
            mcSyozokuCd: true,
            corpCd: true,
            userBunrui: true,
            email: true,
            webpushDeviceInfo: true,
            flgCalendarSync: true,
        },
        where,
    });
    if (dbUser && dbUser.email) {
        return dbUser;
    }
    else {
        return {};
    }
}
/**
 * 指定したユーザのRole権限情報を含んだ形で、ユーザ情報詳細を取得する
 * @param prisma
 * @param pid パーソナルID
 */
export async function getUserWithRole(prisma, pid, email) {
    const where = {};
    where.flgDelete = false;
    if (pid) {
        where.pid = pid;
    }
    else if (email) {
        where.email = email;
    }
    else {
        return {};
    }
    // 委任者情報も取得すること
    const dbUsers = await prisma.user.findMany({
        select: {
            pid: true,
            flgAdmin: true,
            firstNameRoma: true,
            lastNameRoma: true,
            firstNameKanji: true,
            lastNameKanji: true,
            mcSyozokuNameKanji: true,
            mcSyozokuNameRoma: true,
            mcSyozokuGrpCd: true,
            mcSyozokuCd: true,
            corpCd: true,
            userBunrui: true,
            email: true,
            assigners: {
                select: {
                    expiredAt: true,
                    assigner: {
                        select: {
                            pid: true,
                            firstNameRoma: true,
                            lastNameRoma: true,
                            firstNameKanji: true,
                            lastNameKanji: true,
                            mcSyozokuGrpCd: true,
                            mcSyozokuCd: true,
                            corpCd: true,
                            userBunrui: true,
                            email: true,
                            webpushDeviceInfo: true,
                            flgCalendarSync: true,
                            flgDelete: true,
                        },
                    },
                },
            },
            webpushDeviceInfo: true,
            flgCalendarSync: true,
        },
        where,
    });
    if (dbUsers.length !== 1) {
        return {};
    }
    const dbUser = dbUsers[0];
    if (dbUser) {
        const user = {
            pid: dbUser.pid,
            firstNameRoma: dbUser.firstNameRoma,
            lastNameRoma: dbUser.lastNameRoma,
            firstNameKanji: dbUser.firstNameKanji,
            lastNameKanji: dbUser.lastNameKanji,
            mcSyozokuNameKanji: dbUser.mcSyozokuNameKanji || '',
            mcSyozokuNameRoma: dbUser.mcSyozokuNameRoma || '',
            mcSyozokuCd: dbUser.mcSyozokuCd,
            email: dbUser.email || undefined,
            webpushDeviceInfo: dbUser.webpushDeviceInfo,
            flgCalendarSync: dbUser.flgCalendarSync,
            roles: convertRoles(dbUser),
            assigners: [],
        };
        if (dbUser.assigners && dbUser.assigners.length > 0) {
            for (const assignerItem of dbUser.assigners) {
                const assigner = assignerItem.assigner;
                // prismaの標準機能では削除フラグ有無でデータ取得制御が大変なので、ロジック側で削除フラグを除外する
                if (!assigner.flgDelete) {
                    user.assigners?.push({
                        expiredAt: assignerItem.expiredAt,
                        user: {
                            pid: assigner.pid,
                            firstNameRoma: assigner.firstNameRoma,
                            lastNameRoma: assigner.lastNameRoma,
                            firstNameKanji: assigner.firstNameKanji,
                            lastNameKanji: assigner.lastNameKanji,
                            email: assigner.email || undefined,
                            flgCalendarSync: assigner.flgCalendarSync,
                            // roles: convertRoles(assigner), // 委託者のrole情報は送信しない
                        },
                    });
                }
            }
        }
        return user;
    }
    return {};
}
/**
 * 指定したユーザ(複数可)がユーザテーブルに存在しているかどうかをチェック
 * @param prisma
 * @param pids 存在するかをチェックしたいpidもしくは、pidの配列
 */
export async function isExists(prisma, pids) {
    if (isString(pids)) {
        pids = [pids];
    }
    pids = uniq(pids);
    const users = await prisma.user.findMany({
        select: { pid: true },
        where: {
            pid: { in: pids },
            flgDelete: false,
        },
    });
    if (pids.length === users.length) {
        return true;
    }
    else {
        return false;
    }
}
/**
 * 同行者指定されている同行者のpidが存在するものかどうかチェックする。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param pids
 * @returns
 */
export async function isExistsCompanions(prisma, pids) {
    const uniquePids = uniq(pids);
    // 同じPIDの人が複数回指定されている
    if (uniquePids.length !== pids.length) {
        return { code: Define.ERROR_CODES.W00118, status: 400 };
    }
    if (!(await isExists(prisma, pids))) {
        return { code: Define.ERROR_CODES.W00104, status: 400 };
    }
    else {
        return undefined;
    }
}
/**
 * 委任者指定されたユーザのpidが存在するものかどうかチェックする。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param pids
 * @returns
 */
export async function isExistsDelegators(prisma, pids) {
    if (!(await isExists(prisma, pids))) {
        return { code: Define.ERROR_CODES.W00301, status: 401 };
    }
    else {
        return undefined;
    }
}
/**
 * ユーザテーブルから、キーワード指定されたユーザを検索する。
 * @param prisma
 * @param keywords
 * @returns
 */
export async function searchUsers(prisma, keywords) {
    const where = {};
    where.AND = [{ flgDelete: false }];
    for (const keyword of keywords) {
        if (keyword) {
            where.AND.push({
                OR: [
                    { lastNameRoma: { contains: keyword } },
                    { lastNameKanji: { contains: keyword } },
                    { lastNameKana: { contains: keyword } },
                    { firstNameRoma: { contains: keyword } },
                    { firstNameKanji: { contains: keyword } },
                    { firstNameKana: { contains: keyword } },
                    { pid: { contains: keyword } },
                    { email: { contains: keyword } },
                ],
            });
        }
    }
    return await _getUsers(prisma, where, true);
}
/**
 * 指定されたPIDに該当するユーザを全て返却する
 * @param prisma
 * @param pids
 * @returns
 */
export async function getUsersByPids(prisma, pids) {
    const where = {};
    where.flgDelete = false;
    const filteredPids = uniq(pids);
    if (filteredPids.length <= 0) {
        return [];
    }
    // 引数指定したEmail配列をIN句指定して、該当するEmailに合致する全てのユーザを取得する
    where.pid = { in: filteredPids };
    const users = await _getUsers(prisma, where);
    return users;
}
export async function getUsersByEmails(prisma, emails) {
    const where = {};
    where.flgDelete = false;
    const filteredEmails = uniq(emails);
    if (filteredEmails.length <= 0) {
        return [];
    }
    // 引数指定したEmail配列をIN句指定して、該当するEmailに合致する全てのユーザを取得する
    where.email = { in: filteredEmails };
    return await _getUsers(prisma, where);
}
export async function getCompanions(prisma, itineraryId) {
    const where = {};
    where.flgDelete = false;
    // この旅程の参加者のみを取得
    where.itineraryIndividuals = { some: { itineraryId, flgDelete: false } };
    const users = await _getUsers(prisma, where);
    return users;
}
async function _getUsers(prisma, where, isSearch = false) {
    const dbUsers = await prisma.user.findMany({
        select: {
            pid: true,
            lastNameRoma: true,
            lastNameKanji: true,
            lastNameKana: true,
            firstNameRoma: true,
            firstNameKanji: true,
            firstNameKana: true,
            email: true,
            mcSyozokuGrpNameKanji: true,
            mcSyozokuCd: true,
            userBunrui: true,
            corpCd: true,
        },
        take: isSearch ? Define.SETTINGS.MAX_PAGE : undefined,
        where,
    });
    const users = [];
    for (const dbUser of dbUsers) {
        const user = {
            pid: dbUser.pid,
            lastNameRoma: dbUser.lastNameRoma,
            lastNameKanji: dbUser.lastNameKanji,
            firstNameRoma: dbUser.firstNameRoma,
            firstNameKanji: dbUser.firstNameKanji,
            email: dbUser.email || undefined,
            mcSyozokuNameKanji: dbUser.mcSyozokuGrpNameKanji || '',
            roles: convertRoles(dbUser),
        };
        users.push(user);
    }
    return users;
}
/**
 * 指定されたPIDに該当するユーザのwebpushデバイス情報を取得する
 * @param prisma
 * @param pids
 * @returns
 */
export async function getWebpushDeviceInfos(prisma, pids) {
    const where = {};
    where.flgDelete = false;
    // 引数指定したEmail配列をIN句指定して、該当するEmailに合致する全てのユーザを取得する
    where.pid = { in: pids };
    const users = await prisma.user.findMany({ select: { pid: true, webpushDeviceInfo: true }, where });
    return users;
}
/**
 * ユーザの新規作成
 * @param prisma
 * @param user
 * @param isAdmin Admin権限アカウントかどうか
 * @returns 新規作成したユーザ情報
 */
export async function create(prisma, user, isAdmin = false) {
    const result = await prisma.user.create({ data: merge(user, { flgAdmin: isAdmin }) });
    return result;
}
/**
 * ユーザの更新処理。更新処理は、pidをkeyにして実行
 * @param prisma
 * @param user
 */
export async function update(prisma, user) {
    const result = await prisma.user.update({ where: { pid: user.pid }, data: omit(user, ['pid']) });
    return result;
}
/**
 * 指定したpidのユーザに論理削除を設定する
 * @param prisma
 * @param pid
 * @returns
 */
export async function deleteUserByPid(prisma, pid) {
    await prisma.user.update({ where: { pid }, data: { flgDelete: true } });
}
/**
 * ユーザの新規作成
 * @param prisma
 * @param user
 * @param isAdmin Admin権限アカウントかどうか
 * @returns 新規作成したユーザ情報
 */
export async function upsert(prisma, user) {
    const result = await prisma.user.upsert({
        create: merge(user, { flgAdmin: false, flgDelete: false }),
        update: merge(omit(user, ['pid']), { flgAdmin: false, flgDelete: false }),
        where: { pid: user.pid },
    });
    return result;
}
/**
 * ユーザ情報から、ロール権限情報に変換してロール権限情報を返却する
 * @param user ユーザ情報
 * @returns ロール権限情報
 */
export function convertRoles(user) {
    const result = [];
    if (user.flgAdmin) {
        result.push('admin');
    }
    const mcSyozokuCd2keta = user.mcSyozokuCd?.substring(0, 2) || '';
    const userBunrui = user.userBunrui || '';
    const corpCd = user.corpCd || '';
    if (MC_SYOZOKU_CD_2_KETA_JAPAN.includes(mcSyozokuCd2keta)) {
        if (userBunrui === USER_BUNRUI_MC) {
            result.push('japanStaff');
        }
        else if (USER_BUNRUI_NOT_MC_JAPAN_STAFFS.includes(userBunrui)) {
            if (corpCd === CORP_CD_MC) {
                result.push('japanStaff');
            }
        }
    }
    else if (MC_SYOZOKU_CD_2_KETA_FOREIGN.includes(mcSyozokuCd2keta)) {
        if (userBunrui === USER_BUNRUI_MC) {
            result.push('foreignStaff');
        }
        else if (USER_BUNRUI_NOT_MC_FOREIGN_STAFFS.includes(userBunrui)) {
            if (corpCd === CORP_CD_MC) {
                result.push('foreignStaff');
            }
        }
    }
    return result;
}
export async function updateCalendarSync(prisma, pid, flgCalendarSync) {
    await prisma.user.update({ where: { pid, flgDelete: false }, data: { flgCalendarSync } });
}
export async function updateWebpushDeviceInfo(prisma, pid, 
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
webpushDeviceInfo) {
    await prisma.user.update({ where: { pid, flgDelete: false }, data: { webpushDeviceInfo } });
}
//# sourceMappingURL=userService.js.map