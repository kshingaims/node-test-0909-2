/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { addDays, addMinutes, isBefore, isValid } from 'date-fns';
import { getSchedFlightsReflectedInOutlook } from '../../service/flight/flightService.js';
import { getSchedHotelsReflectedInOutlook } from '../../service/hotel/hotelService.js';
import { getSchedTransportationsReflectedInOutlook } from '../../service/transportation/transportationService.js';
import { getSchedEventsReflectedInOutlook } from '../../service/event/eventService.js';
import { getSchedCompanyCarsReflectedInOutlook } from '../../service/companyCar/companyCarService.js';
import { getItineraryIndividualList } from '../../service/itinerary/itineraryService.js';
import { Define } from '../../utils/define.js';
import { formatDateTime, isBeforeToday, pickStrValue } from '../../utils/index.js';
import { checkAndGetTargetCalendar, getCalendarEvents, getSupportedTimezone, } from '../../service/azure/graphApiService.js';
export async function getOutlookEvents(prisma, pid, itineraryId, isForeignStaff = false) {
    // この旅程、このPIDユーザに紐つく、MCTripがDBに持っているoutlook予定を取得
    const list = await prisma.outlookCalendarEvent.findMany({
        select: { iCalUId: true, startDateTime: true, endDateTime: true, event: true, flgHidden: true },
        where: { itineraryId, pid, flgHidden: false },
        orderBy: {
            startDateTime: 'asc',
        },
    });
    // 海外拠点担当には、件名と場所情報しか返却しない
    if (isForeignStaff) {
        for (const item of list) {
            const oldEvent = item.event;
            item.event = {
                iCalUId: oldEvent.iCalUId,
                subject: oldEvent.subject,
                isAllDay: oldEvent.isAllDay,
                location: oldEvent.location,
            };
        }
    }
    return list;
}
export async function reflectOutlookCalendar(prisma, log, pid, user, itineraryId, adAEnc, isUseDummy = false) {
    const result = { isSuccess: false };
    // 対象PIDの旅程情報取得
    const list = await getItineraryIndividualList(prisma, pid, [itineraryId]);
    if (!list || list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    const utcStart = formatDateTime(new Date(list[0].itineraryFrom));
    const utcEnd = formatDateTime(addDays(new Date(list[0].itineraryTo), 1));
    // 出張終了日が過去日になっている場合は何も処理しないで終了とする。
    if (isBeforeToday(new Date(list[0].itineraryTo))) {
        result.isSuccess = true;
        result.data = { isPast: true };
        return result;
    }
    const lastExeDatetime = list[0].itineraryIndividualStatus?.outlookCalendarImportedAt;
    if (lastExeDatetime) {
        // 前回のoutlook予定取り込みからそれほど時間が経過していない場合は処理しないで終了とする。
        if (isBefore(new Date(), addMinutes(new Date(lastExeDatetime), Define.SETTINGS.OUTLOOK_INTEGRATION.minImportSpanMinutes))) {
            result.isSuccess = true;
            result.data = { isIgnore: true };
            return result;
        }
    }
    const { isSkip, token, isNoAccessRight, calendar } = await checkAndGetTargetCalendar(log, prisma, pid, user, adAEnc);
    if (isNoAccessRight) {
        result.isSuccess = false;
        result.error = { code: Define.ERROR_CODES.W01101, status: 200 };
        return result;
    }
    // このユーザがoutlook連携対象となっていない場合は処理終了
    if (isSkip) {
        result.isSuccess = false;
        result.error = { code: Define.ERROR_CODES.W01102, status: 200 };
        return result;
    }
    // outlookから該当期間の予定表一覧を取得すると共に、DBからoutlook連携済の予定情報を取得
    const [apiRes, { mctripSchedEventMap, dbCalendarEventMap }] = await Promise.all([
        getCalendarEvents(log, token, calendar, utcStart, utcEnd, 'text', isUseDummy),
        getMctripSchedEventMap(prisma, pid, itineraryId),
    ]);
    if (!apiRes.isSuccess) {
        result.error = apiRes.error;
        return result;
    }
    const tRes = await getSupportedTimezone(log, token);
    const timezoneMap = _formatTimezones(tRes.data?.value);
    const calendarEvents = apiRes.data?.value || [];
    let isDbChenged = false;
    const addICalUIdMap = {};
    // mctripが生成したoutlook予定は無視して、まだmctripに取り込んでいないoutlook予定を
    // mctripに取り込み実施する。
    // ・新規に見つかったoutlook予定は新規追加
    // ・既にmctripに取り込み済のoutlook予定は更新実施
    // ・mctrip取り込みしているoutlook予定が、今回outlook予定になければ削除実施
    for (const calendarEvent of calendarEvents) {
        const iCalUId = calendarEvent.iCalUId;
        // mcTripの予定であり、outlookに連携されたものである場合は、何も処理しない
        if (mctripSchedEventMap[iCalUId]) {
            continue;
        }
        // キャンセルされた予定は表示しない
        if (calendarEvent.isCancelled) {
            continue;
        }
        // showAs:freeの予定は、予定表に何も表示されない予定になるので、連携対象外にする。unknownの予定も連携対象外にする
        if (calendarEvent.showAs === 'free' || calendarEvent.showAs === 'unknown') {
            continue;
        }
        // mcTripで表示すべき予定とならない場合は、処理しない(mctriptに既に取り込み済の場合は、削除対象とする)
        if (calendarEvent.isAllDay) {
            continue;
        }
        // senditivityによって取り込み対象を変える。normal予定のみ取得対象
        if (calendarEvent.sensitivity !== 'normal') {
            continue;
            // calendarEvent.subject = calendarEvent.sensitivity;
            // calendarEvent.body.content = calendarEvent.sensitivity;
            // calendarEvent.bodyPreview = calendarEvent.sensitivity;
            // calendarEvent.attendees = undefined;
            // calendarEvent.locations = undefined;
            // calendarEvent.location = { displayName: calendarEvent.sensitivity };
        }
        const { start, end } = formatOutlookStartEndTime(calendarEvent.start, calendarEvent.end, timezoneMap);
        // 既にMcTrip側に取り込み完了済のoutlook予定の場合は、更新処理
        if (dbCalendarEventMap[iCalUId]) {
            const dbCalendarEvent = dbCalendarEventMap[iCalUId].data;
            // outlookから予定が取れているので、削除対象から外す
            dbCalendarEventMap[iCalUId].isDelete = false;
            // 更新処理実施
            if (dbCalendarEvent.lastModifiedDateTime !== calendarEvent.lastModifiedDateTime) {
                if (start && end) {
                    await prisma.outlookCalendarEvent.update({
                        where: {
                            itineraryId_pid_iCalUId: { itineraryId, pid, iCalUId },
                        },
                        data: {
                            startDateTime: new Date(start),
                            endDateTime: new Date(end),
                            event: calendarEvent,
                            lastModifiedDateTime: calendarEvent.lastModifiedDateTime,
                            transactionId: calendarEvent.transactionId,
                            updatedBy: user.pid,
                        },
                    });
                    isDbChenged = true;
                }
            }
        }
        else {
            // 新規登録(同じiCalUIdの予定が複数回取得できたとしても、1件のみの新規登録にする)
            if (start && end && !addICalUIdMap[iCalUId]) {
                await prisma.outlookCalendarEvent.create({
                    data: {
                        itineraryId,
                        pid,
                        iCalUId,
                        startDateTime: start,
                        endDateTime: end,
                        event: calendarEvent,
                        lastModifiedDateTime: calendarEvent.lastModifiedDateTime,
                        transactionId: calendarEvent.transactionId,
                        updatedBy: user.pid,
                    },
                });
                addICalUIdMap[iCalUId] = true;
                isDbChenged = true;
            }
        }
    }
    // 削除対象の削除処理
    const deleteICalUIds = [];
    for (const iCalUId of Object.keys(dbCalendarEventMap)) {
        if (dbCalendarEventMap[iCalUId].isDelete) {
            deleteICalUIds.push(iCalUId);
        }
    }
    if (deleteICalUIds.length > 0) {
        const delRes = await prisma.outlookCalendarEvent.deleteMany({
            where: { itineraryId, pid, iCalUId: { in: deleteICalUIds } },
        });
        if (delRes.count !== deleteICalUIds.length) {
            throw new Error('outlookCalendarEvent delete count is not collect');
        }
        isDbChenged = true;
    }
    result.data = { isDbChenged };
    result.isSuccess = true;
    return result;
}
async function getMctripSchedEventMap(prisma, pid, itineraryId) {
    // この旅程に紐つくmctripの予定でoutlook連携済のものを、削除フラグがあるもの含めて全て取得する。
    const mctripSchedEventMap = {};
    const schedFlights = await getSchedFlightsReflectedInOutlook(prisma, pid, itineraryId);
    const schedHotels = await getSchedHotelsReflectedInOutlook(prisma, pid, itineraryId);
    const schedTransportations = await getSchedTransportationsReflectedInOutlook(prisma, pid, itineraryId);
    const schedEvents = await getSchedEventsReflectedInOutlook(prisma, pid, itineraryId);
    const schedCompanyCars = await getSchedCompanyCarsReflectedInOutlook(prisma, pid, itineraryId);
    putMctripSchedEventMap(mctripSchedEventMap, 'flight', schedFlights);
    putMctripSchedEventMap(mctripSchedEventMap, 'hotel', schedHotels);
    putMctripSchedEventMap(mctripSchedEventMap, 'transportation', schedTransportations);
    putMctripSchedEventMap(mctripSchedEventMap, 'event', schedEvents);
    putMctripSchedEventMap(mctripSchedEventMap, 'companyCar', schedCompanyCars);
    const dbCalendarEventMap = {};
    // この旅程、このPIDユーザに紐つく、MCTripがDBに持っているoutlook予定を取得
    const dbCalendarEvents = await prisma.outlookCalendarEvent.findMany({ where: { itineraryId, pid } });
    for (const dbCalendarEvent of dbCalendarEvents) {
        if (dbCalendarEvent.iCalUId) {
            dbCalendarEventMap[dbCalendarEvent.iCalUId] = { data: dbCalendarEvent, isDelete: true };
        }
    }
    return { mctripSchedEventMap, dbCalendarEventMap };
}
function putMctripSchedEventMap(mctripSchedEventMap, type, scheds) {
    for (const sched of scheds) {
        if (sched.calendarId && sched.iCalUId) {
            mctripSchedEventMap[sched.iCalUId] = { type, sched };
        }
    }
}
function formatOutlookStartEndTime(start, end, timezoneMap) {
    return { start: _formatOutlookDateTime(start, timezoneMap), end: _formatOutlookDateTime(end, timezoneMap) };
}
function _formatOutlookDateTime(target, timezoneMap) {
    let result = undefined;
    // outlook予定の時刻情報はUTCとして取得している
    if (target.dateTime) {
        const timezone = timezoneMap[target.timeZone];
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const [datetime, _] = target.dateTime.split('.');
        if (target.timeZone === 'UTC' || timezone === 'UTC') {
            const formatted = datetime + 'Z';
            result = new Date(formatted);
        }
        else if (timezone) {
            const formatted = datetime + timezone;
            result = new Date(formatted);
        }
        if (result && !isValid(result)) {
            throw new Error('outlook event datetime format error.');
        }
    }
    return result;
}
function _formatTimezones(originalTimezones) {
    if (!originalTimezones || originalTimezones.length <= 0) {
        return {};
    }
    const result = {};
    for (const originalTimezone of originalTimezones) {
        const alias = originalTimezone.alias;
        let timezone = pickStrValue(originalTimezone.displayName, [{ keyword: '(UTC', endKeyword: ')' }]);
        if (alias) {
            if (!timezone || timezone === '+00:00' || timezone === '-00:00') {
                timezone = 'UTC';
            }
            result[alias] = timezone;
        }
    }
    return result;
}
export async function hide(prisma, pid, user, itineraryId, iCalUId) {
    try {
        await prisma.outlookCalendarEvent.update({
            data: { flgHidden: true, updatedBy: user.pid },
            where: { itineraryId_pid_iCalUId: { pid, itineraryId, iCalUId } },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
export async function getItem(prisma, pid, itineraryId, iCalUId) {
    return await prisma.outlookCalendarEvent.findUnique({
        where: { itineraryId_pid_iCalUId: { pid, itineraryId, iCalUId } },
    });
}
//# sourceMappingURL=outlookCalendarEventService.js.map