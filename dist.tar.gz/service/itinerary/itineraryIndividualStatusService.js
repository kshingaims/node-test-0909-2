export async function updateCycleLinkStatus(prisma, pid, user, itineraryId, cycleLinkStatus, finishCycleIntegrateDate) {
    await prisma.itineraryIndividualStatus.update({
        data: { cycleLinkStatus, updatedBy: user.pid, finishCycleIntegrateDate },
        where: { itineraryId_pid: { itineraryId, pid } },
    });
}
export async function updateOutlookCalendarImportedAt(prisma, pid, user, itineraryId) {
    await prisma.itineraryIndividualStatus.update({
        data: { outlookCalendarImportedAt: new Date(), updatedBy: user.pid },
        where: { itineraryId_pid: { itineraryId, pid } },
    });
}
//# sourceMappingURL=itineraryIndividualStatusService.js.map