import { log } from '../../utils/logger.js';
import { convertAllNullToMark, format, formatDate, formatDateTime, getCountryOrCityName, getKeys, getLocalDate, joinStr, } from '../../utils/index.js';
import { createCalendarEvent, createEventAttachment, deleteCalendarEvent, deleteEventAttachment, getEventAttachments, updateCalendarEvent, updateCalendarEventAttendees, } from '../../service/azure/graphApiService.js';
import { updateOutlookCalendarInfo as updateDbSchedFlight } from '../../service/flight/flightService.js';
import { hasCheckIn, hasCheckOut, updateOutlookCalendarInfo as updateDbSchedHotel } from '../../service/hotel/hotelService.js';
import { updateOutlookCalendarInfo as updateDbSchedCCar } from '../../service/companyCar/companyCarService.js';
import { updateOutlookCalendarInfo as updateDbSchedTransportation } from '../../service/transportation/transportationService.js';
import { updateOutlookCalendarInfo as updateDbSchedEvent } from '../../service/event/eventService.js';
import { updateOutlookCalendarInfo as updateDbSchedFile } from '../../service/file/schedFileService.js';
import { bufToStr, formatUtcDateTime, replaceCRLF } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { downloadSchedAttachment } from '../../utils/azureBlob.js';
import { COMPANY_CAR_CONTENT, EVENT_CONTENT, FLIGHT_CONTENT, HOTEL_CONTENT, ITINERARY_CONTENT, TRANSPORTATION_CONTENT, } from '../../service/itinerary/outlookEventTemplate.js';
import { addDays, addMinutes } from 'date-fns';
import { cloneDeep } from 'lodash-es';
export async function sendScheds(pid, schedIndividuals, formatOutlookEvent, getSchedFiles, calendar, token) {
    const target = [];
    const result = { isSuccess: true, updatedData: target };
    for (const schedIndividual of schedIndividuals) {
        const cObj = formatOutlookEvent(pid, schedIndividual);
        const { calendarEvent } = await _sendOutlookEvent(token, calendar, cObj.calendarEvent, cObj.calendarId);
        if (calendarEvent) {
            // 予定の添付ファイルの処理
            const schedFiles = getSchedFiles(schedIndividual);
            // outlook予定の更新処理となっているかどうかの判定
            const isUpdate = (cObj.calendarId && cObj.iCalUId === calendarEvent.iCalUId) || false;
            const { isOutlookUpdate, data: atRes } = await _attachmentFileIntoOutlookEvent(token, calendar, calendarEvent.id, schedFiles, isUpdate);
            // 予定参加者に対して、連携実施(Attendeesだけを変更したoutlookイベント更新が必要)
            updateCalendarEventAttendees(log, token, calendar, calendarEvent.id, cObj.calendarEvent, isOutlookUpdate);
            target.push({
                id: cObj.schedId,
                outlookEventId: calendarEvent.id,
                lastModifiedDateTime: calendarEvent.lastModifiedDateTime,
                iCalUId: calendarEvent.iCalUId,
                updatedAttachments: atRes,
            });
        }
        else {
            result.isSuccess = false;
        }
    }
    return result;
}
export async function sendSchedHotels(pid, schedIndividuals, calendar, token) {
    const target = [];
    const result = { isSuccess: true, updatedData: target };
    for (const schedIndividual of schedIndividuals) {
        const cObjMap = {
            default: formatHotel(pid, schedIndividual),
            checkin: formatHotelCheckIn(pid, schedIndividual),
            checkout: formatHotelCheckOut(pid, schedIndividual),
        };
        const hotelResult = { default: {} };
        for (const key of getKeys(cObjMap)) {
            const cObj = cObjMap[key];
            if (!cObj) {
                // チェックイン・チェックアウト時刻が未定の場合
                const calendarId = key === 'checkin'
                    ? schedIndividual.schedHotel.calendarId2
                    : key === 'checkout'
                        ? schedIndividual.schedHotel.calendarId3
                        : null;
                if (calendarId) {
                    // もしoutlook予定連携済の場合は、outlook予定から削除を行う
                    const delRes = await deleteCalendarEvent(log, token, calendar, bufToStr(calendarId));
                    if (delRes.isSuccess || delRes.error?.code === Define.ERROR_CODES.W01103) {
                        // ignore
                    }
                    else {
                        result.isSuccess = false;
                    }
                }
            }
            else {
                // 予定の更新処理
                const { calendarEvent } = await _sendOutlookEvent(token, calendar, cObj.calendarEvent, cObj.calendarId);
                if (calendarEvent) {
                    let atDataRes = [];
                    let isAttachmentUpdate = false;
                    // チェックインの予定、チェックアウトの予定ではない場合は、添付ファイルに関する連携を実施する
                    if (key === 'default') {
                        // 予定の添付ファイルの処理
                        const schedFiles = schedIndividual.schedHotel.schedHotelFiles || [];
                        // outlook予定の更新処理となっているかどうかの判定
                        const isUpdate = (cObj.calendarId && cObj.iCalUId === calendarEvent.iCalUId) || false;
                        const atApiRes = await _attachmentFileIntoOutlookEvent(token, calendar, calendarEvent.id, schedFiles, isUpdate);
                        atDataRes = atApiRes.data;
                        isAttachmentUpdate = atApiRes.isOutlookUpdate;
                    }
                    // 予定参加者に対して、連携実施(Attendeesだけを変更したoutlookイベント更新が必要)
                    updateCalendarEventAttendees(log, token, calendar, calendarEvent.id, cObj.calendarEvent, isAttachmentUpdate);
                    hotelResult[key] = {
                        id: cObj.schedId,
                        outlookEventId: calendarEvent.id,
                        lastModifiedDateTime: calendarEvent.lastModifiedDateTime,
                        iCalUId: calendarEvent.iCalUId,
                        updatedAttachments: atDataRes,
                    };
                }
                else {
                    result.isSuccess = false;
                }
            }
        }
        target.push(hotelResult);
    }
    return result;
}
export async function sendItinerary(pid, itinerary, calendar, token) {
    const result = {
        isSuccess: true,
    };
    if (!itinerary) {
        return result;
    }
    const cObj = formatItinerary(pid, itinerary);
    const { calendarEvent } = await _sendOutlookEvent(token, calendar, cObj.calendarEvent, cObj.calendarId);
    if (calendarEvent) {
        result.updatedData = {
            id: itinerary.itineraryId,
            outlookEventId: calendarEvent.id,
            lastModifiedDateTime: calendarEvent.lastModifiedDateTime,
            iCalUId: calendarEvent.iCalUId,
            updatedAttachments: [],
        };
    }
    else {
        result.isSuccess = false;
    }
    return result;
}
/**
 * MCTrip予定をoutlook予定への反映実施後の結果情報を元に、MCTrip予定情報にoutlook連係情報を追加更新する。
 * @param IControllerTools
 * @param schedType
 * @param apiResult outlook連携の実行結果情報
 * @returns
 */
export async function updateDbSched({ prisma, user }, schedType, apiResult) {
    const result = { isSuccess: true };
    if (!apiResult.isSuccess) {
        result.isSuccess = false;
        result.isApiError = true;
    }
    for (const outlookEvent of apiResult.updatedData) {
        for (const atResult of outlookEvent.updatedAttachments) {
            const azAttachment = atResult.azAttachment;
            const azAtId = azAttachment.id;
            const lastModifiedDateTime = azAttachment.lastModifiedDateTime;
            // 予定に紐つく添付ファイルのDB更新
            if (!(await updateDbSchedFile(prisma, user, schedType, atResult.schedFileId, azAtId, lastModifiedDateTime))) {
                result.isDbError = true;
            }
        }
        const schedId = outlookEvent.id;
        const outlookEventId = outlookEvent.outlookEventId;
        const lModifiedDT = outlookEvent.lastModifiedDateTime;
        const iCalUId = outlookEvent.iCalUId;
        // 予定のDB更新
        let schedResult = false;
        if (schedType === 'flight') {
            schedResult = await updateDbSchedFlight(prisma, user, schedId, outlookEventId, lModifiedDT, iCalUId);
        }
        else if (schedType === 'hotel') {
            throw new Error('programing error.');
        }
        else if (schedType === 'companyCar') {
            schedResult = await updateDbSchedCCar(prisma, user, schedId, outlookEventId, lModifiedDT, iCalUId);
        }
        else if (schedType === 'transportation') {
            schedResult = await updateDbSchedTransportation(prisma, user, schedId, outlookEventId, lModifiedDT, iCalUId);
        }
        else if (schedType === 'event') {
            schedResult = await updateDbSchedEvent(prisma, user, schedId, outlookEventId, lModifiedDT, iCalUId);
        }
        if (!schedResult) {
            result.isDbError = true;
        }
    }
    return result;
}
/**
 * MCTripホテル予定をoutlook予定への反映実施後の結果情報を元に、MCTrip予定情報にoutlook連係情報を追加更新する。
 * @param IControllerTools
 * @param apiResult outlook連携の実行結果情報
 * @returns
 */
export async function updateDatabaseSchedHotel({ prisma, user }, apiResult) {
    const result = { isSuccess: true };
    if (!apiResult.isSuccess) {
        result.isSuccess = false;
        result.isApiError = true;
    }
    for (const outlookEvent of apiResult.updatedData) {
        for (const atResult of outlookEvent.default.updatedAttachments) {
            const azAttachment = atResult.azAttachment;
            const azAtId = azAttachment.id;
            const lastModifiedDateTime = azAttachment.lastModifiedDateTime;
            // 予定に紐つく添付ファイルのDB更新
            if (!(await updateDbSchedFile(prisma, user, 'hotel', atResult.schedFileId, azAtId, lastModifiedDateTime))) {
                result.isDbError = true;
            }
        }
        // idはdefault, checkin, checkoutどれも同じなので、defaultから取得
        const schedId = outlookEvent.default.id;
        const outlookEventId = outlookEvent.default.outlookEventId;
        // outlook予定更新時刻はdefaultを利用
        const lModifiedDT = outlookEvent.default.lastModifiedDateTime;
        const iCalUId = outlookEvent.default.iCalUId;
        const outlookEventId2 = outlookEvent.checkin?.outlookEventId;
        const iCalUId2 = outlookEvent.checkin?.iCalUId;
        const outlookEventId3 = outlookEvent.checkout?.outlookEventId;
        const iCalUId3 = outlookEvent.checkout?.iCalUId;
        // 予定のDB更新
        const schedResult = await updateDbSchedHotel(prisma, user, schedId, outlookEventId, lModifiedDT, iCalUId, outlookEventId2 || null, iCalUId2 || null, outlookEventId3 || null, iCalUId3 || null);
        if (!schedResult) {
            result.isDbError = true;
        }
    }
    return result;
}
export async function deleteOutlookCalendarEvent(prisma, user, aadToken, calendar, sched, type) {
    const result = { isSuccess: true };
    const schedId = sched.id;
    const calendarId = sched.calendarId;
    if (type !== 'hotel') {
        const delRes = await deleteCalendarEvent(log, aadToken, calendar, calendarId);
        if (delRes.isSuccess || delRes.error?.code === Define.ERROR_CODES.W01103) {
            try {
                if (type === 'flight') {
                    await updateDbSchedFlight(prisma, user, schedId, null, null, null);
                }
                else if (type === 'companyCar') {
                    await updateDbSchedCCar(prisma, user, schedId, null, null, null);
                }
                else if (type === 'transportation') {
                    await updateDbSchedTransportation(prisma, user, schedId, null, null, null);
                }
                else if (type === 'event') {
                    await updateDbSchedEvent(prisma, user, schedId, null, null, null);
                }
            }
            catch (error) {
                result.isDbError = true;
            }
        }
        else {
            result.isSuccess = false;
            result.isApiError = true;
        }
    }
    else {
        const targets = [calendarId, sched.calendarId2 || null, sched.calendarId3 || null];
        for (const target of targets) {
            if (target) {
                const delRes = await deleteCalendarEvent(log, aadToken, calendar, target);
                if (delRes.isSuccess || delRes.error?.code === Define.ERROR_CODES.W01103) {
                    // ignore
                }
                else {
                    result.isSuccess = false;
                    result.isApiError = true;
                }
            }
        }
        if (result.isSuccess) {
            try {
                await updateDbSchedHotel(prisma, user, schedId, null, null, null, null, null, null, null);
            }
            catch (error) {
                result.isDbError = true;
            }
        }
    }
    return result;
}
/**
 * Azure graph APIを利用して、MCTripの予定をoutlook予定登録を行う。
 * @param aadToken
 * @param calendar
 * @param calendarEvent outlook予定登録情報
 * @param outlookEventId outlook予定のID情報(更新時は指定あり)
 * @returns
 */
async function _sendOutlookEvent(aadToken, calendar, calendarEvent, outlookEventId) {
    const apiRes = outlookEventId
        ? await updateCalendarEvent(log, aadToken, calendar, outlookEventId, calendarEvent)
        : await createCalendarEvent(log, aadToken, calendar, calendarEvent);
    if (apiRes.isSuccess) {
        return { calendarEvent: apiRes.data };
    }
    else {
        if (apiRes.error?.code === Define.ERROR_CODES.W01103 && outlookEventId) {
            // 予定表から削除された可能性が高いので、新規作成を進める
            const againRes = await createCalendarEvent(log, aadToken, calendar, calendarEvent);
            if (againRes.isSuccess) {
                return { calendarEvent: againRes.data };
            }
            else {
                return { calendarEvent: undefined, error: againRes.error };
            }
        }
        return { calendarEvent: undefined, error: apiRes.error };
    }
}
/**
 * Azure graph APIを利用して、MCTripの予定の添付ファイルをoutlook予定の添付ファイルとして紐付ける。
 * 更新処理時は削除・追加の有無をチェックしながら、実施する。
 * ファイルアップロードでエラーがあった場合を細かく通知してもフロント側の処理が大変なので一旦エラー判定はしない
 * @param aadToken
 * @param calendar
 * @param outlookEventId outlook予定のID情報
 * @param schedAttachments 予定の添付ファイル情報一覧
 * @param isUpdate 更新処理かどうか
 */
async function _attachmentFileIntoOutlookEvent(aadToken, calendar, outlookEventId, schedAttachments, isUpdate = false) {
    const result = [];
    let isOutlookUpdate = false;
    if (!schedAttachments || schedAttachments.length <= 0) {
        // ファイル添付がないので終了
        return { isOutlookUpdate, data: [] };
    }
    // outlook予定内にある添付ファイルをファイル名をキーにしてまとめたもの
    let outlookAttachmentMap = {};
    // outlook予定内にある添付ファイルの中で、削除対象となるものをファイル名をキーにしてまとめたもの
    const outlookAttachmentDeleteMap = {};
    // 新規追加となる添付ファイル
    const createSchedAttachments = [];
    if (isUpdate) {
        const lOutlookAttachmentMap = await latestEventAttachments(aadToken, calendar, outlookEventId);
        if (lOutlookAttachmentMap) {
            outlookAttachmentMap = lOutlookAttachmentMap;
            for (const filename of Object.keys(outlookAttachmentMap)) {
                // outlook予定に紐付く添付ファイルは初期状態はすべて削除対象として判定しておく
                outlookAttachmentDeleteMap[filename] = true;
            }
        }
        else {
            // 一覧取得できない場合は、何も処理しないで終了する
            return { isOutlookUpdate, data: [] };
        }
    }
    // 削除 or 新規登録 or 変更なしかを判定
    for (const schedAttachment of schedAttachments) {
        // outlook連係実施した場合は、azAttachmentIdが存在するので、それがない場合は常に新規登録が必要
        if (!schedAttachment.azAttachmentId) {
            // 新規登録(outlook予定に紐つく添付ファイルとなっていない)
            createSchedAttachments.push(schedAttachment);
        }
        else {
            if (outlookAttachmentMap[schedAttachment.originalFileName]) {
                // outlook予定に紐つく添付ファイル一覧の中に、同じファイル名のファイルがあるので、何もしない(そのまま残す)
                // 削除対象解除
                outlookAttachmentDeleteMap[schedAttachment.originalFileName] = false;
            }
            else {
                // outlook連係実施した場合でも、同じファイル名のファイルがoutlook側にない場合も新規登録が必要
                createSchedAttachments.push(schedAttachment);
            }
        }
    }
    // 削除対象フラグた立ったままのoutlook予定に紐つく添付ファイルは削除処理実施
    for (const filename of Object.keys(outlookAttachmentDeleteMap)) {
        // 削除フラグが立っているもののみ、処理対象
        if (outlookAttachmentDeleteMap[filename]) {
            let azureAttachment = outlookAttachmentMap[filename];
            // 削除処理(非同期処理とする)
            // outlook予定では、予定に紐付く添付ファイルの数に増減が発生すると添付ファイルIDが
            // 変わってしまう事象がある。そのため、ファイルを確実に削除する為には、都度最新の添付ファイルIDを取得しながら、
            // 処理を行う必要がある。
            const delRes = await deleteEventAttachment(log, aadToken, calendar, outlookEventId, azureAttachment.id);
            // outlook予定に紐付くファイル一覧の最新を取得しなおしして、添付ID最新情報を取得しておく
            const lOutlookAttachmentMap = await latestEventAttachments(aadToken, calendar, outlookEventId);
            if (lOutlookAttachmentMap) {
                outlookAttachmentMap = lOutlookAttachmentMap;
            }
            if (!delRes.isSuccess && !delRes.error) {
                // 添付ファイルIDが更新されている等、運用上発生するAPiエラーの場合は、ファイル削除を再実行する。
                azureAttachment = outlookAttachmentMap[filename];
                // 再実行がエラーの場合は、SKIPするので、成功・失敗判定しない
                await deleteEventAttachment(log, aadToken, calendar, outlookEventId, azureAttachment.id);
                const lOutlookAttachmentMap = await latestEventAttachments(aadToken, calendar, outlookEventId);
                if (lOutlookAttachmentMap) {
                    outlookAttachmentMap = lOutlookAttachmentMap;
                }
            }
            isOutlookUpdate = true;
        }
    }
    // ファイルの新規追加処理
    for (const addFile of createSchedAttachments) {
        // 添付ファイル取得処理
        const fileData = await downloadSchedAttachment(addFile.path);
        if (fileData.base64) {
            // 新規登録処理(予定に紐つく添付ファイル情報の中に、outlook予定の添付ファイルIDがない場合)
            const res = await createEventAttachment(log, aadToken, calendar, outlookEventId, {
                contentBytes: fileData.base64,
                name: addFile.originalFileName,
            });
            if (res.isSuccess && res.data) {
                const azAttachment = res.data;
                result.push({ schedFileId: addFile.id, azAttachment });
                isOutlookUpdate = true;
            }
        }
    }
    return { isOutlookUpdate, data: result };
}
async function latestEventAttachments(aadToken, calendar, outlookEventId) {
    const result = {};
    // outlook予定に紐つく添付ファイル一覧を取得する
    const apiRes = await getEventAttachments(log, aadToken, calendar, outlookEventId);
    if (!apiRes.isSuccess) {
        return undefined;
    }
    const outlookAttachments = apiRes.data?.value || [];
    // oulook予定に紐付いている添付ファイル情報を、ファイル名をキーにして情報保持しておく
    for (const outlookAttachment of outlookAttachments) {
        result[outlookAttachment.name] = outlookAttachment;
    }
    return result;
}
/**
 * Azure graph APIを利用して、MCTripの予定の添付ファイルをoutlook予定の添付ファイルとして紐付ける。
 * 更新処理時は削除・追加の有無をチェックしながら、実施する。
 * ファイルアップロードでエラーがあった場合を細かく通知してもフロント側の処理が大変なので一旦エラー判定はしない
 * @param aadToken
 * @param calendar
 * @param outlookEventId outlook予定のID情報
 * @param schedAttachments 予定の添付ファイル情報一覧
 * @param isUpdate 更新処理かどうか
 */
export async function _attachmentFileIntoOutlookEventOld(aadToken, calendar, outlookEventId, schedAttachments, isUpdate = false) {
    const result = [];
    const outlookAttachmentMap = {};
    const outlookAttachmentDeleteMap = {};
    if (isUpdate) {
        // outlook予定に紐つく添付ファイル一覧を取得する
        const apiRes = await getEventAttachments(log, aadToken, calendar, outlookEventId);
        if (!apiRes.isSuccess) {
            return [];
        }
        const outlookAttachments = apiRes.data?.value || [];
        for (const outlookAttachment of outlookAttachments) {
            outlookAttachmentMap[outlookAttachment.id] = outlookAttachment;
            outlookAttachmentDeleteMap[outlookAttachment.id] = true;
        }
    }
    for (const schedAttachment of schedAttachments) {
        let isNew = false;
        // 削除 or 新規登録 or 変更なしかを判定
        if (!schedAttachment.azAttachmentId) {
            // 新規登録(outlook予定に紐つく添付ファイルとなっていない)
            isNew = true;
        }
        else {
            const azAttachmentId = bufToStr(schedAttachment.azAttachmentId);
            // outlook予定に紐つく添付ファイル一覧の中に、この予定の添付ファイルが含まれている場合は何もしない(そのまま残す)
            if (outlookAttachmentMap[azAttachmentId]) {
                // 削除対象解除
                outlookAttachmentDeleteMap[azAttachmentId] = false;
            }
            else {
                // 新規登録(outlookで予定削除されてしまって、今回新たにoutlook予定作成し直しとなっている可能性あり)
                //isNew = true;
            }
        }
        if (isNew) {
            // 添付ファイル取得処理
            const fileData = await downloadSchedAttachment(schedAttachment.path);
            if (fileData.base64) {
                // 新規登録処理(予定に紐つく添付ファイル情報の中に、outlook予定の添付ファイルIDがない場合)
                const res = await createEventAttachment(log, aadToken, calendar, outlookEventId, {
                    contentBytes: fileData.base64,
                    name: schedAttachment.originalFileName,
                });
                if (res.isSuccess && res.data) {
                    const azAttachment = res.data;
                    result.push({ schedFileId: schedAttachment.id, azAttachment });
                }
            }
        }
    }
    // 削除対象フラグた立ったままのoutlook予定に紐つく添付ファイルは削除処理実施
    for (const key of Object.keys(outlookAttachmentDeleteMap)) {
        if (outlookAttachmentDeleteMap[key]) {
            // 削除処理(非同期処理とする)
            // outlook予定では、予定に紐付く添付ファイルの数に増減が発生すると添付ファイルIDが
            // 変わってしまう事象がある。そのため、同期処理にしてしまうと、添付ファイル削除を検知したタイミングで
            // 添付ファイルIDが変わってしまって、添付ファイル削除が失敗する事象(404エラー etc)があることを検知している。
            // 添付ファイル削除を検知する前に、削除APIを一気に送信してしまう方が良さそうなので、非同期処理にしている。
            await deleteEventAttachment(log, aadToken, calendar, outlookEventId, key);
        }
    }
    return result;
}
function _formatSchedToOutlookEvent(pid, schedId, subject, content, start, end, allSchedIndividuals, location, calendarId, iCalUId, showAs, isAllDay = false) {
    const contentReplaced = replaceCRLF(content);
    const attendees = _makeAttendees(allSchedIndividuals, pid);
    const cEvent = {
        subject,
        body: {
            contentType: 'Text',
            content: contentReplaced,
        },
        start: _makeStartEndTimeOjb(start, false, isAllDay),
        end: _makeStartEndTimeOjb(end, true, isAllDay),
        showAs,
        isAllDay,
    };
    if (attendees) {
        cEvent.attendees = attendees;
    }
    if (location) {
        cEvent.location = {
            displayName: location,
        };
    }
    return { calendarEvent: cEvent, calendarId: bufToStr(calendarId), schedId, iCalUId };
}
function _makeAttendees(schedIndividuals, pid) {
    const result = [];
    for (const schedIndividual of schedIndividuals) {
        // 自分自身は会議出席者への追加はしなくて良いので除外する
        if (schedIndividual.user.email && schedIndividual.user.pid !== pid) {
            result.push({ emailAddress: { address: schedIndividual.user.email }, type: 'required' });
        }
    }
    return result;
}
function _makeStartEndTimeOjb(datetime, isEnd, isAllDay = false) {
    // ==== azure graph APIの終日フラグ指定時の仕様 ====
    // 終日フラグがある場合で、終了時刻が00:00を超えている場合は、終了日もきちんと終日予定として表示させる為に、+1日しておく必要がある。
    if (isEnd && isAllDay) {
        if (formatUtcDateTime(datetime, 'HH:mm:ss') !== '00:00:00') {
            datetime = addDays(datetime, 1);
        }
    }
    const dateTime = isAllDay
        ? formatUtcDateTime(datetime, 'yyyy-MM-dd')
        : formatUtcDateTime(datetime, "yyyy-MM-dd'T'HH:mm:ssXXX");
    return {
        dateTime,
        timeZone: 'UTC',
    };
}
export function formatFlight(pid, schedFlightIndividual) {
    const schedFlight = schedFlightIndividual.schedFlight;
    const arrangementStatus = Define.SETTINGS.FLG_ARRGT_TEXT[schedFlight.flgArrgt ? 1 : 0];
    const data = cloneDeep({ schedFlight, arrangementStatus });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(FLIGHT_CONTENT, data));
    const subject = `【フライト】${schedFlight.flightNumber}`;
    const location = joinStr([schedFlight.departureAirport, schedFlight.arrivalAirport], '→', true);
    return _formatSchedToOutlookEvent(pid, schedFlight.id, subject, content, schedFlight.departureDateTime, schedFlight.arrivalDateTime, schedFlight.schedFlightIndividuals, location, schedFlight.calendarId, schedFlight.iCalUId, schedFlight.flgArrgt ? undefined : 'tentative');
}
export function formatHotel(pid, schedHotelIndividual) {
    const schedHotel = schedHotelIndividual.schedHotel;
    const arrangementStatus = Define.SETTINGS.FLG_ARRGT_TEXT[schedHotel.flgArrgt ? 1 : 0];
    let checkInDate = undefined;
    let checkOutDate = undefined;
    if (schedHotel.timezone) {
        const tz = schedHotel.timezone;
        if (schedHotel.checkInDateTime) {
            checkInDate = getLocalDate(new Date(schedHotel.checkInDateTime), tz);
        }
        if (schedHotel.checkOutDateTime) {
            checkOutDate = getLocalDate(new Date(schedHotel.checkOutDateTime), tz);
        }
    }
    const checkin = checkInDate && hasCheckIn(schedHotel) ? formatDateTime(checkInDate, 'yyyy/MM/dd HH:mm') : '';
    const checkout = checkOutDate && hasCheckOut(schedHotel) ? formatDateTime(checkOutDate, 'yyyy/MM/dd HH:mm') : '';
    const data = cloneDeep({ schedHotel, arrangementStatus, checkin, checkout });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(HOTEL_CONTENT, data));
    const subject = `【ホテル】${schedHotel.name}`;
    const location = `${schedHotel.address}`;
    return _formatSchedToOutlookEvent(pid, schedHotel.id, subject, content, schedHotel.checkInDateTime, schedHotel.checkOutDateTime, schedHotel.schedHotelIndividuals, location, schedHotel.calendarId, schedHotel.iCalUId, schedHotel.flgArrgt ? 'free' : 'tentative', true);
}
export function formatHotelCheckIn(pid, schedHotelIndividual) {
    const schedHotel = schedHotelIndividual.schedHotel;
    if (!hasCheckIn(schedHotel)) {
        return null;
    }
    const arrangementStatus = Define.SETTINGS.FLG_ARRGT_TEXT[schedHotel.flgArrgt ? 1 : 0];
    let checkInDate = undefined;
    let checkOutDate = undefined;
    if (schedHotel.timezone) {
        const tz = schedHotel.timezone;
        if (schedHotel.checkInDateTime) {
            checkInDate = getLocalDate(new Date(schedHotel.checkInDateTime), tz);
        }
        if (schedHotel.checkOutDateTime) {
            checkOutDate = getLocalDate(new Date(schedHotel.checkOutDateTime), tz);
        }
    }
    const checkin = checkInDate && hasCheckIn(schedHotel) ? formatDateTime(checkInDate, 'yyyy/MM/dd HH:mm') : '';
    const checkout = checkOutDate && hasCheckOut(schedHotel) ? formatDateTime(checkOutDate, 'yyyy/MM/dd HH:mm') : '';
    const data = cloneDeep({ schedHotel, arrangementStatus, checkin, checkout });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(HOTEL_CONTENT, data));
    const subject = `【チェックイン】${schedHotel.name}`;
    const location = `${schedHotel.address}`;
    return _formatSchedToOutlookEvent(pid, schedHotel.id, subject, content, schedHotel.checkInDateTime, addMinutes(schedHotel.checkInDateTime, 30), schedHotel.schedHotelIndividuals, location, schedHotel.calendarId2, schedHotel.iCalUId2, schedHotel.flgArrgt ? undefined : 'tentative');
}
export function formatHotelCheckOut(pid, schedHotelIndividual) {
    const schedHotel = schedHotelIndividual.schedHotel;
    if (!hasCheckOut(schedHotel)) {
        return null;
    }
    const arrangementStatus = Define.SETTINGS.FLG_ARRGT_TEXT[schedHotel.flgArrgt ? 1 : 0];
    let checkInDate = undefined;
    let checkOutDate = undefined;
    if (schedHotel.timezone) {
        const tz = schedHotel.timezone;
        if (schedHotel.checkInDateTime) {
            checkInDate = getLocalDate(new Date(schedHotel.checkInDateTime), tz);
        }
        if (schedHotel.checkOutDateTime) {
            checkOutDate = getLocalDate(new Date(schedHotel.checkOutDateTime), tz);
        }
    }
    const checkin = checkInDate && hasCheckIn(schedHotel) ? formatDateTime(checkInDate, 'yyyy/MM/dd HH:mm') : '';
    const checkout = checkOutDate && hasCheckOut(schedHotel) ? formatDateTime(checkOutDate, 'yyyy/MM/dd HH:mm') : '';
    const data = cloneDeep({ schedHotel, arrangementStatus, checkin, checkout });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(HOTEL_CONTENT, data));
    const subject = `【チェックアウト】${schedHotel.name}`;
    const location = `${schedHotel.address}`;
    return _formatSchedToOutlookEvent(pid, schedHotel.id, subject, content, addMinutes(schedHotel.checkOutDateTime, -30), schedHotel.checkOutDateTime, schedHotel.schedHotelIndividuals, location, schedHotel.calendarId3, schedHotel.iCalUId3, schedHotel.flgArrgt ? undefined : 'tentative');
}
export function formatCompanyCar(pid, schedCompanyCarIndividual) {
    const schedCompanyCar = schedCompanyCarIndividual.schedCompanyCar;
    const data = cloneDeep({ schedCompanyCar });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(COMPANY_CAR_CONTENT, data));
    const subject = '【移動】社有車';
    const location = schedCompanyCar.departureLocation;
    return _formatSchedToOutlookEvent(pid, schedCompanyCar.id, subject, content, schedCompanyCar.startDateTime, schedCompanyCar.endDateTime, schedCompanyCar.schedCompanyCarIndividuals, location, schedCompanyCar.calendarId, schedCompanyCar.iCalUId, schedCompanyCar.flgArrgt ? undefined : 'tentative');
}
export function formatTransportation(pid, schedTransportationIndividual) {
    const schedTransportation = schedTransportationIndividual.schedTransportation;
    const data = cloneDeep({ schedTransportation });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(TRANSPORTATION_CONTENT, data));
    const subject = `【移動】${schedTransportation.transportationMode}`;
    const location = joinStr([schedTransportation.departureLocation, schedTransportation.arrivalLocation], '→', true);
    return _formatSchedToOutlookEvent(pid, schedTransportation.id, subject, content, schedTransportation.departureDateTime, schedTransportation.arrivalDateTime, schedTransportation.schedTransportationIndividuals, location, schedTransportation.calendarId, schedTransportation.iCalUId);
}
export function formatEvent(pid, schedEventIndividual) {
    const schedEvent = schedEventIndividual.schedEvent;
    const data = cloneDeep({ schedEvent });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(EVENT_CONTENT, data));
    const subject = schedEvent.name || '';
    const location = joinStr([schedEvent.location, schedEvent.address], '; ');
    return _formatSchedToOutlookEvent(pid, schedEvent.id, subject, content, schedEvent.startDateTime, schedEvent.endDateTime, schedEvent.schedEventIndividuals, location, schedEvent.calendarId, schedEvent.iCalUId);
}
export function formatItinerary(pid, itineray) {
    const placeStrs = [];
    const cityNames = [];
    // 出張情報
    itineray.places.forEach((place) => {
        const cityName = getCountryOrCityName(place.city);
        const spanStart = formatDate(place.stayDurationFrom, 'yyyy/M/d');
        const spanTo = formatDate(place.stayDurationTo, 'M/d');
        placeStrs.push(`${cityName}：${spanStart} - ${spanTo}`);
        cityNames.push(cityName);
    });
    const placesInfo = joinStr(placeStrs, '\n');
    const data = cloneDeep({ itineraryName: itineray.itineraryName, placesInfo });
    convertAllNullToMark(data);
    const content = replaceCRLF(format(ITINERARY_CONTENT, data));
    const subject = itineray.itineraryName || '';
    const location = joinStr(cityNames, '; ');
    return _formatSchedToOutlookEvent(pid, itineray.itineraryId, subject, content, new Date(itineray.itineraryFrom), new Date(itineray.itineraryTo), [], // 自分自身にしか送信しない(会議出席依頼にしない)
    location, itineray.calendarId, itineray.iCalUId, 'free');
}
//# sourceMappingURL=syncOutlookEventService.js.map