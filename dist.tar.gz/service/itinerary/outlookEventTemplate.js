/* eslint no-irregular-whitespace: ["off"] */
export const FLIGHT_CONTENT = `※本予定はMC Tripから送付されています。
　MC Tripから予定の修正・削除が実行されますので、Outlook上では編集しないでください。

手配状況：{{arrangementStatus}}
出発都市：{{schedFlight.departureCity}}
到着都市：{{schedFlight.arrivalCity}}
航空会社：{{schedFlight.airline}}
備考：{{schedFlight.remark}}
`;
export const HOTEL_CONTENT = `※本予定はMC Tripから送付されています。
　MC Tripから予定の修正・削除が実行されますので、Outlook上では編集しないでください。

手配状況：{{arrangementStatus}}
チェックイン：{{checkin}}
チェックアウト：{{checkout}}
備考：{{schedHotel.remark}}
`;
export const COMPANY_CAR_CONTENT = `※本予定はMC Tripから送付されています。
　MC Tripから予定の修正・削除が実行されますので、Outlook上では編集しないでください。

車種：{{schedCompanyCar.carModel}}
社有車のNo.プレート：{{schedCompanyCar.carNo}}
社有車の車体カラー：{{schedCompanyCar.carColor}}
ドライバー氏名：{{schedCompanyCar.driverName}}
ドライバー電話番号：{{schedCompanyCar.driverTel}}
ドライバーemailアドレス：{{schedCompanyCar.driverEmail}}
備考：{{schedCompanyCar.remark}}
`;
export const TRANSPORTATION_CONTENT = `※本予定はMC Tripから送付されています。
　MC Tripから予定の修正・削除が実行されますので、Outlook上では編集しないでください。

備考：{{schedTransportation.remark}}
`;
export const EVENT_CONTENT = `※本予定はMC Tripから送付されています。
　MC Tripから予定の修正・削除が実行されますので、Outlook上では編集しないでください。

備考：{{schedEvent.remark}}
`;
export const ITINERARY_CONTENT = `※本予定はMC Tripから送付されています。
　MC Tripから予定の修正・削除が実行されますので、Outlook上では編集しないでください。

{{itineraryName}}
{{placesInfo}}
`;
//# sourceMappingURL=outlookEventTemplate.js.map