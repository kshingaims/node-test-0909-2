/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { orderBy, filter, uniq } from 'lodash-es';
import { isAfter } from 'date-fns';
import { Define } from '../../utils/define.js';
import { format, formatDate, formatDateTimeMiliSecond, replaceCRLF, strToBuf } from '../../utils/index.js';
import { createExpense } from '../../service/expense/expenseIndexService.js';
import { createSiteNotification, createTo_doList } from '../../service/notification/notificationService.js';
import { getNotificationSettingMapByIds } from '../../service/notification/notificationSettingService.js';
import { getUserByPid } from '../../service/user/userService.js';
import { sendSmtpMail } from '../../utils/smtpMail.js';
/**
 * 指定された引数に合致する旅程個人一覧テーブルのidの配列を返却する
 * @param prisma
 * @param pid
 * @param pageIndex
 * @param maxPage
 * @param year
 */
export async function searchItineraryList(prisma, pid, pageIndex, maxPage, year) {
    const where = {
        pid,
        flgDelete: false,
        itinerary: {
            flgDelete: false,
        },
    };
    // year指定がある場合は、その年に旅程が組まれているものを取得対象にする
    if (year) {
        where.OR = [
            { itineraryFrom: { lte: formatDate(new Date(`${year}-12-31`)) } },
            { itineraryTo: { gte: formatDate(new Date(`${year}-01-01`)) } },
        ];
    }
    const list = await prisma.itineraryIndividual.findMany({
        select: { itineraryId: true },
        take: maxPage,
        skip: maxPage * (pageIndex - 1),
        where,
        orderBy: [{ itineraryFrom: 'desc' }, { itineraryId: 'desc' }],
    });
    return list.map((item) => {
        return item.itineraryId;
    });
}
/**
 * 旅程一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryIds
 * @param isInternal API返却ではなく、内部処理で取得する場合に指定するフラグ
 * @returns
 */
export async function getItineraryIndividualList(prisma, pid, itineraryIds, isInternal = false) {
    const iIndividuals = await prisma.itineraryIndividual.findMany({
        where: { pid, itineraryId: { in: itineraryIds }, flgDelete: false, itinerary: { flgDelete: false } },
        select: {
            itineraryId: isInternal,
            itineraryName: true,
            itineraryFrom: true,
            itineraryTo: true,
            itineraryIndividualStatus: true,
            calendarId: isInternal,
            calendarUpdatedAt: isInternal,
            iCalUId: isInternal,
            updatedAt: isInternal,
            places: {
                select: {
                    city: {
                        select: {
                            id: true,
                            countryCode: true,
                            countryRoma: true,
                            country: true,
                            cityCode: true,
                            cityRoma: true,
                            city: true,
                            cityTimezone: true,
                            timezoneLabel: true,
                            currency: true,
                            timeTransitions: true,
                        },
                    },
                    stayDurationFrom: true,
                    stayDurationTo: true,
                },
            },
            itinerary: {
                select: {
                    id: true,
                    ownerPid: true,
                    itineraryIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    lastNameRoma: true,
                                    firstNameRoma: true,
                                    lastNameKanji: true,
                                    firstNameKanji: true,
                                    lastNameKana: true,
                                    firstNameKana: true,
                                    email: true,
                                },
                            },
                            createdAt: true,
                            updatedBy: isInternal,
                            flgDelete: true,
                        },
                    },
                },
            },
        },
        orderBy: [{ itineraryFrom: 'asc' }, { itineraryId: 'desc' }],
    });
    // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
    for (const individual of iIndividuals) {
        individual.places = orderBy(individual.places, ['stayDurationFrom'], ['asc']);
        individual.itinerary.itineraryIndividuals = orderBy(
        // 削除フラグが経っていない同行者(出張代表者)のみを抽出
        filter(individual.itinerary.itineraryIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    // 出張の開始期間のdescとなるように並び替え
    return orderBy(iIndividuals, ['places[0].stayDurationFrom'], ['desc']);
}
/**
 * pidとitineraryIdに合致するItineraryIndivudualを返す。
 * それに紐つく旅程(Itinerary)も含む。itineraryに紐つく予定取得はしない。
 *
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param isIncludeComanionsPlaces 同行者のplaces情報を取得するかどうか(default: false)
 * @return Itinerary
 */
export async function getItineraryIndividual(prisma, pid, itineraryId, isIncludeComanionsPlaces = false) {
    const iIndividual = await prisma.itineraryIndividual.findFirst({
        where: { pid, itineraryId, flgDelete: false, itinerary: { flgDelete: false } },
        select: {
            itineraryId: true,
            pid: true,
            itineraryName: true,
            itineraryFrom: true,
            itineraryTo: true,
            places: {
                select: {
                    stayDurationFrom: true,
                    stayDurationTo: true,
                    city: {
                        select: {
                            id: true,
                            countryCode: true,
                            countryRoma: true,
                            country: true,
                            cityCode: true,
                            cityRoma: true,
                            city: true,
                            cityTimezone: true,
                            timezoneLabel: true,
                            currency: true,
                            timeTransitions: true,
                        },
                    },
                },
            },
            itinerary: {
                select: {
                    id: true,
                    ownerPid: true,
                    itineraryIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    lastNameRoma: true,
                                    firstNameRoma: true,
                                    lastNameKanji: true,
                                    firstNameKanji: true,
                                    lastNameKana: true,
                                    firstNameKana: true,
                                    email: true,
                                },
                            },
                            places: isIncludeComanionsPlaces,
                            ownerPid: true,
                            updatedBy: true,
                            flgDelete: true,
                        },
                    },
                },
            },
        },
    });
    if (iIndividual) {
        // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
        iIndividual.places = orderBy(iIndividual.places, ['stayDurationFrom'], ['asc']);
        if (isIncludeComanionsPlaces) {
            for (const companion of iIndividual.itinerary.itineraryIndividuals) {
                companion.places = orderBy(companion.places, ['stayDurationFrom'], ['asc']);
            }
        }
    }
    return iIndividual;
}
/**
 * 旅程の登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props ItineraryCreateProps
 * @return ItineraryId
 */
export async function create(log, prisma, pid, user, props) {
    // Itineraryテーブル作成
    const itineraryId = await createItinerary(prisma, pid, user);
    const itineraryName = props.itineraryName;
    const { itineraryFrom, itineraryTo, places } = formatItineraryPlaces(props.places);
    // 旅程の同行者へのメール通知実施,サイト内通知用のテンプレート取得
    const settingMap = await getNotificationSettingMapByIds(prisma, [
        'add_itinerary_companion_mail',
        'add_itinerary_companion_site_notification',
    ]);
    // 出張代表者をitineraryIndividualとして最初に登録しておく
    const targetPids = [pid];
    // 同行者がいれば、その同行者の数だけ、itineraryIndividualとexpenseを登録する
    if (props.companions) {
        for (const companion of props.companions) {
            targetPids.push(companion.pid);
        }
    }
    for (const targetPid of targetPids) {
        const isOwner = targetPid === pid;
        // 旅程個人登録
        await createItineraryIndividual(prisma, pid, targetPid, user, itineraryId, itineraryName, itineraryFrom, itineraryTo, places);
        // 経費登録
        await createExpense(prisma, targetPid, user, itineraryId);
        // TODOリスト作成
        await createTo_doList(prisma, targetPid, user, itineraryId, isOwner);
        // 同行者設定されたことをメールで通知実施
        if (!isOwner) {
            const itineraryInfo = { itineraryName, itineraryFrom, itineraryTo, id: itineraryId };
            await sendSmtpMailAndCreateSiteNotificationToCompanion(log, prisma, targetPid, user, itineraryInfo, settingMap);
        }
    }
    return itineraryId;
}
/**
 * 旅程テーブルの登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @returns
 */
export async function createItinerary(prisma, pid, user) {
    // Itineraryテーブル作成
    const result = await prisma.itinerary.create({
        data: {
            ownerPid: pid,
            updatedBy: user.pid,
        },
    });
    return result.id;
}
/**
 * 旅程テーブルの論理削除。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @returns
 */
export async function deleteItinerary(prisma, user, itineraryId) {
    // Itineraryテーブル作成
    await prisma.itinerary.update({
        where: {
            id: itineraryId,
        },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * 旅程個人の登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param itineraryId
 * @param itineraryName
 * @param itineraryFrom
 * @param itineraryTo
 * @param places
 */
export async function createItineraryIndividual(prisma, ownerPid, pid, user, itineraryId, itineraryName, itineraryFrom, itineraryTo, places) {
    await prisma.itineraryIndividual.create({
        data: {
            pid,
            itineraryId,
            itineraryName,
            itineraryFrom,
            itineraryTo,
            ownerPid,
            updatedBy: user.pid,
            places: { createMany: { data: places } },
            itineraryIndividualStatus: { create: { cycleLinkStatus: 0, updatedBy: user.pid } },
        },
    });
}
/**
 * places情報を、stayDurationFromでソートし、
 * itineraryFrom, itineraryToを取得する
 * @param places
 * @returns
 */
export function formatItineraryPlaces(places) {
    // stayDurationFromの昇順でソート
    const sortedPlaces = orderBy(places.map((place) => {
        return {
            cityId: place.cityId,
            stayDurationFrom: new Date(place.stayDurationFrom),
            stayDurationTo: new Date(place.stayDurationTo),
        };
    }), ['stayDurationFrom'], ['asc']);
    // 本日よりも前日となる出張はないので、本日を一旦セット
    const itineraryFromTypeDate = sortedPlaces[0].stayDurationFrom;
    const today = new Date();
    let itineraryTo = formatDate(today);
    for (const place of sortedPlaces) {
        const stayDurationTo = new Date(place.stayDurationTo);
        // 旅程の最終日を取得
        if (isAfter(stayDurationTo, today)) {
            itineraryTo = formatDate(stayDurationTo);
        }
    }
    const itineraryFrom = formatDate(itineraryFromTypeDate);
    return { itineraryFrom, itineraryTo, places: sortedPlaces };
}
/**
 * 旅程個人の更新作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param itineraryId
 * @param itineraryName
 * @param itineraryFrom
 * @param itineraryTo
 * @param places
 */
export async function updateItineraryIndividual(prisma, ownerPid, pid, user, itineraryId, itineraryName, itineraryFrom, itineraryTo, places) {
    // 旅程個人テーブルに紐つくItineraryIndividualPlaceを削除(後で新規作成をする)
    await prisma.itineraryIndividualPlace.deleteMany({
        where: { itineraryId, pid },
    });
    // 旅程個人テーブルの更新(ItineraryIndividualPlaceデータは新規登録)
    await prisma.itineraryIndividual.update({
        where: { itineraryId_pid: { itineraryId, pid } },
        data: {
            pid,
            itineraryName,
            itineraryFrom,
            itineraryTo,
            places: { createMany: { data: places } },
            flgDelete: false,
            ownerPid,
            updatedBy: user.pid,
        },
    });
}
/**
 * 旅程個人テーブルデータを削除する(論理削除)
 * @param prisma
 * @param pid
 * @param user
 * @param itineraryId
 */
export async function deleteItineraryIndividual(prisma, pid, user, itineraryId) {
    await prisma.itineraryIndividual.update({
        where: { itineraryId_pid: { itineraryId, pid } },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * 同行者指定されている同行者のpidが存在するものかどうかチェックする。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param itineraryId 旅程ID
 * @param pids チェック対象となる同行者
 * @returns
 */
export async function isExistsItineraryCompanions(prisma, itineraryId, pids) {
    if (!pids || pids.length <= 0) {
        return undefined;
    }
    const uniquePids = uniq(pids);
    // 同じPIDの人が複数回指定されている
    if (uniquePids.length !== pids.length) {
        return { code: Define.ERROR_CODES.W00118, status: 400 };
    }
    const itineraryIndividuals = await prisma.itineraryIndividual.findMany({
        select: { pid: true },
        where: {
            pid: { in: pids },
            itineraryId,
            flgDelete: false,
            itinerary: {
                flgDelete: false,
            },
        },
    });
    if (pids.length === itineraryIndividuals.length) {
        return undefined;
    }
    else {
        return { code: Define.ERROR_CODES.W00104, status: 400 };
    }
}
/**
 * フライト手配、ホテル手配時において、
 * 同行者指定されている同行者のpidが存在するものかどうかチェックする。
 * フライト手配、ホテル手配では、手配実施者についても、companions内に情報が含まれているので、
 * 手配者の情報もきちんと存在しているかどうかもチェックする。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param pid 処理対象アカウントのpid
 * @param itineraryId 旅程ID
 * @param schedFlights 手配実施するフライト手配(予定)一覧
 */
export async function isExistsItineraryCompanionsForArrgt(prisma, pid, itineraryId, schedFlights) {
    const checkResult = isExistsItineraryCompanionsForArrgtInner(pid, schedFlights);
    if (checkResult.error) {
        return checkResult.error;
    }
    return await isExistsItineraryCompanions(prisma, itineraryId, checkResult.pids);
}
export function isExistsItineraryCompanionsForArrgtInner(pid, schedFlights) {
    const existsCheckPidMap = {};
    for (const schedFlight of schedFlights) {
        const checkedPids = schedFlight.companions.map((item) => {
            return item.pid;
        });
        // 手配者のpidが、companionsに含まれているかをチェック
        if (!checkedPids.includes(pid)) {
            return { pids: [], error: { code: Define.ERROR_CODES.W00119, status: 400 } };
        }
        const uniqueCheckPidMap = {};
        for (const checkedPid of checkedPids) {
            // 同じPIDの人が複数回指定されている
            if (uniqueCheckPidMap[checkedPid]) {
                return { pids: [], error: { code: Define.ERROR_CODES.W00118, status: 400 } };
            }
            uniqueCheckPidMap[checkedPid] = true;
            // companionsとして初めて指定されているpidになるので存在チェック対象にする
            if (!existsCheckPidMap[checkedPid]) {
                existsCheckPidMap[checkedPid] = true;
            }
        }
    }
    return { pids: Object.keys(existsCheckPidMap) };
}
export async function sendSmtpMailAndCreateSiteNotificationToCompanion(log, prisma, targetPid, loginUser, itineraryInfo, settingMap) {
    const smtpSetting = settingMap['add_itinerary_companion_mail'];
    // SMTP通知処理
    if (!smtpSetting.title || !smtpSetting.content || !smtpSetting.linkUrl) {
        throw new Error('title, content linkUrl is necessary.');
    }
    const user = await getUserByPid(prisma, targetPid);
    if (!user || !user.email) {
        throw new Error(`user or user.email must be exist. [pid: ${targetPid}]`);
    }
    const itineraryFrom = formatDate(new Date(itineraryInfo.itineraryFrom), 'yyyyMMdd');
    const itineraryTo = formatDate(new Date(itineraryInfo.itineraryTo), 'MMdd');
    // リンクURL整形
    let linkUrl = format(smtpSetting.linkUrl, { domain: Define.DOMAIN, itineraryId: itineraryInfo.id });
    // メール本文整形
    const body = replaceCRLF(format(smtpSetting.content, { loginUser, itineraryFrom, itineraryTo, itinerary: itineraryInfo, linkUrl }));
    // メール送信
    sendSmtpMail(log, { to: [user.email], title: smtpSetting.title || '', body });
    // サイト上での通知実施
    const setting = settingMap['add_itinerary_companion_site_notification'];
    if (!setting.content || !setting.linkUrl) {
        throw new Error('content, linkUrl is necessary.');
    }
    linkUrl = format(setting.linkUrl, { domain: Define.DOMAIN, itineraryId: itineraryInfo.id });
    await createSiteNotification(prisma, targetPid, itineraryInfo.id, setting.content, linkUrl);
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、outlook calendar連携時の内部ロジックとして実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param pid
 * @param itineraryId 旅程ID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @param iCalUId outlookイベント固有ID
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, pid, itineraryId, calendarId, calendarUpdatedAt, iCalUId) {
    try {
        const updatedAt = calendarUpdatedAt ? new Date(formatDateTimeMiliSecond(new Date(calendarUpdatedAt))) : new Date();
        await prisma.itineraryIndividual.update({
            where: { itineraryId_pid: { itineraryId, pid } },
            data: { calendarId: strToBuf(calendarId) || null, calendarUpdatedAt, iCalUId, updatedAt },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
//# sourceMappingURL=itineraryService.js.map