/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { convertListToMapByUniqueKey } from '../../utils/index.js';
export const NOTIFICATION_SETTING_TYPES = ['to_do', 'site_notice', 'webpush', 'smtp_mail', 'azure_mail'];
export const TO_DO_TARGET_PERSONS = ['all', 'owner'];
export const TO_DO_WHEN_CREATES = ['init'];
export const TARGET_PERSIONS = ['all'];
/**
 * 通知設定一覧の返却。
 * @param prisma PrismaClient
 * @param type タイプ情報
 * @return NotificationSetting[]
 */
export async function getNotificationSettingsByType(prisma, type) {
    const settings = await prisma.notificationSetting.findMany({
        select: {
            id: true,
            title: true,
            content: true,
            linkUrl: true,
            options: true,
        },
        where: { type },
        orderBy: { id: 'asc' },
    });
    return settings;
}
/**
 * 通知設定情報の返却。
 * @param prisma PrismaClient
 * @param id ID
 * @return NotificationSetting
 */
export async function getNotificationSettingById(prisma, id) {
    const setting = await prisma.notificationSetting.findUnique({
        select: {
            id: true,
            title: true,
            content: true,
            linkUrl: true,
            options: true,
        },
        where: { id },
    });
    return setting;
}
/**
 * 通知設定情報の返却。
 * @param prisma PrismaClient
 * @param id ID
 * @return NotificationSetting
 */
export async function getNotificationSettingMapByIds(prisma, ids) {
    const settings = await prisma.notificationSetting.findMany({
        select: {
            id: true,
            title: true,
            content: true,
            linkUrl: true,
            options: true,
        },
        where: { id: { in: ids } },
    });
    if (settings.length !== ids.length) {
        throw new Error('some id is not collect.');
    }
    return convertListToMapByUniqueKey(settings, 'id');
}
/**
 * NotificationSettingを新規登録する。
 * @param prisma PrismaClient
 * @param nSetting NotificationSetting
 * @return NotificationSetting
 */
export async function createNotificationSetting(prisma, nSetting) {
    const insertResult = await prisma.notificationSetting.create({
        data: {
            id: nSetting.id,
            type: nSetting.type,
            title: nSetting.title || null,
            content: nSetting.content || null,
            linkUrl: nSetting.linkUrl || null,
            options: nSetting.options || {},
        },
    });
    return insertResult;
}
export async function deleteNotificationSettingByType(prisma, type) {
    await prisma.notificationSetting.deleteMany({ where: { type } });
}
//# sourceMappingURL=notificationSettingService.js.map