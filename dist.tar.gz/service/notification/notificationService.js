import { getNotificationSettingsByType, } from '../../service/notification/notificationSettingService.js';
import { format, formatDate } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { isUpdateNotFound } from '../../utils/error.js';
import { orderBy } from 'lodash-es';
export const STR_TO_DO = 'to_do';
export const STR_SITE_NOTICE = 'site_notice';
const domain = Define.DOMAIN;
/**
 * ToDoリストの登録作業。旅程に登録される時点で生成を行う
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param itineraryId
 * @param isOwner
 */
export async function createTo_doList(prisma, pid, user, itineraryId, isOwner, whenCreate = 'init') {
    const nSettings = await getNotificationSettingsByType(prisma, STR_TO_DO);
    if (nSettings.length > 0) {
        // optionsのsortの降順で並べ替えた上で、順次To Do登録処理を実施する。
        for (const nSetting of orderBy(nSettings, ['options.sort'], ['desc'])) {
            const options = nSetting.options;
            // whenCreateがOPTIONS設定のwhenCreateと同じものだけだ、生成される
            if (options.whenCreate === whenCreate) {
                // owner用のto_doはownerのみに生成されるようにする。
                if (options.targetPerson === 'all' || (options.targetPerson === 'owner' && isOwner)) {
                    await prisma.notification.create({
                        data: {
                            pid,
                            itineraryId,
                            type: STR_TO_DO,
                            content: nSetting.content || '',
                            linkUrl: nSetting.linkUrl ? format(nSetting.linkUrl, { domain, itineraryId }) : null,
                            notificationSettingId: nSetting.id,
                            updatedBy: user.pid,
                        },
                    });
                }
            }
        }
    }
}
export async function createSiteNotification(prisma, pid, itineraryId, content, linkUrl) {
    await prisma.notification.create({
        data: {
            pid,
            itineraryId,
            type: STR_SITE_NOTICE,
            content,
            linkUrl,
            updatedBy: pid,
        },
    });
}
export async function getTo_doList(prisma, pid, itineraryId, isInternal = false) {
    return await _getTo_DoList(prisma, { pid, itineraryId }, isInternal);
}
export async function getTo_do(prisma, pid, id, itineraryId) {
    const list = await _getTo_DoList(prisma, { pid, id, itineraryId });
    if (list && list.length === 1) {
        return list[0];
    }
}
async function _getTo_DoList(prisma, where, isInternal = false) {
    where.type = STR_TO_DO;
    const list = await prisma.notification.findMany({
        select: {
            id: true,
            itineraryId: true,
            content: true,
            linkUrl: true,
            flgFinished: true,
            notificationSetting: {
                select: {
                    options: true,
                },
            },
        },
        where,
        orderBy: { id: 'asc' },
    });
    if (!isInternal) {
        for (const row of list) {
            const item = row;
            const options = row.notificationSetting?.options || {};
            item.isAfter = options.remindAfter || false;
            item.isOwnerTask = options.targetPerson === 'owner';
            row.notificationSetting = null;
        }
    }
    return list;
}
export async function getSiteNotices(prisma, pid, itineraryId) {
    return await prisma.notification.findMany({
        select: {
            id: true,
            content: true,
            linkUrl: true,
            firstDisplayDate: true,
            createdAt: true,
        },
        where: { pid, itineraryId, type: STR_SITE_NOTICE },
        orderBy: { id: 'desc' },
    });
}
/**
 * flgFinishedの値を更新する。
 * @param prisma
 * @param id
 * @param pid
 * @param user
 * @param itineraryId
 * @param flgFinished
 */
export async function updateFlgFinishedById(prisma, id, pid, user, itineraryId, flgFinished) {
    try {
        await prisma.notification.update({
            data: { flgFinished, updatedBy: user.pid },
            where: { id, pid, itineraryId },
        });
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
/**
 * sendRemindDateに現在システム日を設定する。本処理はバッチ実行からの実行のみを想定
 * @param prisma
 * @param ids
 */
export async function updateSendRemindDateByIds(prisma, ids) {
    const res = await prisma.notification.updateMany({
        data: { sendRemindDate: formatDate(new Date()) },
        where: { id: { in: ids } },
    });
    if (res.count === ids.length) {
        return true;
    }
    return false;
}
/**
 * 指定されたids一覧のレコードのfirstDisplayDateを本日日付で更新する。
 * 本メソッドは、内部での限定的な利用想定の為、入力チェック等は実施していない
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param ids
 */
export async function setFirstDisplayDateToday(prisma, pid, itineraryId, ids) {
    const today = formatDate(new Date());
    await prisma.notification.updateMany({
        data: { firstDisplayDate: today },
        where: { pid, itineraryId, id: { in: ids } },
    });
}
//# sourceMappingURL=notificationService.js.map