import { formatDate } from '../../utils/index.js';
import { addDays, addMinutes } from 'date-fns';
import { Define } from '../../utils/define.js';
import { filterDraftSched } from '../../service/companyCar/companyCarService.js';
export async function getTargetsOfSendRemindsBeforeTrip(prisma, targetDate) {
    const today = formatDate(new Date());
    const targetDateStr = formatDate(targetDate);
    return await prisma.itinerary.findMany({
        select: {
            id: true,
            notifications: {
                select: {
                    id: true,
                    pid: true,
                    content: true,
                    linkUrl: true,
                    type: true,
                    flgFinished: true,
                    sendRemindDate: true,
                    notificationSetting: true,
                },
            },
            itineraryIndividuals: {
                select: {
                    itineraryFrom: true,
                    itineraryTo: true,
                    itineraryName: true,
                    pid: true,
                    user: {
                        select: {
                            email: true,
                        },
                    },
                },
            },
        },
        where: {
            flgDelete: false,
            itineraryIndividuals: { some: { flgDelete: false, itineraryFrom: { lte: targetDateStr, gt: today } } },
            // ATTENTION: prismaのsomeを複数回利用すると、検索条件が正しく動作しなくなる。prismaのバグの可能性大
            // notifications: { some: { type: STR_TO_DO, flgFinished: false, sendRemindDate: null } },
        },
    });
}
export async function getTargetsOfSendRemindsAfterTrip(prisma, targetDate) {
    const targetDateStr = formatDate(targetDate);
    const limitDateStr = formatDate(addDays(targetDate, -7));
    return await prisma.itinerary.findMany({
        select: {
            id: true,
            notifications: {
                select: {
                    id: true,
                    pid: true,
                    content: true,
                    linkUrl: true,
                    type: true,
                    flgFinished: true,
                    sendRemindDate: true,
                    notificationSetting: true,
                },
            },
            itineraryIndividuals: {
                select: {
                    itineraryFrom: true,
                    itineraryTo: true,
                    itineraryName: true,
                    pid: true,
                    user: {
                        select: {
                            email: true,
                        },
                    },
                },
            },
        },
        where: {
            flgDelete: false,
            itineraryIndividuals: { some: { flgDelete: false, itineraryTo: { lte: targetDateStr, gt: limitDateStr } } },
            // ATTENTION: prismaのsomeを複数回利用すると、検索条件が正しく動作しなくなる。prismaのバグの可能性大
            // notifications: { some: { type: STR_TO_DO, flgFinished: false, sendRemindDate: null } },
        },
    });
}
/**
 * WEBPUSH,サイト内通知実施対象となるフライト予定の取得処理
 * @param prisma
 * @param options
 * @param isFinalNotification
 * @returns
 */
export async function getFlightSchedListForNotification(prisma, options, isFinalNotification = false) {
    const limitDatetime = addMinutes(options.targetDatetime, -1 * options.targetSpanMinutes);
    return await prisma.schedFlight.findMany({
        select: {
            id: true,
            itineraryId: true,
            departureDateTime: true,
            departureAirport: true,
            departureTerminal: true,
            departureCity: true,
            departureTimezone: true,
            arrivalDateTime: true,
            arrivalAirport: true,
            arrivalTerminal: true,
            arrivalCity: true,
            arrivalTimezone: true,
            flightNumber: true,
            airline: true,
            remark: true,
            schedFlightIndividuals: {
                select: {
                    pid: true,
                    eticket: true,
                    seatClass: true,
                    seatNo: true,
                    flgDelete: true,
                    flgReject: true,
                },
            },
        },
        where: {
            itinerary: {
                flgDelete: false,
            },
            flgDelete: false,
            notificationStatus: {
                notIn: isFinalNotification
                    ? [Define.SETTINGS.NOTIFICATION_STATUS.SEND_FINAL]
                    : [Define.SETTINGS.NOTIFICATION_STATUS.SEND, Define.SETTINGS.NOTIFICATION_STATUS.SEND_FINAL],
            },
            departureDateTime: { lte: options.targetDatetime, gt: limitDatetime },
        },
    });
}
export async function getCompanyCarSchedListForNotification(prisma, options) {
    const limitDatetime = addMinutes(options.targetDatetime, -1 * options.targetSpanMinutes);
    const schedsWithDraft = await prisma.schedCompanyCar.findMany({
        select: {
            id: true,
            itineraryId: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            departureLocation: true,
            arrangedCars: {
                select: {
                    companyCarId: true,
                    carNo: true,
                    carModel: true,
                    carColor: true,
                    driverId: true,
                    driverName: true,
                    driverEmail: true,
                    driverTel: true,
                },
            },
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            flgArrgt: true,
            schedCompanyCarIndividuals: {
                select: {
                    pid: true,
                    flgDelete: true,
                    flgReject: true,
                },
            },
        },
        where: {
            itinerary: {
                flgDelete: false,
            },
            flgDelete: false,
            notificationStatus: {
                notIn: [Define.SETTINGS.NOTIFICATION_STATUS.SEND],
            },
            startDateTime: { lte: options.targetDatetime, gt: limitDatetime },
        },
    });
    return filterDraftSched(schedsWithDraft, false);
}
//# sourceMappingURL=itineraryNotificationService.js.map