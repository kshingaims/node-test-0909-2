/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { filter, orderBy } from 'lodash-es';
import { Define } from '../../utils/define.js';
import { convertListToMapByUniqueKey, formatDateTimeMiliSecond, formatUtcDateTime, getLocalDate, isBeforeToday, isFromDatetimeBeforeToDatetime, strToBuf, } from '../../utils/index.js';
import { isExistsItineraryCompanions } from '../../service/itinerary/itineraryService.js';
import { getExpenseIds } from '../../service/expense/expenseIndexService.js';
import { createExpenseAccommodation } from '../../service/expense/expenseAccommodationService.js';
/**
 * 処理対象アカウントが表示可能なホテル予定一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param hotelId
 * @returns
 */
export async function getHotelSchedList(prisma, pid, itineraryId, hotelId, isForeignStaff = false, isOutlookIntegration = false) {
    const where = {
        pid,
        schedHotel: { flgDelete: !isOutlookIntegration ? false : undefined },
        flgDelete: false,
        flgReject: false,
    };
    if (!hotelId && !itineraryId) {
        // 旅程IDもしくはフライトIDは指定必須
        throw new Error('unreachable error.');
    }
    if (hotelId) {
        where.schedHotelId = hotelId;
    }
    if (itineraryId) {
        where.schedHotel = { itineraryId: itineraryId, flgDelete: !isOutlookIntegration ? false : undefined };
    }
    const schedHotelIndividuals = await prisma.schedHotelIndividual.findMany({
        where,
        select: {
            // arrgtRemarkは同行者側で手配作成者だけが見れる
            price: !isForeignStaff,
            currency: !isForeignStaff,
            flgSmoking: !isForeignStaff,
            remark: !isForeignStaff,
            calendarId: isOutlookIntegration,
            calendarUpdatedAt: isOutlookIntegration,
            flgReject: true,
            schedHotel: {
                select: {
                    id: true,
                    itineraryId: true,
                    name: true,
                    hotelId: true,
                    cityId: true,
                    address: true,
                    checkInDateTime: true,
                    checkOutDateTime: true,
                    timezone: true,
                    checkinOutInputStatus: true,
                    remark: true,
                    arrgtEmail: true,
                    ownerPid: true,
                    flgArrgt: true,
                    flgDelete: true,
                    arrgtStatus: true,
                    calendarId: isOutlookIntegration,
                    calendarUpdatedAt: isOutlookIntegration,
                    iCalUId: isOutlookIntegration,
                    calendarId2: isOutlookIntegration,
                    iCalUId2: isOutlookIntegration,
                    calendarId3: isOutlookIntegration,
                    iCalUId3: isOutlookIntegration,
                    updatedAt: isOutlookIntegration,
                    hotel: {
                        select: {
                            id: true,
                            cityId: true,
                            name: true,
                            address: true,
                            accessToOfficeMinute: true,
                            meansOfAccess: true,
                            checkInOut: true,
                            url: true,
                            tel: true,
                            hotelEmail: true,
                            reservationTel: true,
                            reservationEmail: true,
                            reservationInfo: true,
                            breakfast: true,
                            note: true,
                            recommendation: true,
                            recommendationPoint: true,
                            googleRating: true,
                            googleLocation: true,
                            hotelRooms: {
                                select: {
                                    id: true,
                                    name: true,
                                    price: true,
                                    currency: true,
                                    note: true,
                                },
                            },
                            city: {
                                select: {
                                    id: true,
                                    countryCode: true,
                                    countryRoma: true,
                                    country: true,
                                    cityCode: true,
                                    cityRoma: true,
                                    city: true,
                                    cityTimezone: true,
                                    timezoneLabel: true,
                                    currency: true,
                                    timeTransitions: true,
                                },
                            },
                            hotelFiles: {
                                select: {
                                    path: true,
                                    id: true,
                                    originalFileName: true,
                                    size: true,
                                },
                            },
                        },
                    },
                    city: {
                        select: {
                            id: true,
                            countryCode: true,
                            countryRoma: true,
                            country: true,
                            cityCode: true,
                            cityRoma: true,
                            city: true,
                            cityTimezone: true,
                            timezoneLabel: true,
                            currency: true,
                            timeTransitions: true,
                        },
                    },
                    schedHotelIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    firstNameRoma: true,
                                    lastNameRoma: true,
                                    firstNameKanji: true,
                                    lastNameKanji: true,
                                    firstNameKana: true,
                                    lastNameKana: true,
                                    email: true,
                                },
                            },
                            // remarkはホテル手配/予定作成者も見れない
                            price: true,
                            currency: true,
                            flgSmoking: true,
                            hotelRoomId: true,
                            arrgtRemark: true,
                            flgReject: true,
                            createdAt: true,
                            flgDelete: true, // 作成者/同行者
                        },
                    },
                    schedHotelFiles: {
                        select: {
                            id: true,
                            originalFileName: true,
                            size: true,
                            ownerPid: true,
                            path: isOutlookIntegration,
                            azAttachmentId: isOutlookIntegration,
                            azAttachmentUpdatedAt: isOutlookIntegration,
                        },
                    },
                },
            },
        },
        orderBy: {
            // 取得されるホテル一覧は「1.ホテルチェックイン日時の昇順(asc)」となるように並び替え・一覧取得する。
            schedHotel: {
                checkInDateTime: 'asc',
            },
        },
    });
    // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
    for (const schedHotelIndividual of schedHotelIndividuals) {
        // 同行者(対象アカウントがschedHotelIndividualのownerPidと一致しない場合)や海外担当者には、手配時の情報となる同行者個人に紐つく情報も返却しない。
        if (schedHotelIndividual.schedHotel.ownerPid !== pid || isForeignStaff) {
            for (const changeSchedHotelIndividual of schedHotelIndividual.schedHotel.schedHotelIndividuals) {
                changeSchedHotelIndividual.price = null;
                changeSchedHotelIndividual.currency = null;
                changeSchedHotelIndividual.flgSmoking = false;
                changeSchedHotelIndividual.hotelRoomId = null;
                changeSchedHotelIndividual.arrgtRemark = null;
            }
        }
        // ホテル予定(schedHotel)の中にあるschedHotelIndividualsについては、作成日時の昇順(asc)となるように、ホテル予定一覧の全レコードに対して、並び替えを実施する。
        schedHotelIndividual.schedHotel.schedHotelIndividuals = orderBy(
        // ホテル予定(schedHotel)の中にあるschedHotelIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedHotelIndividual.schedHotel.schedHotelIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return schedHotelIndividuals;
}
/**
 * 旅程Excelダウンロード用に、対象旅程IDに紐づくホテル予定一覧を取得する
 * @param prisma
 * @param itineraryId
 * @returns
 */
export async function getHotelsForExcelDownload(prisma, itineraryId) {
    const schedHotels = await prisma.schedHotel.findMany({
        where: {
            flgDelete: false,
            itineraryId,
        },
        select: {
            id: true,
            itineraryId: true,
            name: true,
            hotelId: true,
            cityId: true,
            address: true,
            checkInDateTime: true,
            checkOutDateTime: true,
            timezone: true,
            checkinOutInputStatus: true,
            remark: true,
            arrgtEmail: true,
            ownerPid: true,
            flgArrgt: true,
            flgDelete: true,
            arrgtStatus: true,
            schedHotelIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                        },
                    },
                    flgReject: true,
                    flgDelete: true,
                },
            },
        },
        orderBy: {
            // 取得されるホテル一覧は「1.ホテルチェックイン日時の昇順(asc)」となるように並び替え・一覧取得する。
            checkInDateTime: 'asc',
        },
    });
    return schedHotels;
}
/**
 * ホテル予定及びホテル個人予定の登録作業。
 * ホテル予定のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props HotelSchedCreateProps
 * @return
 */
export async function createSchedHotel(prisma, pid, user, props) {
    // SchedHotelテーブル作成
    const result = await prisma.schedHotel.create({
        data: {
            ownerPid: pid,
            itineraryId: props.itineraryId,
            name: props.name,
            cityId: props.cityId,
            address: props.address,
            checkInDateTime: new Date(props.checkInDateTime),
            checkOutDateTime: new Date(props.checkOutDateTime),
            timezone: props.timezone,
            checkinOutInputStatus: props.checkinOutInputStatus,
            remark: props.remark,
            flgArrgt: props.flgArrgt,
            arrgtStatus: Define.SETTINGS.ARRGT_STATUS.NO_ARRGT,
            updatedBy: user.pid,
        },
    });
    const schedHotelId = result.id;
    // 出張代表者をSchedHotelIndividualとして最初に登録しておく
    const targetPids = [pid];
    // 同行者がいれば、その同行者の数だけ、SchedHotelIndividualを登録する
    if (props.companions) {
        for (const companion of props.companions) {
            targetPids.push(companion.pid);
        }
    }
    for (const targetPid of targetPids) {
        await prisma.schedHotelIndividual.create({
            data: {
                schedHotelId,
                pid: targetPid,
                updatedBy: user.pid,
            },
        });
    }
    return schedHotelId;
}
/**
 * ホテル予定及びホテル個人予定の更新作業。
 * ホテル予定のみ更新する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedHotel SchedHotelInschedHotelIndividuals
 * @param props HotelSchedUpdateProps
 * @return
 */
export async function updateSchedHotel(prisma, pid, user, schedHotel, props) {
    let arrgtStatus = undefined;
    if (schedHotel.arrgtStatus !== Define.SETTINGS.ARRGT_STATUS.NO_ARRGT) {
        // flgArrgtがfalse指定の場合は、arrgtStatusを手配済(1)、true指定の場合は、arrgtStatusを確定済(2)にする
        if (props.flgArrgt) {
            arrgtStatus = Define.SETTINGS.ARRGT_STATUS.FINISHED;
        }
        else {
            arrgtStatus = Define.SETTINGS.ARRGT_STATUS.START;
        }
    }
    await prisma.schedHotel.update({
        where: { id: schedHotel.id },
        data: {
            id: props.id,
            ownerPid: pid,
            itineraryId: props.itineraryId,
            name: props.name,
            cityId: props.cityId,
            address: props.address,
            checkInDateTime: new Date(props.checkInDateTime),
            checkOutDateTime: new Date(props.checkOutDateTime),
            timezone: props.timezone,
            checkinOutInputStatus: props.checkinOutInputStatus,
            remark: props.remark,
            flgArrgt: props.flgArrgt,
            arrgtStatus: arrgtStatus,
            updatedBy: user.pid,
        },
    });
    // 手配ステータス(arrgtStatus)が、手配不要(9)の場合
    if (schedHotel.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.NO_ARRGT) {
        const companionPids = props.companions ? props.companions?.map((companion) => companion.pid) : [];
        companionPids.unshift(pid); //予定作成者を先頭に追加する
        const schedHotelIndividualPids = [];
        for (const schedHotelIndividual of schedHotel.schedHotelIndividuals) {
            // 変更前状態の時は、対象の同行者には削除フラグが立っていない場合
            if (!schedHotelIndividual.flgDelete) {
                if (!companionPids.includes(schedHotelIndividual.pid)) {
                    // DB取得したSchedHotelIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧に含まれていない場合は、同行者削除(flgDelete=true)を実施する。
                    await updateSchedHotelIndividual(prisma, schedHotelIndividual.pid, user, schedHotelIndividual.schedHotelId, true);
                }
                // DB取得したSchedHotelIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧にも含まれている場合は、何も処理しない(同行者指定済)
            }
            else if (schedHotelIndividual.flgDelete) {
                if (companionPids.includes(schedHotelIndividual.pid)) {
                    // DB取得したSchedHotelIndividualがflgDelete=trueとなっており、クライアント側から取得した同行者一覧に含まれている場合は、同行者の再指定(flgDelete=false)を実施する。
                    await updateSchedHotelIndividual(prisma, schedHotelIndividual.pid, user, schedHotelIndividual.schedHotelId, false);
                }
            }
            // DB取得したSchedHotelIndividualのpid一覧作成
            schedHotelIndividualPids.push(schedHotelIndividual.pid);
        }
        // クライアント側から取得した同行者一覧の中にあるpidが、DB取得したSchedHotelIndividual一覧の中に含まれていない場合は、同行者の新規追加実施
        for (const companionPid of companionPids) {
            if (!schedHotelIndividualPids.includes(companionPid)) {
                await prisma.schedHotelIndividual.create({
                    data: {
                        schedHotelId: schedHotel.id,
                        pid: companionPid,
                        updatedBy: user.pid,
                    },
                });
            }
        }
        // 自身の個人情報の更新:予定のarrgtStatusが9の場合は実施しない
    }
    else if (schedHotel.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.FINISHED ||
        schedHotel.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.START) {
        /**
         * 自身の個人情報の更新:
         * ホテル予定のarrgtStatusが、1:手配済 or 2:確定済となっている場合のみ、schedHotelIndividualで連携された個人情報の内容で、schedHotelIndividualを更新する。
         */
        await updateSchedHotelIndividual(prisma, pid, user, props.id, false, props.schedHotelIndividual?.price, props.schedHotelIndividual?.remark);
        // 同行者(companions)の追加、削除はさせない。companionsが指定されていても、companionsの追加、削除は実施しない(無視する)。
    }
    else {
        throw new Error('unreachable error.');
    }
}
/**
 * ホテル個人予定テーブルの更新作業。
 * ホテル個人予定更新(手配の場合) / ホテル予定(予定の更新) のみ更新する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedHotelIndividual SchedHotelInschedHotelIndividuals
 * @param props HotelSchedIndividualUpdateProps
 * @return
 */
export async function updateSchedHotelIndividual(prisma, pid, user, schedHotelId, flgDelete, price, remark) {
    await prisma.schedHotelIndividual.update({
        where: { schedHotelId_pid: { schedHotelId, pid: pid } },
        data: {
            flgDelete: flgDelete,
            price: price,
            remark: remark,
            updatedBy: user.pid,
        },
    });
}
/**
 * ホテル個人予定テーブルの更新作業。
 * ホテル予定参加の拒否
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedHotelId schedHotelId
 * @param flgReject boolean
 * @return
 */
export async function rejectSchedHotelIndividual(prisma, pid, user, schedHotelId, flgReject) {
    await prisma.schedHotelIndividual.update({
        where: { schedHotelId_pid: { schedHotelId, pid: pid } },
        data: {
            flgReject,
            updatedBy: user.pid,
        },
    });
}
/**
 * ホテル予定(手配は除く)の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param schedHotelId ホテル予定ID
 * @return
 */
export async function deleteSchedHotel(prisma, user, schedHotelId) {
    // クライアント側から送信されたidに合致するホテル予定を削除する(削除フラグをたてる)
    await prisma.schedHotel.update({
        where: { id: schedHotelId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * ホテル手配に関連する登録作業。
 * ホテル手配のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param arrgtProps HotelArrgtCreateProps
 * @return
 */
export async function createArrgtHotel(prisma, pid, user, arrgtProps, dbHotelMastersMap) {
    const createdSchedHotelIds = [];
    // schedHotelの新規登録実施
    for (const props of arrgtProps.schedHotels) {
        // マスタからpropsのhotelIdに一致する情報を取得
        const dbHotelMaster = props.hotelId ? dbHotelMastersMap[props.hotelId] : undefined;
        const resultSchedHotel = await prisma.schedHotel.create({
            data: {
                itineraryId: arrgtProps.itineraryId,
                name: dbHotelMaster?.name,
                address: dbHotelMaster?.address,
                cityId: dbHotelMaster?.city.id,
                hotelId: props.hotelId,
                checkInDateTime: new Date(props.checkInDateTime),
                checkOutDateTime: new Date(props.checkOutDateTime),
                remark: props.remark,
                timezone: props.timezone,
                checkinOutInputStatus: props.checkinOutInputStatus,
                arrgtEmail: props.arrgtEmail,
                ownerPid: pid,
                arrgtStatus: Define.SETTINGS.ARRGT_STATUS.START,
                updatedBy: user.pid,
            },
        });
        // ホテル予定情報(arrgtHotelSchedHotel)で利用する配列
        createdSchedHotelIds.push(resultSchedHotel.id);
        // 手配ではpropsの同行者に作成者も含まれている
        for (const companion of props.companions) {
            const companionHotelRoom = dbHotelMaster?.hotelRooms.find((item) => item.id === companion.hotelRoomId);
            await prisma.schedHotelIndividual.create({
                data: {
                    schedHotelId: resultSchedHotel.id,
                    pid: companion.pid,
                    hotelRoomId: companion.hotelRoomId,
                    roomName: companionHotelRoom?.name,
                    price: companionHotelRoom?.price,
                    currency: companionHotelRoom?.currency,
                    flgSmoking: companion.flgSmoking,
                    arrgtRemark: companion.arrgtRemark,
                    updatedBy: user.pid,
                },
            });
        }
    }
    // ホテル手配の新規登録処理実施。
    const resultArrgtHotel = await prisma.arrgtHotel.create({
        data: {
            itineraryId: arrgtProps.itineraryId,
            ownerPid: pid,
            flgDelete: false,
            updatedBy: user.pid,
        },
    });
    //ホテル手配に紐つくホテル予定情報が、schedFlishtsで指定されたホテル予定となるように、ホテル予定情報(arrgtHotelSchedHotel)を新規登録する。
    for (const createdSchedHotelId of createdSchedHotelIds) {
        // ホテル手配の新規登録処理実施。
        await prisma.arrgtHotelSchedHotel.create({
            data: {
                arrgtHotelId: resultArrgtHotel.id,
                schedHotelId: createdSchedHotelId,
            },
        });
    }
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function createHotelSchedIfNotExists(pid, prisma, itineraryId, checkInDateTime, checkOutDateTime, companions) {
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = companions?.map((item) => {
        return item.pid;
    });
    // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
    if (companionPids) {
        companionPids.push(pid);
    }
    else {
        companionPids = [pid];
    }
    // 予定の作成者ならびに同行者指定のpidが、紐ついている旅程の作成者/同行者になっていない(W00104)場合は入力チェックエラーとする
    if (companionPids) {
        const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
        if (error) {
            return error;
        }
    }
    // チェックイン日時またはチェッアウト日時が現在日よりも前の日時(W00102) になっている場合は入力チェックエラーとする
    if (isBeforeToday(new Date(checkInDateTime)) || isBeforeToday(new Date(checkOutDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // チェックアウト日時がチェックイン日時よりも前の日時となっている(W00103) になっている場合は入力チェックエラーとする
    if (isFromDatetimeBeforeToDatetime(new Date(checkOutDateTime), new Date(checkInDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    return;
}
/**
 * 手配登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export function createArrgtCheck(schedHotelsProp, dbHotelMastersMap) {
    const hotelId = schedHotelsProp.hotelId;
    const checkInDateTime = schedHotelsProp.checkInDateTime;
    const checkOutDateTime = schedHotelsProp.checkOutDateTime;
    const companions = schedHotelsProp.companions;
    // ホテル固有のチェック↓↓↓↓↓↓
    // ホテル(マスタ)IDの存在チェック: 存在しないホテル(マスタ)IDが指定されている(W00114)。
    if (hotelId) {
        if (!dbHotelMastersMap[hotelId]) {
            return { code: Define.ERROR_CODES.W00114, status: 400 };
        }
    }
    // ホテルルーム(マスタ)IDの存在チェック: 存在しないホテルルーム(マスタ)IDが指定されている(W00115)
    for (const comapnion of companions) {
        if (comapnion.hotelRoomId) {
            if (!hotelId) {
                return { code: Define.ERROR_CODES.W00114, status: 400 };
            }
            const masterHotel = dbHotelMastersMap[hotelId];
            if (!masterHotel) {
                return { code: Define.ERROR_CODES.W00114, status: 400 };
            }
            let isRoomExists = false;
            for (const hotelRoom of masterHotel.hotelRooms) {
                if (hotelRoom.id === comapnion.hotelRoomId) {
                    isRoomExists = true;
                }
            }
            if (!isRoomExists) {
                return { code: Define.ERROR_CODES.W00115, status: 400 };
            }
        }
    }
    // ホテル固有のチェック↑↑↑↑↑↑
    // コントローラ側で別の共通関数でチェック済み: 予定の作成者ならびに同行者指定のpidが、紐ついている旅程の作成者/同行者になっていない(W00104)
    if (checkInDateTime !== undefined && checkOutDateTime !== undefined) {
        // チェックイン日時またはチェッアウト日時が現在日よりも前の日時(W00102)になっている場合は入力チェックエラーとする
        if (isBeforeToday(new Date(checkInDateTime)) || isBeforeToday(new Date(checkOutDateTime))) {
            return { code: Define.ERROR_CODES.W00102, status: 200 };
        }
        // チェックアウト日時がチェックイン日時よりも前の日時となっている(W00103)になっている場合は入力チェックエラーとする
        if (isFromDatetimeBeforeToDatetime(new Date(checkOutDateTime), new Date(checkInDateTime))) {
            return { code: Define.ERROR_CODES.W00103, status: 200 };
        }
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function updateHotelSchedIfExists(pid, prisma, schedHotel, //prismaから取得したschedHotelレコード
itineraryId, checkInDateTime, checkOutDateTime, companions) {
    // 手配済(1)/確定済(2)/手配不要(9)と共通のチェック
    // DBからホテル予定情報が取得できない(W00109)
    if (schedHotel === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // DBから取得したitineraryIdとクライアントから取得したitineraryIdが一致しない(W00109)
    if (schedHotel.itineraryId !== itineraryId) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
    if (pid !== schedHotel.ownerPid) {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    // 出発日時または到着日時が現在日よりも前の日時(W00102)
    if (isBeforeToday(new Date(checkInDateTime)) || isBeforeToday(new Date(checkOutDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 到着日時が出発日時よりも前の日時となっている(W00103)
    if (isFromDatetimeBeforeToDatetime(new Date(checkOutDateTime), new Date(checkInDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    // 入力チェック内容 手配ステータス(arrgtStatus)が、手配不要(9)の場合
    if (schedHotel.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.NO_ARRGT) {
        // 同行者設定されている配列の数だけ、pidを取得する
        let companionPids = companions?.map((item) => {
            return item.pid;
        });
        // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
        if (companionPids) {
            companionPids.push(pid);
        }
        else {
            companionPids = [pid];
        }
        // 同行者指定のpidが、紐ついている旅程の作成者/同行者になっていない(W00104)
        if (companionPids) {
            const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
            if (error) {
                return error;
            }
        }
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function deleteHotelSchedIfExists(pid, schedHotel //prismaから取得したschedHotelレコード
) {
    // 入力チェック内容 全ての手配ステータス(arrgtStatus)で共通の内容
    // DBからホテル予定情報が取得できない(W00109)
    if (schedHotel === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
    if (pid !== schedHotel.ownerPid) {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    // 削除対象のホテル予定が手配済・確定済(arrgtStatus = 1 or 2)になっているのに、削除しようとしている(W00112)
    // if (
    //   schedHotel.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.START ||
    //   schedHotel.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.FINISHED
    // ) {
    //   return { code: Define.ERROR_CODES.W00112, status: 200 };
    // }
    return;
}
/**
 * 入力チェック用のデータ取得を実施する。individuals情報は、pid指定がない場合は削除フラグが立っているものも含んで取得する
 * @param prisma
 * @param pid
 * @param schedHotelId
 * @param pid pid指定がある場合は、対象ユーザーが予定の同行者になっているかどうかも検索条件に入れて取得する
 * @returns
 */
export async function getSchedHotelForChecker(prisma, schedHotelId, pid) {
    let schedFlight = null;
    if (pid) {
        schedFlight = await prisma.schedHotel.findFirst({
            where: { id: schedHotelId, flgDelete: false },
            include: { schedHotelIndividuals: { where: { pid: pid, flgDelete: false } } }, // // 削除フラグがたっていない物のみ取得
        });
    }
    else {
        schedFlight = await prisma.schedHotel.findFirst({
            where: { id: schedHotelId, flgDelete: false },
            include: { schedHotelIndividuals: true }, // 削除フラグの更新も行うためリレーション先の削除フラグでの絞り込みはしない。
        });
    }
    return schedFlight;
}
/**
 * こちらの関数は、outlookイベントをmctripに取り込む際に、mctripの予定を取り込まないようにする為のチェックで利用。
 * 指定したitineraryIdとpidに合致して、outlook連携している予定情報一覧を取得する。
 * 削除フラグや拒否フラグがある場合でも取得を実施する。
 * @param prisma
 * @param pid
 * @param itineraryId
 * @returns
 */
export async function getSchedHotelsReflectedInOutlook(prisma, pid, itineraryId) {
    const schedIndividuals = await prisma.schedHotelIndividual.findMany({
        where: {
            pid,
            schedHotel: { itineraryId, calendarId: { not: null } },
        },
        select: {
            flgDelete: true,
            flgReject: true,
            schedHotel: true,
        },
    });
    if (schedIndividuals.length <= 0) {
        return [];
    }
    else {
        return schedIndividuals.map((item) => {
            return item.schedHotel;
        });
    }
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、DB更新処理などのMCTrip予定更新処理後のみ実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param user
 * @param schedId 予定のID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @param iCalUId outlookイベント固有ID
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, user, schedId, calendarId, calendarUpdatedAt, iCalUId, calendarId2, iCalUId2, calendarId3, iCalUId3) {
    try {
        const updatedAt = calendarUpdatedAt ? new Date(formatDateTimeMiliSecond(new Date(calendarUpdatedAt))) : new Date();
        await prisma.schedHotel.update({
            where: { id: schedId },
            data: {
                calendarId: strToBuf(calendarId) || null,
                calendarUpdatedAt,
                iCalUId,
                calendarId2: strToBuf(calendarId2) || null,
                iCalUId2,
                calendarId3: strToBuf(calendarId3) || null,
                iCalUId3,
                updatedBy: user.pid,
                updatedAt,
            },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
export async function getSchedHotelsForCreateExpenseAccomodation(prisma, schedId) {
    return await prisma.schedHotel.findUniqueOrThrow({
        select: {
            id: true,
            itineraryId: true,
            name: true,
            cityId: true,
            checkInDateTime: true,
            checkOutDateTime: true,
            timezone: true,
            checkinOutInputStatus: true,
            remark: true,
            arrgtStatus: true,
            schedHotelIndividuals: {
                select: {
                    pid: true,
                    price: true,
                    currency: true,
                    remark: true,
                    flgDelete: true,
                    flgReject: true,
                },
            },
        },
        where: {
            flgArrgt: true,
            flgDelete: false,
            id: schedId,
        },
    });
}
/**
 * 経費宿泊費の登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param data 経費追加対象pid情報と経費情報
 * @return
 */
export async function createExpenseAccommodationsWhenArrgtFinished(prisma, user, schedHotelId) {
    const schedHotel = await getSchedHotelsForCreateExpenseAccomodation(prisma, schedHotelId);
    const pids = [];
    for (const target of schedHotel.schedHotelIndividuals) {
        if (!target.flgDelete && !target.flgReject) {
            pids.push(target.pid);
        }
    }
    const pidDataMap = convertListToMapByUniqueKey(schedHotel.schedHotelIndividuals, 'pid');
    if (pids.length <= 0) {
        return;
    }
    const expenses = await getExpenseIds(prisma, pids, schedHotel.itineraryId, { schedHotelId });
    for (const expense of expenses) {
        if (expense.expenseAccommodations.length <= 0) {
            const tz = schedHotel.timezone;
            const checkInDate = formatUtcDateTime(getLocalDate(schedHotel.checkInDateTime, tz), 'yyyy-MM-dd');
            const checkOutDate = formatUtcDateTime(getLocalDate(schedHotel.checkOutDateTime, tz), 'yyyy-MM-dd');
            await createExpenseAccommodation(prisma, user, {
                expenseId: expense.id,
                schedHotelId: schedHotelId,
                currency: pidDataMap[expense.pid].currency || undefined,
                price: pidDataMap[expense.pid].price || undefined,
                hotelName: schedHotel.name || undefined,
                cityId: schedHotel.cityId || undefined,
                checkInDate,
                checkOutDate,
                remark: schedHotel.remark || undefined,
            });
        }
    }
}
export function hasCheckIn(schedHotel) {
    if (schedHotel.checkinOutInputStatus == null) {
        return false;
    }
    // チェックイン時刻が分かっている場合
    return [
        Define.SETTINGS.SCHED_HOTEL.CHECKIN_OUT_INPUT_STATUS.INPUT_ALL,
        Define.SETTINGS.SCHED_HOTEL.CHECKIN_OUT_INPUT_STATUS.ONLY_CHECKIN,
    ].includes(schedHotel.checkinOutInputStatus);
}
export function hasCheckOut(schedHotel) {
    if (schedHotel.checkinOutInputStatus == null) {
        return false;
    }
    // チェックイン時刻が分かっている場合
    return [
        Define.SETTINGS.SCHED_HOTEL.CHECKIN_OUT_INPUT_STATUS.INPUT_ALL,
        Define.SETTINGS.SCHED_HOTEL.CHECKIN_OUT_INPUT_STATUS.ONLY_CHECKUOT,
    ].includes(schedHotel.checkinOutInputStatus);
}
//# sourceMappingURL=hotelService.js.map