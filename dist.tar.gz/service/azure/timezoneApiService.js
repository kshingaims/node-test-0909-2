import { lpad } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { isFinite } from 'lodash-es';
const TIMEZONE_API = 'https://atlas.microsoft.com/timezone/byCoordinates/json';
const SUBSCRIPTION_KEY = process.env.AZURE_MAPS_SUBSCRIPTION_KEY;
const noAzureTimezoneApi = Define.DEBUG.noAzureTimezoneApi;
const httpsAgent = Define.SYSTEM.PROXY.isUseProxy
    ? new HttpsProxyAgent(`${Define.SYSTEM.PROXY.protocol}://${Define.SYSTEM.PROXY.host}:${Define.SYSTEM.PROXY.port}`)
    : undefined;
export async function getPlaceTimezoneByCordinates(log, lat, lng) {
    if (noAzureTimezoneApi) {
        return {};
    }
    const latNum = Number(lat);
    const lngNum = Number(lng);
    if (!isFinite(latNum) || !isFinite(lngNum)) {
        log.error(`getPlaceTimezoneByCordinates error. lat or lng is not collect. [lat:${lat}][lng:${lng}]`);
        return {};
    }
    try {
        const { data, status } = await axios.get(TIMEZONE_API, {
            params: {
                'subscription-key': SUBSCRIPTION_KEY,
                'api-version': '1.0',
                query: `${lat},${lng}`,
                options: 'all',
            },
            proxy: false,
            httpsAgent,
        });
        if (status < 200 || status >= 300) {
            log.error(`${TIMEZONE_API} access error. [status: ${status}]`);
            return {};
        }
        else if (!data.TimeZones || data.TimeZones.length <= 0) {
            log.error(`${TIMEZONE_API} no timezones. lat or lng is not collect.`);
            return {};
        }
        const timezoneInfo = data.TimeZones[0];
        if (!timezoneInfo.ReferenceTime) {
            log.error(`${TIMEZONE_API} no ReferenceTime. lat or lng is not collect.`);
            return {};
        }
        return formatTimezones(log, timezoneInfo, lat, lng);
    }
    catch (error) {
        log.error(`${TIMEZONE_API} access error.`, error);
        return {};
    }
}
export function formatTimezones(log, timezoneInfo, lat, lng) {
    let timezoneLabel = timezoneInfo.ReferenceTime.Tag.length <= 3
        ? timezoneInfo.ReferenceTime.Tag
        : timezoneInfo.ReferenceTime.Tag.substring(0, 3);
    // timezoneは、StandardOffsetを利用
    const timezone = formatStandardOffset(timezoneInfo.ReferenceTime.StandardOffset);
    const timeTransitions = [];
    if (timezoneInfo.TimeTransitions && timezoneInfo.TimeTransitions.length > 0) {
        let hasSummerTime = true;
        if (timezoneInfo.TimeTransitions.length === 1) {
            const timeTransition = timezoneInfo.TimeTransitions[0];
            if (timeTransition.UtcEnd.indexOf('9999') === 0 && timeTransition.DaylightSavings === '00:00:00') {
                hasSummerTime = false;
            }
        }
        if (hasSummerTime) {
            for (const timeTransition of timezoneInfo.TimeTransitions) {
                // サマータイムではないラベルを正式のラベルとする
                if (timeTransition.StandardOffset === '00:00:00') {
                    timezoneLabel = timeTransition.Tag;
                }
                timeTransitions.push({
                    tag: timeTransition.Tag,
                    timezone: calcTimezone(log, timeTransition.StandardOffset, timeTransition.DaylightSavings),
                    startDateTime: timeTransition.UtcStart,
                    endDateTime: timeTransition.UtcEnd,
                });
            }
        }
    }
    else {
        log.error(`It is no country in this cordinates. [lat:${lat}] [lng:${lng}]`);
    }
    return { timezoneLabel, timezone, timeTransitions };
}
/**
 * サマータイムを加味した、時差情報を取得する。フォーマット：±hh:mm
 * @param log
 * @param standardOffset
 * @param dailightSavings
 * @returns 時差情報を取得する。フォーマット：±hh:mm
 */
export function calcTimezone(log, standardOffset, dailightSavings) {
    // コロンの位置から、時・分・秒を取り出す
    const [bh, bm, bs] = standardOffset.split(':');
    const [dh, dm, ds] = dailightSavings.split(':');
    const baseSeconds = _getSeconds(bh, bm, bs);
    const dailightSeconds = _getSeconds(dh, dm, ds);
    if (!isFinite(baseSeconds) || !isFinite(dailightSeconds)) {
        throw new Error('standardOffset or dailightSavings format error.');
    }
    // サマータイム適用時の時差計算
    const realSeconds = baseSeconds + dailightSeconds;
    // タイムゾーン表記文字列生成(±hh:mm)
    const result = realSeconds < 0 ? '-' : '+';
    const hours = lpad(Math.floor(Math.abs(realSeconds) / 3600), '0', 2);
    const hoursLeft = Math.abs(realSeconds) % 3600;
    if (hoursLeft <= 0) {
        return result + hours + ':00';
    }
    const minutes = lpad(Math.floor(hoursLeft / 60), '0', 2);
    const seconds = hoursLeft % 60;
    if (seconds <= 0) {
        return result + hours + ':' + minutes;
    }
    else {
        log.warn('dailightSaving has second.');
        // 秒単位で時差がある国はないので、現状は秒は無視する。
        return result + hours + ':' + minutes;
    }
}
function _getSeconds(hours, minutes, seconds) {
    const hasMinus = hours.indexOf('-') === 0;
    const absResult = Math.abs(Number(hours)) * 3600 + Number(minutes) * 60 + Number(seconds);
    return hasMinus && absResult > 0 ? absResult * -1 : absResult;
}
function formatStandardOffset(standardOffset) {
    // コロンの位置から、時・分・秒を取り出す
    const [bh, bm] = standardOffset.split(':');
    const hasMinus = bh.indexOf('-') === 0;
    const result = [bh, bm].join(':');
    return hasMinus ? result : '+' + result;
}
//# sourceMappingURL=timezoneApiService.js.map