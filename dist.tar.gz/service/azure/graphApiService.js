import { v4 as uuidv4 } from 'uuid';
import { merge, random } from 'lodash-es';
import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import baseConfig from 'config';
import { Define } from '../../utils/define.js';
import { decrypt } from '../../utils/crypt.js';
import { formatUtcDateTime, sleep } from '../../utils/index.js';
import { getUserByPid } from '../../service/user/userService.js';
import { addHours, differenceInHours } from 'date-fns';
const TEST_MARK = '[test] ';
const httpsAgent = Define.SYSTEM.PROXY.isUseProxy
    ? new HttpsProxyAgent(`${Define.SYSTEM.PROXY.protocol}://${Define.SYSTEM.PROXY.host}:${Define.SYSTEM.PROXY.port}`)
    : undefined;
const isStaging = process.env.NODE_ENV === 'staging';
const noExternalIntegration = Define.DEBUG.noExternalIntegration;
const isDummyOutlookCalendar = Define.DEBUG.isDummyOutlookCalendar;
const showErrorCause = Define.DEBUG.showErrorCause;
const { baseURL } = baseConfig.get('api.graph');
export async function getLoginUser(log, tokenEnc) {
    const token = decrypt(tokenEnc);
    if (noExternalIntegration) {
        return {};
    }
    const path = '/me';
    const result = await _get(log, path, token);
    log.debug('/me response.', result.data);
    return result.data;
}
export async function createCalendarEvent(log, aadToken, calendar, sched) {
    if (noExternalIntegration) {
        // ダミーデータを返却する
        return { isSuccess: true, data: _makeDummyCalendarEvent() };
    }
    if (sched.allowNewTimeProposals == null) {
        sched.allowNewTimeProposals = false;
    }
    if (sched.transactionId == null) {
        sched.transactionId = uuidv4();
    }
    const path = calendar ? `/me/calendars/${calendar.id}/events/` : '/me/events';
    const result = await _post(log, path, aadToken, sched);
    log.debug('create event response.', result);
    return result;
}
export async function updateCalendarEvent(log, aadToken, calendar, calendarEventId, sched) {
    if (noExternalIntegration) {
        // ダミーデータを返却する
        return { isSuccess: true, data: _makeDummyCalendarEvent(calendarEventId) };
    }
    const path = calendar ? `/me/calendars/${calendar.id}/events/${calendarEventId}` : `/me/events/${calendarEventId}`;
    // 最初にイベント更新処理実施
    const result = await _post(log, path, aadToken, sched, undefined, true);
    log.debug(`update calendarId: ${result.data?.id} [base: ${calendarEventId}]`);
    // 新規予定参加者に対してイベント連携実施
    // if (sched.attendees && sched.attendees.length > 0) {
    //   const result2 = await _post(log, path, aadToken, { attendees: sched.attendees }, undefined, true);
    //   log.debug(`update calendarId: ${result2.data?.id} [base: ${calendarEventId}]`);
    // }
    // log.debug('update event response.', result);
    return result;
}
export async function updateCalendarEventAttendees(log, aadToken, calendar, calendarEventId, sched, isUpdateAttachment) {
    if (noExternalIntegration) {
        // ダミーデータを返却する
        return { isSuccess: true, data: _makeDummyCalendarEvent(calendarEventId) };
    }
    if (isUpdateAttachment) {
        await sleep(Define.SETTINGS.OUTLOOK_INTEGRATION.attendeesSendDelaySeconds * 1000);
    }
    const path = calendar ? `/me/calendars/${calendar.id}/events/${calendarEventId}` : `/me/events/${calendarEventId}`;
    if (isUpdateAttachment) {
        const result = await _post(log, path, aadToken, sched, undefined, true);
        return result;
    }
    // 新規予定参加者に対してイベント連携実施
    if (sched.attendees && sched.attendees.length > 0) {
        const result = await _post(log, path, aadToken, { attendees: sched.attendees }, undefined, true);
        // log.debug('update event response.', result);
        return result;
    }
    else {
        return { isSuccess: true };
    }
}
export async function deleteCalendarEvent(log, aadToken, calendar, calendarEventId) {
    if (noExternalIntegration) {
        return { isSuccess: true };
    }
    const path = calendar ? `/me/calendars/${calendar.id}/events/${calendarEventId}` : `/me/events/${calendarEventId}`;
    const result = await _get(log, path, aadToken, undefined, true);
    log.debug('delete event response.', result);
    return result;
}
export async function getCalendarEvents(log, token, calendar, startDateTime, endDateTime, format = 'text', isUseDummy = false) {
    if (noExternalIntegration) {
        if (isDummyOutlookCalendar || isUseDummy) {
            // ダミーデータを返却する
            return { isSuccess: true, data: _makeDummyCalendarEvents(startDateTime, endDateTime, format) };
        }
        else {
            return { isSuccess: true, data: { value: [] } };
        }
    }
    const path = calendar ? `/me/calendars/${calendar.id}/calendarView` : '/me/calendarView';
    const result = await _get(log, path, token, {
        headers: {
            Prefer: `outlook.body-content-type="${format}"`,
        },
        params: {
            startDateTime,
            endDateTime,
            $top: '1000',
        },
    });
    return result;
}
export async function sendMail(log, tokenEnc, message) {
    const token = decrypt(tokenEnc);
    if (noExternalIntegration) {
        log.info('/me/sendMail send mail', message.emailTo, message.emailCc, message.subject, message.body);
        return { isSuccess: true };
    }
    const path = '/me/sendMail';
    const postMessage = {
        subject: isStaging ? TEST_MARK + message.subject : message.subject,
        body: isStaging
            ? { contentType: message.body.contentType, content: TEST_MARK + '\r\n\r\n' + message.body.content }
            : message.body,
    };
    if (message.attachments) {
        postMessage.attachments = message.attachments;
    }
    if (message.emailTo && message.emailTo.length > 0) {
        // 同一メールアドレスの重複セットチェック
        const checkerMap = {};
        const toRecipients = [];
        for (const to of message.emailTo) {
            if (to && !checkerMap[to]) {
                checkerMap[to] = true;
                toRecipients.push({ emailAddress: { address: to } });
            }
        }
        if (toRecipients.length > 0) {
            postMessage.toRecipients = toRecipients;
        }
    }
    if (message.emailCc && message.emailCc.length > 0) {
        // 同一メールアドレスの重複セットチェック
        const checkerMap = {};
        const ccRecipients = [];
        for (const cc of message.emailCc) {
            if (cc && !checkerMap[cc]) {
                checkerMap[cc] = true;
                ccRecipients.push({ emailAddress: { address: cc } });
            }
        }
        if (ccRecipients.length > 0) {
            postMessage.ccRecipients = ccRecipients;
        }
    }
    if (!postMessage.toRecipients && !postMessage.ccRecipients) {
        throw new Error('emailTo or emailCc is required.');
    }
    const result = await _post(log, path, token, {
        message: postMessage,
        saveToSentItems: 'true',
    });
    log.info('send mail response.', result);
    return result;
}
export async function getSupportedTimezone(log, aadToken) {
    if (noExternalIntegration) {
        // ダミーデータを返却する
        return {
            isSuccess: true,
            data: {
                value: [
                    { alias: 'UTC', displayName: '(UTC)' },
                    { alias: 'GMT Standard Time', displayName: '(UTC+00:00) ダブリン、エジンバラ' },
                    { alias: 'Azores Standard Time', displayName: '(UTC-01:00) Azores' },
                ],
            },
        };
    }
    const path = '/me/outlook/supportedTimeZones';
    const result = await _get(log, path, aadToken);
    return result;
}
export async function getDelegatedCalendar(log, aadToken, targetEmail) {
    if (noExternalIntegration) {
        return {
            id: 'dummyId',
            canEdit: true,
            canShare: false,
            canViewPrivateItems: false,
            owner: {
                address: targetEmail,
            },
        };
    }
    const path = '/me/calendars';
    const result = await _get(log, path, aadToken, {
        params: {
            $top: '1000',
        },
    });
    const calendars = result.data?.value || [];
    if (calendars && calendars.length > 0) {
        for (const calendar of calendars) {
            if (calendar && calendar.owner && calendar.owner.address === targetEmail) {
                return calendar;
            }
        }
    }
    return undefined;
}
export async function getEventAttachments(log, aadToken, calendar, calendarEventId) {
    if (noExternalIntegration) {
        log.debug('graph api getEventAttachemnts called.');
        // ダミーデータを返却する
        return {
            isSuccess: true,
            data: {
                value: [
                    {
                        id: uuidv4(),
                        name: 'testファイル名1',
                        size: 12,
                        lastModifiedDateTime: formatUtcDateTime(new Date(), "yyyy-MM-dd'T'HH:mm:ss.3454567XXX"),
                    },
                    {
                        id: uuidv4(),
                        name: 'testファイル名2',
                        size: 12,
                        lastModifiedDateTime: formatUtcDateTime(new Date(), "yyyy-MM-dd'T'HH:mm:ss.3454567XXX"),
                    },
                ],
            },
        };
    }
    const path = calendar
        ? `/me/calendars/${calendar.id}/events/${calendarEventId}/attachments`
        : `/me/events/${calendarEventId}/attachments`;
    const result = await _get(log, path, aadToken, {
        params: {
            $select: 'contentType,id,isInline,lastModifiedDateTime,name,size',
            $orderby: 'lastModifiedDateTime desc',
        },
    });
    for (const row of result.data?.value) {
        log.debug('event attachments:', row.id, row.name, row.size, row.isInline, row.lastModifiedDateTime);
    }
    // log.debug('get event attachments response.', omitSecretRequestParameters(cloneDeep(result)));
    return result;
}
export async function createEventAttachment(log, aadToken, calendar, calendarEventId, attachment) {
    if (noExternalIntegration) {
        log.debug('graph api createEventAttachemnts called.');
        return {
            isSuccess: true,
            data: {
                id: uuidv4(),
                name: 'ダミーファイル名',
                size: 12,
                lastModifiedDateTime: formatUtcDateTime(new Date(), "yyyy-MM-dd'T'HH:mm:ss.3454567XXX"),
            },
        };
    }
    const path = calendar
        ? `/me/calendars/${calendar.id}/events/${calendarEventId}/attachments`
        : `/me/events/${calendarEventId}/attachments`;
    if (!attachment['@odata.type']) {
        attachment['@odata.type'] = '#microsoft.graph.fileAttachment';
    }
    const result = await _post(log, path, aadToken, attachment);
    // log.debug('create event attachments response.', omitSecretRequestParameters(cloneDeep(result)));
    return result;
}
export async function deleteEventAttachment(log, aadToken, calendar, calendarEventId, attachmentId) {
    if (noExternalIntegration) {
        log.debug('graph api deleteEventAttachemnts called.');
        return { isSuccess: true };
    }
    const path = calendar
        ? `/me/calendars/${calendar.id}/events/${calendarEventId}/attachments/${attachmentId}`
        : `/me/events/${calendarEventId}/attachments/${attachmentId}`;
    const result = await _get(log, path, aadToken, undefined, true);
    //log.debug('delete event attachments response.', omitSecretRequestParameters(cloneDeep(result)));
    return result;
}
async function _get(log, path, token, options, isDelete = false) {
    const headers = options?.headers || {};
    const baseConfig = {
        headers: merge(headers, {
            Authorization: `Bearer ${token}`,
        }),
        httpsAgent,
    };
    if (options?.params) {
        baseConfig.params = options.params;
    }
    const result = { isSuccess: false };
    const method = isDelete ? 'delete' : 'get';
    try {
        log.debug(`graph api access [method: ${method}] [path:${path}]`);
        const res = isDelete ? await axios.delete(baseURL + path, baseConfig) : await axios.get(baseURL + path, baseConfig);
        if (isDelete) {
            if (res.status === 204) {
                result.isSuccess = true;
            }
            else {
                log.warn(`graph api access delete error. [method: delete] [path: ${path}]`);
            }
        }
        else {
            if (res?.data) {
                result.isSuccess = true;
                result.data = res.data;
            }
            else {
                log.warn(`graph api access no response data. [method: get] [path: ${path}]`);
            }
        }
        return result;
    }
    catch (error) {
        if (axios.isAxiosError(error)) {
            if (isDelete) {
                // 削除時は、azure graph APIの特性上、404エラー、412エラーがどうしても発生してしまいそうなので、
                // 回避策を取るようにする(エラー扱いにしない)。
                if (error.response?.status === 404) {
                    log.info(`graph api access not found(404). [method: ${method}] [path: ${path}]`);
                }
                else if (error.response?.status === 412) {
                    log.info(`graph api access Precondition Failed(412). [method: ${method}] [path: ${path}]`);
                }
                else if (error.response?.status === 403) {
                    log.warn(`graph api access no access right(403) error. [method: ${method}] [path: ${path}]`);
                    result.error = { code: Define.ERROR_CODES.W01101, status: 200 };
                }
                else {
                    const axiosError = error;
                    log.warn(`graph api access error. [method: ${method}] [path: ${path}]`, error);
                    if (showErrorCause) {
                        result.error = { code: Define.ERROR_CODES.W01104, cause: axiosError, status: 500 };
                    }
                }
            }
            else {
                if (error.response?.status === 404) {
                    log.warn(`graph api access not found(404) error. [method: ${method}] [path: ${path}]`);
                    result.error = { code: Define.ERROR_CODES.W01103, status: 200 };
                }
                else if (error.response?.status === 403) {
                    log.warn(`graph api access no access right(403) error. [method: ${method}] [path: ${path}]`);
                    result.error = { code: Define.ERROR_CODES.W01101, status: 200 };
                }
                else {
                    const axiosError = error;
                    log.warn(`graph api access error. [method: ${method}] [path: ${path}]`, error);
                    if (showErrorCause) {
                        result.error = { code: Define.ERROR_CODES.W01104, cause: axiosError, status: 500 };
                    }
                }
            }
            return result;
        }
        else {
            log.warn(`graph api access error. [method: ${method}] [path: ${path}]`, error);
            if (showErrorCause) {
                result.error = { code: Define.ERROR_CODES.W01104, cause: error, status: 500 };
            }
            return result;
        }
    }
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function _post(log, path, token, 
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
postData, options, isPatch = false) {
    const headers = options?.headers || {};
    const baseConfig = {
        headers: merge(headers, {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        }),
        httpsAgent,
    };
    const result = { isSuccess: false };
    const method = isPatch ? 'patch' : 'post';
    try {
        log.debug(`graph api access [method: ${method}] [path:${path}]`);
        const res = isPatch
            ? await await axios.patch(baseURL + path, postData, baseConfig)
            : await axios.post(baseURL + path, postData, baseConfig);
        if (res?.data) {
            result.data = res.data;
        }
        result.isSuccess = true;
        return result;
    }
    catch (error) {
        if (axios.isAxiosError(error)) {
            if (error.response?.status === 404) {
                log.warn(`graph api access not found(404) error. [method: ${method}] [path: ${path}]`);
                result.error = { code: Define.ERROR_CODES.W01103, status: 200 };
            }
            else if (error.response?.status === 403) {
                log.warn(`graph api access no access right(403) error. [method: ${method}] [path: ${path}]`);
                result.error = { code: Define.ERROR_CODES.W01101, status: 200 };
            }
            else {
                const axiosError = error;
                log.warn(`graph api access error. [method: ${method}] [path: ${path}]`, error);
                if (showErrorCause) {
                    result.error = { code: Define.ERROR_CODES.W01104, cause: axiosError, status: 500 };
                }
            }
            return result;
        }
        else {
            log.warn(`graph api access error. [method: ${method}] [path: ${path}]`, error);
            if (showErrorCause) {
                result.error = { code: Define.ERROR_CODES.W01104, cause: error, status: 500 };
            }
            return result;
        }
    }
}
/**
 * Azure連携対象ユーザを取得する。
 * 合わせてそのユーザがoutlook連携設定を実施しているかどうかを確認する
 * @param prisma
 * @param pid
 * @param user
 * @param tokenEnc
 * @returns
 */
export async function checkAndGetTargetCalendar(log, prisma, pid, user, tokenEnc) {
    const isDelegator = pid !== user.pid;
    const token = decrypt(tokenEnc);
    // 代理人による処理の場合であっても、ログインユーザによる処理であっても、最新のユーザ情報を取得する
    const targetUser = await getUserByPid(prisma, pid);
    if (!targetUser || !targetUser.email) {
        throw new Error(`there is no user. [pid: ${pid}]`);
    }
    // カレンダー同期設定がfalseの場合は処理しない
    if (!targetUser.flgCalendarSync) {
        return { isSkip: true, token: '' };
    }
    // 他システム連携しない設定の場合は、処理終了
    if (noExternalIntegration) {
        return { isSkip: false, token: '' };
    }
    const calendar = isDelegator ? await getDelegatedCalendar(log, token, targetUser.email) : undefined;
    const isNoAccessRight = isDelegator && !calendar;
    return { token, isSkip: false, isNoAccessRight, calendar };
}
function _makeDummyCalendarEvent(id) {
    return {
        id: id || uuidv4(),
        lastModifiedDateTime: formatUtcDateTime(new Date(), "yyyy-MM-dd'T'HH:mm:ss.1234567XXX"),
    };
}
function _makeDummyCalendarEvents(startDateTime, endDateTime, format = 'text') {
    const result = [];
    const diffHours = differenceInHours(new Date(endDateTime), new Date(startDateTime));
    const half = Math.round(diffHours / 2);
    const minHour = Math.round(diffHours / 4);
    const maxHour = Math.round((diffHours * 3) / 4);
    if (half > 1) {
        let roopCount = 1;
        if (half >= 24 && half < 48) {
            roopCount = 2;
        }
        else if (half >= 48) {
            roopCount = 3;
        }
        for (let i = 0; i < roopCount; i++) {
            const startHour = random(minHour, maxHour);
            const uuidStr = uuidv4();
            const timeZone = i % 2 === 0 ? 'UTC' : 'Azores Standard Time';
            result.push({
                id: uuidStr,
                iCalUId: uuidStr,
                lastModifiedDateTime: formatUtcDateTime(new Date()),
                sensitivity: 'normal',
                importance: 'normal',
                allowNewTimeProposals: false,
                subject: '[dummy] outlookタイトル' + (i + 1),
                body: {
                    contentType: format === 'text' ? 'Text' : 'HTML',
                    content: '[dummy]\r\n\r\noutlook カレンダー予定本文' + (i + 1),
                },
                bodyPreview: '[dummy]\r\n\r\noutlook カレンダー予定プレビュー' + (i + 1),
                start: {
                    dateTime: formatUtcDateTime(addHours(new Date(), startHour), 'yyyy-MM-dd HH:mm:ss.0000000'),
                    timeZone,
                },
                end: {
                    dateTime: formatUtcDateTime(addHours(new Date(), startHour + 1), 'yyyy-MM-dd HH:mm:ss.0000000'),
                    timeZone,
                },
                organizer: {
                    emailAddress: {
                        name: 'Taro Owner1',
                        address: 'Taro Owner1 (MC-TOK/PW)',
                    },
                },
                hasAttachments: false,
                isAllDay: false,
                isCancelled: false,
                isDraft: false,
                isOnlineMeeting: false,
                isOrganizer: true,
                showAs: 'busy',
                isReminderOn: true,
                transactionId: uuidStr,
                changeKey: uuidStr,
                location: {
                    displayName: 'location displayName' + (i + 1),
                },
            });
        }
    }
    return { value: result };
}
//# sourceMappingURL=graphApiService.js.map