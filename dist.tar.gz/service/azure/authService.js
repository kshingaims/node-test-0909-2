import axios, { isAxiosError } from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import baseConfig from 'config';
import { Define } from '../../utils/define.js';
import { decrypt, encrypt } from '../../utils/crypt.js';
const { getTokenApi: getMcidmTokenApi, redirectUrl: mcidmRedirectUrl } = baseConfig.get('api.mcidmAuth');
const tenantId = Define.SETTINGS.AZURE_AAD.tenantId;
const clientId = Define.SETTINGS.AZURE_AAD.clientId;
const redirectUrl = Define.SETTINGS.AZURE_AAD.redirectUrl;
const graphScoes = Define.SETTINGS.AZURE_AAD.graphScopes;
const isDummySso = Define.DEBUG.isDummySso;
const httpsAgent = Define.SYSTEM.PROXY.isUseProxy
    ? new HttpsProxyAgent(`${Define.SYSTEM.PROXY.protocol}://${Define.SYSTEM.PROXY.host}:${Define.SYSTEM.PROXY.port}`)
    : undefined;
export async function getAzureAadToken(log, code) {
    if (isDummySso) {
        return { tokenEnc: '', expiresSecond: 0, scope: '', refleshTokenEnc: '' };
    }
    const AZURE_AAD_CLIENT_SECRET = process.env.AZURE_AAD_CLIENT_SECRET;
    const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
    try {
        const postData = new URLSearchParams();
        postData.append('client_id', clientId);
        postData.append('grant_type', 'authorization_code');
        postData.append('redirect_uri', redirectUrl);
        postData.append('scope', graphScoes.join(' '));
        postData.append('client_secret', AZURE_AAD_CLIENT_SECRET);
        postData.append('code', code);
        const { data, status } = await axios.post(url, postData, {
            proxy: false,
            httpsAgent: httpsAgent,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        if (status < 200 || status >= 300 || !data?.access_token) {
            log.warn(`${url} access error. can not get access_token [status: ${status}]`);
            return { tokenEnc: '', expiresSecond: 0, scope: '', refleshTokenEnc: '' };
        }
        log.debug('aad token: ', data.access_token);
        return {
            tokenEnc: encrypt(data.access_token),
            expiresSecond: data.expires_in,
            refleshTokenEnc: encrypt(data.refresh_token),
            idToken: data.id_token,
            scope: data.scope,
        };
    }
    catch (error) {
        if (isAxiosError(error)) {
            const axiosError = error;
            if (axiosError.response?.status === 400) {
                log.debug(`${getMcidmTokenApi} access error.`, error);
                log.warn(`${getMcidmTokenApi} auth error. code is not collect.`);
                return { tokenEnc: '', expiresSecond: 0, scope: '', refleshTokenEnc: '' };
            }
        }
        log.warn(`${getMcidmTokenApi} access error.`, error);
        return { tokenEnc: '', expiresSecond: 0, scope: '', refleshTokenEnc: '' };
    }
}
export async function refleshAzureAadToken(log, refleshTokenEnc) {
    if (isDummySso) {
        return { tokenEnc: '', expiresSecond: 0, scope: '', refleshTokenEnc: '', idToken: '' };
    }
    if (!refleshTokenEnc) {
        return { tokenEnc: '', expiresSecond: 0, scope: '', refleshTokenEnc: '', idToken: '' };
    }
    const AZURE_AAD_CLIENT_SECRET = process.env.AZURE_AAD_CLIENT_SECRET;
    const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
    try {
        const postData = new URLSearchParams();
        postData.append('client_id', clientId);
        postData.append('grant_type', 'refresh_token');
        postData.append('scope', 'offline_access ' + graphScoes.join(' '));
        postData.append('client_secret', AZURE_AAD_CLIENT_SECRET);
        postData.append('refresh_token', decrypt(refleshTokenEnc));
        const { data, status } = await axios.post(url, postData, {
            proxy: false,
            httpsAgent: httpsAgent,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        if (status < 200 || status >= 300 || !data?.access_token) {
            log.warn(`${url} reflesh token access error. can not get access_token [status: ${status}]`);
            return { tokenEnc: '' };
        }
        return {
            tokenEnc: encrypt(data.access_token),
            expiresSecond: data.expires_in,
            refleshTokenEnc: encrypt(data.refresh_token),
            idToken: data.id_token,
            scope: data.scope,
        };
    }
    catch (error) {
        if (isAxiosError(error)) {
            const axiosError = error;
            if (axiosError.response?.status === 400) {
                log.debug(`${getMcidmTokenApi} reflesh token access error.`, error);
                log.warn(`${getMcidmTokenApi} reflesh error. code is not collect.`);
                return { tokenEnc: '' };
            }
        }
        log.warn(`${getMcidmTokenApi} reflesh token access error.`, error);
        return { tokenEnc: '' };
    }
}
export async function getMcidmToken(log, code) {
    if (isDummySso) {
        return { token: '', expiresSecond: 0, refleshToken: '', idToken: '' };
    }
    try {
        const MCIDM_AUTH_CLIENT_SECRET = process.env.MCIDM_AUTH_CLIENT_SECRET;
        const postData = new URLSearchParams();
        postData.append('client_id', 'mctrip');
        postData.append('client_secret', MCIDM_AUTH_CLIENT_SECRET);
        postData.append('grant_type', 'authorization_code');
        postData.append('redirect_uri', mcidmRedirectUrl);
        postData.append('code', code);
        const { data, status } = await axios.post(getMcidmTokenApi, postData, {
            proxy: false,
            httpsAgent: httpsAgent,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        if (status < 200 || status >= 300 || !data?.access_token) {
            log.warn(`${getMcidmTokenApi} access error. can not get access_token [status: ${status}]`);
            return { token: '' };
        }
        return {
            token: data.access_token,
            expiresSecond: data.expires_in,
            refleshToken: data.refresh_token,
            idToken: data.id_token,
        };
    }
    catch (error) {
        if (isAxiosError(error)) {
            const axiosError = error;
            if (axiosError.response?.status === 400) {
                log.debug(`${getMcidmTokenApi} access error.`, error);
                log.warn(`${getMcidmTokenApi} auth error. code is not collect.`, error);
                return { token: '' };
            }
        }
        log.warn(`${getMcidmTokenApi} access error.`, error);
        return { token: '' };
    }
}
//# sourceMappingURL=authService.js.map