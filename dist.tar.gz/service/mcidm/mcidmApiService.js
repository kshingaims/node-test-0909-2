import axios from 'axios';
import baseConfig from 'config';
import { XMLParser } from 'fast-xml-parser';
import { Define } from '../../utils/define.js';
const { domain, systemNo, path } = baseConfig.get('api.mcidm');
const noExternalIntegration = Define.DEBUG.noExternalIntegration;
const axiosClient = axios.create({
    baseURL: domain,
    headers: {
        timeout: 600000,
        'Content-Type': 'application/xml',
    },
});
const allUserPostBody = `
<?xml version="1.0" encoding="UTF-8"?><ns1:RequestMessage xmlns:xsd="http://www.w3.org/2001/XMLSchema"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xmlns:ns1="http://xml.ac.jp/NsShinseiAPI"
 xsi:schemaLocation="http://xml.ac.jp/NsShinseiAPI/APP/aw3/data/weblogic/sinseiapi/xsd/Request/ReqXmlUserInfoShutoku.xsd">
 <ns1:CallMethod>UserInfoShutoku</ns1:CallMethod>
 <ns1:RequestInfomation>
  <ns1:SystemNo>${systemNo}</ns1:SystemNo>
  <ns1:Ninka1APList>
    <ns1:Ninka1ApNo>${systemNo}</ns1:Ninka1ApNo>
  </ns1:Ninka1APList>
 </ns1:RequestInfomation>
</ns1:RequestMessage>`;
const sabunUserPostBody = (reacquisitionCallKbn = 0) => {
    return `
<?xml version="1.0" encoding="UTF-8"?><ns1:RequestMessage xmlns:xsd="http://www.w3.org/2001/XMLSchema"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xmlns:ns1="http://xml.ac.jp/NsShinseiAPI"
 xsi:schemaLocation="http://xml.ac.jp/NsShinseiAPIAPP/aw3/data/weblogic/sinseiapi/xsd/Request/ReqXmlSabunUserInfoShutoku.xsd">
 <ns1:CallMethod>SabunUserInfoShutoku</ns1:CallMethod>
 <ns1:RequestInfomation>
  <ns1:SystemNo>${systemNo}</ns1:SystemNo>
  <ns1:Ninka1APList>
    <ns1:Ninka1ApNo>${systemNo}</ns1:Ninka1ApNo>
  </ns1:Ninka1APList>
  <ns1:Reacquisition_Call_Kbn>${reacquisitionCallKbn}</ns1:Reacquisition_Call_Kbn>
 </ns1:RequestInfomation>
</ns1:RequestMessage>`;
};
export async function getAllUsers(log) {
    return await _getUsers(log, allUserPostBody, true);
}
export async function getSabunUsers(log, iaAll = false) {
    if (iaAll) {
        return await _getUsers(log, sabunUserPostBody(1), true);
    }
    else {
        return await _getUsers(log, sabunUserPostBody(0));
    }
}
export async function _getUsers(log, postBody, isAll = false) {
    if (noExternalIntegration) {
        return { users: [], isAll };
    }
    try {
        const { data, status } = await axiosClient.post(path.allUser, postBody.replace(/\n/g, ''));
        if (status < 200 || status >= 300) {
            log.error(`mcidm get all users api access error. [path: ${path.allUser}] [status: ${status}]`);
            return { users: [], isAll };
        }
        const parser = new XMLParser({
            ignoreAttributes: false,
            numberParseOptions: {
                leadingZeros: false,
                hex: false,
            },
        });
        const jObj = parser.parse(data);
        if (jObj['ns1:ResultMessage']) {
            const detailMessageCd = jObj['ns1:ResultMessage']['ns1:DetailMessageCd'];
            let hasData = false;
            if (detailMessageCd === 'I000' || detailMessageCd === 'W034') {
                hasData = true;
            }
            else if (detailMessageCd === 'I001') {
                log.info('mcidm no user.');
                // ignore
            }
            else if (detailMessageCd === 'E001') {
                log.error(`mcidm db error. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E006') {
                log.error(`mcidm io error. it may be too many access. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E007') {
                log.error(`mcidm xml format error. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E204') {
                log.error(`mcidm systemNo error. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E205') {
                log.warn(`mcidm auth error. wrong id or password. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E206') {
                log.warn(`mcidm auth error. account is disabled. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E207') {
                log.warn(`mcidm auth error. account is not allowed to access. [detailMessageCd: ${detailMessageCd}]`);
            }
            else if (detailMessageCd === 'E215') {
                if (isAll) {
                    log.error(`mcidm error. change search conditions. [detailMessageCd: ${detailMessageCd}]`);
                }
                else {
                    log.info(`mcidm error. change search conditions. tray again. [detailMessageCd: ${detailMessageCd}]`);
                    return await _getUsers(log, sabunUserPostBody(1), true);
                }
            }
            else if (detailMessageCd === 'E216') {
                if (isAll) {
                    log.error(`mcidm error. change user attribute to get. [detailMessageCd: ${detailMessageCd}]`);
                }
                else {
                    log.info(`mcidm error. change user attribute to get. tray again. [detailMessageCd: ${detailMessageCd}]`);
                    return await _getUsers(log, sabunUserPostBody(1), true);
                }
            }
            else {
                log.error(`mcidm error. something wrong. [detailMessageCd: ${detailMessageCd}]`);
            }
            if (!hasData) {
                return { users: [], isAll };
            }
            if (jObj['ns1:ResultMessage']['ns1:ResultInfomation']) {
                return { users: jObj['ns1:ResultMessage']['ns1:ResultInfomation']['ns1:UserList'], isAll };
            }
            else {
                return { users: [], isAll };
            }
        }
        else {
            log.error('prgoraming error in mcidm side.');
            return { users: [], isAll };
        }
    }
    catch (error) {
        log.error(`mcidm get users api access error. [path: ${path.allUser}]`, error);
        return { users: [], isAll };
    }
}
//# sourceMappingURL=mcidmApiService.js.map