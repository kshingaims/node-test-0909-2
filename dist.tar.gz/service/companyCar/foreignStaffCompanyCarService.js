/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { Define } from '../../utils/define.js';
import { isBeforeToday, isFromDatetimeBeforeToDatetime } from '../../utils/index.js';
import { getNotVacantCompanyCarIds, listCompanyCars } from '../../service/master/companyCarService.js';
import { getNotVacantDriverIds, listDrivers } from '../../service/master/driverService.js';
/**
 * 該当する旅程に紐つく海外拠点担当用社有者予定一覧を返す
 * @param prisma
 * @param itineraryId
 * @param foreignStaffSchedCompanyCarId 海外拠点用社有車予定ID
 * @returns
 */
export async function getForeignStaffCompanyCarSchedList(prisma, itineraryId, foreignStaffSchedCompanyCarId) {
    const where = {
        itineraryId,
        flgDelete: false,
    };
    // schedCompanyCarを返す
    if (foreignStaffSchedCompanyCarId) {
        where.id = foreignStaffSchedCompanyCarId;
    }
    const foreignStaffSchedCCars = await prisma.foreignStaffSchedCompanyCar.findMany({
        where,
        select: {
            id: true,
            itineraryId: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            remark: true,
            ownerPid: true,
            arrangedCars: {
                select: {
                    id: true,
                    companyCarId: true,
                    carNo: true,
                    carModel: true,
                    carColor: true,
                    driverId: true,
                    driverName: true,
                    driverTel: true,
                    driverEmail: true,
                    companyCar: {
                        select: {
                            id: true,
                            carNo: true,
                            carModel: true,
                            carColor: true,
                            driver: {
                                select: {
                                    id: true,
                                    name: true,
                                    tel: true,
                                    email: true,
                                    driverFiles: {
                                        select: {
                                            path: true,
                                            id: true,
                                            originalFileName: true,
                                            size: true,
                                        },
                                    },
                                },
                            },
                            companyCarFiles: {
                                select: {
                                    path: true,
                                    id: true,
                                    originalFileName: true,
                                    size: true,
                                },
                            },
                        },
                    },
                    driver: {
                        select: {
                            id: true,
                            name: true,
                            email: true,
                            tel: true,
                            driverFiles: {
                                select: {
                                    path: true,
                                    id: true,
                                    originalFileName: true,
                                    size: true,
                                },
                            },
                        },
                    },
                },
            },
            flgArrgt: true,
            schedCompanyCars: {
                select: {
                    id: true,
                    startDateTime: true,
                    endDateTime: true,
                    timezone: true,
                },
            },
        },
        orderBy: {
            // 取得される予定一覧は「1.予定出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            startDateTime: 'asc',
        },
    });
    return foreignStaffSchedCCars;
}
/**
 * 該当する旅程に紐つく海外拠点担当用社有者予定一覧を返す
 * 手配完了処理時に利用する
 * @param prisma
 * @param itineraryId
 * @param assinerPid
 * @returns
 */
export async function getForeignStaffCompanyCarSchedListForArrangeComplete(prisma, itineraryId, assinerPid) {
    const where = {
        itineraryId,
        ownerPid: assinerPid,
        flgDelete: false,
    };
    const foreignStaffSchedCCars = await prisma.foreignStaffSchedCompanyCar.findMany({
        where,
        select: {
            id: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            ownerPid: true,
            flgArrgt: true,
            itinerary: {
                select: {
                    itineraryIndividuals: {
                        select: {
                            pid: true,
                            itineraryName: true,
                            itineraryFrom: true,
                            itineraryTo: true,
                        },
                    },
                },
            },
            schedCompanyCars: {
                select: {
                    id: true,
                    flgArrgt: true,
                    flgDelete: true,
                    schedCompanyCarIndividuals: {
                        select: {
                            user: {
                                select: {
                                    email: true,
                                    pid: true,
                                    mcSyozokuCd: true,
                                },
                            },
                        },
                    },
                },
            },
        },
        orderBy: {
            // 取得される予定一覧は「1.予定出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            startDateTime: 'asc',
        },
    });
    return foreignStaffSchedCCars;
}
/**
 * 海外拠点担当用社有車予定及び社有車個人予定の登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props ForeignStaffSchedCompanyCarCreateProps
 * @param itineraryId 旅程ID
 * @param assinerPid 出張手配依頼を実施した出張者のPID
 * @return
 */
export async function createForeignStaffSchedCompanyCar(prisma, user, props, itineraryId, assinerPid) {
    // SchedCompanyCarテーブル作成;
    const result = await prisma.foreignStaffSchedCompanyCar.create({
        data: {
            itineraryId,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            remark: props.remark ? props.remark : undefined,
            ownerPid: assinerPid,
            updatedBy: user.pid,
        },
    });
    // ArrangedCarForForeignStaffテーブル作成;
    for (const arrangedCar of props.arrangedCars) {
        await _upsertArrangedCar(prisma, result.id, arrangedCar);
    }
    return result;
}
/**
 * 海外拠点用社有車予定の更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props ForeignStaffSchedCompanyCarUpdateProps
 * @param itineraryId 旅程ID
 * @param dbOriginal dbから検索した更新前のForeignStaffSchedCompanyCar情報
 * @return
 */
export async function updateForeignStaffSchedCompanyCar(prisma, user, props, dbOriginal, itineraryId) {
    await prisma.foreignStaffSchedCompanyCar.update({
        where: { id: props.id, itineraryId },
        data: {
            itineraryId,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            remark: props.remark ? props.remark : '',
            updatedBy: user.pid,
        },
    });
    const updatedIdMap = {};
    // ArrangedCarForForeignStaffテーブル作成;
    for (const arrangedCar of props.arrangedCars) {
        if (arrangedCar.id) {
            updatedIdMap[arrangedCar.id] = true;
        }
        await _upsertArrangedCar(prisma, props.id, arrangedCar);
    }
    // 削除されているArrangedCarを削除実施
    const deleteTargetIds = [];
    for (const dbArrangedCar of dbOriginal.arrangedCars) {
        // 更新対象となっていないものは削除対象となる
        if (dbArrangedCar.id && !updatedIdMap[dbArrangedCar.id]) {
            deleteTargetIds.push(dbArrangedCar.id);
        }
    }
    if (deleteTargetIds.length > 0) {
        await _deleteArrangedCar(prisma, deleteTargetIds);
    }
}
/**
 * 海外拠点用社有車予定の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param itineraryId 旅程ID
 * @param id 海外拠点用社有車予定ID
 * @return
 */
export async function deleteForeignStaffSchedCompanyCar(prisma, user, itineraryId, id) {
    // クライアント側から送信されたidに合致する社有車予定を削除する(削除フラグをたてる)
    await prisma.foreignStaffSchedCompanyCar.update({
        where: { id, itineraryId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * 海外拠点担当用社有車予定の手配実施フラグ更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param itineraryId
 * @param ids 更新対象のID配列
 * @return
 */
export async function updateForeignStaffSchedChangeArrgt(prisma, user, itineraryId, ids, flgArrgt = false) {
    await prisma.foreignStaffSchedCompanyCar.updateMany({
        where: { itineraryId, id: { in: ids } },
        data: {
            flgArrgt,
            updatedBy: user.pid,
        },
    });
}
async function _upsertArrangedCar(prisma, foreignStaffSchedCompanyCarId, arrangedCar) {
    if (arrangedCar.id) {
        await prisma.arrangedCarForForeignStaff.update({
            data: {
                companyCarId: arrangedCar.companyCarId,
                carColor: arrangedCar.carColor,
                carModel: arrangedCar.carModel,
                carNo: arrangedCar.carNo,
                driverId: arrangedCar.driverId,
                driverName: arrangedCar.driverName,
                driverTel: arrangedCar.driverTel,
                driverEmail: arrangedCar.driverEmail,
            },
            where: {
                id: arrangedCar.id,
                foreignStaffSchedCompanyCarId,
            },
        });
        return arrangedCar;
    }
    else {
        const result = await prisma.arrangedCarForForeignStaff.create({
            data: {
                foreignStaffSchedCompanyCarId,
                companyCarId: arrangedCar.companyCarId,
                carColor: arrangedCar.carColor,
                carModel: arrangedCar.carModel,
                carNo: arrangedCar.carNo,
                driverId: arrangedCar.driverId,
                driverName: arrangedCar.driverName,
                driverTel: arrangedCar.driverTel,
                driverEmail: arrangedCar.driverEmail,
            },
        });
        return result;
    }
}
async function _deleteArrangedCar(prisma, ids) {
    const result = await prisma.arrangedCarForForeignStaff.deleteMany({ where: { id: { in: ids } } });
    if (result.count !== ids.length) {
        throw new Error('db delete count is not collect.');
    }
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function checkValidateCommon(prisma, user, props) {
    // 開始日時または終了日時が現在日よりも前の日時(W00102)
    if (isBeforeToday(new Date(props.startDateTime)) || isBeforeToday(new Date(props.endDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 終了日時が開始日時よりも前の日時となっている(W00103)
    if (isFromDatetimeBeforeToDatetime(new Date(props.endDateTime), new Date(props.startDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    const checkedCarIds = [];
    const carUniqueChecker = {};
    const checkedDriverIds = [];
    const driverUniqueChecker = {};
    for (const arrangedCar of props.arrangedCars) {
        if (arrangedCar.companyCarId) {
            if (!carUniqueChecker[arrangedCar.companyCarId]) {
                carUniqueChecker[arrangedCar.companyCarId] = true;
                checkedCarIds.push(arrangedCar.companyCarId);
            }
            else {
                // 同じ社有車が重複して指定されているので、入力チェックエラーにする
                return { code: Define.ERROR_CODES.W00124, status: 200 };
            }
        }
        if (arrangedCar.driverId) {
            if (!driverUniqueChecker[arrangedCar.driverId]) {
                driverUniqueChecker[arrangedCar.driverId] = true;
                checkedDriverIds.push(arrangedCar.driverId);
            }
            else {
                // 同じドライバーが重複して指定されているので、入力チェックエラーにする
                return { code: Define.ERROR_CODES.W00125, status: 200 };
            }
        }
    }
    // 指定された社有車IDが存在し、その社有車はログインユーザのMC所属コードに属していることをチェック(W00109)
    if (checkedCarIds.length > 0) {
        // 指定された社有車IDが存在し、その社有車はログインユーザのMC所属コードに属していることをチェック(W00109)
        const companyCars = await listCompanyCars(prisma, user, Define.SETTINGS.LIMIT_GROUP.ONLY_MY_SYOZOKU_GROUP, checkedCarIds);
        if (companyCars.length !== checkedCarIds.length) {
            return { code: Define.ERROR_CODES.W00109, status: 400 };
        }
        // 指定された社有車IDが、利用時間帯において空車状態(空きがある)かをチェック
        const revervedIds = await getNotVacantCompanyCarIds(prisma, props.startDateTime, props.endDateTime, props.id);
        if (revervedIds.some((reserveId) => checkedCarIds.includes(reserveId))) {
            return { code: Define.ERROR_CODES.W00124, status: 200 };
        }
    }
    // 指定されたドライバーIDが存在し、そのドライバーはログインユーザのMC所属コードに属していることをチェック(W00109)
    if (checkedDriverIds.length > 0) {
        const drivers = await listDrivers(prisma, user, Define.SETTINGS.LIMIT_GROUP.ONLY_MY_SYOZOKU_GROUP, checkedDriverIds);
        if (drivers.length !== checkedDriverIds.length) {
            return { code: Define.ERROR_CODES.W00109, status: 400 };
        }
        // 指定されたドライバーIDが、利用時間帯においてアサインされている(空きがある)かをチェック
        const revervedIds = await getNotVacantDriverIds(prisma, props.startDateTime, props.endDateTime, props.id);
        if (revervedIds.some((reserveId) => checkedDriverIds.includes(reserveId))) {
            return { code: Define.ERROR_CODES.W00125, status: 200 };
        }
    }
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function checkValidateForSchedCreate(prisma, user, props) {
    return await checkValidateCommon(prisma, user, props);
}
/**
 * 予定更新用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function checkValidateForSchedUpdate(prisma, dbOriginal, user, props) {
    // arrangedCarsで指定されているidが、dbから取得したarrangedCarsに含まれているかをチェック
    const checkArrangedCarIdMap = {};
    for (const dbInfo of dbOriginal.arrangedCars) {
        if (dbInfo.id) {
            checkArrangedCarIdMap[dbInfo.id] = true;
        }
    }
    for (const arrangedCar of props.arrangedCars) {
        if (arrangedCar.id && !checkArrangedCarIdMap[arrangedCar.id]) {
            return { code: Define.ERROR_CODES.W00109, status: 400 };
        }
    }
    return await checkValidateCommon(prisma, user, props);
}
//# sourceMappingURL=foreignStaffCompanyCarService.js.map