/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { filter, orderBy } from 'lodash-es';
import { Define } from '../../utils/define.js';
import { format, formatDate, formatDateTimeMiliSecond, isBeforeToday, isFromDatetimeBeforeToDatetime, replaceCRLF, strToBuf, } from '../../utils/index.js';
import { sendSmtpMail } from '../../utils/smtpMail.js';
import { createItineraryAccessKey, makeAccesskeyFromUuid } from '../../utils/foreignStaff.js';
import { isExistsItineraryCompanions } from '../../service/itinerary/itineraryService.js';
import { getNotVacantCompanyCarIds, listCompanyCars } from '../../service/master/companyCarService.js';
import { getNotVacantDriverIds, listDrivers } from '../../service/master/driverService.js';
import { getUsersByPids } from '../../service/user/userService.js';
import { getNotificationSettingMapByIds } from '../../service/notification/notificationSettingService.js';
import { createSiteNotification } from '../../service/notification/notificationService.js';
/**
 * 処理対象アカウントが表示可能な社有車予定一覧取得
 * 指定されたitineraryIdに合致する社有車手配一覧を取得する
 * japanStaffもforeignStaffもこの関数では同じ処理をする
 * 社有車手配と、社有車予定を紐つける必要はないので、それぞれ独立したテーブルデータとして考えて良いという設計
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param arrgtCompanyCarId
 * @returns
 */
export async function getArrgtCompanyCarList(prisma, pid, itineraryId, arrgtCompanyCarId, isForeignStaff = false) {
    const where = {
        // (共通条件)社有車手配に削除フラグがたっていないもの
        flgDelete: false,
    };
    // 海外拠点担当以外の場合は、自身の手配情報しか取得させない。
    if (!isForeignStaff) {
        where.ownerPid = pid;
    }
    if (arrgtCompanyCarId) {
        where.id = arrgtCompanyCarId;
    }
    if (itineraryId) {
        where.itineraryId = itineraryId;
    }
    const arrgtCompanyCars = await prisma.arrgtCompanyCar.findMany({
        where,
        select: {
            id: true,
            itineraryId: true,
            emailTo: true,
            startDate: true,
            endDate: true,
            passengers: true,
            otherPeopleCount: true,
            remark: true,
            ownerPid: true,
        },
        orderBy: {
            // 取得される社有車手配一覧は「社有車手配IDの昇順(asc) となるように一覧取得する。
            id: 'asc',
        },
    });
    // passengersに紐つくユーザ情報を取得する
    const allUserPids = [];
    let pidUseMap = {};
    // 社有車手配一覧のデータ内に存在する全てのユーザのpidsを取得する
    for (const arrgtCompanyCar of arrgtCompanyCars) {
        const pids = arrgtCompanyCar.passengers;
        if (pids && pids.length > 0) {
            for (const pid of pids) {
                if (!pidUseMap[pid]) {
                    allUserPids.push(pid);
                    pidUseMap[pid] = true;
                }
            }
        }
    }
    const users = await getUsersByPids(prisma, allUserPids);
    // pidUserMapは初期化しておく
    pidUseMap = {};
    // pidUserMapにUserオブジェクトをセットしておく
    for (const user of users) {
        if (!pidUseMap[user.pid]) {
            pidUseMap[user.pid] = user;
        }
    }
    for (const arrgtCompanyCar of arrgtCompanyCars) {
        const pids = arrgtCompanyCar.passengers;
        if (pids && pids.length > 0) {
            const newPassengers = [];
            for (const pid of pids) {
                if (pidUseMap[pid]) {
                    newPassengers.push(pidUseMap[pid]);
                }
                else {
                    throw new Error('programing error. passengers must be user pid.');
                }
            }
            // passengersは、pidの配列ではなく、userの配列に変換する
            arrgtCompanyCar.passengers = newPassengers;
        }
    }
    return arrgtCompanyCars;
}
/**
 * 社有車手配の登録作業
 * itineraryAccessForeignStaffに対象のレコードが存在しない場合は登録作業
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props ArrgtCompanyCarCreateProps
 * @return
 */
export async function createArrgtCompanyCar(prisma, pid, user, props) {
    // 社有車手配の新規登録を実施する。
    const result = await prisma.arrgtCompanyCar.create({
        data: {
            ownerPid: pid,
            itineraryId: props.arrgt.itineraryId,
            emailTo: props.arrgt.emailTo,
            startDate: props.arrgt.startDate,
            endDate: props.arrgt.endDate,
            passengers: props.arrgt.passengers,
            otherPeopleCount: props.arrgt.otherPeopleCount,
            remark: props.arrgt.remark,
            updatedBy: user.pid,
        },
    });
    // ItineraryAccessForeignStaffテーブルに、以下の条件に合致するレコードが存在しているか確認。
    const itineraryAccessForeignStaffResult = await prisma.itineraryAccessForeignStaff.findFirst({
        where: {
            itineraryId: props.arrgt.itineraryId,
            assignerPid: pid, // 社有車手配実施者のpid
        },
    });
    let accessKey = undefined;
    // レコードが存在していなければ、新規追加する。
    if (!itineraryAccessForeignStaffResult) {
        const accessUuidKey = createItineraryAccessKey();
        await prisma.itineraryAccessForeignStaff.create({
            data: {
                itineraryId: props.arrgt.itineraryId,
                assignerPid: pid,
                accessUuidKey: accessUuidKey.uuid,
                updatedBy: user.pid,
            },
        });
        accessKey = accessUuidKey.accessKey ? accessUuidKey.accessKey : undefined;
    }
    else {
        accessKey = makeAccesskeyFromUuid(itineraryAccessForeignStaffResult?.accessUuidKey);
    }
    if (!accessKey) {
        throw new Error('unreachable error.');
    }
    return { id: result.id, accessKey };
}
/**
 * 処理対象アカウントが表示可能な予定一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param schedCompanyCarId
 * @param isForeignStaff
 * @param isOutlookIntegration outlook連携用のデータ取得である(default: false)
 * @returns
 */
export async function getCompanyCarSchedList(prisma, pid, itineraryId, schedCompanyCarId, isOutlookIntegration = false) {
    const where = {
        pid,
        schedCompanyCar: { flgDelete: !isOutlookIntegration ? false : undefined },
        flgDelete: false,
        flgReject: false,
    };
    if (!schedCompanyCarId && !itineraryId) {
        // 旅程IDもしくは予定IDは指定必須
        throw new Error('unreachable error.');
    }
    // schedCompanyCarを返す
    if (schedCompanyCarId) {
        where.schedCompanyCarId = schedCompanyCarId;
    }
    if (itineraryId) {
        where.schedCompanyCar = { itineraryId: itineraryId, flgDelete: !isOutlookIntegration ? false : undefined };
    }
    const schedCompanyCarIndividuals = await prisma.schedCompanyCarIndividual.findMany({
        where,
        select: {
            calendarId: isOutlookIntegration,
            calendarUpdatedAt: isOutlookIntegration,
            flgReject: true,
            schedCompanyCar: {
                select: {
                    id: true,
                    itineraryId: true,
                    startDateTime: true,
                    endDateTime: true,
                    timezone: true,
                    departureLocation: true,
                    remark: true,
                    ownerPid: true,
                    flgCreateForeignStaff: true,
                    calendarId: isOutlookIntegration,
                    calendarUpdatedAt: isOutlookIntegration,
                    iCalUId: isOutlookIntegration,
                    flgArrgt: true,
                    flgDelete: true,
                    updatedAt: isOutlookIntegration,
                    arrangedCars: {
                        select: {
                            id: true,
                            companyCarId: true,
                            carNo: true,
                            carModel: true,
                            carColor: true,
                            driverId: true,
                            driverName: true,
                            driverTel: true,
                            driverEmail: true,
                            companyCar: {
                                select: {
                                    id: true,
                                    carNo: true,
                                    carModel: true,
                                    carColor: true,
                                    driver: {
                                        select: {
                                            id: true,
                                            name: true,
                                            tel: true,
                                            email: true,
                                            driverFiles: {
                                                select: {
                                                    path: true,
                                                    id: true,
                                                    originalFileName: true,
                                                    size: true,
                                                },
                                            },
                                        },
                                    },
                                    companyCarFiles: {
                                        select: {
                                            path: true,
                                            id: true,
                                            originalFileName: true,
                                            size: true,
                                        },
                                    },
                                },
                            },
                            driver: {
                                select: {
                                    id: true,
                                    name: true,
                                    email: true,
                                    tel: true,
                                    driverFiles: {
                                        select: {
                                            path: true,
                                            id: true,
                                            originalFileName: true,
                                            size: true,
                                        },
                                    },
                                },
                            },
                        },
                    },
                    foreignStaffSchedCompanyCar: {
                        select: {
                            id: true,
                            startDateTime: true,
                            endDateTime: true,
                            timezone: true,
                            arrangedCars: {
                                select: {
                                    companyCarId: true,
                                    carNo: true,
                                    carModel: true,
                                    carColor: true,
                                    driverId: true,
                                    driverName: true,
                                    driverTel: true,
                                    driverEmail: true,
                                    companyCar: {
                                        select: {
                                            id: true,
                                            carNo: true,
                                            carModel: true,
                                            carColor: true,
                                            driver: {
                                                select: {
                                                    id: true,
                                                    name: true,
                                                    tel: true,
                                                    email: true,
                                                    driverFiles: {
                                                        select: {
                                                            path: true,
                                                            id: true,
                                                            originalFileName: true,
                                                            size: true,
                                                        },
                                                    },
                                                },
                                            },
                                            companyCarFiles: {
                                                select: {
                                                    path: true,
                                                    id: true,
                                                    originalFileName: true,
                                                    size: true,
                                                },
                                            },
                                        },
                                    },
                                    driver: {
                                        select: {
                                            id: true,
                                            name: true,
                                            tel: true,
                                            email: true,
                                            driverFiles: {
                                                select: {
                                                    path: true,
                                                    id: true,
                                                    originalFileName: true,
                                                    size: true,
                                                },
                                            },
                                        },
                                    },
                                },
                            },
                            remark: true,
                        },
                    },
                    schedCompanyCarIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    firstNameRoma: true,
                                    lastNameRoma: true,
                                    firstNameKanji: true,
                                    lastNameKanji: true,
                                    firstNameKana: true,
                                    lastNameKana: true,
                                    email: true,
                                },
                            },
                            flgReject: true,
                            createdAt: true,
                            flgDelete: true,
                        },
                    },
                    schedCompanyCarFiles: {
                        select: {
                            id: true,
                            originalFileName: true,
                            size: true,
                            ownerPid: true,
                            path: isOutlookIntegration,
                            azAttachmentId: isOutlookIntegration,
                            azAttachmentUpdatedAt: isOutlookIntegration,
                        },
                    },
                    arrgtCompanyCar: {
                        select: {
                            id: true,
                            itineraryId: true,
                            emailTo: true,
                            startDate: true,
                            endDate: true,
                            passengers: true,
                            otherPeopleCount: true,
                            remark: true,
                            ownerPid: true,
                        },
                    },
                },
            },
        },
        orderBy: {
            // 取得される予定一覧は「1.予定出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            schedCompanyCar: {
                startDateTime: 'asc',
            },
        },
    });
    // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
    for (const schedCompanyCarIndividual of schedCompanyCarIndividuals) {
        // 予定予定(schedCompanyCar)の中にあるschedCompanyCarIndividualsについては、作成日時の昇順(asc)となるように、予定予定一覧の全レコードに対して、並び替えを実施する。
        schedCompanyCarIndividual.schedCompanyCar.schedCompanyCarIndividuals = orderBy(
        // 予定予定(schedCompanyCar)の中にあるschedCompanyCarIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedCompanyCarIndividual.schedCompanyCar.schedCompanyCarIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return schedCompanyCarIndividuals;
}
/**
 * 更新処理のレスポンスデータとして予定情報を返す (海外拠点担当者なら誰でも取得可能)
 * @param prisma
 * @param schedCompanyCarId
 * @returns
 */
export async function getCompanyCarSchedData(prisma, schedCompanyCarId) {
    // schedCompanyCarを返す。JSON構造についてはGET返却時のAPIレスポンスと同じ構造となるようにする
    // schedCompanyCarIndividualに紐つくshcedCompanyCarがあるという
    const schedCompanyCar = await prisma.schedCompanyCar.findFirst({
        where: { id: schedCompanyCarId, flgDelete: false },
        select: {
            id: true,
            itineraryId: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            departureLocation: true,
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            calendarId: true,
            calendarUpdatedAt: true,
            flgArrgt: true,
            foreignStaffSchedCompanyCar: {
                select: {
                    id: true,
                    startDateTime: true,
                    endDateTime: true,
                    timezone: true,
                    arrangedCars: {
                        select: {
                            companyCarId: true,
                            carNo: true,
                            carModel: true,
                            carColor: true,
                            driverId: true,
                            driverName: true,
                            driverTel: true,
                            driverEmail: true,
                            companyCar: {
                                select: {
                                    id: true,
                                    carNo: true,
                                    carModel: true,
                                    carColor: true,
                                    driver: {
                                        select: {
                                            id: true,
                                            name: true,
                                            tel: true,
                                            email: true,
                                            driverFiles: {
                                                select: {
                                                    path: true,
                                                    id: true,
                                                    originalFileName: true,
                                                    size: true,
                                                },
                                            },
                                        },
                                    },
                                    companyCarFiles: {
                                        select: {
                                            path: true,
                                            id: true,
                                            originalFileName: true,
                                            size: true,
                                        },
                                    },
                                },
                            },
                            driver: {
                                select: {
                                    id: true,
                                    name: true,
                                    email: true,
                                    tel: true,
                                    driverFiles: {
                                        select: {
                                            path: true,
                                            id: true,
                                            originalFileName: true,
                                            size: true,
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
            schedCompanyCarIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                            firstNameRoma: true,
                            lastNameRoma: true,
                            firstNameKanji: true,
                            lastNameKanji: true,
                            firstNameKana: true,
                            lastNameKana: true,
                            email: true,
                        },
                    },
                    flgReject: true,
                    createdAt: true,
                    flgDelete: true,
                },
            },
            schedCompanyCarFiles: {
                select: {
                    id: true,
                    originalFileName: true,
                    size: true,
                    ownerPid: true,
                },
            },
            arrgtCompanyCar: {
                select: {
                    id: true,
                    itineraryId: true,
                    emailTo: true,
                    startDate: true,
                    endDate: true,
                    passengers: true,
                    otherPeopleCount: true,
                    remark: true,
                    ownerPid: true,
                },
            },
        },
    });
    if (schedCompanyCar) {
        // 予定予定(schedCompanyCar)の中にあるschedCompanyCarIndividualsについては、作成日時の昇順(asc)となるように、予定予定一覧の全レコードに対して、並び替えを実施する。
        schedCompanyCar.schedCompanyCarIndividuals = orderBy(
        // 予定予定(schedCompanyCar)の中にあるschedCompanyCarIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedCompanyCar.schedCompanyCarIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return {
        schedCompanyCar,
    };
}
/**
 * 海外拠点担当者による関数呼び出しを想定。
 * 海外拠点担当者が海外拠点担当用社有車予定を登録・更新・削除を実施する際に利用する。
 * @param prisma
 * @param itineraryId
 * @param foreignStaffSchedCompanyCarId
 * @returns
 */
export async function getSchedCompanyCarsForForeignStaffChangingFlgArrgt(prisma, itineraryId, foreignStaffSchedCompanyCarId) {
    const where = { flgDelete: false, itineraryId };
    if (foreignStaffSchedCompanyCarId) {
        where.foreignStaffSchedCompanyCarId = foreignStaffSchedCompanyCarId;
    }
    return prisma.schedCompanyCar.findMany({
        select: {
            id: true,
            arrgtCompanyCarId: true,
            flgArrgt: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            foreignStaffSchedCompanyCarId: true,
            flgCreateForeignStaff: true,
        },
        where,
    });
}
/**
 * 旅程Excelダウンロード用に、対象旅程IDに紐づく社有車予定一覧を取得する
 * @param prisma
 * @param itineraryId
 * @returns
 */
export async function getCompanyCarsForExcelDownload(prisma, itineraryId) {
    const schedCompanyCars = await prisma.schedCompanyCar.findMany({
        where: {
            flgDelete: false,
            itineraryId,
        },
        select: {
            id: true,
            itineraryId: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            departureLocation: true,
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            flgArrgt: true,
            flgDelete: true,
            schedCompanyCarIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                        },
                    },
                    flgReject: true,
                    flgDelete: true,
                },
            },
        },
        orderBy: {
            // 取得される予定一覧は「1.予定出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            startDateTime: 'asc',
        },
    });
    return schedCompanyCars;
}
/**
 * 社有車予定及び社有車個人予定の登録作業。
 * 社有車予定のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props CompanyCarSchedCreateProps
 * @param itineraryId 旅程ID
 * @return
 */
export async function createSchedCompanyCar(prisma, pid, user, props, itineraryId) {
    // SchedCompanyCarテーブル作成;
    const result = await prisma.schedCompanyCar.create({
        data: {
            ownerPid: pid,
            itineraryId,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            departureLocation: props.departureLocation ? props.departureLocation : undefined,
            remark: props.remark ? props.remark : undefined,
            flgArrgt: true,
            flgCreateForeignStaff: false,
            updatedBy: user.pid,
        },
    });
    const schedCompanyCarId = result.id;
    const targetPids = [];
    // 利用者がいれば、その利用者の数だけ、SchedCompanyCarIndividualを登録する
    if (props.companions) {
        for (const companion of props.companions) {
            targetPids.push(companion.pid);
        }
    }
    // 出張代表者をSchedEventIndividualとして最初に登録しておく
    targetPids.unshift(pid); //予定作成者を先頭に追加する
    for (const targetPid of targetPids) {
        await prisma.schedCompanyCarIndividual.create({
            data: {
                schedCompanyCarId,
                pid: targetPid,
                updatedBy: user.pid,
            },
        });
    }
    // ArrangedCarテーブル作成;
    for (const arrangedCar of props.arrangedCars) {
        await _upsertArrangedCar(prisma, result.id, arrangedCar);
    }
    return schedCompanyCarId;
}
/**
 * 社有車手配時に実行する
 * 社有車予定及び社有車個人予定の登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props CompanyCarSchedCreateProps
 * @param itineraryId 旅程ID
 * @return
 */
export async function createSchedCompanyCarForArrangement(prisma, pid, user, itineraryId, arrgtCompanyCarId, passengers, props) {
    // SchedCompanyCarテーブル作成;
    const result = await prisma.schedCompanyCar.create({
        data: {
            arrgtCompanyCarId: arrgtCompanyCarId,
            ownerPid: pid,
            itineraryId,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            flgArrgt: false,
            flgCreateForeignStaff: false,
            updatedBy: user.pid,
        },
    });
    const schedCompanyCarId = result.id;
    for (const targetPid of passengers) {
        await prisma.schedCompanyCarIndividual.create({
            data: {
                schedCompanyCarId,
                pid: targetPid,
                updatedBy: user.pid,
            },
        });
    }
    return schedCompanyCarId;
}
/**
 * 社有車予定及び社有車個人予定の更新作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props CompanyCarSchedUpdateProps
 * @param itineraryId 旅程ID
 * @param dbSchedCompanyCar SchedCompanyCarInschedCompanyCarIndividuals
 * @return
 */
export async function updateSchedCompanyCar(prisma, pid, user, props, itineraryId, dbSchedCompanyCar, isForeignStaff = false) {
    const companionPids = props.companions ? props.companions?.map((companion) => companion.pid) : [];
    // 出張代表者をSchedEventIndividualとして最初に登録しておく ※海外拠点担当者を除く
    if (!isForeignStaff) {
        companionPids.unshift(pid); //予定作成者を先頭に追加する
    }
    await prisma.schedCompanyCar.update({
        where: { id: props.id, itineraryId },
        data: {
            ownerPid: pid,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            departureLocation: props.departureLocation,
            remark: props.remark,
            flgArrgt: props.flgArrgt,
            updatedBy: user.pid,
        },
    });
    const schedCompanyCarIndividualPids = [];
    for (const dbSchedCompanyCarIndividual of dbSchedCompanyCar.schedCompanyCarIndividuals) {
        if (!dbSchedCompanyCarIndividual.flgDelete) {
            if (!companionPids.includes(dbSchedCompanyCarIndividual.pid)) {
                // DB取得したSchedCompanyCarIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧に含まれていない場合は、同行者削除(flgDelete=true)を実施する。
                await prisma.schedCompanyCarIndividual.update({
                    data: {
                        flgDelete: true,
                        updatedBy: user.pid,
                    },
                    where: {
                        schedCompanyCarId_pid: {
                            schedCompanyCarId: dbSchedCompanyCarIndividual.schedCompanyCarId,
                            pid: dbSchedCompanyCarIndividual.pid,
                        },
                    },
                });
            }
            // DB取得したSchedCompanyCarIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧にも含まれている場合は、何も処理しない(同行者指定済)
        }
        else if (dbSchedCompanyCarIndividual.flgDelete) {
            if (companionPids.includes(dbSchedCompanyCarIndividual.pid)) {
                // DB取得したSchedCompanyCarIndividualがflgDelete=trueとなっており、クライアント側から取得した同行者一覧に含まれている場合は、同行者の再指定(flgDelete=false)を実施する。
                await prisma.schedCompanyCarIndividual.update({
                    data: {
                        flgDelete: false,
                        updatedBy: user.pid,
                    },
                    where: {
                        schedCompanyCarId_pid: {
                            schedCompanyCarId: dbSchedCompanyCarIndividual.schedCompanyCarId,
                            pid: dbSchedCompanyCarIndividual.pid,
                        },
                    },
                });
            }
        }
        // DB取得したSchedCompanyCarIndividualのpid一覧作成
        schedCompanyCarIndividualPids.push(dbSchedCompanyCarIndividual.pid);
    }
    // クライアント側から取得した同行者一覧の中にあるpidが、DB取得したSchedCompanyCarIndividual一覧の中に含まれていない場合は、同行者の新規追加実施
    for (const companionPid of companionPids) {
        if (!schedCompanyCarIndividualPids.includes(companionPid)) {
            await prisma.schedCompanyCarIndividual.create({
                data: {
                    schedCompanyCarId: dbSchedCompanyCar.id,
                    pid: companionPid,
                    updatedBy: user.pid,
                },
            });
        }
    }
    // 海外拠点担当用社有車予定との紐付けがある場合は、海外拠点側で社有車の手配を決定しているので、
    // 出張者側では社有車情報の紐付けを実施しない
    if (!dbSchedCompanyCar.foreignStaffSchedCompanyCarId && props.arrangedCars) {
        const updatedIdMap = {};
        // ArrangedCarテーブル作成;
        for (const arrangedCar of props.arrangedCars) {
            if (arrangedCar.id) {
                updatedIdMap[arrangedCar.id] = true;
            }
            await _upsertArrangedCar(prisma, props.id, arrangedCar);
        }
        // 削除されているArrangedCarを削除実施
        const deleteTargetIds = [];
        for (const dbArrangedCar of dbSchedCompanyCar.arrangedCars) {
            // 更新対象となっていないものは削除対象となる
            if (dbArrangedCar.id && !updatedIdMap[dbArrangedCar.id]) {
                deleteTargetIds.push(dbArrangedCar.id);
            }
        }
        if (deleteTargetIds.length > 0) {
            await _deleteArrangedCar(prisma, deleteTargetIds);
        }
    }
}
/**
 * 社有車予定の手配実施フラグ更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param itineraryId
 * @param ids 更新対象のID配列
 * @return
 */
export async function updateSchedChangeArrgt(prisma, user, itineraryId, ids, flgArrgt = false) {
    await prisma.schedCompanyCar.updateMany({
        where: { itineraryId, id: { in: ids } },
        data: {
            flgArrgt,
            updatedBy: user.pid,
        },
    });
}
/**
 * 社有車予定に紐ついている海外拠点用社有車ID情報を更新する
 * こちらの関数は海外拠点担当のみしか実施しない処理となる。
 * @param prisma PrismaClient
 * @param itineraryId 条件となる旅程ID
 * @param ids 条件となる社有車IDの配列
 * @param foreignStaffSchedCompanyCarId 更新実施する海外拠点担当用社有車予定ID
 * @param flgArrgt
 * @return
 */
export async function updateForeignStaffSchedCompanyIdByForeignStaff(prisma, itineraryId, ids, foreignStaffSchedCompanyCarId, parentflgArrgt = false) {
    const isRelease = foreignStaffSchedCompanyCarId == null;
    const result = await prisma.schedCompanyCar.updateMany({
        where: { itineraryId, id: { in: ids } },
        data: {
            flgArrgt: isRelease ? false : parentflgArrgt,
            flgCreateForeignStaff: isRelease ? false : true,
            foreignStaffSchedCompanyCarId,
        },
    });
    if (result.count !== ids.length) {
        throw new Error('unreachable error. update count is not collect.');
    }
}
/**
 * 社有車個人予定テーブルの更新作業。
 * 社有車予定参加の拒否
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedCompanyCarId schedCompanyCarId
 * @param flgReject boolean
 * @return
 */
export async function rejectSchedCompanyCarIndividual(prisma, pid, user, schedCompanyCarId, flgReject) {
    await prisma.schedCompanyCarIndividual.update({
        where: { schedCompanyCarId_pid: { schedCompanyCarId, pid: pid } },
        data: {
            flgReject,
            updatedBy: user.pid,
        },
    });
}
/**
 * 社有車予定(手配は除く)の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param schedCompanyCarId 社有車予定ID
 * @return
 */
export async function deleteSchedCompanyCar(prisma, user, schedCompanyCarId) {
    // クライアント側から送信されたidに合致する社有車予定を削除する(削除フラグをたてる)
    await prisma.schedCompanyCar.update({
        where: { id: schedCompanyCarId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * 手配登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function createArrgtCompanyCarValidate(pid, prisma, props) {
    const itineraryId = props.arrgt.itineraryId;
    const startDate = props.arrgt.startDate;
    const endDate = props.arrgt.endDate;
    const passengers = props.arrgt.passengers;
    const mailBody = props.mail.body;
    const schedCompanyCars = props.schedCompanyCars;
    /*
     * passengers配列に指定されているpidが、紐ついている旅程の作成者/同行者になっていない(W00104)
     * 同じpidが複数回指定されている(W00118)
     **/
    const error = await isExistsItineraryCompanions(prisma, itineraryId, passengers);
    if (error) {
        return error;
    }
    // 手配者のpidが、companionsに含まれているかをチェック
    if (!passengers.includes(pid)) {
        return { code: Define.ERROR_CODES.W00119, status: 400 };
    }
    if (startDate !== undefined && endDate !== undefined) {
        // 開始日時または終了日時が現在日よりも前の日時(W00102)
        if (isBeforeToday(new Date(startDate)) || isBeforeToday(new Date(endDate))) {
            return { code: Define.ERROR_CODES.W00102, status: 200 };
        }
        // 終了日が開始日よりも前の日時となっている(W00103)
        if (isFromDatetimeBeforeToDatetime(new Date(endDate), new Date(startDate))) {
            return { code: Define.ERROR_CODES.W00103, status: 200 };
        }
    }
    for (const schedCompanyCar of schedCompanyCars) {
        if (schedCompanyCar.startDateTime && schedCompanyCar.endDateTime) {
            const startDateTime = new Date(schedCompanyCar.startDateTime);
            const endDateTime = new Date(schedCompanyCar.endDateTime);
            // 開始日時または終了日時が現在日よりも前の日時(W00102)
            if (isBeforeToday(startDateTime) || isBeforeToday(endDateTime)) {
                return { code: Define.ERROR_CODES.W00102, status: 200 };
            }
            // 終了日が開始日よりも前の日時となっている(W00103)
            if (isFromDatetimeBeforeToDatetime(endDateTime, startDateTime)) {
                return { code: Define.ERROR_CODES.W00103, status: 200 };
            }
        }
    }
    // mail.bodyの中に、Define.SETTINGS.FOREIGN_STAFF.COMPANY_CAR_ARRGT_PATH.BASE文字列が存在しない場合は、メール本文入力チェックエラー(W00801)
    if (!mailBody.includes(Define.SETTINGS.FOREIGN_STAFF.COMPANY_CAR_ARRGT_PATH.BASE)) {
        return { code: Define.ERROR_CODES.W00801, status: 200 };
    }
    return;
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function checkValidateCommon(prisma, itineraryId, user, pid, props) {
    // 終日フラグがない場合は、開始日時・終了日時・タイムゾーンについては入力必須チェック実施。 (W00802)
    if (props.startDateTime === undefined || props.endDateTime === undefined || props.timezone === undefined) {
        return { code: Define.ERROR_CODES.W00802, status: 400 };
    }
    // 開始日時または終了日時が現在日よりも前の日時(W00102)
    if (isBeforeToday(new Date(props.startDateTime)) || isBeforeToday(new Date(props.endDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 終了日時が開始日時よりも前の日時となっている(W00103)
    if (isFromDatetimeBeforeToDatetime(new Date(props.endDateTime), new Date(props.startDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    if (props.arrangedCars) {
        const checkedCarIds = [];
        const carUniqueChecker = {};
        const checkedDriverIds = [];
        const driverUniqueChecker = {};
        for (const arrangedCar of props.arrangedCars) {
            if (arrangedCar.companyCarId) {
                if (!carUniqueChecker[arrangedCar.companyCarId]) {
                    carUniqueChecker[arrangedCar.companyCarId] = true;
                    checkedCarIds.push(arrangedCar.companyCarId);
                }
                else {
                    // 同じ社有車が重複して指定されているので、入力チェックエラーにする
                    return { code: Define.ERROR_CODES.W00124, status: 200 };
                }
            }
            if (arrangedCar.driverId) {
                if (!driverUniqueChecker[arrangedCar.driverId]) {
                    driverUniqueChecker[arrangedCar.driverId] = true;
                    checkedDriverIds.push(arrangedCar.driverId);
                }
                else {
                    // 同じドライバーが重複して指定されているので、入力チェックエラーにする
                    return { code: Define.ERROR_CODES.W00125, status: 200 };
                }
            }
        }
        // 指定された社有車IDが存在し、その社有車はログインユーザのMC所属コードに属していることをチェック(W00109)
        if (checkedCarIds.length > 0) {
            // 指定された社有車IDが存在し、その社有車はログインユーザのMC所属コードに属していることをチェック(W00109)
            const companyCars = await listCompanyCars(prisma, user, Define.SETTINGS.LIMIT_GROUP.NO_LIMIT, checkedCarIds);
            if (companyCars.length !== checkedCarIds.length) {
                return { code: Define.ERROR_CODES.W00109, status: 400 };
            }
            // 指定された社有車IDが、利用時間帯において空車状態(空きがある)かをチェック
            const revervedIds = await getNotVacantCompanyCarIds(prisma, props.startDateTime, props.endDateTime);
            if (revervedIds.some((reserveId) => checkedCarIds.includes(reserveId))) {
                return { code: Define.ERROR_CODES.W00124, status: 200 };
            }
        }
        // 指定されたドライバーIDが存在し、そのドライバーはログインユーザのMC所属コードに属していることをチェック(W00109)
        if (checkedDriverIds.length > 0) {
            const drivers = await listDrivers(prisma, user, Define.SETTINGS.LIMIT_GROUP.NO_LIMIT, checkedDriverIds);
            if (drivers.length !== checkedDriverIds.length) {
                return { code: Define.ERROR_CODES.W00109, status: 400 };
            }
            // 指定されたドライバーIDが、利用時間帯においてアサインされている(空きがある)かをチェック
            const revervedIds = await getNotVacantDriverIds(prisma, props.startDateTime, props.endDateTime);
            if (revervedIds.some((reserveId) => checkedDriverIds.includes(reserveId))) {
                return { code: Define.ERROR_CODES.W00125, status: 200 };
            }
        }
    }
    const companions = [];
    // 自分自身が旅程の作成者まはた同行者であることをチェック
    companions.push(pid);
    // 利用者を配列で取得
    if (props.companions !== undefined) {
        for (const companion of props.companions) {
            companions.push(companion.pid);
        }
    }
    // 利用者が同行者であることを確認
    const isExistsItineraryCompanion = await isExistsItineraryCompanions(prisma, itineraryId, companions);
    // 利用者のパラメータが旅程の同行者に存在しない場合
    if (isExistsItineraryCompanion !== undefined) {
        return isExistsItineraryCompanion;
    }
    return;
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function checkValidateForSchedCreate(prisma, itineraryId, user, pid, props) {
    return await checkValidateCommon(prisma, itineraryId, user, pid, props);
}
/**
 * 予定更新用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function checkValidateForSchedUpdate(prisma, itineraryId, user, pid, props, schedCompanyCar) {
    // DBから社有車予定情報が取得できない(W00109)
    if (schedCompanyCar === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    if (pid === schedCompanyCar.ownerPid) {
        // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
    }
    else {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    return await checkValidateCommon(prisma, itineraryId, user, pid, props);
}
async function _upsertArrangedCar(prisma, schedCompanyCarId, arrangedCar) {
    if (arrangedCar.id) {
        await prisma.arrangedCar.update({
            data: {
                companyCarId: arrangedCar.companyCarId,
                carColor: arrangedCar.carColor,
                carModel: arrangedCar.carModel,
                carNo: arrangedCar.carNo,
                driverId: arrangedCar.driverId,
                driverName: arrangedCar.driverName,
                driverTel: arrangedCar.driverTel,
                driverEmail: arrangedCar.driverEmail,
            },
            where: {
                id: arrangedCar.id,
                schedCompanyCarId,
            },
        });
        return arrangedCar;
    }
    else {
        const result = await prisma.arrangedCar.create({
            data: {
                schedCompanyCarId,
                companyCarId: arrangedCar.companyCarId,
                carColor: arrangedCar.carColor,
                carModel: arrangedCar.carModel,
                carNo: arrangedCar.carNo,
                driverId: arrangedCar.driverId,
                driverName: arrangedCar.driverName,
                driverTel: arrangedCar.driverTel,
                driverEmail: arrangedCar.driverEmail,
            },
        });
        return result;
    }
}
async function _deleteArrangedCar(prisma, ids) {
    const result = await prisma.arrangedCar.deleteMany({ where: { id: { in: ids } } });
    if (result.count !== ids.length) {
        throw new Error('db delete count is not collect.');
    }
}
/**
 * 予定手配実施フラグ更新処理の入力チェックとメール通知で利用する情報をDBから取得する
 * @param prisma
 * @param itineraryId
 * @param props
 * @returns
 */
export async function getSchedCompanyCarsForChangeArrgt(prisma, itineraryId, props) {
    const schedCompanyCars = await prisma.schedCompanyCar.findMany({
        select: {
            id: true,
            flgCreateForeignStaff: true,
            ownerPid: true,
            schedCompanyCarIndividuals: {
                select: {
                    flgDelete: true,
                    flgReject: true,
                    pid: true,
                    user: true,
                },
            },
            itinerary: {
                select: {
                    itineraryIndividuals: {
                        select: {
                            itineraryId: true,
                            itineraryFrom: true,
                            itineraryTo: true,
                            itineraryName: true,
                            pid: true,
                        },
                    },
                },
            },
        },
        where: { id: { in: props.ids }, itineraryId, flgDelete: false },
    });
    return schedCompanyCars;
}
/**
 * 予定手配実施フラグ更新用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function validateSchedChangeArrgt(props, schedCompanyCars) {
    // DBから予定情報が取得できない(W00109)
    if (schedCompanyCars.length !== props.ids.length) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // 予定の中に、一つでも海外拠点担当が作成した予定ではないものがあったら、エラー
    for (const schedCompanyCar of schedCompanyCars) {
        if (!schedCompanyCar.flgCreateForeignStaff) {
            return { code: Define.ERROR_CODES.W00123, status: 400 };
        }
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function deleteIfExists(pid, schedCompanyCar //prismaから取得したschedCompanyCarレコード
) {
    // DBから社有車予定情報が取得できない(W00109)
    if (schedCompanyCar === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    if (pid !== schedCompanyCar.ownerPid) {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    return;
}
/**
 * 入力チェック用のデータ取得を実施する。Individuals情報は削除フラグが立っているものも含んで取得する
 * @param prisma
 * @param pid
 * @param schedCompanyCarId
 * @param itineraryId
 * @returns
 */
export async function getSchedCompanyCarForChecker(prisma, schedCompanyCarId, itineraryId) {
    const schedEvent = await prisma.schedCompanyCar.findFirst({
        where: {
            id: schedCompanyCarId,
            itineraryId,
            flgDelete: false, // 削除フラグがたっていない
        },
        include: { schedCompanyCarIndividuals: true, arrangedCars: true }, //(flgDelete=trueのものも含んで取得する)
    });
    return schedEvent;
}
/**
 * こちらの関数は、outlookイベントをmctripに取り込む際に、mctripの予定を取り込まないようにする為のチェックで利用。
 * 指定したitineraryIdとpidに合致して、outlook連携している予定情報一覧を取得する。
 * 削除フラグや拒否フラグがある場合でも取得を実施する。
 * @param prisma
 * @param pid
 * @param itineraryId
 * @returns
 */
export async function getSchedCompanyCarsReflectedInOutlook(prisma, pid, itineraryId) {
    const schedIndividuals = await prisma.schedCompanyCarIndividual.findMany({
        where: {
            pid,
            schedCompanyCar: { itineraryId, calendarId: { not: null } },
        },
        select: {
            flgDelete: true,
            flgReject: true,
            schedCompanyCar: true,
        },
    });
    if (schedIndividuals.length <= 0) {
        return [];
    }
    else {
        return schedIndividuals.map((item) => {
            return item.schedCompanyCar;
        });
    }
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、DB更新処理などのMCTrip予定更新処理後のみ実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param user
 * @param schedId 予定のID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @param iCalUId outlookイベント固有ID
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, user, schedId, calendarId, calendarUpdatedAt, iCalUId) {
    try {
        const updatedAt = calendarUpdatedAt ? new Date(formatDateTimeMiliSecond(new Date(calendarUpdatedAt))) : new Date();
        await prisma.schedCompanyCar.update({
            where: { id: schedId },
            data: { calendarId: strToBuf(calendarId) || null, calendarUpdatedAt, iCalUId, updatedBy: user.pid, updatedAt },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
/**
 * 海外拠点担当の場合のみ処理実施。
 * 海外拠点が作成した社有車予定で、まだドラフト状態のものを取り除いた予定一覧を返却する
 * @param scheds
 * @param isForeignStaff
 * @returns
 */
export function filterDraftSched(scheds, isForeignStaff) {
    if (isForeignStaff) {
        return scheds;
    }
    if (scheds && scheds.length > 0) {
        return scheds.filter((sched) => {
            if (!sched.flgCreateForeignStaff) {
                return true;
            }
            else if (sched.flgArrgt) {
                return true;
            }
            else {
                return false;
            }
        });
    }
    return scheds;
}
export async function sendArrgtFinishSmtpMailAndCreateSiteNotificationToCompanions(log, prisma, targetEmails, targetPids, itineraryInfo) {
    const settingMap = await getNotificationSettingMapByIds(prisma, [
        'foreign_staff_company_car_arrange_finish_mail',
        'foreign_staff_company_car_arrange_finish_s_notice',
    ]);
    // SMTP通知処理
    const smtpSetting = settingMap['foreign_staff_company_car_arrange_finish_mail'];
    if (!smtpSetting.title || !smtpSetting.content || !smtpSetting.linkUrl) {
        throw new Error('title, content linkUrl is necessary.');
    }
    const itineraryFrom = formatDate(new Date(itineraryInfo.itineraryFrom), 'yyyyMMdd');
    const itineraryTo = formatDate(new Date(itineraryInfo.itineraryTo), 'MMdd');
    // リンクURL整形
    let linkUrl = format(smtpSetting.linkUrl, { domain: Define.DOMAIN, itineraryId: itineraryInfo.id });
    // メール本文整形
    const body = replaceCRLF(format(smtpSetting.content, { itineraryFrom, itineraryTo, itinerary: itineraryInfo, linkUrl }));
    // メール送信
    sendSmtpMail(log, { to: targetEmails, title: smtpSetting.title, body });
    // サイト上での通知実施
    const setting = settingMap['foreign_staff_company_car_arrange_finish_s_notice'];
    if (!setting.content || !setting.linkUrl) {
        throw new Error('content, linkUrl is necessary.');
    }
    linkUrl = format(setting.linkUrl, { domain: Define.DOMAIN, itineraryId: itineraryInfo.id });
    for (const targetPid of targetPids) {
        await createSiteNotification(prisma, targetPid, itineraryInfo.id, setting.content, linkUrl);
    }
}
/**
 * notificationStatus情報を更新する。
 * 本関数はバッチからの実行のみを想定。入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param schedId 予定のID
 * @param notificationStatus
 * @returns
 */
export async function updateNotificationStatus(prisma, schedId, notificationStatus) {
    if (notificationStatus !== Define.SETTINGS.NOTIFICATION_STATUS.SEND) {
        throw new Error(`invalid notificationStatus value. [notificationStatus: ${notificationStatus}]`);
    }
    await prisma.schedCompanyCar.update({
        where: { id: schedId },
        data: { notificationStatus },
    });
}
//# sourceMappingURL=companyCarService.js.map