/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
/**
 * 処理対象アカウントが表示可能な経費項目(単数)を返す
 * @param prisma
 * @param pid
 * @param expenseTransportationId
 * @returns
 */
export async function getExpenseTransportation(prisma, pid, expenseTransportationId) {
    if (!expenseTransportationId) {
        // 経費IDは指定必須
        throw new Error('unreachable error.');
    }
    const expenses = await prisma.expenseTransportation.findFirst({
        where: { id: expenseTransportationId, flgDelete: false, expense: { pid } },
        select: {
            id: true,
            expenseId: true,
            settlementDate: true,
            settlementType: true,
            transportationType: true,
            departureLocation: true,
            arrivalLocation: true,
            price: true,
            currency: true,
            remark: true,
            expenseTransportationFiles: {
                select: {
                    id: true,
                    originalFileName: true,
                    size: true,
                    ownerPid: true,
                },
            },
        },
    });
    return expenses;
}
/**
 * 経費交通費の登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props ExpenseTransportationCreateProps
 * @return
 */
export async function createExpenseTransportation(prisma, user, props) {
    // SchedEventテーブル作成
    const result = await prisma.expenseTransportation.create({
        data: {
            expenseId: props.expenseId,
            settlementDate: props.settlementDate,
            settlementType: props.settlementType,
            transportationType: props.transportationType,
            departureLocation: props.departureLocation,
            arrivalLocation: props.arrivalLocation,
            price: props.price,
            currency: props.currency,
            remark: props.remark,
            updatedBy: user.pid,
        },
    });
    return result.id;
}
/**
 * 経費交通費の更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props ExpenseTransportationUpdateProps
 * @return
 */
export async function updateExpenseTransportation(prisma, user, props) {
    await prisma.expenseTransportation.update({
        where: { id: props.id },
        data: {
            settlementDate: props.settlementDate,
            settlementType: props.settlementType,
            transportationType: props.transportationType,
            departureLocation: props.departureLocation,
            arrivalLocation: props.arrivalLocation,
            price: props.price,
            currency: props.currency,
            remark: props.remark,
            updatedBy: user.pid,
        },
    });
}
/**
 * 経費交通費の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param expenseTransportationId 経費交通費
 * @return
 */
export async function deleteExpenseTransportation(prisma, user, expenseTransportationId) {
    // クライアント側から送信されたidに合致する経費交通費を削除する(削除フラグをたてる)
    await prisma.expenseTransportation.update({
        where: { id: expenseTransportationId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
export function isCheckTransportationRequired(props) {
    if (!props.settlementDate ||
        !props.settlementType ||
        !props.transportationType ||
        !props.departureLocation ||
        !props.arrivalLocation ||
        props.price == null ||
        !props.currency) {
        return false;
    }
    return true;
}
//# sourceMappingURL=expenseTransportService.js.map