import { createWriteStream } from 'fs';
import { stat, readFile, rm } from 'fs/promises';
import archiver from 'archiver';
import { convertxpenseZipFullPath } from '../../utils/localFile.js';
import { downloadFile } from '../../utils/azureBlob.js';
import baseConfig from 'config';
const expenseZipMaxSize = baseConfig.get('download.expenseZipMaxSize');
export async function createZip(log, expenseInfo, fileName) {
    const MAX_THREADS = 8;
    try {
        // zipファイル名がない場合は、経費に添付されたファイルが一つもないので処理終了
        if (!fileName) {
            return { isSuccess: true };
        }
        const outputPath = convertxpenseZipFullPath(fileName);
        const output = createWriteStream(outputPath);
        const zipArchive = archiver('zip', {
            zlib: { level: 9 },
        });
        // node-archiver-zip-encryptedモジュールを追加すればパスワードもかけられそう
        // const zipArchive = archiver('zip-encrypted', {
        //   zlib: { level: 8 }, // 圧縮レベル
        //   encryptionMethod: 'aes256', // 暗号化方法
        //   password: password, // パスワード
        // });
        output.on('close', function () {
            log.info(`zip created. [size: ${zipArchive.pointer()} bytes] [file: ${outputPath}]`);
        });
        zipArchive.on('error', function (err) {
            throw err;
        });
        zipArchive.pipe(output);
        const execs = [];
        if (expenseInfo.expenseTransportations) {
            for (const expT of expenseInfo.expenseTransportations) {
                const fileInfos = expT.expenseTransportationFiles;
                if (expT.extensionB && fileInfos && fileInfos.length > 0) {
                    execs.push(getAttchmantsAndAdd(zipArchive, fileInfos, expT.extensionB));
                }
            }
        }
        if (expenseInfo.expenseAccommodations) {
            for (const expM of expenseInfo.expenseAccommodations) {
                const fileInfos = expM.expenseAccommodationFiles;
                if (expM.extensionB && fileInfos && fileInfos.length > 0) {
                    execs.push(getAttchmantsAndAdd(zipArchive, fileInfos, expM.extensionB));
                }
            }
        }
        if (expenseInfo.expenseOthers) {
            for (const expO of expenseInfo.expenseOthers) {
                const fileInfos = expO.expenseOtherFiles;
                if (expO.extensionB && fileInfos && fileInfos.length > 0) {
                    execs.push(getAttchmantsAndAdd(zipArchive, fileInfos, expO.extensionB));
                }
            }
        }
        let threads = [];
        for (const exec of execs) {
            threads.push(exec);
            if (threads.length >= MAX_THREADS) {
                // マルチスレッドでまとめて処理実施
                await Promise.all(threads);
                threads = [];
            }
        }
        // まだ未実行のものを処理する
        if (threads.length > 0) {
            // マルチスレッドでまとめて処理実施
            await Promise.all(threads);
        }
        await zipArchive.finalize();
        return { isSuccess: true };
    }
    catch (error) {
        log.error(`zip create error. [fileName: ${fileName}]`, error);
        return { isSuccess: false };
    }
}
async function getAttchmantsAndAdd(archive, fileInfos, extensionB) {
    const execs = [];
    if (fileInfos.length === 1) {
        execs.push(_getAttchmantAndAddArchive(archive, fileInfos[0], extensionB));
    }
    else {
        let count = 1;
        for (const fileInfo of fileInfos) {
            execs.push(_getAttchmantAndAddArchive(archive, fileInfo, extensionB + '_' + count));
            count++;
        }
    }
    await Promise.all(execs);
}
async function _getAttchmantAndAddArchive(archive, fileInfo, name) {
    const filename = name + getFileExpression(fileInfo.originalFileName);
    const buf = await downloadFile(fileInfo.path, false);
    addBuffer(archive, filename, buf);
}
function addBuffer(archive, fileName, buf) {
    archive.append(buf, { name: fileName });
}
function getFileExpression(filename) {
    if (filename) {
        const lastIndex = filename.lastIndexOf('.');
        if (lastIndex > 0) {
            return filename.substring(lastIndex);
        }
    }
    return '';
}
export async function getZipFileInfo(filename) {
    if (filename) {
        const fullpath = convertxpenseZipFullPath(filename);
        const filePropery = await stat(fullpath);
        const size = filePropery.size;
        if (size > expenseZipMaxSize) {
            return {
                base64: '',
                originalFileName: filename,
                size,
            };
        }
        else {
            const buf = await readFile(fullpath);
            return {
                base64: buf.toString('base64'),
                originalFileName: filename,
                size,
            };
        }
    }
    return undefined;
}
export async function removeZipFile(filename) {
    try {
        const fullpath = convertxpenseZipFullPath(filename);
        await rm(fullpath, { force: true });
    }
    catch (error) {
        // ignore
    }
}
//# sourceMappingURL=makeZipOfAllExpenseAttachments.js.map