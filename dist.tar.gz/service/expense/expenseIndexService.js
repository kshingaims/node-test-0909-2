/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { isBeforeToday } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { filter, orderBy } from 'lodash-es';
/**
 * 経費の登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param itineraryId
 */
export async function createExpense(prisma, pid, user, itineraryId) {
    const expense = await prisma.expense.create({
        data: {
            pid,
            itineraryId,
            updatedBy: user.pid,
        },
    });
    return expense.id;
}
/**
 * 処理対象アカウントが表示可能な旅程に紐づく経費(単数)と関連する経費項目一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param forCycleIntegration
 * @returns
 */
export async function getExpense(prisma, pid, itineraryId, forCycleIntegration = false) {
    if (!itineraryId) {
        // 旅程IDは指定必須
        throw new Error('unreachable error.');
    }
    const select = {
        id: true,
        itineraryId: true,
        expenseTransportations: {
            select: {
                id: true,
                expenseId: true,
                settlementDate: true,
                settlementType: true,
                transportationType: true,
                departureLocation: true,
                arrivalLocation: true,
                price: true,
                currency: true,
                remark: true,
                flgDelete: true,
                expenseTransportationFiles: {
                    select: {
                        id: true,
                        originalFileName: true,
                        size: true,
                        ownerPid: true,
                        path: forCycleIntegration,
                    },
                },
            },
        },
        expenseAccommodations: {
            select: {
                id: true,
                expenseId: true,
                settlementDate: true,
                cityId: true,
                hotelName: true,
                checkInDate: true,
                checkOutDate: true,
                price: true,
                currency: true,
                remark: true,
                flgDelete: true,
                city: {
                    select: {
                        id: true,
                        countryCode: true,
                        countryRoma: true,
                        country: true,
                        cityCode: true,
                        cityRoma: true,
                        city: true,
                        cityTimezone: true,
                        timezoneLabel: true,
                        currency: true,
                        timeTransitions: true,
                    },
                },
                expenseAccommodationFiles: {
                    select: {
                        id: true,
                        originalFileName: true,
                        size: true,
                        ownerPid: true,
                        path: forCycleIntegration,
                    },
                },
            },
        },
        expenseOthers: {
            select: {
                id: true,
                expenseId: true,
                settlementDate: true,
                settlementType: true,
                price: true,
                currency: true,
                remark: true,
                flgDelete: true,
                expenseOtherFiles: {
                    select: {
                        id: true,
                        originalFileName: true,
                        size: true,
                        ownerPid: true,
                        path: forCycleIntegration,
                    },
                },
            },
        },
    };
    if (forCycleIntegration) {
        select.itinerary = {
            select: {
                itineraryIndividuals: {
                    select: {
                        itineraryFrom: true,
                        itineraryTo: true,
                        itineraryName: true,
                        itineraryIndividualStatus: true,
                    },
                    where: { pid },
                },
            },
        };
    }
    const expenses = await prisma.expense.findMany({
        where: { pid, itineraryId, flgDelete: false },
        select,
        orderBy: {
            id: 'asc',
        },
    });
    if (expenses && expenses.length === 1) {
        //「交通費、宿泊費、その他」配列要素の順序は作成日時の昇順(asc)となるように、各配列に対して、並び替えを実施する。
        for (const expense of expenses) {
            expense.expenseTransportations = orderBy(filter(expense.expenseTransportations, ['flgDelete', false]), ['createdAt'], ['asc']);
            expense.expenseAccommodations = orderBy(filter(expense.expenseAccommodations, ['flgDelete', false]), ['createdAt'], ['asc']);
            expense.expenseOthers = orderBy(filter(expense.expenseOthers, ['flgDelete', false]), ['createdAt'], ['asc']);
        }
        return expenses[0];
    }
    else {
        return {};
    }
}
/**
 * 経費登録時の動的な入力チェック処理を実施
 * @param prisma
 * @param pid
 * @param expenseId 経費ID
 * @param requiredCheckCallback システム現在日が旅程出張終了日を超えている場合の必須入力チェック内容
 * @returns
 */
export async function checkDynamicValidationForCreate(prisma, pid, expenseId, requiredCheckCallback) {
    const expense = await _getExpenseForCheck(prisma, pid, { expenseId });
    return _checkDynamicValidation(pid, requiredCheckCallback, expense);
}
/**
 * 経費登録時の動的な入力チェック処理を実施
 * @param prisma
 * @param pid
 * @param expenseId 経費ID
 * @param requiredCheckCallback システム現在日が旅程出張終了日を超えている場合の必須入力チェック内容
 * @returns
 */
export async function checkDynamicValidationForUpdate(prisma, pid, ids, requiredCheckCallback) {
    const expense = await _getExpenseForCheck(prisma, pid, ids);
    return _checkDynamicValidation(pid, requiredCheckCallback, expense);
}
/**
 * 経費登録時の動的な入力チェック処理を実施
 * @param prisma
 * @param pid
 * @param expenseId 経費ID
 * @param requiredCheckCallback システム現在日が旅程出張終了日を超えている場合の必須入力チェック内容
 * @returns
 */
export function _checkDynamicValidation(pid, requiredCheckCallback, expenseInfo) {
    // 経費IDに合致する経費レコードが取得できない(W00903)
    if (!expenseInfo) {
        return { code: Define.ERROR_CODES.W00903, status: 400 };
    }
    const itineraryTo = expenseInfo?.itinerary?.itineraryIndividuals[0]?.itineraryTo;
    const cycleLinkStatus = expenseInfo?.itinerary?.itineraryIndividuals[0]?.itineraryIndividualStatus.cycleLinkStatus;
    if (!itineraryTo) {
        throw new Error('unreachable error.');
    }
    // 経費作成者ではないのに、経費(交通費/宿泊費/その他)を登録・更新・削除しようとしている(W00901)
    if (expenseInfo.pid !== pid) {
        return { code: Define.ERROR_CODES.W00901, status: 401 };
    }
    // 経費テーブルの申請フラグがtrueの場合(W00902)
    if (cycleLinkStatus === Define.SETTINGS.CYCLE_LINK_STATUS.FINISH_AFTER_APPLY) {
        return { code: Define.ERROR_CODES.W00902, status: 200 };
    }
    // 出張期間終了後(システム日時が出張期間終了日を超えている場合)は、入力必須となっている項目の必須チェック実施。
    if (isBeforeToday(new Date(itineraryTo))) {
        if (requiredCheckCallback) {
            return requiredCheckCallback();
        }
    }
    return undefined;
}
/**
 * 経費作成時に、入力チェックで利用する経費情報(紐つく旅程情報含む)を取得する
 * @param prisma
 * @param pid
 * @param itineraryId
 * @returns
 */
async function _getExpenseForCheck(prisma, pid, ids) {
    if (!ids.expenseId && !ids.expenseTransportationId && !ids.expenseAccommodationId && !ids.expenseOtherId) {
        // 旅程IDは指定必須
        throw new Error('unreachable error.');
    }
    const where = { pid, flgDelete: false };
    if (ids.expenseId) {
        where.id = ids.expenseId;
    }
    if (ids.expenseTransportationId) {
        where.expenseTransportations = {
            some: {
                id: ids.expenseTransportationId,
                flgDelete: false,
            },
        };
    }
    if (ids.expenseAccommodationId) {
        where.expenseAccommodations = {
            some: {
                id: ids.expenseAccommodationId,
                flgDelete: false,
            },
        };
    }
    if (ids.expenseOtherId) {
        where.expenseOthers = {
            some: {
                id: ids.expenseOtherId,
                flgDelete: false,
            },
        };
    }
    const expenses = await prisma.expense.findMany({
        where,
        select: {
            id: true,
            pid: true,
            itineraryId: true,
            itinerary: {
                select: {
                    itineraryIndividuals: {
                        select: {
                            itineraryName: true,
                            itineraryFrom: true,
                            itineraryTo: true,
                            itineraryIndividualStatus: true,
                        },
                        where: { pid },
                    },
                },
            },
        },
        orderBy: {
            id: 'asc',
        },
    });
    if (expenses && expenses.length === 1) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return expenses[0];
    }
    else {
        return undefined;
    }
}
export async function getExpenseIds(prisma, pids, itineraryId, options = { schedHotelId: null }) {
    const expenses = await prisma.expense.findMany({
        select: {
            id: true,
            pid: true,
            itineraryId: true,
            expenseAccommodations: options.schedHotelId
                ? { select: { schedHotelId: true }, where: { schedHotelId: options.schedHotelId } }
                : false,
        },
        where: {
            itineraryId,
            pid: { in: pids },
            flgDelete: false,
        },
    });
    if (pids.length !== expenses.length) {
        throw new Error('expense table data is invalid.');
    }
    return expenses;
}
//# sourceMappingURL=expenseIndexService.js.map