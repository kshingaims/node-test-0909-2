/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
/**
 * 処理対象アカウントが表示可能な経費項目(単数)を返す
 * @param prisma
 * @param pid
 * @param expenseAccommodationId
 * @returns
 */
export async function getExpenseAccommodation(prisma, pid, expenseAccommodationId) {
    if (!expenseAccommodationId) {
        // 経費IDは指定必須
        throw new Error('unreachable error.');
    }
    const expenses = await prisma.expenseAccommodation.findFirst({
        where: { id: expenseAccommodationId, flgDelete: false, expense: { pid } },
        select: {
            id: true,
            expenseId: true,
            settlementDate: true,
            cityId: true,
            hotelName: true,
            checkInDate: true,
            checkOutDate: true,
            price: true,
            currency: true,
            remark: true,
            city: true,
            expenseAccommodationFiles: {
                select: {
                    id: true,
                    originalFileName: true,
                    size: true,
                    ownerPid: true,
                },
            },
        },
    });
    return expenses;
}
/**
 * 経費宿泊費の登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props ExpenseAccommodationCreateProps
 * @return
 */
export async function createExpenseAccommodation(prisma, user, props) {
    // ExpenseAccommodationテーブル作成
    const result = await prisma.expenseAccommodation.create({
        data: {
            expenseId: props.expenseId,
            schedHotelId: props.schedHotelId,
            settlementDate: props.settlementDate,
            cityId: props.cityId,
            hotelName: props.hotelName,
            checkInDate: props.checkInDate,
            checkOutDate: props.checkOutDate,
            price: props.price,
            currency: props.currency,
            remark: props.remark,
            updatedBy: user.pid,
        },
    });
    return result.id;
}
/**
 * 経費宿泊費の更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props ExpenseAccommodationUpdateProps
 * @return
 */
export async function updateExpenseAccommodation(prisma, user, props) {
    await prisma.expenseAccommodation.update({
        where: { id: props.id },
        data: {
            settlementDate: props.settlementDate,
            cityId: props.cityId,
            hotelName: props.hotelName,
            checkInDate: props.checkInDate,
            checkOutDate: props.checkOutDate,
            price: props.price,
            currency: props.currency,
            remark: props.remark,
            updatedBy: user.pid,
        },
    });
}
/**
 * 経費宿泊費の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param expenseAccommodationId 経費宿泊費
 * @return
 */
export async function deleteExpenseAccommodation(prisma, user, expenseAccommodationId) {
    // クライアント側から送信されたidに合致する経費宿泊費を削除する(削除フラグをたてる)
    await prisma.expenseAccommodation.update({
        where: { id: expenseAccommodationId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
export function isCheckAccomodationRequired(props) {
    if (!props.settlementDate ||
        !props.cityId ||
        !props.hotelName ||
        !props.checkInDate ||
        !props.checkOutDate ||
        props.price == null ||
        !props.currency) {
        return false;
    }
    return true;
}
//# sourceMappingURL=expenseAccommodationService.js.map