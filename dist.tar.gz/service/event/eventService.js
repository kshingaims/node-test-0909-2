/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { filter, orderBy } from 'lodash-es';
import { Define } from '../../utils/define.js';
import { formatDateTimeMiliSecond, isBeforeToday, isFromDatetimeBeforeToDatetime, strToBuf } from '../../utils/index.js';
import { isExistsItineraryCompanions } from '../itinerary/itineraryService.js';
/**
 * 処理対象アカウントが表示可能なイベント予定一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param eventId
 * @returns
 */
export async function getEventSchedList(prisma, pid, itineraryId, eventId, isOutlookIntegration = false) {
    const where = {
        pid,
        schedEvent: { flgDelete: !isOutlookIntegration ? false : undefined },
        flgDelete: false,
        flgReject: false,
    };
    if (!eventId && !itineraryId) {
        // 旅程IDもしくはイベントIDは指定必須
        throw new Error('unreachable error.');
    }
    if (eventId) {
        where.schedEventId = eventId;
    }
    if (itineraryId) {
        where.schedEvent = { itineraryId: itineraryId, flgDelete: !isOutlookIntegration ? false : undefined };
    }
    const schedEventIndividuals = await prisma.schedEventIndividual.findMany({
        where,
        select: {
            calendarId: isOutlookIntegration,
            calendarUpdatedAt: isOutlookIntegration,
            flgReject: true,
            schedEvent: {
                select: {
                    id: true,
                    itineraryId: true,
                    name: true,
                    startDateTime: true,
                    endDateTime: true,
                    timezone: true,
                    location: true,
                    address: true,
                    remark: true,
                    ownerPid: true,
                    flgCreateForeignStaff: true,
                    calendarId: isOutlookIntegration,
                    calendarUpdatedAt: isOutlookIntegration,
                    iCalUId: isOutlookIntegration,
                    flgDelete: true,
                    updatedAt: isOutlookIntegration,
                    schedEventIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    firstNameRoma: true,
                                    lastNameRoma: true,
                                    firstNameKanji: true,
                                    lastNameKanji: true,
                                    firstNameKana: true,
                                    lastNameKana: true,
                                    email: true,
                                },
                            },
                            flgReject: true,
                            createdAt: true,
                            flgDelete: true,
                        },
                    },
                    schedEventFiles: {
                        select: {
                            id: true,
                            originalFileName: true,
                            size: true,
                            ownerPid: true,
                            path: isOutlookIntegration,
                            azAttachmentId: isOutlookIntegration,
                            azAttachmentUpdatedAt: isOutlookIntegration,
                        },
                    },
                },
            },
        },
        orderBy: {
            // 取得されるイベント一覧は「1.イベント出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            schedEvent: {
                startDateTime: 'asc',
            },
        },
    });
    // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
    for (const schedEventIndividual of schedEventIndividuals) {
        // イベント予定(schedEvent)の中にあるschedEventIndividualsについては、作成日時の昇順(asc)となるように、イベント予定一覧の全レコードに対して、並び替えを実施する。
        schedEventIndividual.schedEvent.schedEventIndividuals = orderBy(
        // イベント予定(schedEvent)の中にあるschedEventIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedEventIndividual.schedEvent.schedEventIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return schedEventIndividuals;
}
/**
 * 海外担当者による予定作成時のレスポンスデータとして予定情報を返す
 * @param prisma
 * @param eventId
 * @returns
 */
export async function getEventSchedData(prisma, eventId) {
    // schedEvemtを返す。JSON構造についてはGET返却時のAPIレスポンスと同じ構造となるようにする
    // schedEvemtIndividualに紐つくschedEvemtがあるという
    const schedEvent = await prisma.schedEvent.findFirst({
        where: { id: eventId, flgDelete: false },
        select: {
            id: true,
            itineraryId: true,
            name: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            location: true,
            address: true,
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            calendarId: true,
            calendarUpdatedAt: true,
            schedEventIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                            firstNameRoma: true,
                            lastNameRoma: true,
                            firstNameKanji: true,
                            lastNameKanji: true,
                            firstNameKana: true,
                            lastNameKana: true,
                            email: true,
                        },
                    },
                    flgReject: true,
                    createdAt: true,
                    flgDelete: true,
                },
            },
            schedEventFiles: {
                select: {
                    id: true,
                    originalFileName: true,
                    size: true,
                    ownerPid: true,
                },
            },
        },
        orderBy: {
            // 取得されるイベント一覧は「1.イベント出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            startDateTime: 'asc',
        },
    });
    if (schedEvent) {
        // 予定予定(schedEvent)の中にあるschedEventIndividualsについては、作成日時の昇順(asc)となるように、予定予定一覧の全レコードに対して、並び替えを実施する。
        schedEvent.schedEventIndividuals = orderBy(
        // 予定予定(schedEvent)の中にあるschedEventIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedEvent.schedEventIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return {
        schedEvent,
    };
}
/**
 * 旅程Excelダウンロード用に、対象旅程IDに紐づく各種イベント予定一覧を取得する
 * @param prisma
 * @param itineraryId
 * @returns
 */
export async function getEventsForExcelDownload(prisma, itineraryId) {
    const schedEvents = await prisma.schedEvent.findMany({
        where: {
            flgDelete: false,
            itineraryId,
        },
        select: {
            id: true,
            itineraryId: true,
            name: true,
            startDateTime: true,
            endDateTime: true,
            timezone: true,
            location: true,
            address: true,
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            flgDelete: true,
            schedEventIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                        },
                    },
                    flgReject: true,
                    flgDelete: true,
                },
            },
        },
        orderBy: {
            // 取得されるイベント一覧は「1.イベント出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            startDateTime: 'asc',
        },
    });
    return schedEvents;
}
/**
 * イベント予定及びイベント個人予定の登録作業。
 * イベント予定のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props EventSchedCreateProps
 * @return
 */
export async function createSchedEvent(prisma, pid, user, props, itineraryId, isForeignStaff = false) {
    // SchedEventテーブル作成
    const result = await prisma.schedEvent.create({
        data: {
            ownerPid: pid,
            itineraryId,
            name: props.name,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            location: props.location,
            address: props.address,
            remark: props.remark,
            flgCreateForeignStaff: isForeignStaff,
            updatedBy: user.pid,
        },
    });
    const schedEventId = result.id;
    let targetPids = [];
    // 出張代表者をSchedEventIndividualとして最初に登録しておく ※海外拠点担当者を除く
    if (!isForeignStaff) {
        targetPids = [pid];
    } // 同行者がいれば、その同行者の数だけ、SchedEventIndividualを登録する
    if (props.companions) {
        for (const companion of props.companions) {
            targetPids.push(companion.pid);
        }
    }
    for (const targetPid of targetPids) {
        await prisma.schedEventIndividual.create({
            data: {
                schedEventId,
                pid: targetPid,
                updatedBy: user.pid,
            },
        });
    }
    return schedEventId;
}
/**
 * イベント予定及びイベント個人予定の更新作業。
 * イベント予定のみ更新する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedEvent SchedEventInschedEventIndividuals
 * @param props EventSchedUpdateProps
 * @return
 */
export async function updateSchedEvent(prisma, pid, user, schedEvent, props, isForeignStaff = false) {
    const companionPids = props.companions ? props.companions?.map((companion) => companion.pid) : [];
    // 出張代表者をSchedEventIndividualとして最初に登録しておく ※海外拠点担当者を除く
    if (!isForeignStaff) {
        companionPids.unshift(pid); //予定作成者を先頭に追加する
    }
    await prisma.schedEvent.update({
        where: { id: schedEvent.id },
        data: {
            ownerPid: pid,
            itineraryId: props.itineraryId,
            name: props.name,
            startDateTime: new Date(props.startDateTime),
            endDateTime: new Date(props.endDateTime),
            timezone: props.timezone,
            location: props.location,
            address: props.address,
            remark: props.remark,
            updatedBy: user.pid,
        },
    });
    const schedEventIndividualPids = [];
    for (const schedEventIndividual of schedEvent.schedEventIndividuals) {
        if (!schedEventIndividual.flgDelete) {
            if (!companionPids.includes(schedEventIndividual.pid)) {
                // DB取得したSchedEventIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧に含まれていない場合は、同行者削除(flgDelete=true)を実施する。
                await prisma.schedEventIndividual.update({
                    data: {
                        flgDelete: true,
                        updatedBy: user.pid,
                    },
                    where: {
                        schedEventId_pid: {
                            schedEventId: schedEventIndividual.schedEventId,
                            pid: schedEventIndividual.pid,
                        },
                    },
                });
            }
            // DB取得したSchedEventIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧にも含まれている場合は、何も処理しない(同行者指定済)
        }
        else if (schedEventIndividual.flgDelete) {
            if (companionPids.includes(schedEventIndividual.pid)) {
                // DB取得したSchedEventIndividualがflgDelete=trueとなっており、クライアント側から取得した同行者一覧に含まれている場合は、同行者の再指定(flgDelete=false)を実施する。
                await prisma.schedEventIndividual.update({
                    data: {
                        flgDelete: false,
                        updatedBy: user.pid,
                    },
                    where: {
                        schedEventId_pid: {
                            schedEventId: schedEventIndividual.schedEventId,
                            pid: schedEventIndividual.pid,
                        },
                    },
                });
            }
        }
        // DB取得したSchedEventIndividualのpid一覧作成
        schedEventIndividualPids.push(schedEventIndividual.pid);
    }
    // クライアント側から取得した同行者一覧の中にあるpidが、DB取得したSchedEventIndividual一覧の中に含まれていない場合は、同行者の新規追加実施
    for (const companionPid of companionPids) {
        if (!schedEventIndividualPids.includes(companionPid)) {
            await prisma.schedEventIndividual.create({
                data: {
                    schedEventId: schedEvent.id,
                    pid: companionPid,
                    updatedBy: user.pid,
                },
            });
        }
    }
}
/**
 * イベント予定(手配は除く)の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param schedEventId イベント予定ID
 * @return
 */
export async function deleteSchedEvent(prisma, user, schedEventId) {
    // クライアント側から送信されたidに合致するイベント予定を削除する(削除フラグをたてる)
    await prisma.schedEvent.update({
        where: { id: schedEventId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * イベント個人予定テーブルの更新作業。
 * イベント予定参加の拒否
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedEventId schedEventId
 * @param flgReject boolean
 * @return
 */
export async function rejectSchedEventIndividual(prisma, pid, user, schedEventId, flgReject) {
    await prisma.schedEventIndividual.update({
        where: { schedEventId_pid: { schedEventId, pid: pid } },
        data: {
            flgReject,
            updatedBy: user.pid,
        },
    });
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function createEventSchedIfNotExists(pid, prisma, itineraryId, startDateTime, endDateTime, companions, isForeignStaff = false) {
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = companions?.map((item) => {
        return item.pid;
    });
    if (isForeignStaff) {
        // 海外拠点の場合は、companionsの指定がない場合は入力チェックエラー
        if (!companions || companions.length <= 0) {
            return { code: Define.ERROR_CODES.W00122, status: 200 };
        }
    }
    else {
        // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
        if (companionPids) {
            companionPids.push(pid);
        }
        else {
            companionPids = [pid];
        }
    }
    // 指定されているpidが、旅程の作成者/同行者に含まれているかをチェック(W00104)
    if (companionPids) {
        const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
        if (error) {
            return error;
        }
    }
    // 予定_出発日時または予定_到着日時が現在日よりも前の日時(W00102) になっている場合は入力チェックエラーとする
    if (isBeforeToday(new Date(startDateTime)) || isBeforeToday(new Date(endDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 予定_到着日時が予定_出発日時よりも前の日時となっている(W00103) になっている場合は入力チェックエラーとする
    if (isFromDatetimeBeforeToDatetime(new Date(endDateTime), new Date(startDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function updateIfExists(pid, prisma, schedEvent, //prismaから取得したschedEventレコード
itineraryId, startDateTime, endDateTime, companions, isForeignStaff = false) {
    // DBからイベント予定情報が取得できない(W00109)
    if (schedEvent === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // DBから取得したitineraryIdとクライアントから取得したitineraryIdが一致しない(W00109)
    if (schedEvent.itineraryId !== itineraryId) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    if (isForeignStaff) {
        // 海外拠点の場合は、companionsの指定がない場合は入力チェックエラー
        if (!companions || companions.length <= 0) {
            return { code: Define.ERROR_CODES.W00122, status: 200 };
        }
        // 海外拠点担当は、海外拠点担当が作成した予定のみ処理実施可能
        if (!schedEvent.flgCreateForeignStaff) {
            return { code: Define.ERROR_CODES.W00123, status: 400 };
        }
    }
    else {
        if (pid === schedEvent.ownerPid) {
            // 対象アカウント(pid)が、予定の作成者(オーナー)だが、海外拠点担当が作成した予定を更新・削除しようとしている(W00111)
            if (schedEvent.flgCreateForeignStaff) {
                return { code: Define.ERROR_CODES.W00111, status: 401 };
            }
            // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
        }
        else {
            return { code: Define.ERROR_CODES.W00111, status: 401 };
        }
    }
    // 出発日時または到着日時が現在日よりも前の日時(W00102)
    if (isBeforeToday(new Date(startDateTime)) || isBeforeToday(new Date(endDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 到着日時が出発日時よりも前の日時となっている(W00103)
    if (isFromDatetimeBeforeToDatetime(new Date(endDateTime), new Date(startDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = companions?.map((item) => {
        return item.pid;
    });
    // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
    if (companionPids) {
        companionPids.push(pid);
    }
    else {
        companionPids = [pid];
    }
    if (!isForeignStaff) {
        // 同行者指定のpidが、紐ついている旅程の作成者/同行者になっていない(W00104)
        if (companionPids) {
            const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
            if (error) {
                return error;
            }
        }
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function deleteIfExists(pid, schedEvent, //prismaから取得したschedEventレコード
isForeignStaff = false) {
    // 入力チェック内容 全ての手配ステータス(arrgtStatus)で共通の内容
    // DBからイベント予定情報が取得できない(W00109)
    if (schedEvent === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    if (isForeignStaff) {
        // 海外拠点担当は、海外拠点担当が作成した予定のみ処理実施可能
        if (!schedEvent.flgCreateForeignStaff) {
            return { code: Define.ERROR_CODES.W00123, status: 400 };
        }
    }
    else {
        if (pid === schedEvent.ownerPid) {
            // 対象アカウント(pid)が、予定の作成者(オーナー)だが、海外拠点担当が作成した予定を更新・削除しようとしている(W00111)
            if (schedEvent.flgCreateForeignStaff) {
                return { code: Define.ERROR_CODES.W00111, status: 401 };
            }
            // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
        }
        else {
            return { code: Define.ERROR_CODES.W00111, status: 401 };
        }
    }
    return;
}
/**
 * 入力チェック用のデータ取得を実施する。Individuals情報は削除フラグが立っているものも含んで取得する
 * @param prisma
 * @param pid
 * @param schedEventId
 * @param itineraryId
 * @returns
 */
export async function getSchedEventForChecker(prisma, schedEventId, itineraryId) {
    const schedEvent = await prisma.schedEvent.findFirst({
        where: {
            id: schedEventId,
            itineraryId,
            flgDelete: false, // 削除フラグがたっていない
        },
        include: { schedEventIndividuals: true }, //(flgDelete=trueのものも含んで取得する)
    });
    return schedEvent;
}
/**
 * こちらの関数は、outlookイベントをmctripに取り込む際に、mctripの予定を取り込まないようにする為のチェックで利用。
 * 指定したitineraryIdとpidに合致して、outlook連携している予定情報一覧を取得する。
 * 削除フラグや拒否フラグがある場合でも取得を実施する。
 * @param prisma
 * @param pid
 * @param itineraryId
 * @returns
 */
export async function getSchedEventsReflectedInOutlook(prisma, pid, itineraryId) {
    const schedIndividuals = await prisma.schedEventIndividual.findMany({
        where: {
            pid,
            schedEvent: { itineraryId, calendarId: { not: null } },
        },
        select: {
            flgDelete: true,
            flgReject: true,
            schedEvent: true,
        },
    });
    if (schedIndividuals.length <= 0) {
        return [];
    }
    else {
        return schedIndividuals.map((item) => {
            return item.schedEvent;
        });
    }
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、DB更新処理などのMCTrip予定更新処理後のみ実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param user
 * @param schedId 予定のID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @param iCalUId outlookイベント固有ID
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, user, schedId, calendarId, calendarUpdatedAt, iCalUId) {
    try {
        const updatedAt = calendarUpdatedAt ? new Date(formatDateTimeMiliSecond(new Date(calendarUpdatedAt))) : new Date();
        await prisma.schedEvent.update({
            where: { id: schedId },
            data: { calendarId: strToBuf(calendarId) || null, calendarUpdatedAt, iCalUId, updatedBy: user.pid, updatedAt },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
//# sourceMappingURL=eventService.js.map