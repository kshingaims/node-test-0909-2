/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { Define } from '../../utils/define.js';
import { divideFilenameToNameAndExp, strToBuf } from '../../utils/index.js';
/**
 * 指定したファイルIDに合致するdata部分のレコードを取得する。
 * 合わせて、入力チェックも実施する。
 * @param prisma
 * @param pid
 * @param schedType
 * @param FileId
 * @param foreignStaffItineraryId // 海外拠点の場合は必須
 * @returns
 */
export async function checkValidate(prisma, pid, schedType, fileId, foreignStaffItineraryId, isUpdate = false) {
    let switchResult;
    const where = { id: fileId };
    const schedTypeDifine = Define.SETTINGS.SCHED_TYPE;
    let schedIndividuals;
    // 予定IDに紐づくファイルのレコードを取得する。
    switch (schedType) {
        case schedTypeDifine.FLIGHT:
            switchResult = await prisma.schedFlightFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    schedFlight: { select: { ownerPid: true, itineraryId: true, schedFlightIndividuals: true } },
                },
            });
            if (switchResult) {
                // 海外拠点担当者が、添付ファイルを持っている予定が紐ついている旅程に対して、アクセス権を持っていない(W00403)
                if (foreignStaffItineraryId && switchResult.schedFlight.itineraryId !== foreignStaffItineraryId) {
                    return { code: Define.ERROR_CODES.W00403, status: 401 };
                }
                if (isUpdate) {
                    const ownerPid = switchResult.schedFlight.ownerPid;
                    const accessCheck = checkAccessRight({ ownerPid }, pid, !!foreignStaffItineraryId);
                    if (accessCheck) {
                        return accessCheck;
                    }
                }
                // 処理対象アカウント(pid)が、添付ファイルを持っている予定の参加者となっていない(XX予定個人テーブルにレコードがない)(W00402)
                schedIndividuals = switchResult.schedFlight.schedFlightIndividuals;
                if (schedIndividuals) {
                    const schedIndividualsArray = schedIndividuals.map((item) => item.pid);
                    const result = checkForPidInSchedIndividualsOrErrorObj(pid, schedIndividualsArray);
                    if (result !== undefined) {
                        return result;
                    }
                }
            }
            break;
        case schedTypeDifine.HOTEL:
            switchResult = await prisma.schedHotelFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    schedHotel: { select: { ownerPid: true, itineraryId: true, schedHotelIndividuals: true } },
                },
            });
            if (switchResult) {
                // 海外拠点担当者が、添付ファイルを持っている予定が紐ついている旅程に対して、アクセス権を持っていない(W00403)
                if (foreignStaffItineraryId && switchResult.schedHotel.itineraryId !== foreignStaffItineraryId) {
                    return { code: Define.ERROR_CODES.W00403, status: 401 };
                }
                if (isUpdate) {
                    const ownerPid = switchResult.schedHotel.ownerPid;
                    const accessCheck = checkAccessRight({ ownerPid }, pid, !!foreignStaffItineraryId);
                    if (accessCheck) {
                        return accessCheck;
                    }
                }
                // 処理対象アカウント(pid)が、添付ファイルを持っている予定の参加者となっていない(XX予定個人テーブルにレコードがない)(W00402)
                schedIndividuals = switchResult?.schedHotel.schedHotelIndividuals;
                if (schedIndividuals) {
                    const schedIndividualsArray = schedIndividuals.map((item) => item.pid);
                    const result = checkForPidInSchedIndividualsOrErrorObj(pid, schedIndividualsArray);
                    if (result !== undefined) {
                        return result;
                    }
                }
            }
            break;
        case schedTypeDifine.COMPANYCAR:
            switchResult = await prisma.schedCompanyCarFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    schedCompanyCar: {
                        select: {
                            ownerPid: true,
                            itineraryId: true,
                            schedCompanyCarIndividuals: true,
                            flgCreateForeignStaff: true,
                        },
                    },
                },
            });
            if (switchResult) {
                // 海外拠点担当者
                if (foreignStaffItineraryId) {
                    // 添付ファイルを持っている予定が紐ついている旅程に対して、アクセス権を持っていない(W00403)
                    if (switchResult.schedCompanyCar.itineraryId !== foreignStaffItineraryId) {
                        return { code: Define.ERROR_CODES.W00403, status: 401 };
                    }
                }
                if (isUpdate) {
                    const ownerPid = switchResult.schedCompanyCar.ownerPid;
                    const accessCheck = checkAccessRight({ ownerPid }, pid, !!foreignStaffItineraryId);
                    if (accessCheck) {
                        return accessCheck;
                    }
                }
                // 処理対象アカウント(pid)が、添付ファイルを持っている予定の参加者となっていない(XX予定個人テーブルにレコードがない)(W00402)
                schedIndividuals = switchResult.schedCompanyCar.schedCompanyCarIndividuals;
                if (schedIndividuals) {
                    const schedIndividualsArray = schedIndividuals.map((item) => item.pid);
                    const result = checkForPidInSchedIndividualsOrErrorObj(pid, schedIndividualsArray);
                    if (result !== undefined) {
                        return result;
                    }
                }
            }
            break;
        case schedTypeDifine.TRANSPORTATION:
            switchResult = await prisma.schedTransportationFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    schedTransportation: {
                        select: {
                            ownerPid: true,
                            itineraryId: true,
                            schedTransportationIndividuals: true,
                            flgCreateForeignStaff: true,
                        },
                    },
                },
            });
            if (switchResult) {
                // 海外拠点担当者
                if (foreignStaffItineraryId) {
                    // 添付ファイルを持っている予定が紐ついている旅程に対して、アクセス権を持っていない(W00403)
                    if (switchResult.schedTransportation.itineraryId !== foreignStaffItineraryId) {
                        return { code: Define.ERROR_CODES.W00403, status: 401 };
                    }
                }
                if (isUpdate) {
                    const ownerPid = switchResult.schedTransportation.ownerPid;
                    const flgCreateForeignStaff = switchResult.schedTransportation.flgCreateForeignStaff;
                    const accessCheck = checkAccessRight({ ownerPid, flgCreateForeignStaff }, pid, !!foreignStaffItineraryId);
                    if (accessCheck) {
                        return accessCheck;
                    }
                }
                // 処理対象アカウント(pid)が、添付ファイルを持っている予定の参加者となっていない(XX予定個人テーブルにレコードがない)(W00402)
                schedIndividuals = switchResult.schedTransportation.schedTransportationIndividuals;
                if (schedIndividuals) {
                    const schedIndividualsArray = schedIndividuals.map((item) => item.pid);
                    const result = checkForPidInSchedIndividualsOrErrorObj(pid, schedIndividualsArray);
                    if (result !== undefined) {
                        return result;
                    }
                }
            }
            break;
        case schedTypeDifine.EVENT:
            switchResult = await prisma.schedEventFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    schedEvent: {
                        select: { ownerPid: true, itineraryId: true, schedEventIndividuals: true, flgCreateForeignStaff: true },
                    },
                },
            });
            if (switchResult) {
                // 海外拠点担当者
                if (foreignStaffItineraryId) {
                    // 添付ファイルを持っている予定が紐ついている旅程に対して、アクセス権を持っていない(W00403)
                    if (switchResult.schedEvent.itineraryId !== foreignStaffItineraryId) {
                        return { code: Define.ERROR_CODES.W00403, status: 401 };
                    }
                }
                if (isUpdate) {
                    const ownerPid = switchResult.schedEvent.ownerPid;
                    const flgCreateForeignStaff = switchResult.schedEvent.flgCreateForeignStaff;
                    const accessCheck = checkAccessRight({ ownerPid, flgCreateForeignStaff }, pid, !!foreignStaffItineraryId);
                    if (accessCheck) {
                        return accessCheck;
                    }
                }
                // 処理対象アカウント(pid)が、添付ファイルを持っている予定の参加者となっていない(XX予定個人テーブルにレコードがない)(W00402)
                schedIndividuals = switchResult.schedEvent.schedEventIndividuals;
                if (schedIndividuals) {
                    const schedIndividualsArray = schedIndividuals.map((item) => item.pid);
                    const result = checkForPidInSchedIndividualsOrErrorObj(pid, schedIndividualsArray);
                    if (result !== undefined) {
                        return result;
                    }
                }
            }
            break;
        default:
            break;
    }
    // ファイルIDに合致する添付ファイルレコードが存在しない(W00401)
    if (!switchResult) {
        return { code: Define.ERROR_CODES.W00401, status: 400 };
    }
    return { path: switchResult.path, originalFileName: switchResult.originalFileName, size: switchResult.size };
}
/**
 * 処理対象のPIDが予定個人IDの配列に含まれるかのチェック
 * @param pid
 * @param schedIndividualsArray
 * @returns
 */
export function checkForPidInSchedIndividualsOrErrorObj(pid, schedIndividuals) {
    if (schedIndividuals !== undefined) {
        if (!schedIndividuals.includes(pid)) {
            return { code: Define.ERROR_CODES.W00402, status: 401 };
        }
    }
    return;
}
/**
 * ファイルアップロード済みの添付ファイル情報の新規登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedType 予定タイプ
 * @param schedId 予定ID
 * @param fileInfoOriginalFileName クライアントから取得したOriginalFileName
 * @param returnPath azureから取得したパス
 * @param returnSize azureから取得したサイズ
 * @return
 */
export async function createSchedFile(prisma, pid, user, schedType, schedId, fileInfoOriginalFileName, returnPath, returnSize) {
    let createResult;
    const schedTypeDifine = Define.SETTINGS.SCHED_TYPE;
    switch (schedType) {
        case schedTypeDifine.FLIGHT:
            createResult = await prisma.schedFlightFile.create({
                data: {
                    schedFlightId: schedId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case schedTypeDifine.HOTEL:
            createResult = await prisma.schedHotelFile.create({
                data: {
                    schedHotelId: schedId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case schedTypeDifine.COMPANYCAR:
            createResult = await prisma.schedCompanyCarFile.create({
                data: {
                    schedCompanyCarId: schedId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case schedTypeDifine.TRANSPORTATION:
            createResult = await prisma.schedTransportationFile.create({
                data: {
                    schedTransportationId: schedId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case schedTypeDifine.EVENT:
            createResult = await prisma.schedEventFile.create({
                data: {
                    schedEventId: schedId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        default:
            break;
    }
    return createResult;
}
/**
 * 添付ファイルの物理削除作業。
 * @param prisma PrismaClient
 * @param schedType 予定タイプ
 * @param schedFileId ファイル予定ID
 * @return
 */
export async function deleteSchedFile(prisma, schedType, schedFileId) {
    // クライアント側から送信されたidに合致するファイル予定を削除する(削除フラグをたてる)
    const schedTypeDifine = Define.SETTINGS.SCHED_TYPE;
    switch (schedType) {
        case schedTypeDifine.FLIGHT:
            await prisma.schedFlightFile.delete({
                where: { id: schedFileId },
            });
            break;
        case schedTypeDifine.HOTEL:
            await prisma.schedHotelFile.delete({
                where: { id: schedFileId },
            });
            break;
        case schedTypeDifine.COMPANYCAR:
            await prisma.schedCompanyCarFile.delete({
                where: { id: schedFileId },
            });
            break;
        case schedTypeDifine.TRANSPORTATION:
            await prisma.schedTransportationFile.delete({
                where: { id: schedFileId },
            });
            break;
        case schedTypeDifine.EVENT:
            await prisma.schedEventFile.delete({
                where: { id: schedFileId },
            });
            break;
        default:
            break;
    }
}
/**
 * 対象となる予定の存在チェックおよび、予定に紐づくファイル情報の取得
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)または対象の予定に紐づくトータルファイルサイズ取得
 * @return
 */
export async function checkExistingSchedTotalSizeOrReturnError(pid, prisma, schedType, schedId, itineraryId) {
    const where = {
        id: schedId,
        flgDelete: false,
        itineraryId,
    };
    let result = undefined;
    // switch内で使用
    let findResult;
    let totalFileSize = 0;
    const existFilenames = [];
    let checkErrorDetailResult = undefined;
    const schedTypeDifine = Define.SETTINGS.SCHED_TYPE;
    switch (schedType) {
        case schedTypeDifine.FLIGHT:
            findResult = await prisma.schedFlight.findFirst({
                where,
                select: {
                    ownerPid: true,
                    schedFlightFiles: true,
                },
            });
            // 入力チェック
            checkErrorDetailResult = checkErrorDetail(findResult, pid, !!itineraryId);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            // ファイルのトータルサイズを算出、ファイル名を全て取得
            if (findResult) {
                for (const schedFlightFile of findResult.schedFlightFiles) {
                    totalFileSize += schedFlightFile.size;
                    existFilenames.push(schedFlightFile.originalFileName);
                }
                result = { totalFileSize, existFilenames };
            }
            break;
        case schedTypeDifine.HOTEL:
            findResult = await prisma.schedHotel.findFirst({
                where,
                select: {
                    ownerPid: true,
                    schedHotelFiles: true,
                },
            });
            checkErrorDetailResult = checkErrorDetail(findResult, pid, !!itineraryId);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            if (findResult) {
                for (const schedHotelFile of findResult.schedHotelFiles) {
                    totalFileSize += schedHotelFile.size;
                    existFilenames.push(schedHotelFile.originalFileName);
                }
                result = { totalFileSize, existFilenames };
            }
            break;
        case schedTypeDifine.COMPANYCAR:
            findResult = await prisma.schedCompanyCar.findFirst({
                where,
                select: {
                    ownerPid: true,
                    schedCompanyCarFiles: true,
                },
            });
            checkErrorDetailResult = checkErrorDetail(findResult, pid, !!itineraryId);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            if (findResult) {
                for (const schedCompanyCarFile of findResult.schedCompanyCarFiles) {
                    totalFileSize += schedCompanyCarFile.size;
                    existFilenames.push(schedCompanyCarFile.originalFileName);
                }
                result = { totalFileSize, existFilenames };
            }
            break;
        case schedTypeDifine.TRANSPORTATION:
            findResult = await prisma.schedTransportation.findFirst({
                where,
                select: {
                    ownerPid: true,
                    schedTransportationFiles: true,
                    flgCreateForeignStaff: true,
                },
            });
            checkErrorDetailResult = checkErrorDetail(findResult, pid, !!itineraryId);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            if (findResult) {
                for (const schedTransportationFile of findResult.schedTransportationFiles) {
                    totalFileSize += schedTransportationFile.size;
                    existFilenames.push(schedTransportationFile.originalFileName);
                }
                result = { totalFileSize, existFilenames };
            }
            break;
        case schedTypeDifine.EVENT:
            findResult = await prisma.schedEvent.findFirst({
                where,
                select: {
                    ownerPid: true,
                    schedEventFiles: true,
                    flgCreateForeignStaff: true,
                },
            });
            checkErrorDetailResult = checkErrorDetail(findResult, pid, !!itineraryId);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            if (findResult) {
                for (const schedEventFile of findResult.schedEventFiles) {
                    totalFileSize += schedEventFile.size;
                    existFilenames.push(schedEventFile.originalFileName);
                }
                result = { totalFileSize, existFilenames };
            }
            break;
    }
    return result;
}
export function checkErrorDetail(findResult, pid, isForeignStaff) {
    const target = findResult;
    return checkAccessRight(target, pid, isForeignStaff);
}
export function checkAccessRight(target, pid, isForeignStaff) {
    // DBからidをキーにして、予定情報が取得できない(W00401)
    if (!target) {
        return { code: Define.ERROR_CODES.W00401, status: 400 };
    }
    if (isForeignStaff) {
        // 海外拠点担当は、海外拠点担当が作成した予定のみ処理実施可能
        if (!target.flgCreateForeignStaff) {
            return { code: Define.ERROR_CODES.W00123, status: 400 };
        }
    }
    else {
        if (pid === target.ownerPid) {
            // 対象アカウント(pid)が、予定の作成者(オーナー)だが、海外拠点担当が作成した予定に添付ファイルを設定しようとしている(W00111)
            if (target.flgCreateForeignStaff) {
                return { code: Define.ERROR_CODES.W00111, status: 401 };
            }
            // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
        }
        else {
            return { code: Define.ERROR_CODES.W00111, status: 401 };
        }
    }
    return;
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、DB更新処理などのMCTrip予定更新処理後のみ実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param user
 * @param attachmentId ファイルID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, user, schedType, attachmentId, azAttachmentId, azAttachmentUpdatedAt) {
    try {
        if (schedType === 'flight') {
            await prisma.schedFlightFile.update({
                where: { id: attachmentId },
                data: {
                    azAttachmentId: strToBuf(azAttachmentId) || null,
                    azAttachmentUpdatedAt,
                    updatedBy: user.pid,
                },
            });
        }
        else if (schedType === 'hotel') {
            await prisma.schedHotelFile.update({
                where: { id: attachmentId },
                data: {
                    azAttachmentId: strToBuf(azAttachmentId) || null,
                    azAttachmentUpdatedAt,
                    updatedBy: user.pid,
                },
            });
        }
        else if (schedType === 'companyCar') {
            await prisma.schedCompanyCarFile.update({
                where: { id: attachmentId },
                data: {
                    azAttachmentId: strToBuf(azAttachmentId) || null,
                    azAttachmentUpdatedAt,
                    updatedBy: user.pid,
                },
            });
        }
        else if (schedType === 'transportation') {
            await prisma.schedTransportationFile.update({
                where: { id: attachmentId },
                data: {
                    azAttachmentId: strToBuf(azAttachmentId) || null,
                    azAttachmentUpdatedAt,
                    updatedBy: user.pid,
                },
            });
        }
        else if (schedType === 'event') {
            await prisma.schedEventFile.update({
                where: { id: attachmentId },
                data: {
                    azAttachmentId: strToBuf(azAttachmentId) || null,
                    azAttachmentUpdatedAt,
                    updatedBy: user.pid,
                },
            });
        }
        return true;
    }
    catch (error) {
        return false;
    }
}
/**
 * ファイル名がユニークでなければ、枝番をつけたファイル名に変更する。
 * @param fileName 調査対象ファイル名
 * @param existsFilenames ユニークチェック対象となるファイル名一覧
 */
export function changeFilenameIfNotUnique(fileName, existsFilenames, count = 0) {
    if (!existsFilenames || existsFilenames.length <= 0) {
        return fileName;
    }
    let checkedFilename = fileName;
    if (count > 0) {
        checkedFilename = _getFilenameWithNumbering(fileName, count);
    }
    if (count > existsFilenames.length) {
        return checkedFilename;
    }
    for (const existFilename of existsFilenames) {
        if (existFilename === checkedFilename) {
            const nextCount = count + 1;
            return changeFilenameIfNotUnique(fileName, existsFilenames, nextCount);
        }
    }
    return checkedFilename;
}
function _getFilenameWithNumbering(fileName, count) {
    const [name, exp] = divideFilenameToNameAndExp(fileName);
    return name + '_' + count + exp;
}
//# sourceMappingURL=schedFileService.js.map