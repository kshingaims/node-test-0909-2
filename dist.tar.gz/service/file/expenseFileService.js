/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { Define } from '../../utils/define.js';
/**
 * 経費に添付されたファイルのダウンロードのdata部分のレコードを取得する(入力チェックも含む)。
 * @param prisma
 * @param pid
 * @param expenseType
 * @param FileId
 * @returns
 */
export async function getFileExpense(prisma, pid, expenseType, FileId) {
    let switchResult;
    const where = { id: FileId };
    const expenseTypeDifine = Define.SETTINGS.EXPENSE_TYPE;
    let expense;
    // 経費IDに紐づくファイルのレコードを取得する。
    switch (expenseType) {
        case expenseTypeDifine.ACCOMMODATION:
            switchResult = await prisma.expenseAccommodationFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    expenseAccommodation: { select: { expense: true } },
                },
            });
            // 処理対象アカウント(pid)が、大元の経費テーブルのPIDと同じである必要がある(W00402)
            expense = switchResult?.expenseAccommodation.expense;
            if (expense) {
                const result = checkForPidInExpenseError(pid, expense.pid);
                if (result !== undefined) {
                    return result;
                }
            }
            break;
        case expenseTypeDifine.TRANSPORTATION:
            switchResult = await prisma.expenseTransportationFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    expenseTransportation: { select: { expense: true } },
                },
            });
            // 処理対象アカウント(pid)が、大元の経費テーブルのPIDと同じである必要がある(W00402)
            expense = switchResult?.expenseTransportation.expense;
            if (expense) {
                const result = checkForPidInExpenseError(pid, expense.pid);
                if (result !== undefined) {
                    return result;
                }
            }
            break;
        case expenseTypeDifine.OTHER:
            switchResult = await prisma.expenseOtherFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    expenseOther: { select: { expense: true } },
                },
            });
            // 処理対象アカウント(pid)が、大元の経費テーブルのPIDと同じである必要がある(W00402)
            expense = switchResult?.expenseOther.expense;
            if (expense) {
                const result = checkForPidInExpenseError(pid, expense.pid);
                if (result !== undefined) {
                    return result;
                }
            }
            break;
        default:
            break;
    }
    // ファイルIDに合致する添付ファイルレコードが存在しない(W00401)
    if (!switchResult) {
        return { code: Define.ERROR_CODES.W00401, status: 400 };
    }
    return { path: switchResult.path, originalFileName: switchResult.originalFileName, size: switchResult.size };
}
/**
 * 処理対象のPIDが経費IDと一致するかチェック 経費はオーナーだけしか処理できない
 * @param pid
 * @param expense
 * @returns
 */
export function checkForPidInExpenseError(pid, expense) {
    if (expense !== undefined) {
        if (expense !== pid) {
            return { code: Define.ERROR_CODES.W00402, status: 401 };
        }
    }
    return;
}
/**
 * ファイルアップロード済みの添付ファイル情報の新規登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param expenseType 経費タイプ
 * @param expenseCategoryId 経費項目ID
 * @param fileInfoOriginalFileName クライアントから取得したOriginalFileName
 * @param returnPath azureから取得したパス
 * @param returnSize azureから取得したサイズ
 * @return
 */
export async function createExpenseFile(prisma, pid, user, expenseType, expenseCategoryId, fileInfoOriginalFileName, returnPath, returnSize) {
    let createResult;
    const expenseTypeDifine = Define.SETTINGS.EXPENSE_TYPE;
    switch (expenseType) {
        case expenseTypeDifine.ACCOMMODATION:
            createResult = await prisma.expenseAccommodationFile.create({
                data: {
                    expenseAccommodationId: expenseCategoryId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case expenseTypeDifine.TRANSPORTATION:
            createResult = await prisma.expenseTransportationFile.create({
                data: {
                    expenseTransportationId: expenseCategoryId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case expenseTypeDifine.OTHER:
            createResult = await prisma.expenseOtherFile.create({
                data: {
                    expenseOtherId: expenseCategoryId,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        default:
            break;
    }
    return createResult;
}
/**
 * 添付ファイルの物理削除作業。
 * @param prisma PrismaClient
 * @param expenseType 経費タイプ
 * @param expenseFileId ファイル経費ID
 * @return
 */
export async function deleteExpenseFile(prisma, expenseType, expenseFileId) {
    // クライアント側から送信されたidに合致するファイル経費を削除する(削除フラグをたてる)
    const expenseTypeDifine = Define.SETTINGS.EXPENSE_TYPE;
    switch (expenseType) {
        case expenseTypeDifine.ACCOMMODATION:
            await prisma.expenseAccommodationFile.delete({
                where: { id: expenseFileId },
            });
            break;
        case expenseTypeDifine.TRANSPORTATION:
            await prisma.expenseTransportationFile.delete({
                where: { id: expenseFileId },
            });
            break;
        case expenseTypeDifine.OTHER:
            await prisma.expenseOtherFile.delete({
                where: { id: expenseFileId },
            });
            break;
        default:
            break;
    }
}
/**
 * 対象となる経費の存在チェックおよび、経費に紐づくファイル情報の取得
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)または対象の経費に紐づくトータルファイルサイズ取得
 * @return
 */
export async function checkExistingExpenseTotalSizeOrReturnError(pid, prisma, expenseType, expenseCategoryId) {
    const where = { id: expenseCategoryId, flgDelete: false };
    let result = undefined;
    // switch内で使用
    let findResult;
    let totalFileSize = 0;
    let checkErrorDetailResult = undefined;
    const expenseTypeDifine = Define.SETTINGS.EXPENSE_TYPE;
    switch (expenseType) {
        case expenseTypeDifine.ACCOMMODATION:
            findResult = await prisma.expenseAccommodation.findFirst({
                where,
                select: {
                    expenseAccommodationFiles: true,
                    expense: { select: { pid: true } },
                },
            });
            // 入力チェック
            checkErrorDetailResult = await checkErrorDetail(findResult, pid);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            // ファイルのトータルサイズを算出
            if (findResult) {
                for (const expenseFlightFile of findResult.expenseAccommodationFiles) {
                    totalFileSize += expenseFlightFile.size;
                }
                result = { totalFileSize: totalFileSize };
            }
            break;
        case expenseTypeDifine.TRANSPORTATION:
            findResult = await prisma.expenseTransportation.findFirst({
                where,
                select: {
                    expenseTransportationFiles: true,
                    expense: { select: { pid: true } },
                },
            });
            // 入力チェック
            checkErrorDetailResult = await checkErrorDetail(findResult, pid);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            // ファイルのトータルサイズを算出
            if (findResult) {
                for (const expenseTransportationFile of findResult.expenseTransportationFiles) {
                    totalFileSize += expenseTransportationFile.size;
                }
                result = { totalFileSize: totalFileSize };
            }
            break;
        case expenseTypeDifine.OTHER:
            findResult = await prisma.expenseOther.findFirst({
                where,
                select: {
                    expenseOtherFiles: true,
                    expense: { select: { pid: true } },
                },
            });
            // 入力チェック
            checkErrorDetailResult = await checkErrorDetail(findResult, pid);
            if (checkErrorDetailResult !== undefined) {
                result = { error: checkErrorDetailResult };
                break;
            }
            // ファイルのトータルサイズを算出
            if (findResult) {
                for (const expenseOtherFile of findResult.expenseOtherFiles) {
                    totalFileSize += expenseOtherFile.size;
                }
                result = { totalFileSize: totalFileSize };
            }
            break;
    }
    return result;
}
export async function checkErrorDetail(findResult, pid) {
    // DBからidをキーにして、経費情報が取得できない(W00109)
    if (!findResult) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // 対象アカウント(pid)が、経費の作成者(オーナー)ではないのに、経費を更新・削除しようとしている(W00111)
    if (pid !== findResult.expense.pid) {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    return;
}
//# sourceMappingURL=expenseFileService.js.map