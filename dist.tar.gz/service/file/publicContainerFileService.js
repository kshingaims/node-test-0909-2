/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { Define } from '../../utils/define.js';
/**
 * 関連するレコードに添付されたファイルのダウンロードのdata部分のレコードを取得する(入力チェックも含む)。
 * @param prisma
 * @param pid
 * @param publicContainerType
 * @param FileId
 * @returns
 */
export async function getFilePublicContainer(prisma, user, publicContainerType, FileId) {
    let switchResult;
    const where = { id: FileId };
    const publicContainerTypeDifine = Define.SETTINGS.PUBLIC_CONTAINER_TYPE;
    // 関連するレコードに紐づくファイルのレコードを取得する。
    switch (publicContainerType) {
        case publicContainerTypeDifine.COMPANY_CAR:
            switchResult = await prisma.companyCarFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    companyCar: true,
                },
            });
            if (switchResult) {
                if (switchResult.companyCar.mcSyozokuCd !== user.mcSyozokuCd) {
                    return { code: Define.ERROR_CODES.W99002, status: 400 };
                }
            }
            break;
        case publicContainerTypeDifine.HOTEL:
            switchResult = await prisma.hotelFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    hotel: true,
                },
            });
            if (switchResult) {
                if (switchResult.hotel.mcSyozokuCd !== user.mcSyozokuCd) {
                    return { code: Define.ERROR_CODES.W99002, status: 400 };
                }
            }
            break;
        case publicContainerTypeDifine.DRIVER:
            switchResult = await prisma.driverFile.findFirst({
                where,
                select: {
                    path: true,
                    originalFileName: true,
                    size: true,
                    driver: true,
                },
            });
            if (switchResult) {
                if (switchResult.driver.mcSyozokuCd !== user.mcSyozokuCd) {
                    return { code: Define.ERROR_CODES.W99002, status: 400 };
                }
            }
            break;
        default:
            break;
    }
    // ファイルIDに合致する添付ファイルレコードが存在しない(W00401)
    if (!switchResult) {
        return { code: Define.ERROR_CODES.W00401, status: 400 };
    }
    return { path: switchResult.path, originalFileName: switchResult.originalFileName, size: switchResult.size };
}
/**
 * ファイルアップロード済みの添付ファイル情報の新規登録作業。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param publicContainerType パブリックコンテナタイプ
 * @param id 関連ファイルID
 * @param fileInfoOriginalFileName クライアントから取得したOriginalFileName
 * @param returnPath azureから取得したパス
 * @param returnSize azureから取得したサイズ
 * @return
 */
export async function createPublicContainerFile(prisma, pid, user, publicContainerType, id, fileInfoOriginalFileName, returnPath, returnSize) {
    let createResult;
    const publicContainerTypeDifine = Define.SETTINGS.PUBLIC_CONTAINER_TYPE;
    switch (publicContainerType) {
        case publicContainerTypeDifine.COMPANY_CAR:
            createResult = await prisma.companyCarFile.create({
                data: {
                    companyCarId: id,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case publicContainerTypeDifine.HOTEL:
            createResult = await prisma.hotelFile.create({
                data: {
                    hotelId: id,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        case publicContainerTypeDifine.DRIVER:
            createResult = await prisma.driverFile.create({
                data: {
                    driverId: id,
                    originalFileName: fileInfoOriginalFileName,
                    path: returnPath,
                    size: returnSize,
                    ownerPid: pid,
                    updatedBy: user.pid,
                },
            });
            break;
        default:
            break;
    }
    return createResult;
}
/**
 * 添付ファイルの物理削除作業。
 * @param prisma PrismaClient
 * @param publicContainerType パブリックコンテナタイプ
 * @param id ファイルID
 * @return
 */
export async function deletePublicContainerFile(prisma, publicContainerType, id) {
    // クライアント側から送信されたidに合致するファイルを削除する(削除フラグをたてる)
    const publicContainerTypeDifine = Define.SETTINGS.PUBLIC_CONTAINER_TYPE;
    switch (publicContainerType) {
        case publicContainerTypeDifine.COMPANY_CAR:
            await prisma.companyCarFile.delete({
                where: { id },
            });
            break;
        case publicContainerTypeDifine.HOTEL:
            await prisma.hotelFile.delete({
                where: { id },
            });
            break;
        case publicContainerTypeDifine.DRIVER:
            await prisma.driverFile.delete({
                where: { id },
            });
            break;
        default:
            break;
    }
}
/**
 * 対象となる関連ファイルの存在チェックおよび、関連ファイルに紐づくファイル情報の取得
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)または対象の経費に紐づくトータルファイルサイズ取得
 * @return
 */
export async function checkExistingPublicContainerTotalSizeOrReturnError(user, prisma, publicContainerType, expenseCategoryId) {
    const where = {
        id: expenseCategoryId,
        flgDelete: false,
        mcSyozokuCd: user.mcSyozokuCd,
    };
    let result = undefined;
    // switch内で使用
    let findResult = undefined;
    let totalFileSize = 0;
    const publicContainerTypeDifine = Define.SETTINGS.PUBLIC_CONTAINER_TYPE;
    switch (publicContainerType) {
        case publicContainerTypeDifine.COMPANY_CAR:
            findResult = await prisma.companyCar.findFirst({
                where,
                select: {
                    companyCarFiles: true,
                },
            });
            // ファイルのトータルサイズを算出
            if (findResult) {
                for (const companyCarFile of findResult.companyCarFiles) {
                    totalFileSize += companyCarFile.size;
                }
                result = { totalFileSize: totalFileSize };
            }
            break;
        case publicContainerTypeDifine.HOTEL:
            findResult = await prisma.hotel.findFirst({
                where,
                select: {
                    hotelFiles: true,
                },
            });
            // ファイルのトータルサイズを算出
            if (findResult) {
                for (const hotelFile of findResult.hotelFiles) {
                    totalFileSize += hotelFile.size;
                }
                result = { totalFileSize: totalFileSize };
            }
            break;
        case publicContainerTypeDifine.DRIVER:
            findResult = await prisma.driver.findFirst({
                where,
                select: {
                    driverFiles: true,
                },
            });
            // ファイルのトータルサイズを算出
            if (findResult) {
                for (const driverFile of findResult.driverFiles) {
                    totalFileSize += driverFile.size;
                }
                result = { totalFileSize: totalFileSize };
            }
            break;
    }
    if (!findResult) {
        return { error: { code: Define.ERROR_CODES.W99002, status: 400 } };
    }
    return result;
}
//# sourceMappingURL=publicContainerFileService.js.map