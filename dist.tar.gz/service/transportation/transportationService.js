/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { filter, orderBy } from 'lodash-es';
import { Define } from '../../utils/define.js';
import { sendSmtpMail } from '../../utils/smtpMail.js';
import { format, formatDate, formatDateTime, formatDateTimeMiliSecond, getLocalDate, isBeforeToday, isFromDatetimeBeforeToDatetime, replaceCRLF, strToBuf, } from '../../utils/index.js';
import { isExistsItineraryCompanions } from '../../service/itinerary/itineraryService.js';
import { getNotificationSettingMapByIds } from '../../service/notification/notificationSettingService.js';
import { getExpenseIds } from '../../service/expense/expenseIndexService.js';
import { createExpenseTransportation } from '../../service/expense/expenseTransportService.js';
import { createSiteNotification } from '../../service/notification/notificationService.js';
/**
 * 処理対象アカウントが表示可能な移動予定一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param transportationId
 * @returns
 */
export async function getTransportationSchedList(prisma, pid, itineraryId, transportationId, isOutlookIntegration = false) {
    const where = {
        pid,
        schedTransportation: { flgDelete: !isOutlookIntegration ? false : undefined },
        flgDelete: false,
        flgReject: false,
    };
    if (!transportationId && !itineraryId) {
        // 旅程IDもしくは移動IDは指定必須
        throw new Error('unreachable error.');
    }
    if (transportationId) {
        where.schedTransportationId = transportationId;
    }
    if (itineraryId) {
        where.schedTransportation = { itineraryId: itineraryId, flgDelete: !isOutlookIntegration ? false : undefined };
    }
    const schedTransportationIndividuals = await prisma.schedTransportationIndividual.findMany({
        where,
        select: {
            calendarId: isOutlookIntegration,
            calendarUpdatedAt: isOutlookIntegration,
            flgReject: true,
            schedTransportation: {
                select: {
                    id: true,
                    itineraryId: true,
                    transportationMode: true,
                    departureDateTime: true,
                    arrivalDateTime: true,
                    timezone: true,
                    departureLocation: true,
                    arrivalLocation: true,
                    remark: true,
                    ownerPid: true,
                    flgCreateForeignStaff: true,
                    calendarId: isOutlookIntegration,
                    calendarUpdatedAt: isOutlookIntegration,
                    iCalUId: isOutlookIntegration,
                    flgDelete: true,
                    updatedAt: isOutlookIntegration,
                    schedTransportationIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    firstNameRoma: true,
                                    lastNameRoma: true,
                                    firstNameKanji: true,
                                    lastNameKanji: true,
                                    firstNameKana: true,
                                    lastNameKana: true,
                                    email: true,
                                },
                            },
                            flgReject: true,
                            createdAt: true,
                            flgDelete: true,
                        },
                    },
                    schedTransportationFiles: {
                        select: {
                            id: true,
                            originalFileName: true,
                            size: true,
                            ownerPid: true,
                            path: isOutlookIntegration,
                            azAttachmentId: isOutlookIntegration,
                            azAttachmentUpdatedAt: isOutlookIntegration,
                        },
                    },
                },
            },
        },
        orderBy: {
            // 取得される移動一覧は「1.移動出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            schedTransportation: {
                departureDateTime: 'asc',
            },
        },
    });
    // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
    for (const schedTransportationIndividual of schedTransportationIndividuals) {
        // 移動予定(schedTransportation)の中にあるschedTransportationIndividualsについては、作成日時の昇順(asc)となるように、移動予定一覧の全レコードに対して、並び替えを実施する。
        schedTransportationIndividual.schedTransportation.schedTransportationIndividuals = orderBy(
        // 移動予定(schedTransportation)の中にあるschedTransportationIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedTransportationIndividual.schedTransportation.schedTransportationIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return schedTransportationIndividuals;
}
/**
 * 海外担当者による予定作成時のレスポンスデータとして予定情報を返す
 * @param prisma
 * @param eventId
 * @returns
 */
export async function getTransportationSchedData(prisma, transportationId) {
    // schedTransportaionを返す。JSON構造についてはGET返却時のAPIレスポンスと同じ構造となるようにする
    // schedTransportaionIndividualに紐つくschedTransportaionがあるという
    const schedTransportation = await prisma.schedTransportation.findFirst({
        where: { id: transportationId, flgDelete: false },
        select: {
            id: true,
            itineraryId: true,
            transportationMode: true,
            departureDateTime: true,
            arrivalDateTime: true,
            timezone: true,
            departureLocation: true,
            arrivalLocation: true,
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            calendarId: true,
            calendarUpdatedAt: true,
            schedTransportationIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                            firstNameRoma: true,
                            lastNameRoma: true,
                            firstNameKanji: true,
                            lastNameKanji: true,
                            firstNameKana: true,
                            lastNameKana: true,
                            email: true,
                        },
                    },
                    flgReject: true,
                    createdAt: true,
                    flgDelete: true,
                },
            },
            schedTransportationFiles: {
                select: {
                    id: true,
                    originalFileName: true,
                    size: true,
                    ownerPid: true,
                },
            },
        },
        orderBy: {
            // 取得されるイベント一覧は「1.イベント出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            departureDateTime: 'asc',
        },
    });
    if (schedTransportation) {
        // 予定予定(schedTransportation)の中にあるschedTransportationIndividualsについては、作成日時の昇順(asc)となるように、予定予定一覧の全レコードに対して、並び替えを実施する。
        schedTransportation.schedTransportationIndividuals = orderBy(
        // 予定予定(schedTransportation)の中にあるschedTransportationIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedTransportation.schedTransportationIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return {
        schedTransportation,
    };
}
/**
 * 旅程Excelダウンロード用に、対象旅程IDに紐づく各種移動予定一覧を取得する
 * @param prisma
 * @param itineraryId
 * @returns
 */
export async function getTransportationsForExcelDownload(prisma, itineraryId) {
    const schedTransportations = await prisma.schedTransportation.findMany({
        where: {
            flgDelete: false,
            itineraryId,
        },
        select: {
            id: true,
            itineraryId: true,
            transportationMode: true,
            departureDateTime: true,
            arrivalDateTime: true,
            timezone: true,
            departureLocation: true,
            arrivalLocation: true,
            remark: true,
            ownerPid: true,
            flgCreateForeignStaff: true,
            flgDelete: true,
            schedTransportationIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                        },
                    },
                    flgReject: true,
                    flgDelete: true,
                },
            },
        },
        orderBy: {
            departureDateTime: 'asc',
        },
    });
    return schedTransportations;
}
/**
 * 移動予定及び移動個人予定の登録作業。
 * 移動予定のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props TransportationSchedCreateProps
 * @return
 */
export async function createSchedTransportation(prisma, pid, user, props, itineraryId, isForeignStaff = false) {
    // SchedTransportationテーブル作成
    const result = await prisma.schedTransportation.create({
        data: {
            ownerPid: pid,
            itineraryId,
            transportationMode: props.transportationMode,
            departureDateTime: new Date(props.departureDateTime),
            arrivalDateTime: new Date(props.arrivalDateTime),
            timezone: props.timezone,
            departureLocation: props.departureLocation,
            arrivalLocation: props.arrivalLocation,
            remark: props.remark,
            flgCreateForeignStaff: isForeignStaff,
            updatedBy: user.pid,
        },
    });
    const schedTransportationId = result.id;
    let targetPids = [];
    // 出張代表者をSchedEventIndividualとして最初に登録しておく ※海外拠点担当者を除く
    if (!isForeignStaff) {
        targetPids = [pid];
    }
    // 同行者がいれば、その同行者の数だけ、SchedTransportationIndividualを登録する
    if (props.companions) {
        for (const companion of props.companions) {
            targetPids.push(companion.pid);
        }
    }
    for (const targetPid of targetPids) {
        await prisma.schedTransportationIndividual.create({
            data: {
                schedTransportationId,
                pid: targetPid,
                updatedBy: user.pid,
            },
        });
    }
    return schedTransportationId;
}
/**
 * 移動予定及び移動個人予定の更新作業。
 * 移動予定のみ更新する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedTransportation SchedTransportationInschedTransportationIndividuals
 * @param props TransportationSchedUpdateProps
 * @return
 */
export async function updateSchedTransportation(prisma, pid, user, schedTransportation, props, isForeignStaff = false) {
    const companionPids = props.companions ? props.companions?.map((companion) => companion.pid) : [];
    // 出張代表者をSchedEventIndividualとして最初に登録しておく ※海外拠点担当者を除く
    if (!isForeignStaff) {
        companionPids.unshift(pid); //予定作成者を先頭に追加する
    }
    await prisma.schedTransportation.update({
        where: { id: schedTransportation.id },
        data: {
            ownerPid: pid,
            itineraryId: props.itineraryId,
            transportationMode: props.transportationMode,
            departureDateTime: new Date(props.departureDateTime),
            arrivalDateTime: new Date(props.arrivalDateTime),
            timezone: props.timezone,
            departureLocation: props.departureLocation,
            arrivalLocation: props.arrivalLocation,
            remark: props.remark,
            updatedBy: user.pid,
        },
    });
    const schedTransportationIndividualPids = [];
    for (const schedTransportationIndividual of schedTransportation.schedTransportationIndividuals) {
        if (!schedTransportationIndividual.flgDelete) {
            if (!companionPids.includes(schedTransportationIndividual.pid)) {
                // DB取得したSchedTransportationIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧に含まれていない場合は、同行者削除(flgDelete=true)を実施する。
                await prisma.schedTransportationIndividual.update({
                    data: {
                        flgDelete: true,
                        updatedBy: user.pid,
                    },
                    where: {
                        schedTransportationId_pid: {
                            schedTransportationId: schedTransportationIndividual.schedTransportationId,
                            pid: schedTransportationIndividual.pid,
                        },
                    },
                });
            }
            // DB取得したSchedTransportationIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧にも含まれている場合は、何も処理しない(同行者指定済)
        }
        else if (schedTransportationIndividual.flgDelete) {
            if (companionPids.includes(schedTransportationIndividual.pid)) {
                // DB取得したSchedTransportationIndividualがflgDelete=trueとなっており、クライアント側から取得した同行者一覧に含まれている場合は、同行者の再指定(flgDelete=false)を実施する。
                await prisma.schedTransportationIndividual.update({
                    data: {
                        flgDelete: false,
                        updatedBy: user.pid,
                    },
                    where: {
                        schedTransportationId_pid: {
                            schedTransportationId: schedTransportationIndividual.schedTransportationId,
                            pid: schedTransportationIndividual.pid,
                        },
                    },
                });
            }
        }
        // DB取得したSchedTransportationIndividualのpid一覧作成
        schedTransportationIndividualPids.push(schedTransportationIndividual.pid);
    }
    // クライアント側から取得した同行者一覧の中にあるpidが、DB取得したSchedTransportationIndividual一覧の中に含まれていない場合は、同行者の新規追加実施
    for (const companionPid of companionPids) {
        if (!schedTransportationIndividualPids.includes(companionPid)) {
            await prisma.schedTransportationIndividual.create({
                data: {
                    schedTransportationId: schedTransportation.id,
                    pid: companionPid,
                    updatedBy: user.pid,
                },
            });
        }
    }
}
/**
 * 移動予定(手配は除く)の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param schedTransportationId 移動予定ID
 * @return
 */
export async function deleteSchedTransportation(prisma, user, schedTransportationId) {
    // クライアント側から送信されたidに合致する移動予定を削除する(削除フラグをたてる)
    await prisma.schedTransportation.update({
        where: { id: schedTransportationId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * 移動個人予定テーブルの更新作業。
 * 移動予定参加の拒否
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedTransportationId schedTransportationId
 * @param flgReject boolean
 * @return
 */
export async function rejectSchedTransportationIndividual(prisma, pid, user, schedTransportationId, flgReject) {
    await prisma.schedTransportationIndividual.update({
        where: { schedTransportationId_pid: { schedTransportationId, pid: pid } },
        data: {
            flgReject,
            updatedBy: user.pid,
        },
    });
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function createTransportationSchedIfNotExists(pid, prisma, itineraryId, arrivalDateTime, departureDateTime, companions, isForeignStaff = false) {
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = companions?.map((item) => {
        return item.pid;
    });
    if (isForeignStaff) {
        // 海外拠点の場合は、companionsの指定がない場合は入力チェックエラー
        if (!companions || companions.length <= 0) {
            return { code: Define.ERROR_CODES.W00122, status: 200 };
        }
    }
    else {
        // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
        if (companionPids) {
            companionPids.push(pid);
        }
        else {
            companionPids = [pid];
        }
    }
    // 指定されているpidが、旅程の作成者/同行者に含まれているかをチェック(W00104)
    if (companionPids) {
        const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
        if (error) {
            return error;
        }
    }
    // 予定_出発日時または予定_到着日時が現在日よりも前の日時(W00102) になっている場合は入力チェックエラーとする
    if (isBeforeToday(new Date(departureDateTime)) || isBeforeToday(new Date(arrivalDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 予定_到着日時が予定_出発日時よりも前の日時となっている(W00103) になっている場合は入力チェックエラーとする
    if (isFromDatetimeBeforeToDatetime(new Date(arrivalDateTime), new Date(departureDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function updateIfExists(pid, prisma, schedTransportation, //prismaから取得したschedTransportationレコード
itineraryId, arrivalDateTime, departureDateTime, companions, isForeignStaff = false) {
    // DBから移動予定情報が取得できない(W00109)
    if (schedTransportation === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // DBから取得したitineraryIdとクライアントから取得したitineraryIdが一致しない(W00109)
    if (schedTransportation.itineraryId !== itineraryId) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    if (isForeignStaff) {
        // 海外拠点の場合は、companionsの指定がない場合は入力チェックエラー
        if (!companions || companions.length <= 0) {
            return { code: Define.ERROR_CODES.W00122, status: 200 };
        }
        // 海外拠点担当は、海外拠点担当が作成した予定のみ処理実施可能
        if (!schedTransportation.flgCreateForeignStaff) {
            return { code: Define.ERROR_CODES.W00123, status: 400 };
        }
    }
    else {
        if (pid === schedTransportation.ownerPid) {
            // 対象アカウント(pid)が、予定の作成者(オーナー)だが、海外拠点担当が作成した予定を更新・削除しようとしている(W00111)
            if (schedTransportation.flgCreateForeignStaff) {
                return { code: Define.ERROR_CODES.W00111, status: 401 };
            }
            // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
        }
        else {
            return { code: Define.ERROR_CODES.W00111, status: 401 };
        }
    }
    // 出発日時または到着日時が現在日よりも前の日時(W00102)
    if (isBeforeToday(new Date(departureDateTime)) || isBeforeToday(new Date(arrivalDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 到着日時が出発日時よりも前の日時となっている(W00103)
    if (isFromDatetimeBeforeToDatetime(new Date(arrivalDateTime), new Date(departureDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = companions?.map((item) => {
        return item.pid;
    });
    if (!isForeignStaff) {
        // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
        if (companionPids) {
            companionPids.push(pid);
        }
        else {
            companionPids = [pid];
        }
    }
    // 同行者指定のpidが、紐ついている旅程の作成者/同行者になっていない(W00104)
    if (companionPids) {
        const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
        if (error) {
            return error;
        }
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function deleteIfExists(pid, schedTransportation, //prismaから取得したschedTransportationレコード
isForeignStaff = false) {
    // 入力チェック内容 全ての手配ステータス(arrgtStatus)で共通の内容
    // DBから移動予定情報が取得できない(W00109)
    if (schedTransportation === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    if (isForeignStaff) {
        // 海外拠点担当は、海外拠点担当が作成した予定のみ処理実施可能
        if (!schedTransportation.flgCreateForeignStaff) {
            return { code: Define.ERROR_CODES.W00123, status: 400 };
        }
    }
    else {
        if (pid === schedTransportation.ownerPid) {
            // 対象アカウント(pid)が、予定の作成者(オーナー)だが、海外拠点担当が作成した予定を更新・削除しようとしている(W00111)
            if (schedTransportation.flgCreateForeignStaff) {
                return { code: Define.ERROR_CODES.W00111, status: 401 };
            }
            // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
        }
        else {
            return { code: Define.ERROR_CODES.W00111, status: 401 };
        }
    }
    return;
}
/**
 * 入力チェック用のデータ取得を実施する。schedTransportationIndividualsは削除フラグが立っているものも含んで取得する
 * @param prisma
 * @param pid
 * @param schedTransporationId
 * @param itineraryId
 * @returns
 */
export async function getSchedTransportationForChecker(prisma, schedTransporationId, itineraryId) {
    const schedTransportation = await prisma.schedTransportation.findFirst({
        where: {
            id: schedTransporationId,
            itineraryId,
            flgDelete: false, // 削除フラグがたっていない
        },
        include: { schedTransportationIndividuals: true }, //(flgDelete=trueのものも含んで取得する)
    });
    return schedTransportation;
}
/**
 * こちらの関数は、outlookイベントをmctripに取り込む際に、mctripの予定を取り込まないようにする為のチェックで利用。
 * 指定したitineraryIdとpidに合致して、outlook連携している予定情報一覧を取得する。
 * 削除フラグや拒否フラグがある場合でも取得を実施する。
 * @param prisma
 * @param pid
 * @param itineraryId
 * @returns
 */
export async function getSchedTransportationsReflectedInOutlook(prisma, pid, itineraryId) {
    const schedIndividuals = await prisma.schedTransportationIndividual.findMany({
        where: {
            pid,
            schedTransportation: { itineraryId, calendarId: { not: null } },
        },
        select: {
            flgDelete: true,
            flgReject: true,
            schedTransportation: true,
        },
    });
    if (schedIndividuals.length <= 0) {
        return [];
    }
    else {
        return schedIndividuals.map((item) => {
            return item.schedTransportation;
        });
    }
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、DB更新処理などのMCTrip予定更新処理後のみ実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param user
 * @param schedId 予定のID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @param iCalUId outlookイベント固有ID
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, user, schedId, calendarId, calendarUpdatedAt, iCalUId) {
    try {
        const updatedAt = calendarUpdatedAt ? new Date(formatDateTimeMiliSecond(new Date(calendarUpdatedAt))) : new Date();
        await prisma.schedTransportation.update({
            where: { id: schedId },
            data: { calendarId: strToBuf(calendarId) || null, calendarUpdatedAt, iCalUId, updatedBy: user.pid, updatedAt },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
/**
 * 予定手配実施フラグ更新処理の入力チェックとメール通知で利用する情報をDBから取得する
 * @param prisma
 * @param itineraryId
 * @returns
 */
export async function getSchedTransportationForSendSmtpMail(prisma, schedTransporationId) {
    const schedTransportation = await prisma.schedTransportation.findUniqueOrThrow({
        select: {
            id: true,
            ownerPid: true,
            transportationMode: true,
            timezone: true,
            departureDateTime: true,
            arrivalDateTime: true,
            schedTransportationIndividuals: {
                select: {
                    flgDelete: true,
                    flgReject: true,
                    pid: true,
                    user: true,
                },
            },
            itinerary: {
                select: {
                    itineraryIndividuals: {
                        select: {
                            itineraryId: true,
                            itineraryFrom: true,
                            itineraryTo: true,
                            itineraryName: true,
                            pid: true,
                        },
                    },
                },
            },
        },
        where: { id: schedTransporationId, flgDelete: false, flgCreateForeignStaff: true },
    });
    return schedTransportation;
}
export async function sendSchedCreateMailAndSiteNotificationToCompanions(log, prisma, transportationId) {
    const settingMap = await getNotificationSettingMapByIds(prisma, [
        'foreign_staff_create_transportation_mail',
        'foreign_staff_create_transportation_s_notice',
    ]);
    // SMTP通知処理
    const smtpSetting = await settingMap['foreign_staff_create_transportation_mail'];
    let itineraryInfo = {};
    if (!smtpSetting.title || !smtpSetting.content || !smtpSetting.linkUrl) {
        throw new Error('title, content linkUrl is necessary.');
    }
    const schedTransportation = await getSchedTransportationForSendSmtpMail(prisma, transportationId);
    const targetEmails = [];
    const targetPids = [];
    for (const schedIndividual of schedTransportation.schedTransportationIndividuals) {
        if (schedIndividual.flgDelete || schedIndividual.flgReject) {
            continue;
        }
        if (schedIndividual.user.email) {
            targetEmails.push(schedIndividual.user.email);
            targetPids.push(schedIndividual.user.pid);
        }
    }
    // 一番最初に該当している社有車予定のownerPidが持っている旅程情報を取得する
    const ownerPid = schedTransportation.ownerPid;
    for (const itiIndividual of schedTransportation.itinerary.itineraryIndividuals) {
        if (itiIndividual.pid === ownerPid) {
            itineraryInfo = {
                id: itiIndividual.itineraryId,
                itineraryName: itiIndividual.itineraryName,
                itineraryFrom: itiIndividual.itineraryFrom,
                itineraryTo: itiIndividual.itineraryTo,
            };
            break;
        }
    }
    const tz = schedTransportation.timezone;
    const departureDateTime = schedTransportation.departureDateTime;
    const arrivalDateTime = schedTransportation.arrivalDateTime;
    if (!tz || !departureDateTime || !arrivalDateTime) {
        throw new Error('data invalid.');
    }
    const transportation = {
        transportationMode: getTransportationModeLabel(schedTransportation.transportationMode),
        from: formatDateTime(getLocalDate(departureDateTime, tz), 'yyyyMMddHH:mm'),
        to: formatDateTime(getLocalDate(arrivalDateTime, tz), 'HH:mm'),
    };
    const itineraryFrom = formatDate(new Date(itineraryInfo.itineraryFrom), 'yyyyMMdd');
    const itineraryTo = formatDate(new Date(itineraryInfo.itineraryTo), 'MMdd');
    // リンクURL整形
    let linkUrl = format(smtpSetting.linkUrl, { domain: Define.DOMAIN, itineraryId: itineraryInfo.id });
    const title = format(smtpSetting.title, { transportation });
    // メール本文整形
    const body = replaceCRLF(format(smtpSetting.content, { itineraryFrom, itineraryTo, itinerary: itineraryInfo, transportation, linkUrl }));
    // メール送信
    sendSmtpMail(log, { to: targetEmails, title, body });
    // サイト上での通知実施
    const setting = settingMap['foreign_staff_create_transportation_s_notice'];
    if (!setting.content || !setting.linkUrl) {
        throw new Error('content, linkUrl is necessary.');
    }
    linkUrl = format(setting.linkUrl, { domain: Define.DOMAIN, itineraryId: itineraryInfo.id });
    const content = format(setting.content, { transportation });
    for (const targetPid of targetPids) {
        await createSiteNotification(prisma, targetPid, itineraryInfo.id, content, linkUrl);
    }
}
export async function getSchedTransportationForCreateExpenseTransportation(prisma, schedId) {
    return await prisma.schedTransportation.findUniqueOrThrow({
        select: {
            id: true,
            itineraryId: true,
            transportationMode: true,
            departureLocation: true,
            arrivalLocation: true,
            remark: true,
            schedTransportationIndividuals: {
                select: {
                    pid: true,
                    flgDelete: true,
                    flgReject: true,
                },
            },
        },
        where: {
            flgDelete: false,
            id: schedId,
        },
    });
}
export function getTransportationModeLabel(transportationMode, lang = 'ja') {
    if (lang === 'ja') {
        if (transportationMode === 'taxi') {
            return 'タクシー';
        }
        else if (transportationMode === 'train') {
            return '電車';
        }
        else if (transportationMode === 'bus') {
            return 'バス';
        }
        else if (transportationMode === 'other') {
            return 'その他';
        }
        else {
            return '';
        }
    }
    else {
        if (transportationMode === 'taxi') {
            return 'Taxi';
        }
        else if (transportationMode === 'train') {
            return 'Train';
        }
        else if (transportationMode === 'bus') {
            return 'Bus';
        }
        else if (transportationMode === 'other') {
            return 'Other';
        }
        else {
            return '';
        }
    }
}
/**
 * 経費宿泊費の登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param data 経費追加対象pid情報と経費情報
 * @return
 */
export async function createExpenseTransportationsWhenSchedCreated(prisma, pid, user, schedTransporatationId) {
    const sched = await getSchedTransportationForCreateExpenseTransportation(prisma, schedTransporatationId);
    const pids = [];
    for (const target of sched.schedTransportationIndividuals) {
        if (!target.flgDelete && !target.flgReject) {
            pids.push(target.pid);
        }
    }
    if (pids.length <= 0) {
        return;
    }
    const expenses = await getExpenseIds(prisma, pids, sched.itineraryId);
    for (const expense of expenses) {
        // taxiの場合は、予定のオーナーのみ交通費系項目の追加を実施する
        if (['taxi'].includes(sched.transportationMode || '') && expense.pid !== pid) {
            continue;
        }
        else {
            await createExpenseTransportation(prisma, user, {
                expenseId: expense.id,
                settlementType: '海外交通費',
                transportationType: getExpenseTransportationType(sched.transportationMode) || undefined,
                departureLocation: sched.departureLocation || undefined,
                arrivalLocation: sched.arrivalLocation || undefined,
                remark: sched.remark || undefined,
            });
        }
    }
}
function getExpenseTransportationType(target) {
    if (target === 'train') {
        return '電車（新幹線・特急を除く）';
    }
    else if (target === 'taxi') {
        return 'タクシー';
    }
    else if (target === 'bus') {
        return 'バス';
    }
    else if (target === 'other') {
        return 'その他';
    }
    else {
        return null;
    }
}
//# sourceMappingURL=transportationService.js.map