/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { filter, orderBy } from 'lodash-es';
import { Define } from '../../utils/define.js';
import { formatDate, formatDateTimeMiliSecond, isBeforeToday, isFromDatetimeBeforeToDatetime, strToBuf } from '../../utils/index.js';
import { isExistsItineraryCompanions } from '../itinerary/itineraryService.js';
import { addMinutes, subMinutes } from 'date-fns';
/**
 * 処理対象アカウントが表示可能なフライト予定一覧を返す
 * @param prisma
 * @param pid
 * @param itineraryId
 * @param flightId
 * @returns
 */
export async function getFlightSchedList(prisma, pid, itineraryId, flightId, isForeignStaff = false, isOutlookIntegration = false) {
    const where = {
        pid,
        schedFlight: { flgDelete: !isOutlookIntegration ? false : undefined },
        flgDelete: false,
        flgReject: false,
    };
    if (!flightId && !itineraryId) {
        // 旅程IDもしくはフライトIDは指定必須
        throw new Error('unreachable error.');
    }
    if (flightId) {
        where.schedFlightId = flightId;
    }
    if (itineraryId) {
        where.schedFlight = { itineraryId: itineraryId, flgDelete: !isOutlookIntegration ? false : undefined };
    }
    const schedFlightIndividuals = await prisma.schedFlightIndividual.findMany({
        where,
        select: {
            // arrgtRemarkは同行者側で手配作成者だけが見れる
            seatClass: !isForeignStaff,
            eticket: !isForeignStaff,
            seatNo: !isForeignStaff,
            remark: !isForeignStaff,
            calendarId: isOutlookIntegration,
            calendarUpdatedAt: isOutlookIntegration,
            flgArrgtTarget: true,
            flgReject: true,
            schedFlight: {
                select: {
                    id: true,
                    itineraryId: true,
                    flgArrgtFlightNumber: true,
                    arrgtDateType: true,
                    departureDateTime: true,
                    departureAirport: true,
                    departureTerminal: true,
                    departureCity: true,
                    departureTimezone: true,
                    arrivalDateTime: true,
                    arrivalAirport: true,
                    arrivalTerminal: true,
                    arrivalCity: true,
                    arrivalTimezone: true,
                    flightNumber: true,
                    airline: true,
                    remark: true,
                    ownerPid: true,
                    flgArrgt: true,
                    flgDelete: true,
                    arrgtStatus: true,
                    calendarId: isOutlookIntegration,
                    calendarUpdatedAt: isOutlookIntegration,
                    iCalUId: isOutlookIntegration,
                    updatedAt: isOutlookIntegration,
                    schedFlightIndividuals: {
                        select: {
                            user: {
                                select: {
                                    pid: true,
                                    firstNameRoma: true,
                                    lastNameRoma: true,
                                    firstNameKanji: true,
                                    lastNameKanji: true,
                                    firstNameKana: true,
                                    lastNameKana: true,
                                    email: true,
                                },
                            },
                            // eticket,seatNo,remarkはフライト手配/予定作成者も見れない
                            seatClass: true,
                            arrgtRemark: true,
                            flgArrgtTarget: true,
                            flgReject: true,
                            createdAt: true,
                            flgDelete: true, // 作成者/同行者
                        },
                    },
                    schedFlightFiles: {
                        select: {
                            id: true,
                            originalFileName: true,
                            size: true,
                            ownerPid: true,
                            path: isOutlookIntegration,
                            azAttachmentId: isOutlookIntegration,
                            azAttachmentUpdatedAt: isOutlookIntegration,
                        },
                    },
                },
            },
        },
        orderBy: {
            // 取得されるフライト一覧は「1.フライト出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            schedFlight: {
                departureDateTime: 'asc',
            },
        },
    });
    // 旅程の出張先情報の配列は、期間の昇順となるように並び替えをする
    for (const schedFlightIndividual of schedFlightIndividuals) {
        // 同行者(対象アカウントがschedFlightIndividualのownerPidと一致しない場合)や海外担当者には、手配時の情報となる同行者個人に紐つく情報も返却しない。
        if (schedFlightIndividual.schedFlight.ownerPid !== pid || isForeignStaff) {
            for (const changeSchedFlightIndividual of schedFlightIndividual.schedFlight.schedFlightIndividuals) {
                changeSchedFlightIndividual.seatClass = null;
                changeSchedFlightIndividual.arrgtRemark = null;
            }
        }
        // フライト予定(schedFlight)の中にあるschedFlightIndividualsについては、作成日時の昇順(asc)となるように、フライト予定一覧の全レコードに対して、並び替えを実施する。
        schedFlightIndividual.schedFlight.schedFlightIndividuals = orderBy(
        // フライト予定(schedFlight)の中にあるschedFlightIndividualsについては、flgDelete:trueとなっているデータはfilter実施する(flgDelete:trueは削除された同行者となる)。
        filter(schedFlightIndividual.schedFlight.schedFlightIndividuals, ['flgDelete', false]), ['createdAt'], ['asc']);
    }
    return schedFlightIndividuals;
}
/**
 * 旅程Excelダウンロード用に、対象旅程IDに紐づくフライト予定一覧を取得する
 * @param prisma
 * @param itineraryId
 * @returns
 */
export async function getFlightsForExcelDownload(prisma, itineraryId) {
    const schedFlighs = await prisma.schedFlight.findMany({
        where: {
            flgDelete: false,
            itineraryId,
        },
        select: {
            id: true,
            itineraryId: true,
            flgArrgtFlightNumber: true,
            arrgtDateType: true,
            departureDateTime: true,
            departureAirport: true,
            departureTerminal: true,
            departureCity: true,
            departureTimezone: true,
            arrivalDateTime: true,
            arrivalAirport: true,
            arrivalTerminal: true,
            arrivalCity: true,
            arrivalTimezone: true,
            flightNumber: true,
            airline: true,
            remark: true,
            ownerPid: true,
            flgArrgt: true,
            flgDelete: true,
            arrgtStatus: true,
            schedFlightIndividuals: {
                select: {
                    user: {
                        select: {
                            pid: true,
                        },
                    },
                    flgReject: true,
                    flgDelete: true,
                },
            },
        },
        orderBy: {
            // 取得されるフライト一覧は「1.フライト出発日時の昇順(asc)」となるように並び替え・一覧取得する。
            departureDateTime: 'asc',
        },
    });
    return schedFlighs;
}
/**
 * フライト予定及びフライト個人予定の登録作業。
 * フライト予定のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props FlightSchedCreateProps
 * @return
 */
export async function createSchedFlight(prisma, pid, user, props) {
    // SchedFlightテーブル作成
    const result = await prisma.schedFlight.create({
        data: {
            ownerPid: pid,
            itineraryId: props.itineraryId,
            departureDateTime: new Date(props.departureDateTime),
            departureAirport: props.departureAirport,
            departureTerminal: props.departureTerminal,
            departureCity: props.departureCity,
            departureTimezone: props.departureTimezone,
            arrivalDateTime: new Date(props.arrivalDateTime),
            arrivalAirport: props.arrivalAirport,
            arrivalTerminal: props.arrivalTerminal,
            arrivalCity: props.arrivalCity,
            arrivalTimezone: props.arrivalTimezone,
            flightNumber: props.flightNumber,
            airline: props.airline,
            remark: props.remark,
            flgArrgt: props.flgArrgt,
            updatedBy: user.pid,
            arrgtStatus: Define.SETTINGS.ARRGT_STATUS.NO_ARRGT,
        },
    });
    const schedFlightId = result.id;
    // 出張代表者をSchedFlightIndividualとして最初に登録しておく
    const targetPids = [pid];
    // 同行者がいれば、その同行者の数だけ、SchedFlightIndividualを登録する
    if (props.companions) {
        for (const companion of props.companions) {
            targetPids.push(companion.pid);
        }
    }
    for (const targetPid of targetPids) {
        await prisma.schedFlightIndividual.create({
            data: {
                schedFlightId,
                pid: targetPid,
                updatedBy: user.pid,
            },
        });
    }
    return schedFlightId;
}
/**
 * フライト予定及びフライト個人予定の更新作業。
 * フライト予定のみ更新する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedFlight SchedFlightInschedFlightIndividuals
 * @param props FlightSchedUpdateProps
 * @return
 */
export async function updateSchedFlight(prisma, pid, user, schedFlight, props) {
    let arrgtStatus = undefined;
    if (!(schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.NO_ARRGT)) {
        // flgArrgtがfalse指定の場合は、arrgtStatusを手配済(1)、true指定の場合は、arrgtStatusを確定済(2)にする
        if (props.flgArrgt) {
            arrgtStatus = Define.SETTINGS.ARRGT_STATUS.FINISHED;
        }
        else {
            arrgtStatus = Define.SETTINGS.ARRGT_STATUS.START;
        }
    }
    await prisma.schedFlight.update({
        where: { id: schedFlight.id },
        data: {
            itineraryId: props.itineraryId,
            departureDateTime: new Date(props.departureDateTime),
            departureAirport: props.departureAirport,
            departureTerminal: props.departureTerminal,
            departureCity: props.departureCity,
            departureTimezone: props.departureTimezone,
            arrivalDateTime: new Date(props.arrivalDateTime),
            arrivalAirport: props.arrivalAirport,
            arrivalTerminal: props.arrivalTerminal,
            arrivalCity: props.arrivalCity,
            arrivalTimezone: props.arrivalTimezone,
            flightNumber: props.flightNumber,
            airline: props.airline,
            remark: props.remark,
            flgArrgt: props.flgArrgt,
            arrgtStatus: arrgtStatus,
            updatedBy: user.pid,
        },
    });
    // 手配ステータス(arrgtStatus)が、手配不要(9)の場合
    if (schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.NO_ARRGT) {
        const companionPids = props.companions ? props.companions?.map((companion) => companion.pid) : [];
        companionPids.unshift(pid); //予定作成者を先頭に追加する
        const schedFlightIndividualPids = [];
        for (const schedFlightIndividual of schedFlight.schedFlightIndividuals) {
            if (!schedFlightIndividual.flgDelete) {
                if (!companionPids.includes(schedFlightIndividual.pid)) {
                    // DB取得したSchedFlightIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧に含まれていない場合は、同行者削除(flgDelete=true)を実施する。
                    await updateSchedFlightIndividual(prisma, schedFlightIndividual.pid, user, schedFlightIndividual.schedFlightId, true);
                }
                // DB取得したSchedFlightIndividualがflgDelete=falseとなっており、クライアント側から取得した同行者一覧にも含まれている場合は、何も処理しない(同行者指定済)
            }
            else if (schedFlightIndividual.flgDelete) {
                if (companionPids.includes(schedFlightIndividual.pid)) {
                    // DB取得したSchedFlightIndividualがflgDelete=trueとなっており、クライアント側から取得した同行者一覧に含まれている場合は、同行者の再指定(flgDelete=false)を実施する。
                    await updateSchedFlightIndividual(prisma, schedFlightIndividual.pid, user, schedFlightIndividual.schedFlightId, false);
                }
            }
            // DB取得したSchedFlightIndividualのpid一覧作成
            schedFlightIndividualPids.push(schedFlightIndividual.pid);
        }
        // クライアント側から取得した同行者一覧の中にあるpidが、DB取得したSchedFlightIndividual一覧の中に含まれていない場合は、同行者の新規追加実施
        for (const companionPid of companionPids) {
            if (!schedFlightIndividualPids.includes(companionPid)) {
                await prisma.schedFlightIndividual.create({
                    data: {
                        schedFlightId: schedFlight.id,
                        pid: companionPid,
                        updatedBy: user.pid,
                    },
                });
            }
        }
        // 自身の個人情報の更新:予定のarrgtStatusが9の場合は実施しない
    }
    else if (schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.FINISHED ||
        schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.START) {
        // 自身の個人情報の更新
        await updateSchedFlightIndividual(prisma, pid, user, props.id, false, props.schedFlightIndividual?.eticket, props.schedFlightIndividual?.remark, props.schedFlightIndividual?.seatNo);
        // 同行者(companions)の追加、削除はさせない。companionsが指定されていても、companionsの追加、削除は実施しない(無視する)。
    }
    else {
        throw new Error('unreachable error.');
    }
}
/**
 * フライト個人予定テーブルの更新作業。
 * フライト個人予定更新(手配の場合) / フライト予定(予定の更新) のみ更新する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedFlightId schedFlightId
 * @param flgDelete boolean
 * @param eticket boolean | undfined
 * @param remark string | undfined
 * @param seatNo string| undfined
 * @return
 */
export async function updateSchedFlightIndividual(prisma, pid, user, schedFlightId, flgDelete, eticket, remark, seatNo) {
    await prisma.schedFlightIndividual.update({
        where: { schedFlightId_pid: { schedFlightId, pid: pid } },
        data: {
            flgDelete: flgDelete,
            eticket: eticket,
            remark: remark,
            seatNo: seatNo,
            updatedBy: user.pid,
        },
    });
}
/**
 * フライト個人予定テーブルの更新作業。
 * フライト予定参加の拒否
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param schedFlightId schedFlightId
 * @param flgReject boolean
 * @return
 */
export async function rejectSchedFlightIndividual(prisma, pid, user, schedFlightId, flgReject) {
    await prisma.schedFlightIndividual.update({
        where: { schedFlightId_pid: { schedFlightId, pid: pid } },
        data: {
            flgReject,
            updatedBy: user.pid,
        },
    });
}
/**
 * フライト予定(手配は除く)の論理削除(削除フラグ更新)作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param schedFlightId フライト予定ID
 * @return
 */
export async function deleteSchedFlight(prisma, user, schedFlightId) {
    // クライアント側から送信されたidに合致するフライト予定を削除する(削除フラグをたてる)
    await prisma.schedFlight.update({
        where: { id: schedFlightId },
        data: {
            flgDelete: true,
            updatedBy: user.pid,
        },
    });
}
/**
 * フライト手配に関連する登録作業。
 * フライト手配のみ登録する場合に利用すること。
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param arrgtProps FlightArrgtCreateProps
 * @return
 */
export async function createArrgtFlight(prisma, pid, user, arrgtProps) {
    const schedFlightIds = [];
    // schedFlightの新規登録実施
    for (const props of arrgtProps.schedFlights) {
        if (props.flgArrgtFlightNumber === false) {
            if (props.departureDateTime !== undefined) {
                // departureTimezoneと同じタイムゾーンをarrivalTimezoneとする
                props.arrivalTimezone = props.departureTimezone;
                // departureDateTimeからarrivalDateTimeを予測
                props.arrivalDateTime = formatDate(addMinutes(new Date(props.departureDateTime), Define.SETTINGS.ESTIMATED_MINUTES), 'yyyy-MM-dd HH:mm:ss');
            }
            else if (props.arrivalDateTime !== undefined) {
                // arrivalTimezoneと同じタイムゾーンをdepartureTimezoneとする
                props.departureTimezone = props.arrivalTimezone;
                // arrivalDateTimeからdepartureDateTimeを予測
                props.departureDateTime = formatDate(subMinutes(new Date(props.arrivalDateTime), Define.SETTINGS.ESTIMATED_MINUTES), 'yyyy-MM-dd HH:mm:ss');
            }
        }
        if (props.departureDateTime === undefined || props.arrivalDateTime === undefined) {
            throw new Error('unreachable error.');
        }
        const resultSchedFlight = await prisma.schedFlight.create({
            data: {
                ownerPid: pid,
                itineraryId: arrgtProps.itineraryId,
                departureDateTime: new Date(props.departureDateTime),
                departureAirport: props.departureAirport,
                departureCity: props.departureCity,
                departureTimezone: props.departureTimezone,
                arrivalDateTime: new Date(props.arrivalDateTime),
                arrivalAirport: props.arrivalAirport,
                arrivalCity: props.arrivalCity,
                arrivalTimezone: props.arrivalTimezone,
                flightNumber: props.flightNumber,
                airline: props.airline,
                remark: props.remark,
                flgArrgtFlightNumber: props.flgArrgtFlightNumber,
                arrgtDateType: props.arrgtDateType,
                arrgtStatus: Define.SETTINGS.ARRGT_STATUS.START,
                updatedBy: user.pid,
            },
        });
        // フライト予定情報(arrgtFlightSchedFlight)で利用する配列
        schedFlightIds.push(resultSchedFlight.id);
        // 手配ではpropsの同行者に作成者も含まれている
        for (const companion of props.companions) {
            const flgArrgtTarget = companion.flgArrgtTarget === false ? false : true;
            await prisma.schedFlightIndividual.create({
                data: {
                    schedFlightId: resultSchedFlight.id,
                    pid: companion.pid,
                    seatClass: companion.seatClass,
                    arrgtRemark: companion.arrgtRemark,
                    flgArrgtTarget,
                    updatedBy: user.pid,
                },
            });
        }
    }
    // フライト手配の新規登録処理実施。
    const resultArrgtFlight = await prisma.arrgtFlight.create({
        data: {
            itineraryId: arrgtProps.itineraryId,
            emailTo: arrgtProps.arrgtFlight.emailTo,
            ownerPid: pid,
            flgDelete: false,
            updatedBy: user.pid,
        },
    });
    //フライト手配に紐つくフライト予定情報が、schedFlishtsで指定されたフライト予定となるように、フライト予定情報(arrgtFlightSchedFlight)を新規登録する。
    for (const schedFlightId of schedFlightIds) {
        // フライト手配の新規登録処理実施。
        await prisma.arrgtFlightSchedFlight.create({
            data: {
                arrgtFlightId: resultArrgtFlight.id,
                schedFlightId: schedFlightId,
            },
        });
    }
}
/**
 * 予定登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function createFlightSchedIfNotExists(pid, prisma, itineraryId, arrivalDateTime, departureDateTime, companions) {
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = companions?.map((item) => {
        return item.pid;
    });
    // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
    if (companionPids) {
        companionPids.push(pid);
    }
    else {
        companionPids = [pid];
    }
    // 指定されているpidが、旅程の作成者/同行者に含まれているかをチェック(W00104)
    if (companionPids) {
        const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
        if (error) {
            return error;
        }
    }
    // 予定_出発日時または予定_到着日時が現在日よりも前の日時(W00102) になっている場合は入力チェックエラーとする
    if (isBeforeToday(new Date(departureDateTime)) || isBeforeToday(new Date(arrivalDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 予定_到着日時が予定_出発日時よりも前の日時となっている(W00103) になっている場合は入力チェックエラーとする
    if (isFromDatetimeBeforeToDatetime(new Date(arrivalDateTime), new Date(departureDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    return;
}
/**
 * 手配登録用
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export function createArrgtIfNotExists(target) {
    // フライト固有のチェック↓↓↓↓↓↓
    // flgArrgtFlightNumberがtrue
    if (target.flgArrgtFlightNumber) {
        // フライト番号が入力されていない(W99002)
        if (target.flightNumber === undefined) {
            return { code: Define.ERROR_CODES.W99002, status: 400 };
        }
        // 出発時刻、到着時刻、出発タイムゾーン、到着タイムゾーンが入力されていない(W99002)
        if (target.departureDateTime === undefined ||
            target.departureTimezone === undefined ||
            target.arrivalDateTime === undefined ||
            target.arrivalTimezone === undefined) {
            return { code: Define.ERROR_CODES.W99002, status: 400 };
        }
        // 予定_出発日時または予定_到着日時が現在日よりも前の日時(W00102) になっている場合は入力チェックエラーとする
        if (isBeforeToday(new Date(target.departureDateTime)) || isBeforeToday(new Date(target.arrivalDateTime))) {
            return { code: Define.ERROR_CODES.W00102, status: 200 };
        }
        // 予定_到着日時が予定_出発日時よりも前の日時となっている(W00103) になっている場合は入力チェックエラーとする
        if (isFromDatetimeBeforeToDatetime(new Date(target.arrivalDateTime), new Date(target.departureDateTime))) {
            return { code: Define.ERROR_CODES.W00103, status: 200 };
        }
    }
    else {
        if (target.arrgtDateType === 'departure') {
            // 出発時刻とタイムゾーンの指定必須
            if (!target.departureDateTime || !target.departureTimezone) {
                return { code: Define.ERROR_CODES.W99002, status: 200 };
            }
        }
        if (target.arrgtDateType === 'arrival') {
            // 到着時刻とタイムゾーンの指定必須
            if (!target.arrivalDateTime || !target.arrivalTimezone) {
                return { code: Define.ERROR_CODES.W99002, status: 200 };
            }
        }
        // 出発空港、出発都市のいずれか一方は必須
        if (!target.departureCity && !target.departureAirport) {
            return { code: Define.ERROR_CODES.W99002, status: 200 };
        }
        // 到着空港、到着都市のいずれか一方は必須
        if (!target.arrivalCity && !target.arrivalAirport) {
            return { code: Define.ERROR_CODES.W99002, status: 200 };
        }
    }
    // フライト固有のチェック↑↑↑↑↑↑
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function updateIfExists(pid, prisma, schedFlight, //prismaから取得したschedFlightレコード
itineraryId, arrivalDateTime, departureDateTime, companions) {
    // 手配済(1)/確定済(2)/手配不要(9)と共通のチェック
    // DBからフライト予定情報が取得できない(W00109)
    if (schedFlight === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // DBから取得したitineraryIdとクライアントから取得したitineraryIdが一致しない(W00109)
    if (schedFlight.itineraryId !== itineraryId) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
    if (pid !== schedFlight.ownerPid) {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    // 出発日時、到着日時、出発タイムゾーン、到着タイムゾーンが必須入力となっていない(W99002)
    if (schedFlight.departureDateTime === undefined &&
        schedFlight.arrivalDateTime === undefined &&
        schedFlight.departureTimezone === undefined &&
        schedFlight.arrivalTimezone === undefined) {
        return { code: Define.ERROR_CODES.W99002, status: 400 };
    }
    // 出発日時または到着日時が現在日よりも前の日時(W00102)
    if (isBeforeToday(new Date(departureDateTime)) || isBeforeToday(new Date(arrivalDateTime))) {
        return { code: Define.ERROR_CODES.W00102, status: 200 };
    }
    // 到着日時が出発日時よりも前の日時となっている(W00103)
    if (isFromDatetimeBeforeToDatetime(new Date(arrivalDateTime), new Date(departureDateTime))) {
        return { code: Define.ERROR_CODES.W00103, status: 200 };
    }
    // 入力チェック内容 手配ステータス(arrgtStatus)が、手配不要(9)の場合
    if (schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.NO_ARRGT) {
        // 同行者設定されている配列の数だけ、pidを取得する
        let companionPids = companions?.map((item) => {
            return item.pid;
        });
        // 予定(手配)の新規作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
        if (companionPids) {
            companionPids.push(pid);
        }
        else {
            companionPids = [pid];
        }
        // 同行者指定のpidが、紐ついている旅程の作成者/同行者になっていない(W00104)
        if (companionPids) {
            const error = await isExistsItineraryCompanions(prisma, itineraryId, companionPids);
            if (error) {
                return error;
            }
        }
    }
    return;
}
/**
 * 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
 * @return
 */
export async function deleteIfExists(pid, schedFlight //prismaから取得したschedFlightレコード
) {
    // 入力チェック内容 全ての手配ステータス(arrgtStatus)で共通の内容
    // DBからフライト予定情報が取得できない(W00109)
    if (schedFlight === null) {
        return { code: Define.ERROR_CODES.W00109, status: 400 };
    }
    // 対象アカウント(pid)が、予定の作成者(オーナー)ではないのに、予定を更新・削除しようとしている(W00111)
    if (pid !== schedFlight.ownerPid) {
        return { code: Define.ERROR_CODES.W00111, status: 401 };
    }
    // 削除対象のフライト予定が手配済・確定済(arrgtStatus = 1 or 2)になっているのに、削除しようとしている(W00112)
    // if (
    //   schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.START ||
    //   schedFlight.arrgtStatus === Define.SETTINGS.ARRGT_STATUS.FINISHED
    // ) {
    //   return { code: Define.ERROR_CODES.W00112, status: 200 };
    // }
    return;
}
/**
 * 入力チェック用のデータ取得を実施する。individuals情報は、pid指定がない場合は削除フラグが立っているものも含んで取得する
 * @param prisma
 * @param pid
 * @param schedFlightId
 * @param pid pid指定がある場合は、対象ユーザーが予定の同行者になっているかどうかも検索条件に入れて取得する
 * @returns
 */
export async function getSchedFlightForChecker(prisma, schedFlightId, pid) {
    let schedFlight = null;
    if (pid) {
        schedFlight = await prisma.schedFlight.findFirst({
            where: { id: schedFlightId, flgDelete: false },
            include: { schedFlightIndividuals: { where: { pid: pid, flgDelete: false } } }, // // 削除フラグがたっていない物のみ取得
        });
    }
    else {
        schedFlight = await prisma.schedFlight.findFirst({
            where: { id: schedFlightId, flgDelete: false },
            include: { schedFlightIndividuals: true }, // 削除フラグの更新も行うためリレーション先の削除フラグでの絞り込みはしない。
        });
    }
    return schedFlight;
}
/**
 * こちらの関数は、outlookイベントをmctripに取り込む際に、mctripの予定を取り込まないようにする為のチェックで利用。
 * 指定したitineraryIdとpidに合致して、outlook連携している予定情報一覧を取得する。
 * 削除フラグや拒否フラグがある場合でも取得を実施する。
 * @param prisma
 * @param pid
 * @param itineraryId
 * @returns
 */
export async function getSchedFlightsReflectedInOutlook(prisma, pid, itineraryId) {
    const schedIndividuals = await prisma.schedFlightIndividual.findMany({
        where: {
            pid,
            schedFlight: { itineraryId, calendarId: { not: null } },
        },
        select: {
            flgDelete: true,
            flgReject: true,
            schedFlight: true,
        },
    });
    if (schedIndividuals.length <= 0) {
        return [];
    }
    else {
        return schedIndividuals.map((item) => {
            return item.schedFlight;
        });
    }
}
/**
 * outlook calendar連携情報を更新する。
 * 本関数は、DB更新処理などのMCTrip予定更新処理後のみ実行される予定なので、入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param user
 * @param schedId 予定のID
 * @param calendarId outlook calendar eventのid
 * @param calendarUpdatedAt outlook calendar eventの最終更新日時
 * @param iCalUId outlookイベント固有ID
 * @returns
 */
export async function updateOutlookCalendarInfo(prisma, user, schedId, calendarId, calendarUpdatedAt, iCalUId) {
    try {
        const updatedAt = calendarUpdatedAt ? new Date(formatDateTimeMiliSecond(new Date(calendarUpdatedAt))) : new Date();
        await prisma.schedFlight.update({
            where: { id: schedId },
            data: { calendarId: strToBuf(calendarId) || null, calendarUpdatedAt, iCalUId, updatedBy: user.pid, updatedAt },
        });
        return true;
    }
    catch (error) {
        return false;
    }
}
/**
 * notificationStatus情報を更新する。
 * 本関数はバッチからの実行のみを想定。入力チェック対応は、本関数内では実施していない。
 * @param prisma
 * @param schedId 予定のID
 * @param notificationStatus
 * @returns
 */
export async function updateNotificationStatus(prisma, schedId, notificationStatus) {
    if (notificationStatus !== Define.SETTINGS.NOTIFICATION_STATUS.SEND &&
        notificationStatus !== Define.SETTINGS.NOTIFICATION_STATUS.SEND_FINAL) {
        throw new Error(`invalid notificationStatus value. [notificationStatus: ${notificationStatus}]`);
    }
    await prisma.schedFlight.update({
        where: { id: schedId },
        data: { notificationStatus },
    });
}
//# sourceMappingURL=flightService.js.map