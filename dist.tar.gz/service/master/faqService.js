/**
 * FAQ一覧の返却。
 * @param prisma PrismaClient
 * @param faq FAQ情報
 * @return Driver
 */
export async function getFaqs(prisma) {
    const faqs = await prisma.faq.findMany({
        select: {
            category1: true,
            category2: true,
            category3: true,
            linkUrl: true,
        },
        orderBy: { id: 'asc' },
    });
    return faqs;
}
/**
 * FAQの登録作業。
 * @param prisma PrismaClient
 * @return Faq
 */
export async function createFaq(prisma, faq) {
    const faqCreateResult = await prisma.faq.create({
        data: faq,
    });
    return faqCreateResult;
}
/**
 * FAQマスタの全削除(物理削除)
 * @param prisma PrismaClient
 * @return
 */
export async function deleteAllFaqs(prisma) {
    try {
        await prisma.faq.deleteMany();
        return true;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        return false;
    }
}
//# sourceMappingURL=faqService.js.map