import { Define } from '../../utils/define.js';
import { isNumber, uniq } from 'lodash-es';
import { isUpdateNotFound } from '../../utils/error.js';
/**
 * 指定した都市(複数可)が都市テーブルに存在しているかどうかをチェック
 * @param prisma
 * @param cityIds 存在するかをチェックしたいcityIdsもしくは、cityIdsの配列
 */
export async function isExists(prisma, cityIds) {
    if (isNumber(cityIds)) {
        cityIds = [cityIds];
    }
    cityIds = uniq(cityIds);
    const cities = await prisma.city.findMany({
        select: { id: true },
        where: {
            id: { in: cityIds },
            flgDelete: false,
        },
    });
    if (cityIds.length === cities.length) {
        return true;
    }
    else {
        return false;
    }
}
/**
 * 指定されている都市のcityIdが存在するものかどうかチェックする。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param cityIds 存在するかをチェックしたいcityIdsもしくは、cityIdsの配列
 * @returns
 */
export async function isExistsCities(prisma, cityIds) {
    if (!(await isExists(prisma, cityIds))) {
        return { code: Define.ERROR_CODES.W00105, status: 400 };
    }
    else {
        return undefined;
    }
}
/**
 * 都市マスタのcityCodeがユニークであるかどうかをチェックする
 * @param prisma
 * @param cityCode 都市コード
 * @returns
 */
export async function isCityCodeUnique(prisma, cityCode) {
    const citis = await prisma.city.findMany({
        select: { id: true },
        where: {
            cityCode,
        },
    });
    if (citis.length > 0) {
        return false;
    }
    else {
        return true;
    }
}
/**
 * 都市マスタからキーワード指定されたものを取得する。
 * @param prisma
 * @param keywords
 * @returns
 */
export async function searchCities(prisma, keywords) {
    const where = {};
    where.AND = [{ flgDelete: false }];
    for (const keyword of keywords) {
        if (keyword) {
            where.AND.push({
                OR: [
                    { city: { contains: keyword } },
                    { cityRoma: { contains: keyword } },
                    { country: { contains: keyword } },
                    { countryRoma: { contains: keyword } },
                    { cityCode: { contains: keyword } },
                    { countryCode: { contains: keyword } },
                ],
            });
        }
    }
    return await prisma.city.findMany({
        select: {
            id: true,
            countryCode: true,
            countryRoma: true,
            country: true,
            cityCode: true,
            cityRoma: true,
            city: true,
            cityTimezone: true,
            timezoneLabel: true,
            currency: true,
            azureLocation: true,
            timeTransitions: true,
        },
        take: Define.SETTINGS.MAX_PAGE,
        where,
    });
}
/**
 * 都市マスタからキーワード指定されたものを取得する。
 * @param prisma
 * @param enCountry 国名(英語)
 * @param enCities 都市名(英語)
 * @returns
 */
export async function searchCountryOrCity(prisma, enCountry, enCities) {
    if (!enCountry) {
        return [];
    }
    const where = {};
    where.AND = [{ flgDelete: false, countryRoma: { contains: enCountry } }];
    if (enCities && enCities.length > 0) {
        const orConditions = [];
        for (const enCity of enCities) {
            if (enCity) {
                orConditions.push({ cityRoma: { contains: enCity } });
            }
        }
        where.AND.push({ OR: orConditions });
    }
    return await prisma.city.findMany({
        select: {
            id: true,
            countryCode: true,
            countryRoma: true,
            country: true,
            cityCode: true,
            cityRoma: true,
            city: true,
            cityTimezone: true,
            timezoneLabel: true,
            currency: true,
            azureLocation: true,
            timeTransitions: true,
        },
        where,
    });
}
/**
 * 都市マスタ一覧を返却する(論理削除されていないもののみ取得)
 * @param prisma
 * @param keywords
 * @returns
 */
export async function listCities(prisma) {
    return await prisma.city.findMany({
        where: { flgDelete: false },
        select: {
            id: true,
            countryCode: true,
            countryRoma: true,
            country: true,
            cityCode: true,
            cityRoma: true,
            city: true,
            cityTimezone: true,
            timezoneLabel: true,
            currency: true,
            azureLocation: true,
            timeTransitions: true,
        },
    });
}
/**
 * 都市マスタの登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props MasterCityCreateProps
 * @return
 */
export async function createCity(prisma, user, props) {
    // Cityテーブル作成
    await prisma.city.create({
        data: {
            countryCode: props.countryCode,
            countryRoma: props.countryRoma,
            country: props.country,
            cityCode: props.cityCode,
            cityRoma: props.cityRoma,
            city: props.city,
            cityTimezone: props.cityTimezone,
            timezoneLabel: props.timezoneLabel,
            currency: props.currency,
            azureLocation: props.azureLocation,
            timeTransitions: props.timeTransitions,
            updatedBy: user.pid,
        },
    });
}
/**
 * 都市マスタの更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props MasterCityUpdateProps
 * @return
 */
export async function updateCity(prisma, user, props) {
    // Cityテーブル作成
    try {
        await prisma.city.update({
            where: { id: props.id },
            data: {
                countryCode: props.countryCode,
                countryRoma: props.countryRoma,
                country: props.country,
                cityCode: props.cityCode,
                cityRoma: props.cityRoma,
                city: props.city,
                cityTimezone: props.cityTimezone,
                timezoneLabel: props.timezoneLabel,
                currency: props.currency,
                azureLocation: props.azureLocation,
                timeTransitions: props.timeTransitions,
                updatedBy: user.pid,
            },
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
/**
 * 都市マスタの削除(論理削除)
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param propsId 論理削除対照
 * @return
 */
export async function deleteCity(prisma, user, propsId) {
    // Cityテーブル論理削除
    try {
        await prisma.city.update({
            where: { id: propsId },
            data: {
                flgDelete: true,
                updatedBy: user.pid,
            },
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
/**
 * cityIdを指定して、都市マスタレコードを取得する
 * @param prisma
 * @param id
 */
export async function getCity(prisma, id) {
    if (!id) {
        throw new Error('unreachable error.');
    }
    const item = await prisma.city.findUnique({
        select: {
            id: true,
            countryCode: true,
            countryRoma: true,
            country: true,
            cityCode: true,
            cityRoma: true,
            city: true,
            cityTimezone: true,
            timezoneLabel: true,
            currency: true,
            azureLocation: true,
            timeTransitions: true,
        },
        where: {
            id,
        },
    });
    return item;
}
//# sourceMappingURL=cityService.js.map