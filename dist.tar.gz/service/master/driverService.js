import { isUpdateNotFound } from '../../utils/error.js';
import { Define } from '../../utils/define.js';
/**
 * キーワード指定されたドライバーを検索する。
 * @param prisma
 * @param keywords
 * @param exculdeIds
 * @param mcSyozokuCd
 * @returns
 */
export async function searchDrivers(prisma, keywords, exculdeIds, mcSyozokuCd) {
    const where = {};
    where.AND = [{ flgDelete: false }];
    if (exculdeIds?.length > 0) {
        where.AND.push({ id: { notIn: exculdeIds } });
    }
    if (mcSyozokuCd) {
        where.AND.push({ mcSyozokuCd });
    }
    for (const keyword of keywords) {
        if (keyword) {
            where.AND.push({
                OR: [
                    { mcSyozokuCd: { contains: keyword } },
                    { name: { contains: keyword } },
                    { tel: { contains: keyword } },
                    { email: { contains: keyword } },
                ],
            });
        }
    }
    return await _getDrivers(prisma, where, true);
}
/**
 * ドライバーマスタ一覧を返却する(論理削除されていないもののみ取得)
 * @param prisma
 * @param user
 * @param limitGroup 自分が所属するグループのみに一覧取得を限定するかどうか。1:限定する。0:限定しない
 * @param driverIds id指定によるレコード取得
 * @returns
 */
export async function listDrivers(prisma, user, limitGroup, driverIds) {
    const where = { flgDelete: false };
    // 自分が所属するグループのみに一覧取得を限定するかどうか。1:限定する。0:限定しない
    if (user && limitGroup === Define.SETTINGS.LIMIT_GROUP.ONLY_MY_SYOZOKU_GROUP) {
        where.mcSyozokuCd = user.mcSyozokuCd;
    }
    if (driverIds && driverIds.length > 0) {
        where.id = { in: driverIds };
    }
    return await _getDrivers(prisma, where);
}
/**
 * 指定した時間帯の間で、海外拠点用社有車予定でアサインされているドライバーID一覧を返却
 * @param prisma
 * @param from
 * @param to
 * @returns
 */
export async function getNotVacantDriverIds(prisma, from, to, foreignStaffSchedCompanyCarId = 0) {
    // ATTENTION: queryRow利用のサンプルとして利用。
    // SQLインジェクション対策をする為に、こちらの書き方を実施するのが良い。
    // WHERE句が動的に変わる場合は、このやり方は利用できないので、プリペアド形式を利用する必要あり。
    const list = await prisma.$queryRaw `
  select distinct d.id from foreign_staff_sched_company_cars as fsc 
  left outer join arranged_cars_for_foreign_staff as acff on fsc.id = acff.foreign_staff_sched_company_car_id
  left outer join drivers as d on d.id = acff.driver_id
  where fsc.start_date_time < ${to} and fsc.end_date_time > ${from}
  and fsc.flg_delete = false and d.id is not null
  and fsc.id != ${foreignStaffSchedCompanyCarId}
  `;
    if (list.length > 0) {
        return list.map((car) => {
            return Number(car.id);
        });
    }
    else {
        return [];
    }
}
async function _getDrivers(prisma, where, isSearch = false) {
    const dbCompanyCars = await prisma.driver.findMany({
        where,
        select: {
            id: true,
            name: true,
            tel: true,
            email: true,
            mcSyozokuCd: true,
            driverFiles: {
                select: {
                    path: true,
                    id: true,
                    originalFileName: true,
                    size: true,
                },
            },
        },
        take: isSearch ? Define.SETTINGS.MAX_PAGE : undefined,
    });
    return dbCompanyCars;
}
/**
 * ドライバーマスタの登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props MasterDriverCreateProps
 * @return Driver
 */
export async function createDriver(prisma, user, props) {
    const driverCreatedResult = await prisma.driver.create({
        data: {
            name: props.name,
            tel: props.tel,
            email: props.email,
            mcSyozokuCd: user.mcSyozokuCd,
            updatedBy: user.pid,
        },
    });
    return driverCreatedResult;
}
/**
 * ドライバーマスタの更新。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props MasterDriverUpdateProps
 * @return
 */
export async function updateDriver(prisma, user, props) {
    try {
        await prisma.driver.update({
            where: { id: props.id, mcSyozokuCd: user.mcSyozokuCd },
            data: {
                name: props.name,
                tel: props.tel,
                email: props.email,
                mcSyozokuCd: user.mcSyozokuCd,
                updatedBy: user.pid,
            },
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
/**
 * ドライバーマスタの削除(論理削除)
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param propsId 論理削除対照
 * @return
 */
export async function deleteDriver(prisma, user, propsId) {
    try {
        await prisma.driver.update({
            where: { id: propsId, mcSyozokuCd: user.mcSyozokuCd },
            data: {
                flgDelete: true,
                updatedBy: user.pid,
            },
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
//# sourceMappingURL=driverService.js.map