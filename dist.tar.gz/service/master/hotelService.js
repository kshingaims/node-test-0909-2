import { Define } from '../../utils/define.js';
import { isNumber, uniq } from 'lodash-es';
import { isUpdateNotFound } from '../../utils/error.js';
/**
 * 指定したホテル(複数可)がホテルテーブルに存在しているかどうかをチェック
 * @param prisma
 * @param hotelIds 存在するかをチェックしたいhotelIdsもしくは、hotelIdsの配列
 */
export async function isExists(prisma, hotelIds) {
    if (isNumber(hotelIds)) {
        hotelIds = [hotelIds];
    }
    hotelIds = uniq(hotelIds);
    const cities = await prisma.hotel.findMany({
        select: { id: true },
        where: {
            id: { in: hotelIds },
            flgDelete: false,
        },
    });
    if (hotelIds.length === cities.length) {
        return true;
    }
    else {
        return false;
    }
}
/**
 * 指定されているホテルのhotelIdが存在するものかどうかチェックする。
 * チェックがNGの場合はApiErrorオブジェクトを返す。
 * @param prisma
 * @param hotelIds 存在するかをチェックしたいhotelIdsもしくは、hotelIdsの配列
 * @returns
 */
export async function isExistsHotels(prisma, hotelIds) {
    if (!(await isExists(prisma, hotelIds))) {
        return { code: Define.ERROR_CODES.W00105, status: 400 };
    }
    else {
        return undefined;
    }
}
/**
 *
 * @param prisma
 * @param hotelId ホテルID
 */
export async function getHotel(prisma, hotelId) {
    const list = await listHotels(prisma, undefined, undefined, hotelId);
    if (list.length === 1) {
        return list[0];
    }
    else {
        return undefined;
    }
}
/**
 * ホテルマスタからキーワード指定されたものを取得する。
 * @param prisma
 * @param keywords
 * @returns
 */
export async function searchHotels(prisma, keywords, cityCodes) {
    const where = {};
    where.AND = [{ flgDelete: false }];
    for (const keyword of keywords) {
        if (keyword) {
            where.AND.push({
                OR: [{ name: { contains: keyword } }, { address: { contains: keyword } }],
            });
        }
    }
    if (cityCodes && cityCodes.length > 0) {
        where.AND.push({ city: { cityCode: { in: cityCodes } } });
    }
    return await _getHotels(prisma, where);
}
/**
 * ホテルマスタから指定したwhere検索条件で一覧取得実施。
 * @param prisma
 * @param keywords
 * @returns
 */
export async function _getHotels(prisma, where, isSearch = false) {
    return await prisma.hotel.findMany({
        select: {
            id: true,
            cityId: true,
            googlePlaceId: true,
            name: true,
            address: true,
            accessToOfficeMinute: true,
            meansOfAccess: true,
            checkInOut: true,
            url: true,
            tel: true,
            hotelEmail: true,
            reservationTel: true,
            reservationEmail: true,
            reservationInfo: true,
            breakfast: true,
            note: true,
            recommendation: true,
            recommendationPoint: true,
            googleRating: true,
            googleLocation: true,
            mcSyozokuCd: true,
            hotelRooms: {
                select: {
                    id: true,
                    name: true,
                    price: true,
                    currency: true,
                    note: true,
                },
                orderBy: {
                    sort: 'asc',
                },
            },
            city: {
                select: {
                    id: true,
                    countryCode: true,
                    countryRoma: true,
                    country: true,
                    cityCode: true,
                    cityRoma: true,
                    city: true,
                    cityTimezone: true,
                    timezoneLabel: true,
                    currency: true,
                    timeTransitions: true,
                },
            },
            hotelFiles: {
                select: {
                    path: true,
                    id: true,
                    originalFileName: true,
                    size: true,
                },
            },
        },
        take: isSearch ? Define.SETTINGS.MAX_PAGE : undefined,
        where,
    });
}
/**
 * ホテルマスタ一覧を返却する(論理削除されていないもののみ取得)
 * @param prisma
 * @param user
 * @param limitGroup 自分が所属するグループのみに一覧取得を限定するかどうか。1:限定する。0:限定しない
 * @param hotelId idによる単一レコード取得
 * @returns
 */
export async function listHotels(prisma, user, limitGroup, hotelId) {
    const where = { flgDelete: false };
    // 自分が所属するグループのみに一覧取得を限定するかどうか。1:限定する。0:限定しない
    if (user && limitGroup === Define.SETTINGS.LIMIT_GROUP.ONLY_MY_SYOZOKU_GROUP) {
        where.mcSyozokuCd = user.mcSyozokuCd;
    }
    if (hotelId) {
        where.id = hotelId;
    }
    return await _getHotels(prisma, where);
}
export async function getHotelsByIds(prisma, hotelIds) {
    if (!hotelIds || hotelIds.length <= 0) {
        return [];
    }
    const where = { flgDelete: false, id: { in: hotelIds } };
    return await _getHotels(prisma, where);
}
/**
 * ホテルマスタの登録作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props MasterHotelCreateProps
 * @return
 */
export async function createHotel(prisma, user, props) {
    const hotelRoomsProps = props.hotelRooms;
    // ホテルルームのソート情報を配列順でセット
    let sort = 1;
    for (const hotelRoom of hotelRoomsProps) {
        hotelRoom.sort = sort;
        sort++;
    }
    // Hotelテーブル作成
    return await prisma.hotel.create({
        data: {
            cityId: props.cityId,
            googlePlaceId: props.googlePlaceId,
            name: props.name,
            address: props.address,
            accessToOfficeMinute: props.accessToOfficeMinute,
            meansOfAccess: props.meansOfAccess,
            checkInOut: props.checkInOut,
            url: props.url,
            tel: props.tel,
            hotelEmail: props.hotelEmail,
            reservationTel: props.reservationTel,
            reservationEmail: props.reservationEmail,
            reservationInfo: props.reservationInfo,
            breakfast: props.breakfast,
            note: props.note,
            recommendation: props.recommendation,
            recommendationPoint: props.recommendationPoint,
            googleRating: props.googleRating,
            googleLocation: props.googleLocation,
            mcSyozokuCd: user.mcSyozokuCd,
            updatedBy: user.pid,
            hotelRooms: {
                createMany: {
                    data: hotelRoomsProps,
                },
            },
        },
    });
}
/**
 * ホテルマスタの更新作業。
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param props MasterHotelUpdateProps
 * @param dbTargetHotel DBから取得したホテル情報(変更前情報)
 * @return
 */
export async function updateHotel(prisma, user, props) {
    try {
        // このホテルIDに紐つくホテルマスタ一覧をDBから最新取得
        const dbHotels = await _getHotels(prisma, { flgDelete: false, mcSyozokuCd: user.mcSyozokuCd, id: props.id });
        // 指定したホテルIDに紐つくホテルマスタが存在しない
        if (!dbHotels || dbHotels.length <= 0) {
            return { code: Define.ERROR_CODES.W99002, status: 400 };
        }
        // DBホテルマスタ情報に紐つくHotelRoomId一覧を取得
        const existsHotelRoomIds = dbHotels[0].hotelRooms.map((item) => {
            return item.id;
        });
        // ホテルルームのソート情報を配列順でセット
        let sort = 1;
        for (const hotelRoom of props.hotelRooms) {
            // ホテルルームIDに合致するホテルルームがDBに無い場合は、入力チェックエラー
            if (hotelRoom.id && !existsHotelRoomIds.includes(hotelRoom.id)) {
                return { code: Define.ERROR_CODES.W99002, status: 400 };
            }
            hotelRoom.sort = sort;
            sort++;
        }
        // Hotelテーブルに紐つくHotelRoomを削除(後で新規作成をする)
        await prisma.hotelRoom.deleteMany({
            where: { hotelId: props.id },
        });
        // Hotelテーブル作成
        await prisma.hotel.update({
            where: { id: props.id, mcSyozokuCd: user.mcSyozokuCd },
            data: {
                cityId: props.cityId,
                googlePlaceId: props.googlePlaceId,
                name: props.name,
                address: props.address,
                accessToOfficeMinute: props.accessToOfficeMinute,
                meansOfAccess: props.meansOfAccess,
                checkInOut: props.checkInOut,
                url: props.url,
                tel: props.tel,
                hotelEmail: props.hotelEmail,
                reservationTel: props.reservationTel,
                reservationEmail: props.reservationEmail,
                reservationInfo: props.reservationInfo,
                breakfast: props.breakfast,
                note: props.note,
                recommendation: props.recommendation,
                recommendationPoint: props.recommendationPoint,
                googleRating: props.googleRating,
                googleLocation: props.googleLocation,
                mcSyozokuCd: user.mcSyozokuCd,
                updatedBy: user.pid,
                hotelRooms: {
                    createMany: {
                        data: props.hotelRooms,
                    },
                },
            },
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
/**
 * ホテルマスタの削除(ホテルは論理削除、ホテル部屋は物理削除)
 * @param prisma PrismaClient
 * @param user ログインしているユーザ情報
 * @param propsId 論理削除対照
 * @return
 */
export async function deleteHotel(prisma, user, propsId) {
    // Hotelテーブル論理削除
    try {
        await prisma.hotel.update({
            where: { id: propsId, mcSyozokuCd: user.mcSyozokuCd },
            data: {
                flgDelete: true,
                updatedBy: user.pid,
            },
        });
        await prisma.hotelRoom.deleteMany({
            where: { hotelId: propsId },
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const errorResult = isUpdateNotFound(error);
        if (errorResult !== undefined) {
            return errorResult;
        }
        throw error;
    }
}
//# sourceMappingURL=hotelService.js.map