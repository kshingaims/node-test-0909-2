import { Define } from '../../utils/define.js';
import { subDays } from 'date-fns';
/**
 * 直近1週間(Define.SETTINGS.FRONT_ERROR_LOG_EXISTS_CHECK_TARGET_DAYS)で保存されているエラーログをチェックし、同じエラーを検知している場合はログ保存実施しないで終了。
 * エラーログが直近1週間で一度も検知していないものである場合は、ログのDB保存実施
 * @param prisma PrismaClient
 * @param pid 処理対象となるpid
 * @param user ログインしているユーザ情報
 * @param props FrontErrorLogCreateProps
 * @return
 * */
export async function createFrontErrorLog(prisma, props) {
    // FrontErrorLogテーブル取得(直近X日間のものに絞る)
    const targetDays = Define.SETTINGS.FRONT_ERROR_LOG_EXISTS_CHECK_TARGET_DAYS;
    const currentDate = new Date();
    const sevenDaysAgo = subDays(currentDate, targetDays);
    const frontErrorLog = await prisma.frontErrorLog.findFirst({
        where: {
            actionName: props.actionName,
            createdAt: {
                gte: sevenDaysAgo, //直近X日間
            },
        },
    });
    if (!frontErrorLog) {
        // FrontErrorLogテーブル作成(ログ保存実施)
        await prisma.frontErrorLog.create({
            data: {
                actionName: props.actionName,
                detail: props.detail,
                url: props.url,
                clientInfo: props.clientInfo,
            },
        });
    }
}
/**
 * 全件取得(テスト用の関数)
 * @param prisma PrismaClient
 * @return
 * */
export async function getFrontErrorLogs(prisma) {
    return await prisma.frontErrorLog.findMany();
}
//# sourceMappingURL=frontErrorLogService.js.map