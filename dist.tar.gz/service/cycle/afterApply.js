import { Mcsso3AuthAgent, getIwInfoIntra3Cookie } from '../../service/cycle/mcsso3AuthAgent.js';
import { CycleAfterAccess } from '../../service/cycle/cycleAfterApplyAccess.js';
import { finishCycleAfterApply, pickValue } from '../../service/cycle/cycleCommon.js';
import { Define } from '../../utils/define.js';
import { cutStr, formatDate } from '../../utils/index.js';
import { getExpense } from '../../service/expense/expenseIndexService.js';
import { isCheckTransportationRequired } from '../../service/expense/expenseTransportService.js';
import { isCheckAccomodationRequired } from '../../service/expense/expenseAccommodationService.js';
import { isCheckOtherRequired } from '../../service/expense/expenseOtherService.js';
import { createZip } from '../../service/expense/makeZipOfAllExpenseAttachments.js';
const noExternalIntegration = Define.DEBUG.noExternalIntegration;
export async function applyAfterBusinessTrip(log, settings, options) {
    const result = { isSuccess: false };
    const expenseInfo = await getExpense(settings.prisma, settings.pid, settings.itineraryId, true);
    if (!expenseInfo.id) {
        return { isSuccess: false, isInvalidAccess: true, errorCode: Define.ERROR_CODES.W00109 };
    }
    // Cycle連携実施済チェック
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const itineraryObj = expenseInfo.itinerary?.itineraryIndividuals[0];
    const cycleLinkStatus = itineraryObj.itineraryIndividualStatus?.cycleLinkStatus;
    if (cycleLinkStatus == Define.SETTINGS.CYCLE_LINK_STATUS.FINISH_AFTER_APPLY) {
        // Cycle事後申請が未実施と判断されない
        return { isSuccess: false, isInvalidAccess: true };
    }
    // 経費項目の必須入力チェック
    if (expenseInfo.expenseTransportations) {
        for (const eTransportation of expenseInfo.expenseTransportations) {
            if (!isCheckTransportationRequired(eTransportation)) {
                return { isSuccess: false, isInvalidAccess: true, errorCode: Define.ERROR_CODES.W01009 };
            }
        }
    }
    if (expenseInfo.expenseAccommodations) {
        for (const eAccomodation of expenseInfo.expenseAccommodations) {
            if (!isCheckAccomodationRequired(eAccomodation)) {
                return { isSuccess: false, isInvalidAccess: true, errorCode: Define.ERROR_CODES.W01009 };
            }
        }
    }
    if (expenseInfo.expenseOthers) {
        for (const eOther of expenseInfo.expenseOthers) {
            if (!isCheckOtherRequired(eOther)) {
                return { isSuccess: false, isInvalidAccess: true, errorCode: Define.ERROR_CODES.W01009 };
            }
        }
    }
    // システム現在時刻を、DB更新時刻・添付ファイル名の日にち情報とする
    const finishCycleIntegrateDate = formatDate(new Date());
    // 経費項目に添付ファイルがある場合は、バウチャーNo(extensionB)を設定する
    const zipFilename = setExtensionB(settings.pid, finishCycleIntegrateDate, expenseInfo);
    // Cycle連携とZIPファイルの生成処理を並列で実施する
    const [cycleRes, zipRes] = await Promise.all([
        execAfterApplyIntegration(log, settings, options, expenseInfo, itineraryObj),
        createZip(log, expenseInfo, zipFilename),
    ]);
    if (!cycleRes.isSuccess) {
        return cycleRes;
    }
    else if (!zipRes.isSuccess) {
        return result;
    }
    if (zipFilename) {
        result.zipFilename = zipFilename;
    }
    // 経費精算一時保存成功 DB保存処理(noExternalIntegrationがtrueで、_noDbUpdateがtrueの時は処理しない)
    if (await finishCycleAfterApply(settings.pid, settings.user, finishCycleIntegrateDate, settings.itineraryId, settings.prisma, noExternalIntegration && settings._noDbUpdate)) {
        result.isSuccess = true;
        result.isDbUpdate = true;
    }
    else {
        result.isSuccess = true;
    }
    return result;
}
async function execAfterApplyIntegration(log, settings, options, expenseInfo, itineraryObj) {
    const result = { isSuccess: false };
    let initCookies = [];
    const isDelegator = settings.pid !== settings.user.pid;
    // Cycle事後申請連携処理(noExternalIntegrationがtrueの時は連携処理実施しない)
    if (noExternalIntegration) {
        result.isSuccess = true;
    }
    else {
        if (options.id && options.pass) {
            const mcsso3AuthAgent = new Mcsso3AuthAgent(log, options.id, options.pass);
            const authResult = await mcsso3AuthAgent.login();
            if (authResult.isLoginValidateError) {
                result.isLoginValidateError = true;
                return result;
            }
            else if (authResult.isSecretUnset) {
                result.isSecretUnset = true;
                return result;
            }
            const authInfo = mcsso3AuthAgent.getLoginResultInfo();
            log.debug('mcidm authInfo', authInfo);
            initCookies = authInfo.cookies;
        }
        else if (options.cookieIwInfoIntra3) {
            initCookies = [getIwInfoIntra3Cookie(options.cookieIwInfoIntra3)];
        }
        const cycleAccess = new CycleAfterAccess(log, settings);
        let cycleResult = await cycleAccess.prepareApplyAfter(getAfterApplyInfo, initCookies, isDelegator);
        if (!cycleResult.isSuccess) {
            if (cycleResult.isLoginValidateError) {
                result.isLoginValidateError = true;
            }
            result.errorCode = cycleResult.errorCode;
            return result;
        }
        const { kaidenFormData, nodeSetting } = cycleAccess.getAfterApplyDynamicPostData(expenseInfo);
        cycleResult = await cycleAccess.postAfterApply({
            kaidenFormData: JSON.stringify(kaidenFormData),
            nodeSetting: JSON.stringify(nodeSetting),
            title: cutStr(itineraryObj.itineraryName, 400),
        });
        if (!cycleResult.isSuccess) {
            result.errorCode = cycleResult.errorCode;
            return result;
        }
        result.isSuccess = true;
    }
    return result;
}
function getAfterApplyInfo(document) {
    const result = {
        secureTokenSeed: '',
        searchCriteriaCompany: '',
        searchCriteriaDate: '',
        userName: '',
        contactPersonName: '',
        allowanceDiv: '',
        expenseList: {
            searchType: '',
            termCd: '',
            searchCompany: '',
        },
        trvAllowance: {
            companyCurrencyCd: '',
            extensionC: '',
            transCurrencyCd: '',
            payTypeCd: '',
            payMethodCd: '',
            extensionD: '',
            extensionB: '',
            extensionI: '',
            extensionH: '',
            extensionF: '',
            dollarRate: '',
        },
        trvRouteDetail: {
            payTypeCd: '',
            payMethodCd: '',
            paymentFlag: '',
            roundTripFlag: '',
            extensionE: '',
            routeLinkFlag: '',
            commutationRoute: '',
            searchCondition: '',
            routeInfo: '',
            assessDate: '',
            tranceMeansFlag: '',
            assessFlag: '',
        },
        trvLodgeDetail: {
            extensionI: '',
            payTypeCd: '',
            payMethodCd: '',
            paymentFlag: '',
            companyCurrencyCd: '',
        },
        trvExpenseDetail: {
            extensionI: '',
            payTypeCd: '',
            payMethodCd: '',
            paymentFlag: '',
            companyCurrencyCd: '',
            payRateAmount: '',
        },
        trvSettle: {
            companyCurrencyCd: '',
            extensionA: '',
            extensionB: '',
        },
        trvGeneric: {
            extensionB: '',
            extensionC: '',
            extensionD: '',
            currencyCd: '',
        },
        applyFormUrl: '',
        applayForm: {},
        isSuccess: true,
    };
    const scriptTags = document.querySelectorAll('script');
    // scriptタグから情報の抽出
    const flags = {
        isSecureTokenSeed: false,
        isClaimExpense: false,
        isAllowanceDiv: false,
    };
    for (const scriptTag of scriptTags) {
        const src = scriptTag.getAttribute('src');
        if (!src) {
            const baseStr = scriptTag.innerHTML;
            if (!flags.isSecureTokenSeed) {
                result.secureTokenSeed = pickValue(baseStr, [
                    { keyword: 'secureTokenSeed', endKeyword: ';' },
                    { keyword: '"', endKeyword: '"' },
                ]);
                if (result.secureTokenSeed) {
                    flags.isSecureTokenSeed = true;
                }
            }
            if (!flags.isClaimExpense) {
                result.expenseList.searchType = pickValue(baseStr, [
                    { keyword: 'eventManager.registPushListener("claimPushDefoultExpensesLoad"', count: 200 },
                    { keyword: '"', endKeyword: '"' },
                ]);
                if (result.expenseList.searchType) {
                    result.expenseList.searchCompany = pickValue(baseStr, [
                        { keyword: 'criteria.searchCompany', count: 200 },
                        { keyword: '"', endKeyword: '"' },
                    ]);
                    result.expenseList.termCd = pickValue(baseStr, [
                        { keyword: 'criteria.teamCd', count: 200 },
                        { keyword: '"', endKeyword: '"' },
                    ]);
                    flags.isClaimExpense = true;
                }
            }
            if (!flags.isAllowanceDiv) {
                const allowanceDiv = pickValue(baseStr, [
                    { keyword: 'criteria.allowanceDiv', count: 100 },
                    { keyword: '"', endKeyword: '"' },
                ]);
                if (allowanceDiv) {
                    result.allowanceDiv = allowanceDiv;
                    flags.isAllowanceDiv = true;
                }
            }
        }
    }
    if (!flags.isClaimExpense || !flags.isSecureTokenSeed || !flags.isAllowanceDiv) {
        result.isSuccess = false;
    }
    // formからの情報収集
    const applyFormTag = document.querySelector('#applyForm');
    if (applyFormTag) {
        result.applyFormUrl = applyFormTag.getAttribute('action') || '';
        const applyFormInputs = document.querySelectorAll('#applyForm > input');
        for (const inputEle of applyFormInputs) {
            const key = inputEle.getAttribute('name') || '';
            const value = inputEle.getAttribute('value') || '';
            result.applayForm[key] = value;
            if (key === 'searchCriteriaCompany') {
                result.searchCriteriaCompany = value;
            }
            else if (key === 'searchCriteriaDate') {
                result.searchCriteriaDate = value;
            }
        }
    }
    // trvAllowance情報
    const trvAllowance = document.querySelector('[data-kaiden-gadget-class="trvAllowanceDetail"]');
    if (trvAllowance) {
        result.trvAllowance.companyCurrencyCd =
            trvAllowance.querySelector('#companyCurrencyCd')?.getAttribute('value') || '';
        result.trvAllowance.extensionC = trvAllowance.querySelector('#extensionC')?.getAttribute('value') || '';
        result.trvAllowance.transCurrencyCd = trvAllowance.querySelector('#transCurrencyCd')?.getAttribute('value') || '';
        result.trvAllowance.payTypeCd = trvAllowance.querySelector('#payTypeCd')?.getAttribute('value') || '';
        result.trvAllowance.payMethodCd = trvAllowance.querySelector('#payMethodCd')?.getAttribute('value') || '';
        result.trvAllowance.extensionD = trvAllowance.querySelector('#extensionD')?.getAttribute('value') || '';
        result.trvAllowance.extensionB = trvAllowance.querySelector('#extensionB')?.getAttribute('value') || '';
        result.trvAllowance.extensionI = trvAllowance.querySelector('#extensionI')?.getAttribute('value') || '';
        result.trvAllowance.extensionH = trvAllowance.querySelector('#extensionH')?.getAttribute('value') || '';
        result.trvAllowance.extensionF = trvAllowance.querySelector('#extensionF')?.getAttribute('value') || '';
        result.trvAllowance.dollarRate = trvAllowance.querySelector('#dollarRate')?.getAttribute('value') || '';
    }
    else {
        result.isSuccess = false;
    }
    // data-kaiden-gadget-class="trvRouteDetail"情報
    const trvRouteDetail = document.querySelector('[data-kaiden-gadget-class="trvRouteDetail"]');
    if (trvRouteDetail) {
        result.trvRouteDetail.payMethodCd = trvRouteDetail.querySelector('#payMethodCd')?.getAttribute('value') || '';
        result.trvRouteDetail.payTypeCd = trvRouteDetail.querySelector('#payTypeCd')?.getAttribute('value') || '';
        result.trvRouteDetail.paymentFlag = trvRouteDetail.querySelector('#paymentFlag')?.getAttribute('value') || '';
        result.trvRouteDetail.roundTripFlag = trvRouteDetail.querySelector('#roundTripFlag')?.getAttribute('value') || '';
        result.trvRouteDetail.extensionE = trvRouteDetail.querySelector('#extensionE')?.getAttribute('value') || '';
        result.trvRouteDetail.routeLinkFlag = trvRouteDetail.querySelector('#routeLinkFlag')?.getAttribute('value') || '';
        result.trvRouteDetail.commutationRoute =
            trvRouteDetail.querySelector('#commutationRoute')?.getAttribute('value') || '';
        result.trvRouteDetail.searchCondition =
            trvRouteDetail.querySelector('#searchCondition')?.getAttribute('value') || '';
        result.trvRouteDetail.routeInfo = trvRouteDetail.querySelector('#routeInfo')?.getAttribute('value') || '';
        result.trvRouteDetail.assessDate = trvRouteDetail.querySelector('#assessDate')?.getAttribute('value') || '';
        result.trvRouteDetail.tranceMeansFlag =
            trvRouteDetail.querySelector('#tranceMeansFlag')?.getAttribute('value') || '';
        result.trvRouteDetail.assessFlag = trvRouteDetail.querySelector('#assessFlag')?.getAttribute('value') || '';
    }
    else {
        result.isSuccess = false;
    }
    // data-kaiden-gadget-class="trvLodgeDetail"情報
    const trvLodgeDetail = document.querySelector('[data-kaiden-gadget-class="trvLodgeDetail"]');
    if (trvLodgeDetail) {
        result.trvLodgeDetail.extensionI = trvLodgeDetail.querySelector('#extensionI')?.getAttribute('value') || '';
        result.trvLodgeDetail.payTypeCd = trvLodgeDetail.querySelector('#payTypeCd')?.getAttribute('value') || '';
        result.trvLodgeDetail.payMethodCd = trvLodgeDetail.querySelector('#payMethodCd')?.getAttribute('value') || '';
        result.trvLodgeDetail.paymentFlag = trvLodgeDetail.querySelector('#paymentFlag')?.getAttribute('value') || '';
        result.trvLodgeDetail.companyCurrencyCd =
            trvLodgeDetail.querySelector('#companyCurrencyCd')?.getAttribute('value') || '';
    }
    else {
        result.isSuccess = false;
    }
    // data-kaiden-gadget-class="trvExpenseDetail"情報
    const trvExpenseDetail = document.querySelector('[data-kaiden-gadget-class="trvExpenseDetail"]');
    if (trvExpenseDetail) {
        result.trvExpenseDetail.extensionI = trvExpenseDetail.querySelector('#extensionI')?.getAttribute('value') || '';
        result.trvExpenseDetail.payTypeCd = trvExpenseDetail.querySelector('#payTypeCd')?.getAttribute('value') || '';
        result.trvExpenseDetail.payMethodCd = trvExpenseDetail.querySelector('#payMethodCd')?.getAttribute('value') || '';
        result.trvExpenseDetail.paymentFlag = trvExpenseDetail.querySelector('#paymentFlag')?.getAttribute('value') || '';
        result.trvExpenseDetail.companyCurrencyCd =
            trvExpenseDetail.querySelector('#companyCurrencyCd')?.getAttribute('value') || '';
        result.trvExpenseDetail.payRateAmount =
            trvExpenseDetail.querySelector('#payRateAmount')?.getAttribute('value') || '';
    }
    else {
        result.isSuccess = false;
    }
    // trvGeneric情報
    const trvGenericDiv = document.querySelector('[data-kaiden-gadget-class="trvGeneric"]');
    if (trvGenericDiv) {
        result.trvGeneric.extensionB = trvGenericDiv.querySelector('#extensionB')?.getAttribute('value') || '';
        result.trvGeneric.extensionC = trvGenericDiv.querySelector('#extensionC')?.getAttribute('value') || '';
        result.trvGeneric.extensionD = trvGenericDiv.querySelector('#extensionD')?.getAttribute('value') || '';
        result.trvGeneric.currencyCd = trvGenericDiv.querySelector('#currencyCd')?.getAttribute('value') || '';
    }
    else {
        result.isSuccess = false;
    }
    // settle情報
    const trvSettleDiv = document.querySelector('[data-kaiden-gadget-class="settle"]');
    if (trvSettleDiv) {
        result.trvSettle.companyCurrencyCd = trvSettleDiv.querySelector('#companyCurrencyCd')?.getAttribute('value') || '';
        result.trvSettle.extensionA = trvSettleDiv.querySelector('#extensionA')?.getAttribute('value') || '';
        result.trvSettle.extensionB = trvSettleDiv.querySelector('#extensionB')?.getAttribute('value') || '';
    }
    else {
        result.isSuccess = false;
    }
    // 日当情報
    const userNameTable = document.querySelector('#matterInfoTable tr:nth-child(2) > td > label');
    const userNameBase = userNameTable?.innerHTML;
    if (!userNameBase) {
        result.isSuccess = false;
    }
    else {
        const delegotorName = pickValue(userNameBase, [{ keyword: ')' }, { keyword: '(' }]);
        if (delegotorName) {
            result.userName = userNameBase.substring(0, userNameBase.indexOf(')') + 1);
            result.contactPersonName = delegotorName;
        }
        else {
            result.userName = userNameBase;
            result.userName = userNameBase;
        }
    }
    if (!result.searchCriteriaCompany || !result.searchCriteriaDate) {
        result.isSuccess = false;
    }
    return result;
}
/**
 * 経費項目に添付ファイルがある場合は、バウチャーNo(extensionB)をセットする
 * @param pid
 * @param finishCycleIntegrateDate ファイル名に含まれる日付情報
 * @param expenseInfo
 */
export function setExtensionB(pid, finishCycleIntegrateDate, expenseInfo) {
    const SEP = '_';
    let itemCount = 0;
    const dateStr = formatDate(new Date(finishCycleIntegrateDate), 'yyyyMMdd');
    const extensionBBase = pid + SEP + dateStr;
    if (expenseInfo.expenseTransportations) {
        for (const expT of expenseInfo.expenseTransportations) {
            const fileInfos = expT.expenseTransportationFiles;
            if (fileInfos && fileInfos.length > 0) {
                itemCount++;
                expT.extensionB = extensionBBase + SEP + itemCount;
            }
        }
    }
    if (expenseInfo.expenseAccommodations) {
        for (const expM of expenseInfo.expenseAccommodations) {
            const fileInfos = expM.expenseAccommodationFiles;
            if (fileInfos && fileInfos.length > 0) {
                itemCount++;
                expM.extensionB = extensionBBase + SEP + itemCount;
            }
        }
    }
    if (expenseInfo.expenseOthers) {
        for (const expO of expenseInfo.expenseOthers) {
            const fileInfos = expO.expenseOtherFiles;
            if (fileInfos && fileInfos.length > 0) {
                itemCount++;
                expO.extensionB = extensionBBase + SEP + itemCount;
            }
        }
    }
    if (itemCount > 0) {
        return `expenseAttachments_${pid}_${dateStr}.zip`;
    }
    return '';
}
//# sourceMappingURL=afterApply.js.map