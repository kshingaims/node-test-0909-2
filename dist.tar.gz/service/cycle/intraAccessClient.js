import { JSDOM } from 'jsdom';
import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { merge } from 'lodash-es';
import { Define } from '../../utils/define.js';
const httpsAgent = Define.SYSTEM.PROXY.isUseProxy
    ? new HttpsProxyAgent(`${Define.SYSTEM.PROXY.protocol}://${Define.SYSTEM.PROXY.host}:${Define.SYSTEM.PROXY.port}`)
    : undefined;
export class IntraAccessClient {
    constructor(log) {
        // 前回画面再描画さいた際のurl情報
        this.previousUrl = undefined;
        this.log = log;
        this.http = this.createAxiosInstance();
    }
    async get(url, config) {
        const baseConfig = {
            headers: {
                Referer: this.previousUrl,
                Accept: '*/*',
                'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br',
            },
        };
        if (config) {
            merge(baseConfig, config);
        }
        try {
            this.log.debug(`get request header [url:${url}]`, baseConfig);
            const res = await this.http.get(url, baseConfig);
            if (res.request) {
                res.request;
            }
            this.previousUrl = url;
            return res;
        }
        catch (error) {
            if (axios.isAxiosError(error)) {
                const axiosError = error;
                if (axiosError.response?.status !== 302) {
                    this.log.warn(`intraAccessClient get error. [url: ${url}]`, error);
                }
                return axiosError.response;
            }
            else {
                this.log.warn(`intraAccessClient get error. [url: ${url}]`, error);
            }
        }
    }
    async post(url, data, config, options) {
        const baseConfig = {
            headers: {
                Referer: this.previousUrl,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                // 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                Accept: '*/*',
                'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br',
            },
        };
        if (config) {
            merge(baseConfig, config);
        }
        try {
            if (!options?.noLog) {
                this.log.debug(`post request header [url:${url}]`, baseConfig, data);
            }
            else {
                this.log.debug(`post request header [url:${url}]`, baseConfig);
            }
            const res = await this.http.post(url, data, baseConfig);
            if (!options?.isApi) {
                this.previousUrl = url;
            }
            return res;
        }
        catch (error) {
            if (axios.isAxiosError(error)) {
                const axiosError = error;
                if (axiosError.response?.status !== 302) {
                    this.log.warn(`intraAccessClient post error. [url: ${url}]`, error);
                }
                return axiosError.response;
            }
            else {
                this.log.warn(`intraAccessClient post error. [url: ${url}]`, error);
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    async postJson(url, data, config) {
        return await this._postJsonOrXml('json', url, data, config);
    }
    async postXml(url, data, config) {
        return await this._postJsonOrXml('xml', url, data, config);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    async _postJsonOrXml(type, url, data, // eslint-disable-line @typescript-eslint/no-explicit-any
    config) {
        const baseConfig = {
            headers: {
                'Content-Type': type === 'json' ? 'application/json; charset=UTF-8' : 'application/xml',
                // 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                Accept: '*/*',
                'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
            },
        };
        if (config) {
            merge(baseConfig, config);
        }
        try {
            this.log.debug(`post request header [url:${url}]`, baseConfig, data);
            const res = await this.http.post(url, data, baseConfig);
            return res;
        }
        catch (error) {
            if (axios.isAxiosError(error)) {
                const axiosError = error;
                if (axiosError.response?.status !== 302) {
                    this.log.warn(`intraAccessClient post error. [url: ${url}]`, error);
                }
                return axiosError.response;
            }
            else {
                this.log.warn(`intraAccessClient post error. [url: ${url}]`, error);
            }
        }
    }
    convertDom(body) {
        if (!body) {
            return undefined;
        }
        const jsdom = new JSDOM(body);
        if (jsdom) {
            return jsdom.window?.document;
        }
    }
    getHeaderKeyValue(headers, key) {
        const keyValues = this.getHeaderKeyValues(headers);
        for (const keyValue of keyValues) {
            if (keyValue.key === key) {
                return keyValue.value;
            }
        }
        return '';
    }
    getHeaderKeyValues(headers) {
        const result = [];
        if (!headers) {
            return result;
        }
        const cookies = headers['set-cookie'];
        if (cookies && cookies.length > 0) {
            for (const cookie of cookies) {
                const [key, valueInfo] = cookie.split('=');
                const [value] = valueInfo.split(';');
                result.push({ key, value });
            }
        }
        return result;
    }
    createRequestHeaderCookie(cookies) {
        if (cookies && cookies.length > 0) {
            const cookieStrs = [];
            for (const cookie of cookies) {
                const cookieStr = cookie.key + '=' + cookie.value;
                cookieStrs.push(cookieStr);
            }
            return cookieStrs.join('; ');
        }
        return undefined;
    }
    createAxiosInstance(config) {
        const baseConfig = { proxy: false, httpsAgent, maxRedirects: 0 };
        if (config) {
            merge(baseConfig, config);
        }
        const instance = axios.create(baseConfig);
        this.http = instance;
        return instance;
    }
}
//# sourceMappingURL=intraAccessClient.js.map