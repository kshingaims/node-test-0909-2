import { XMLParser } from 'fast-xml-parser';
import { getItineraryIndividualList } from '../../service/itinerary/itineraryService.js';
import { Define } from '../../utils/define.js';
import { getFlightSchedList } from '../../service/flight/flightService.js';
import { getHotelSchedList } from '../../service/hotel/hotelService.js';
import { getCompanyCarSchedList } from '../../service/companyCar/companyCarService.js';
import { getTransportationSchedList } from '../../service/transportation/transportationService.js';
import { updateCycleLinkStatus } from '../itinerary/itineraryIndividualStatusService.js';
import { pickStrValue } from '../../utils/index.js';
const isCycleIntegrationTest = Define.DEBUG.isCycleIntegrationTest || false;
export const ExpTypeTransportation = {
    海外交通費: {
        expTypeCd: 'A00303001',
        expTypeName: '海外交通費',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    '国内交通費（課税）': {
        expTypeCd: 'A00303A03',
        expTypeName: '国内交通費（課税）',
        accountCd: 'A003',
        taxTypeCd: '10',
        taxRate: '0.1',
    },
};
export const ExpTypeAccomodation = {
    海外宿泊費: {
        expTypeCd: 'A00304003',
        expTypeName: '海外宿泊費',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    国内宿泊費: {
        expTypeCd: 'A00304A01',
        expTypeName: '国内宿泊費',
        accountCd: 'A003',
        taxTypeCd: '10',
        taxRate: '0.1',
    },
};
export const ExpTypeOther = {
    '海外通信費（非課税）': {
        expTypeCd: 'A00305002',
        expTypeName: '海外通信費（非課税）',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    '海外通信費（課税）': {
        expTypeCd: 'A00305A02',
        expTypeName: '海外通信費（課税）',
        accountCd: 'A003',
        taxTypeCd: '10',
        taxRate: '0.1',
    },
    '雑費（非課税）': {
        expTypeCd: 'A00305001',
        expTypeName: '雑費（非課税）',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    '雑費（課税）': {
        expTypeCd: 'A00305A03',
        expTypeName: '雑費（課税）',
        accountCd: 'A003',
        taxTypeCd: '10',
        taxRate: '0.1',
    },
    国内通信費: {
        expTypeCd: 'A00305A04',
        expTypeName: '国内通信費',
        accountCd: 'A003',
        taxTypeCd: '10',
        taxRate: '0.1',
    },
    換金手数料: {
        expTypeCd: 'A00305005',
        expTypeName: '換金手数料',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    出張中医療費: {
        expTypeCd: 'A00305006',
        expTypeName: '出張中医療費',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    旅券印紙代: {
        expTypeCd: 'A00305007',
        expTypeName: '旅券印紙代',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    海外空港税: {
        expTypeCd: 'A00305008',
        expTypeName: '海外空港税',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    ビザ代: {
        expTypeCd: 'A00305009',
        expTypeName: 'ビザ代',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    'キャンセル料（非課税）': {
        expTypeCd: 'A00305010',
        expTypeName: 'キャンセル料（非課税）',
        accountCd: 'A003',
        taxTypeCd: '9',
        taxRate: '0',
    },
    '払戻手数料（課税）': {
        expTypeCd: 'A00305A11',
        expTypeName: '払戻手数料（課税）',
        accountCd: 'A003',
        taxTypeCd: '10',
        taxRate: '0.1',
    },
};
export const TransportationType = {
    '電車（新幹線・特急を除く）': {
        extensionC: 'A00003-1',
        extensionCName: '電車（新幹線・特急を除く）',
        classItemTypeCd: 'A00022',
        extensionD: 'A00022-2',
        extensionDName: '普通車',
    },
    '電車（新幹線・特急）': {
        extensionC: 'A00003-2',
        extensionCName: '電電車（新幹線・特急）',
        classItemTypeCd: 'A00022',
        extensionD: 'A00022-2',
        extensionDName: '普通車',
    },
    タクシー: {
        extensionC: 'A00003-3',
        extensionCName: 'タクシー',
        classItemTypeCd: '',
        extensionD: '',
        extensionDName: '',
    },
    バス: {
        extensionC: 'A00003-4',
        extensionCName: 'バス',
        classItemTypeCd: '',
        extensionD: '',
        extensionDName: '',
    },
    その他: {
        extensionC: 'A00003-7',
        extensionCName: 'その他',
        classItemTypeCd: '',
        extensionD: '',
        extensionDName: '',
    },
};
const parser = new XMLParser({
    ignoreAttributes: false,
    numberParseOptions: {
        leadingZeros: false,
        hex: false,
    },
});
export function hexToAscii(str) {
    if (!str) {
        return '';
    }
    // 分割して、各セグメントを処理
    return str
        .split('\\')
        .map((part) => {
        if (part) {
            try {
                let add = '';
                if (part.length > 2) {
                    add = part.substring(2);
                    part = part.substring(0, 2);
                }
                // 16進数を整数に変換し、その整数を文字に変換
                const char = String.fromCharCode(parseInt(part, 16));
                if (char) {
                    return char + add;
                }
                else {
                    return part;
                }
            }
            catch (e) {
                // 有効な16進数でない場合は元の文字列を返す
                return part;
            }
        }
        return '';
    })
        .join('');
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
export function convertXmt2Json(response) {
    if (!response) {
        return {};
    }
    return parser.parse(response);
}
export function getApplyInitInfo(type, data) {
    if (!data) {
        return undefined;
    }
    const applyList = convertXmt2Json(data)?.object?.array?.object;
    if (!applyList || applyList.length <= 0) {
        return undefined;
    }
    for (const item of applyList) {
        const infos = item.string;
        let isTarget = false;
        for (const info of infos) {
            const name = hexToAscii(info['@_name']);
            if (name === 'listPageCol_FlowName') {
                const value = hexToAscii(info['@_value']);
                if (type === 'before' && value === '003.海外出張伺') {
                    isTarget = true;
                    break;
                }
                else if (type === 'after' && value === '004.海外出張精算依頼書') {
                    isTarget = true;
                    break;
                }
            }
        }
        if (isTarget) {
            for (const info of infos) {
                const name = hexToAscii(info['@_name']);
                if (name === 'listPageCol_Apply') {
                    const searchStr = "value='";
                    const value = hexToAscii(info['@_value']);
                    const imwFlowIdIndex1 = value.indexOf(searchStr);
                    const imwFlowIdStr = value.substring(imwFlowIdIndex1 + searchStr.length);
                    const imwFlowId = imwFlowIdStr.substring(0, imwFlowIdStr.indexOf("'"));
                    const imwNodeIdIndex1 = imwFlowIdStr.indexOf(searchStr);
                    const imwNodeIdStr = imwFlowIdStr.substring(imwNodeIdIndex1 + searchStr.length, 100);
                    const imwNodeId = imwNodeIdStr.substring(0, imwNodeIdStr.indexOf("'"));
                    return { imwFlowId, imwNodeId };
                }
            }
        }
    }
    return undefined;
}
export function pickValue(targetStr, conditions) {
    return pickStrValue(targetStr, conditions);
}
export async function getItineraryDetail(pid, itineraryId, prisma) {
    const result = { isSuccess: false };
    // Cycle連携テスト時はダミーデータを返却
    if (isCycleIntegrationTest) {
        const dummy = {
            itinerary: {
                itineraryName: '【テスト】 test バングラデシュ、ブータン出張',
                itineraryFrom: '2023-12-30',
                itineraryTo: '2024-01-01',
                itineraryIndividualStatus: {
                    cycleLinkStatus: 0,
                },
                places: [
                    {
                        city: {
                            id: 1,
                            countryCode: 'A101',
                            countryRoma: 'Bangladesh',
                            country: 'バングラデシュ',
                            cityCode: 'A101000',
                            cityRoma: '-',
                            city: '-',
                            cityTimezone: '+06:00',
                            timezoneLabel: '+06',
                            currency: 'BDT',
                            timeTransitions: [],
                        },
                        stayDurationFrom: '2023-12-30T00:00:00.000Z',
                        stayDurationTo: '2023-12-31T00:00:00.000Z',
                    },
                    {
                        city: {
                            id: 2,
                            countryCode: 'A102',
                            countryRoma: 'Bhutan',
                            country: 'ブータン',
                            cityCode: 'A102000',
                            cityRoma: '-',
                            city: '-',
                            cityTimezone: '+06:00',
                            timezoneLabel: '+06',
                            currency: 'BTN',
                            timeTransitions: [],
                        },
                        stayDurationFrom: '2023-12-31T00:00:00.000Z',
                        stayDurationTo: '2024-01-01T00:00:00.000Z',
                    },
                ],
            },
            schedFlights: [
                {
                    seatClass: null,
                    eticket: 'eticket',
                    seatNo: '61A',
                    remark: '備考',
                    schedFlight: {
                        id: 2,
                        itineraryId: 1,
                        flgArrgtFlightNumber: false,
                        arrgtDateType: 'departure',
                        departureDateTime: '2023-12-30T02:00:00.000Z',
                        departureAirport: '成田',
                        departureCity: '東京',
                        departureTimezone: '+09:00',
                        arrivalDateTime: '2023-12-30T09:29:59.000Z',
                        arrivalAirport: 'バングラデシュ',
                        arrivalCity: 'バングラデシュ',
                        arrivalTimezone: '+06:00',
                        flightNumber: 'ANA209',
                        airline: '航空会社',
                        remark: '備考',
                        ownerPid: 'MC00000001',
                        flgArrgt: false,
                    },
                },
                {
                    seatClass: null,
                    eticket: 'eticket',
                    seatNo: '25A',
                    remark: '備考',
                    schedFlight: {
                        id: 2,
                        itineraryId: 1,
                        flgArrgtFlightNumber: false,
                        arrgtDateType: 'departure',
                        departureDateTime: '2023-12-31T02:00:00.000Z',
                        departureAirport: 'バングラデシュ',
                        departureCity: 'バングラデシュ',
                        departureTimezone: '+06:00',
                        arrivalDateTime: '2023-12-31T05:00:00.000Z',
                        arrivalAirport: 'ブータン',
                        arrivalCity: 'ブータン',
                        arrivalTimezone: '+06:00',
                        flightNumber: 'BTN145',
                        airline: 'ブータン航空会社',
                        remark: '備考',
                        ownerPid: 'MC00000001',
                        flgArrgt: false,
                    },
                },
                {
                    seatClass: null,
                    eticket: 'eticket',
                    seatNo: '20A',
                    remark: '備考',
                    schedFlight: {
                        id: 2,
                        itineraryId: 1,
                        flgArrgtFlightNumber: false,
                        arrgtDateType: 'departure',
                        departureDateTime: '2024-01-01T08:00:00.000Z',
                        departureAirport: 'ブータン',
                        departureCity: 'ブータン',
                        departureTimezone: '+06:00',
                        arrivalDateTime: '2024-01-01T15:00:00.000Z',
                        arrivalAirport: '成田',
                        arrivalCity: '東京',
                        arrivalTimezone: '+09:00',
                        flightNumber: 'ANA109',
                        airline: '航空会社',
                        remark: '備考',
                        ownerPid: 'MC00000001',
                        flgArrgt: false,
                    },
                },
            ],
            schedHotels: [
                {
                    price: 11500,
                    currency: 'BDT',
                    flgSmoking: false,
                    remark: '',
                    calendarId: null,
                    calendarUpdatedAt: null,
                    flgReject: false,
                    schedHotel: {
                        id: 1,
                        itineraryId: 1,
                        name: 'Bangladesh comilla',
                        hotelId: 14,
                        cityId: 1,
                        address: 'Cinema Hall Building, R141, Comilla, バングラデシュ',
                        checkInDateTime: '2023-12-30T05:11:00.000Z',
                        checkOutDateTime: '2023-12-31T09:51:00.000Z',
                        timezone: '+06:00',
                        remark: '',
                        arrgtEmail: 'a@a.com',
                        ownerPid: 'MC00000001',
                        flgArrgt: false,
                        arrgtStatus: 1,
                        calendarId: null,
                        calendarUpdatedAt: null,
                        city: {
                            id: 1,
                            countryCode: 'A101',
                            countryRoma: 'Bangladesh',
                            country: 'バングラデシュ',
                            cityCode: 'A101000',
                        },
                    },
                },
                {
                    price: 68000,
                    currency: 'BTN',
                    flgSmoking: false,
                    remark: '',
                    calendarId: null,
                    calendarUpdatedAt: null,
                    flgReject: false,
                    schedHotel: {
                        id: 1,
                        itineraryId: 1,
                        name: 'ブータンホテル',
                        hotelId: 14,
                        cityId: 2,
                        address: 'Cinema Hall Building, R141, Comilla, ブータン',
                        checkInDateTime: '2023-12-30T05:11:00.000Z',
                        checkOutDateTime: '2023-12-31T09:51:00.000Z',
                        timezone: '+06:00',
                        remark: '',
                        arrgtEmail: 'a@a.com',
                        ownerPid: 'MC00000001',
                        flgArrgt: false,
                        arrgtStatus: 1,
                        calendarId: null,
                        calendarUpdatedAt: null,
                        city: {
                            id: 2,
                            countryCode: 'A102',
                            countryRoma: 'Bangladesh',
                            country: 'バングラデシュ',
                            cityCode: 'A102000',
                        },
                    },
                },
            ],
        };
        result.data = dummy;
        result.isSuccess = true;
        return result;
    }
    if (!itineraryId || !prisma) {
        throw new Error('programing error. itineraryId and prisma is not null.');
    }
    // 旅程情報取得
    const list = await getItineraryIndividualList(prisma, pid, [itineraryId]);
    if (!list || list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = {
        itinerary: list[0],
        schedFlights: await getFlightSchedList(prisma, pid, itineraryId, undefined, false),
        schedHotels: await getHotelSchedList(prisma, pid, itineraryId, undefined, false),
        schedCompanyCars: await getCompanyCarSchedList(prisma, pid, itineraryId, undefined, false),
        schedTransportations: await getTransportationSchedList(prisma, pid, itineraryId, undefined, false),
    };
    result.isSuccess = true;
    return result;
}
export async function finishCycleBeforeApply(pid, user, itineraryId, prisma, noDbUpdate) {
    if (noDbUpdate) {
        return true;
    }
    else {
        return await updateCycleApplyStatus(pid, user, Define.SETTINGS.CYCLE_LINK_STATUS.FINISH_BEFORE_APPLY, itineraryId, prisma);
    }
}
export async function finishCycleAfterApply(pid, user, finishCycleIntegrateDate, itineraryId, prisma, noDbUpdate) {
    if (noDbUpdate) {
        return true;
    }
    else {
        return await updateCycleApplyStatus(pid, user, Define.SETTINGS.CYCLE_LINK_STATUS.FINISH_AFTER_APPLY, itineraryId, prisma, finishCycleIntegrateDate);
    }
}
async function updateCycleApplyStatus(pid, user, cycleLinkStatus, itineraryId, prisma, finishCycleIntegrateDate) {
    try {
        if (isCycleIntegrationTest) {
            return true;
        }
        if (!itineraryId || !prisma) {
            throw new Error('programing error. itineraryId and prisma is not null.');
        }
        await updateCycleLinkStatus(prisma, pid, user, itineraryId, cycleLinkStatus, finishCycleIntegrateDate);
        return true;
    }
    catch (error) {
        return false;
    }
}
//# sourceMappingURL=cycleCommon.js.map