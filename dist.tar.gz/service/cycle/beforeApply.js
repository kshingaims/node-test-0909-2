import { Mcsso3AuthAgent, getIwInfoIntra3Cookie } from '../../service/cycle/mcsso3AuthAgent.js';
import { CycleAccess } from '../../service/cycle/cycleBeforeApplyAccess.js';
import { finishCycleBeforeApply, getItineraryDetail, pickValue, } from '../../service/cycle/cycleCommon.js';
import { Define } from '../../utils/define.js';
import { cutStr, formatUtcDateTime, getLocalDate, isFromDateBeforeToDate, joinStr, showDifferentDateMark, } from '../../utils/index.js';
import { find } from 'lodash-es';
const noExternalIntegration = Define.DEBUG.noExternalIntegration;
export async function applyBeforeBusinessTrip(log, settings, options) {
    const result = { isSuccess: false };
    let initCookies = [];
    const isDelegator = settings.pid !== settings.user.pid;
    const { isSuccess: hasData, data: itineraryInfo, error, } = await getItineraryDetail(settings.pid, settings.itineraryId, settings.prisma);
    if (!hasData) {
        return { isSuccess: false, isInvalidAccess: true, errorCode: error?.code };
    }
    // Cycle連携実施済チェック
    const itineraryObj = itineraryInfo?.itinerary;
    const cycleLinkStatus = itineraryObj?.itineraryIndividualStatus?.cycleLinkStatus;
    if (cycleLinkStatus != null && cycleLinkStatus !== 0) {
        // Cycle事前伺いが未実施と判断されない
        return { isSuccess: false, isInvalidAccess: true };
    }
    // Cycle事前申請連携処理(noExternalIntegrationがtrueの時は連携処理実施しない)
    if (!noExternalIntegration) {
        if (options.id && options.pass) {
            const mcsso3AuthAgent = new Mcsso3AuthAgent(log, options.id, options.pass);
            const authResult = await mcsso3AuthAgent.login();
            if (authResult.isLoginValidateError) {
                result.isLoginValidateError = true;
                return result;
            }
            else if (authResult.isSecretUnset) {
                result.isSecretUnset = true;
                return result;
            }
            const authInfo = mcsso3AuthAgent.getLoginResultInfo();
            log.debug('mcidm authInfo', authInfo);
            initCookies = authInfo.cookies;
        }
        else if (options.cookieIwInfoIntra3) {
            initCookies = [getIwInfoIntra3Cookie(options.cookieIwInfoIntra3)];
        }
        const cycleAccess = new CycleAccess(log, settings);
        let cycleResult = await cycleAccess.prepareApplyBefore(getBeforeApplyInfo, initCookies, isDelegator);
        if (!cycleResult.isSuccess) {
            if (cycleResult.isLoginValidateError) {
                result.isLoginValidateError = true;
            }
            result.errorCode = cycleResult.errorCode;
            return result;
        }
        const businessTrips = makeItinerayListForCycle(log, itineraryInfo);
        if (businessTrips.length <= 0) {
            result.errorCode = Define.ERROR_CODES.E01014;
            return result;
        }
        const { kaidenFormData, nodeSetting } = cycleAccess.getBeforeApplyDynamicPostData(businessTrips, itineraryObj);
        cycleResult = await cycleAccess.postBeforeApply({
            kaidenFormData: JSON.stringify(kaidenFormData),
            nodeSetting: JSON.stringify(nodeSetting),
            title: cutStr(itineraryInfo?.itinerary?.itineraryName, 400),
        });
        if (!cycleResult.isSuccess) {
            result.errorCode = cycleResult.errorCode;
            return result;
        }
    }
    // 出張事前伺い成功 DB保存処理(noExternalIntegrationがtrueで、_noDbUpdateがtrueの時は処理しない)
    if (await finishCycleBeforeApply(settings.pid, settings.user, settings.itineraryId, settings.prisma, noExternalIntegration && settings._noDbUpdate)) {
        result.isSuccess = true;
        result.isDbUpdate = true;
    }
    else {
        result.isSuccess = true;
    }
    return result;
}
/**
 * Cycle連携できるようにCycle連携用の旅程一覧に変換する
 * @param itineraryInfo MCTripから取得した旅程詳細情報
 * @returns
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
function makeItinerayListForCycle(log, itineraryInfo) {
    const result = [];
    try {
        // 出張先一覧を取得する
        const places = itineraryInfo.itinerary.places;
        // フライト一覧を取得する
        const schedFlights = itineraryInfo.schedFlights;
        // ホテル一覧を取得する
        const schedHotels = itineraryInfo.schedHotels;
        let count = 0;
        // 出張先のCycle都市コードをチェックし、該当する都市コードに対するホテルやフライトの有無をチェックして、
        // フライト・ホテルの紐付けを実施する
        for (const place of places) {
            const startDate = new Date(place.stayDurationFrom);
            const endDate = new Date(place.stayDurationTo);
            const destinationCityCd = place.city.cityCode;
            // 都市コードに該当するホテルを取得する
            const targetHotel = find(schedHotels, { schedHotel: { city: { cityCode: destinationCityCd } } });
            const targetFlights = [];
            for (const schedFlight of schedFlights) {
                const departureDateTime = schedFlight.schedFlight.departureDateTime;
                const departureTimezone = schedFlight.schedFlight.departureTimezone;
                const arrivalDateTime = schedFlight.schedFlight.arrivalDateTime;
                const arrivalTimezone = schedFlight.schedFlight.arrivalTimezone;
                let isFlightTarget = false;
                // フライトの出発時刻が、この出張先の出張期間に該当する場合は抽出対象にする
                if (isFlightWithinSpan({ date: departureDateTime, timezone: departureTimezone }, startDate, endDate)) {
                    isFlightTarget = true;
                }
                // フライトの到着時刻が、この出張先の出張期間に該当する場合は抽出対象にする
                if (isFlightWithinSpan({ date: arrivalDateTime, timezone: arrivalTimezone }, startDate, endDate)) {
                    isFlightTarget = true;
                }
                if (isFlightTarget) {
                    targetFlights.push(schedFlight);
                }
            }
            const row = {
                destinationCityCd,
                destinationCountryCd: place.city.countryCode,
                destinationCountryNm: place.city.country,
                startDate: formatUtcDateTime(startDate, 'yyyy/MM/dd'),
                endDate: formatUtcDateTime(endDate, 'yyyy/MM/dd'),
                destination: formatCycleDestination(targetHotel, targetFlights),
                transportation: formatCycleTransportation(targetFlights),
                tupleId: count.toString(),
                rowNumber: (count + 1).toString(),
            };
            result.push(row);
            count++;
        }
        return result;
    }
    catch (error) {
        log.error('mctrip data is something unexpected format. check logic.', error);
        return result;
    }
}
/**
 * 指定した日時情報がfromとtoの間にあるかどうかをチェックする
 * @param dateInfo
 * @param from
 * @param to
 * @returns
 */
export function isFlightWithinSpan(dateInfo, from, to) {
    const date = dateInfo.date;
    const timezone = dateInfo.timezone;
    // この時刻が、指定したDateの期間に含まれる場合は抽出対象にする。
    if (date && timezone) {
        const dLocalDate = new Date(formatUtcDateTime(getLocalDate(date, timezone), 'yyyy-MM-dd'));
        if (!isFromDateBeforeToDate(dLocalDate, from) && !isFromDateBeforeToDate(to, dLocalDate)) {
            return true;
        }
    }
    return false;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
function formatCycleDestination(schedHotel, schedFlights) {
    // 最大50文字
    const maxLength = 50;
    if (schedHotel) {
        return cutStr(schedHotel.schedHotel.name, maxLength);
    }
    else {
        if (schedFlights && schedFlights.length > 0) {
            return cutStr(schedFlights[0]?.schedFlight?.arrivalCity || schedFlights[0]?.schedFlight?.arrivalAirport, maxLength);
        }
    }
    return '';
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
function formatCycleTransportation(targetFlights) {
    // 最大250文字
    const maxLength = 250;
    const RETURN = '\n';
    if (targetFlights && targetFlights.length > 0) {
        const target = joinStr(targetFlights.map((targetFlight) => {
            return formatCycleTransportationPart(targetFlight);
        }), RETURN);
        return cutStr(target, maxLength);
    }
    else {
        return '';
    }
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
function formatCycleTransportationPart(schedFlight) {
    if (schedFlight) {
        const flightInfo = schedFlight?.schedFlight;
        const departureDateTime = flightInfo?.departureDateTime;
        const departureTimezone = flightInfo?.departureTimezone;
        const arrivalDateTime = flightInfo?.arrivalDateTime;
        const arrivalTimezone = flightInfo?.arrivalTimezone;
        const departureAirport = flightInfo?.departureAirport;
        const arrivalAirport = flightInfo?.arrivalAirport;
        const flightNumber = flightInfo?.flightNumber;
        let target = '';
        // 出発時刻
        const localDepartureDatetime = getLocalDate(departureDateTime, departureTimezone);
        const localArrivalDatetime = getLocalDate(arrivalDateTime, arrivalTimezone);
        // 現地日付取得
        const localDate = formatUtcDateTime(localDepartureDatetime, 'yyyy年MM月dd日');
        target = localDate;
        // 出発空港名
        target = addStrForCycleTransportationPart(target, departureAirport, { after: '/' });
        // 出発時刻
        const localDepartureTime = formatUtcDateTime(localDepartureDatetime, 'HH:mm');
        target = addStrForCycleTransportationPart(target, localDepartureTime, { after: ' →' });
        // 到着空港名
        target = addStrForCycleTransportationPart(target, arrivalAirport, { after: '/' });
        // 到着時刻
        const localArrivalTime = formatUtcDateTime(localArrivalDatetime, 'HH:mm');
        target = addStrForCycleTransportationPart(target, localArrivalTime, {
            after: showDifferentDateMark(localDepartureDatetime, localArrivalDatetime),
        });
        // フライトNo
        target = addStrForCycleTransportationPart(target, flightNumber, { before: '(', after: ')' });
        return target;
    }
    return '';
}
function addStrForCycleTransportationPart(target, addStr, options) {
    let base = target;
    if (addStr) {
        if (base) {
            base = base + ' ';
        }
        if (options?.before) {
            base = base + options?.before;
        }
        base = base + addStr;
        if (options?.after) {
            base = base + options?.after;
        }
    }
    return base;
}
function getBeforeApplyInfo(document) {
    const result = {
        secureTokenSeed: '',
        searchCriteriaCompany: '',
        searchCriteriaDate: '',
        userName: '',
        contactPersonName: '',
        extensionB: '',
        extensionC: '',
        extensionD: '',
        expenseList: {
            searchType: '',
            gadgetId: '',
            searchCompany: '',
        },
        carrierBand: {
            masterId: '',
            qualifyTypeCd: '',
            includeBlank: '',
            measureCd: '',
            searchCriteriaLocaleId: '',
            searchCriteriaDate: '',
            extensionId: '',
            searchCriteriaCompany: '',
        },
        applyFormUrl: '',
        applayForm: {},
        isSuccess: true,
    };
    const scriptTags = document.querySelectorAll('script');
    // scriptタグから情報の抽出
    const flags = {
        isSecureTokenSeed: false,
        isClaimExpense: false,
        isCarrierBand: false,
    };
    for (const scriptTag of scriptTags) {
        const src = scriptTag.getAttribute('src');
        if (!src) {
            const baseStr = scriptTag.innerHTML;
            if (!flags.isSecureTokenSeed) {
                result.secureTokenSeed = pickValue(baseStr, [
                    { keyword: 'secureTokenSeed', endKeyword: ';' },
                    { keyword: '"', endKeyword: '"' },
                ]);
                if (result.secureTokenSeed) {
                    flags.isSecureTokenSeed = true;
                }
            }
            if (!flags.isClaimExpense) {
                result.expenseList.searchType = pickValue(baseStr, [
                    { keyword: 'eventManager.registPushListener("claimPushDefoultExpensesLoad"', count: 200 },
                    { keyword: '"', endKeyword: '"' },
                ]);
                if (result.expenseList.searchType) {
                    result.expenseList.gadgetId = pickValue(baseStr, [
                        { keyword: 'registPushListener("claimPushExpensesLoad",', count: 700 },
                        { keyword: 'gadgetId', count: 100 },
                        { keyword: '"', endKeyword: '"' },
                    ]);
                    result.expenseList.searchCompany = pickValue(baseStr, [
                        { keyword: 'registPushListener("claimPushExpensesLoad",', count: 900 },
                        { keyword: 'searchCompany', count: 50 },
                        { keyword: '"', endKeyword: '"' },
                    ]);
                    flags.isClaimExpense = true;
                }
            }
            if (!flags.isCarrierBand) {
                const carierBand = pickValue(baseStr, [
                    { keyword: 'carrierBand_list' },
                    { keyword: '"kaiden/generic/master/masterSelect",', endKeyword: ')' },
                ]);
                if (carierBand) {
                    result.carrierBand = JSON.parse(carierBand.replace(/'/g, '"'));
                    flags.isCarrierBand = true;
                }
            }
        }
    }
    if (!flags.isCarrierBand || !flags.isClaimExpense || !flags.isSecureTokenSeed) {
        result.isSuccess = false;
    }
    // formからの情報収集
    const applyFormTag = document.querySelector('#applyForm');
    if (applyFormTag) {
        result.applyFormUrl = applyFormTag.getAttribute('action') || '';
        const applyFormInputs = document.querySelectorAll('#applyForm > input');
        for (const inputEle of applyFormInputs) {
            const key = inputEle.getAttribute('name') || '';
            const value = inputEle.getAttribute('value') || '';
            result.applayForm[key] = value;
            if (key === 'searchCriteriaCompany') {
                result.searchCriteriaCompany = value;
            }
            else if (key === 'searchCriteriaDate') {
                result.searchCriteriaDate = value;
            }
        }
    }
    const userNameTable = document.querySelector('#matterInfoTable tr:nth-child(2) > td > label');
    const userNameBase = userNameTable?.innerHTML;
    if (!userNameBase) {
        result.isSuccess = false;
    }
    else {
        const delegotorName = pickValue(userNameBase, [{ keyword: ')' }, { keyword: '(' }]);
        if (delegotorName) {
            result.userName = userNameBase.substring(0, userNameBase.indexOf(')') + 1);
            result.contactPersonName = delegotorName;
        }
        else {
            result.userName = userNameBase;
            result.userName = userNameBase;
        }
    }
    if (!result.searchCriteriaCompany || !result.searchCriteriaDate) {
        result.isSuccess = false;
    }
    result.extensionB = document.querySelector('#extensionB')?.getAttribute('value') || '';
    result.extensionC = document.querySelector('#extensionC')?.getAttribute('value') || '';
    result.extensionD = document.querySelector('#extensionD')?.getAttribute('value') || '';
    return result;
}
//# sourceMappingURL=beforeApply.js.map