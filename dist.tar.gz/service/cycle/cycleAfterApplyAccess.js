import { cloneDeep } from 'lodash-es';
import { IntraAccessClient } from '../../service/cycle/intraAccessClient.js';
import { Define } from '../../utils/define.js';
import { formatDate, formatUtcDateTime, round } from '../../utils/index.js';
import { ExpTypeTransportation, TransportationType, ExpTypeAccomodation, ExpTypeOther, getApplyInitInfo, pickValue, } from '../../service/cycle/cycleCommon.js';
const CHANGE_ERROR_MASSAGE = (key) => {
    return `cycleAccess site may be changed recently. [${key}]`;
};
const DOMAIN = 'https://mcsso3.mitsubishicorp.com';
const BASE_URL = DOMAIN + '/imart';
export class CycleAfterAccess {
    /**
     * コンストラクタ
     * code情報を指定している場合は、インスタンス生成時点からログイン認証済として、accessToken、csrfKeyの取得をしておく
     * @param app
     */
    constructor(log, settings) {
        // JSESSIONID_VERSIONを除いたCookie情報
        this.baseCookies = [];
        this.jSessionIdVersion = '1';
        // CycleにログインしているユーザのPID情報
        this.loginPid = '';
        // 処理対象のユーザのPID
        this.targetPid = '';
        // Cycleが保持する処理対象者のユーザ情報(APIから取得する)
        this.targetUserInfo = {};
        // Cycle マスタ 会社経費情報取得trvExpenseInfo取得(APIから取得)
        this.masterTrvExpenseInfoList = [];
        // Cycle マスタ 会社支払い情報(APIから取得)
        this.masterCompanyPaymentMethodList = [];
        // Cycle マスタ 日当情報
        this.masterTrvAllowanceList = [];
        // Cycle 経費負担先
        this.expensesBurdenDestinationList = [];
        // 基準日情報
        this.applyBaseDate = formatDate(new Date(), 'yyyy/MM/dd');
        // システム日次
        this.systemDate = formatDate(new Date(), 'yyyy/MM/dd');
        // 委任処理かどうかのフラグ
        this.isDelegator = false;
        // Cycle申請初回ページにから抽出する情報を保持
        this.firstCyclePage = {
            // CycleシステムのimwCallOriginalParamsの値
            imwCallOriginalParams: '',
            setTargetPidRequestUrl: '',
            imwCallOriginalObj: {},
            getApplyListUrl: '',
        };
        // Cycle申請初回ページにおける申請対象一覧選択で、実際に処理を実施するPIDに関する情報を保持
        this.applyListApi = {
            response: {},
            imwFlowId: '',
            imwNodeId: '',
        };
        // Cicle申請ページへの移動する際に遷移するページで取得可能な情報を保持
        this.switchContentPage = {
            applyPageUrl: '',
            postForms: [],
        };
        // Cycle事前伺い申請実施ページ初期表示で取得可能な情報を保持する
        this.applayPageInfo = {};
        this.beforeApplyPageHtml = '';
        this.postBeforeApplyAfeterPage1 = {
            nextUrl: '',
            imwProcMainFormData: {},
            imwUserParamsJSON: '',
        };
        this.postBeforeApplyTempSavePage = {
            reqParamObj: {},
            tempSaveParamObj: {},
            nextUrl: '',
        };
        this.log = log;
        this.intraClient = new IntraAccessClient(log);
        this.targetPid = settings.pid;
        this.loginPid = settings.user.pid;
    }
    /**
     * Cycle連携処理可能な段階まで、Cycleシステムの操作を実施
     */
    async prepareApplyAfter(getAfterApplyInfo, cookies, isDelegator = false) {
        let result = await this.cycleFirstpageLoad('https://mcsso3.mitsubishicorp.com/imart/im_workflow/user/apply/apply_list', cookies, isDelegator);
        if (!result.isSuccess) {
            return result;
        }
        result = await this.setTargetPid();
        if (!result.isSuccess) {
            return result;
        }
        result = await this.getApplyList('after');
        if (!result.isSuccess) {
            return result;
        }
        result = await this.swithContent();
        if (!result.isSuccess) {
            return result;
        }
        result = await this.forwardApplyPage(getAfterApplyInfo);
        if (!result.isSuccess) {
            return result;
        }
        const masterResults = await Promise.all([
            this.getMaserTrvExpenseInfo(),
            this.getMaserCompanyPaymentMethod(),
            this.getTargetUserInfo(),
            this.getExpenseBurdenDestination(),
        ]);
        for (const masterResult of masterResults) {
            if (!masterResult.isSuccess) {
                return result;
            }
        }
        const masterResults2 = await Promise.all([this.getTrvAllowanceDetails()]);
        for (const masterResult of masterResults2) {
            if (!masterResult.isSuccess) {
                return result;
            }
        }
        result.isSuccess = true;
        return result;
    }
    /**
     *  Cycle事前伺い一時作成処理
     * @param itineraryInfo
     * @returns
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    async postAfterApply(dPostData) {
        let result = await this._postAfterApply1(dPostData);
        if (!result.isSuccess) {
            return result;
        }
        result = await this.__afterApplyTempSavePage();
        if (!result.isSuccess) {
            return result;
        }
        result = await this._afterApplyTempSaveFinish(dPostData.title);
        return result;
    }
    async cycleFirstpageLoad(url, firstCookies, isDelegator = false) {
        const result = { isSuccess: false };
        try {
            // 認証時のCookie情報を初回アクセス時にセット
            const cookieHeaderStr = this.intraClient.createRequestHeaderCookie(firstCookies);
            const res = await this.intraClient.get(url, { headers: { Cookie: cookieHeaderStr } });
            if (res?.status === 302) {
                result.isLoginValidateError = true;
                return result;
            }
            // 問題なくアクセスできれば、CycleサイトのCookieが取得される
            const cookies = this.intraClient.getHeaderKeyValues(res?.headers);
            if (firstCookies) {
                for (const cookie of firstCookies) {
                    this.baseCookies.push(cookie);
                }
            }
            for (const cookie of cookies) {
                // JSESSIONID_VERSIONは通信毎に1つずつ繰り上げるので、baseCookiesにセットしない
                if (cookie.key === 'JSESSIONID_VERSION') {
                    this.jSessionIdVersion = cookie.value;
                }
                else {
                    this.baseCookies.push(cookie);
                }
            }
            const document = this.intraClient.convertDom(res?.data);
            if (!document) {
                this.log.error(CHANGE_ERROR_MASSAGE('cycleFirstpageLoad1'), res?.data);
                return result;
            }
            const data = res?.data;
            // 委任者一覧取得
            const userListEle = document.querySelectorAll('#applyUserCd > option');
            const useListMap = {};
            for (const userEle of userListEle) {
                // const selected = userEle.getAttribute('selected');
                const pid = userEle.getAttribute('value') || '';
                // if (selected === 'selected') {
                //   this.selectedPid = pid;
                // }
                useListMap[pid] = userEle.innerHTML;
            }
            // imwCallOriginalParams取得
            const imwCallOriginalParamsEle = document.querySelector('#imwCallOriginalParams');
            if (imwCallOriginalParamsEle) {
                this.firstCyclePage.imwCallOriginalParams = imwCallOriginalParamsEle.getAttribute('value') || '';
            }
            if (!this.firstCyclePage.imwCallOriginalParams) {
                result.errorCode = Define.ERROR_CODES.E01002;
                this.log.warn(url, data);
                return result;
            }
            // 処理対象実施者の設定リクエストのパス取得
            const pathSearch1Index = data.indexOf('jsAction["createImwCallOriginalParams"]');
            if (pathSearch1Index <= 0) {
                result.errorCode = Define.ERROR_CODES.E01003;
                this.log.warn(url, data);
                return result;
            }
            const pathSerchTarget1 = data.substring(pathSearch1Index, pathSearch1Index + 1000);
            const pathSearch2 = 'ImJsspRpc.sendJsspRpcRequest("';
            const pathSearch2Index = pathSerchTarget1.indexOf(pathSearch2);
            if (pathSearch2Index <= 0) {
                result.errorCode = Define.ERROR_CODES.E01003;
                this.log.warn(url, data);
                return result;
            }
            const pathSerchTarget2 = pathSerchTarget1.substring(pathSearch2Index + pathSearch2.length, pathSearch2Index + 600);
            const pathEndIndex = pathSerchTarget2.indexOf('"');
            if (pathEndIndex <= 0) {
                result.errorCode = Define.ERROR_CODES.E01003;
                this.log.warn(url, data);
                return result;
            }
            this.firstCyclePage.setTargetPidRequestUrl = pathSerchTarget2.substring(0, pathEndIndex);
            if (!this.firstCyclePage.setTargetPidRequestUrl) {
                result.errorCode = Define.ERROR_CODES.E01003;
                this.log.warn(url, data);
                return result;
            }
            // 申請対象リスト一覧取得先URLの取得
            const pathSearch3Index = data.indexOf('setApplySearchKey,');
            if (pathSearch1Index <= 0) {
                result.errorCode = Define.ERROR_CODES.E01005;
                this.log.warn(url, data);
                return result;
            }
            const pathSerchTarget3 = data.substring(pathSearch3Index, pathSearch3Index + 300);
            const pathSearch4 = '"url":"';
            const pathSearch4Index = pathSerchTarget3.indexOf(pathSearch4);
            if (pathSearch4Index <= 0) {
                result.errorCode = Define.ERROR_CODES.E01005;
                this.log.warn(url, data);
                return result;
            }
            const pathSerchTarget4 = pathSerchTarget3.substring(pathSearch4Index + pathSearch4.length, pathSearch4Index + 300);
            const pathEndIndex2 = pathSerchTarget4.indexOf('"');
            if (pathEndIndex2 <= 0) {
                result.errorCode = Define.ERROR_CODES.E01005;
                this.log.warn(url, data);
                return result;
            }
            this.firstCyclePage.getApplyListUrl = pathSerchTarget4.substring(0, pathEndIndex2);
            if (!this.firstCyclePage.getApplyListUrl) {
                result.errorCode = Define.ERROR_CODES.E01005;
                this.log.warn(url, data);
                return result;
            }
            this.firstCyclePage.getApplyListUrl = this.firstCyclePage.getApplyListUrl.replace(/\\\//g, '/');
            // 委任者が処理するのか本人が処理するかを判定してフラグ保持する
            if (isDelegator) {
                this.isDelegator = true;
            }
            // 処理可能なユーザがない場合は認証エラーにする
            if (!useListMap[this.targetPid]) {
                // 委任者であるならば、処理しようとしているPIDがCycleの委任者となっているかを確認する
                if (this.isDelegator) {
                    result.errorCode = Define.ERROR_CODES.W01001;
                }
                result.isLoginValidateError = true;
                return result;
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('cycle first page access error.', error);
            return result;
        }
    }
    async setTargetPid() {
        const result = { isSuccess: false };
        try {
            // POST送信情報
            const postJsonData = [
                '0',
                this.firstCyclePage.imwCallOriginalParams,
                { applyUserCd: this.targetPid, applyBaseDate: this.applyBaseDate, count: '100', offset: 0 },
                { listPageCol_Apply: '0', listPageCol_Flow: '0', listPageCol_FlowName: '0', listPageCol_FlowVersionNote: '0' },
            ]; // eslint-disable-line @typescript-eslint/no-explicit-any
            // 認証時のCookie情報
            const res = await this.intraClient.postJson(this.firstCyclePage.setTargetPidRequestUrl, postJsonData, {
                headers: this._getCycleRequestHeaders(),
            });
            this._setJsessionIdVersion(res);
            if (res?.data) {
                this.firstCyclePage.imwCallOriginalParams = res?.data;
                this.firstCyclePage.imwCallOriginalObj = decodeURIComponent(res?.data.replace(/\+/g, ' '));
            }
            if (!this.firstCyclePage.imwCallOriginalParams) {
                result.errorCode = Define.ERROR_CODES.E01004;
                this.log.warn(this.firstCyclePage.setTargetPidRequestUrl, res?.data);
                return result;
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('setTargetPid api access error.', error);
            return result;
        }
    }
    async getApplyList(type) {
        const result = { isSuccess: false };
        try {
            // POST送信情報
            const postXmlData = `<object><number name="\\70\\61\\67\\65" value="1"/><number name="\\72\\6f\\77\\4e\\75\\6d" value="100"/><string name="\\73\\6f\\72\\74\\49\\6e\\64\\65\\78" value="\\6c\\69\\73\\74\\50\\61\\67\\65\\43\\6f\\6c\\5f\\46\\6c\\6f\\77\\4e\\61\\6d\\65"/><string name="\\73\\6f\\72\\74\\4f\\72\\64\\65\\72" value="\\61\\73\\63"/><object name="\\65\\78\\74\\65\\6e\\73\\69\\6f\\6e"><string name="\\69\\6d\\77\\43\\61\\6c\\6c\\4f\\72\\69\\67\\69\\6e\\61\\6c\\50\\61\\72\\61\\6d\\73" value="${this.firstCyclePage.imwCallOriginalParams}"/></object></object>`;
            const baseHeader = { 'X-Jp-Co-Intra-Mart-Ajax-Request-From-Imui-Form-Util': 'false' };
            // 認証時のCookie情報
            const res = await this.intraClient.postXml(BASE_URL + '/' + this.firstCyclePage.getApplyListUrl, postXmlData, {
                headers: this._getCycleRequestHeaders(baseHeader),
            });
            this._setJsessionIdVersion(res);
            if (res?.data) {
                this.applyListApi.response = res?.data;
            }
            const applyInfo = getApplyInitInfo(type, res?.data);
            if (!applyInfo) {
                result.errorCode = Define.ERROR_CODES.E01006;
                this.log.warn(this.firstCyclePage.getApplyListUrl, res?.data);
                return result;
            }
            this.applyListApi.imwFlowId = applyInfo.imwFlowId;
            this.applyListApi.imwNodeId = applyInfo.imwNodeId;
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('getApplyList api access error.', error);
            return result;
        }
    }
    async swithContent() {
        const result = { isSuccess: false };
        try {
            // POST送信情報
            const url = 'https://mcsso3.mitsubishicorp.com/imart/im_workflow/common/switch/switch_content';
            const postData = new URLSearchParams();
            postData.append('imwUserDataId', '');
            postData.append('imwCallOriginalParams', this.firstCyclePage.imwCallOriginalParams);
            postData.append('imwNodeId', this.applyListApi.imwNodeId);
            postData.append('imwAuthUserCode', this.targetPid);
            postData.append('imwCallOriginalPagePath', 'im_workflow/user/apply/apply_list');
            postData.append('imwApplyBaseDate', this.applyBaseDate);
            postData.append('imwPageType', '0');
            postData.append('imwFlowId', this.applyListApi.imwFlowId);
            // 認証時のCookie情報
            const res = await this.intraClient.post(url, postData, { headers: this._getCycleRequestHeaders() });
            this._setJsessionIdVersion(res);
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!document) {
                result.errorCode = Define.ERROR_CODES.E01007;
                this.log.warn(url, data);
                return result;
            }
            this.switchContentPage.applyPageUrl = document.querySelector('form')?.getAttribute('action') || '';
            for (const inputEle of document.querySelectorAll('form > input')) {
                const name = inputEle.getAttribute('name');
                const value = inputEle.getAttribute('value') || '';
                this.switchContentPage.postForms.push({ name, value });
            }
            if (!this.switchContentPage.applyPageUrl) {
                result.errorCode = Define.ERROR_CODES.E01007;
                this.log.warn(url, data);
                return result;
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('swithContent access error.', error);
            return result;
        }
    }
    async forwardApplyPage(getBeforeApplyInfo) {
        const result = { isSuccess: false };
        try {
            const url = BASE_URL + '/' + this.switchContentPage.applyPageUrl;
            // POST送信情報
            const postData = new URLSearchParams();
            for (const postForm of this.switchContentPage.postForms) {
                postData.append(postForm.name, postForm.value);
            }
            // 認証時のCookie情報
            const res = await this.intraClient.post(url, postData, { headers: this._getCycleRequestHeaders() });
            this._setJsessionIdVersion(res);
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!document) {
                result.errorCode = Define.ERROR_CODES.E01007;
                this.log.warn(url, data);
                return result;
            }
            // scriptタグから情報の抽出
            const applyInfo = getBeforeApplyInfo(document);
            if (!applyInfo.isSuccess) {
                result.errorCode = Define.ERROR_CODES.E01007;
                this.log.warn(url, data);
                return result;
            }
            this.applayPageInfo = applyInfo;
            this.beforeApplyPageHtml = data;
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('forwardApplyPage access error.', error);
            return result;
        }
    }
    async getMaserTrvExpenseInfo() {
        const result = { isSuccess: false };
        const formDataBase = {
            masterId: 'item',
            itemId: '',
            includeBlank: 'false',
            searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
            itemTypeCd: 'A00007',
            extensionId: 'trvExpenseInfo',
            searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
        };
        const formData = cloneDeep(formDataBase);
        formData['json'] = JSON.stringify(formDataBase);
        formData['im_secure_token'] = this.applayPageInfo.secureTokenSeed;
        const { list } = await this._postJsonResponse('https://mcsso3.mitsubishicorp.com/imart/kaiden/generic/master/masterSelect', formData);
        if (list.length > 0) {
            this.masterTrvExpenseInfoList = list;
            result.isSuccess = true;
            return result;
        }
        else {
            result.errorCode = Define.ERROR_CODES.E01011;
            this.log.warn('/imart/kaiden/generic/master/masterSelect', formData, this.beforeApplyPageHtml);
            return result;
        }
    }
    async getMaserCompanyPaymentMethod() {
        const result = { isSuccess: false };
        const formDataBase = {
            payMethodCd: '',
            masterId: 'pay_method',
            includeBlank: 'false',
            searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
            extensionId: 'settle',
            searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
        };
        const formData = cloneDeep(formDataBase);
        formData['json'] = JSON.stringify(formDataBase);
        formData['im_secure_token'] = this.applayPageInfo.secureTokenSeed;
        const { list } = await this._postJsonResponse('https://mcsso3.mitsubishicorp.com/imart/kaiden/generic/master/masterSelect', formData);
        if (list.length > 0) {
            this.masterCompanyPaymentMethodList = list;
            result.isSuccess = true;
            return result;
        }
        else {
            result.errorCode = Define.ERROR_CODES.E01011;
            this.log.warn('/imart/kaiden/generic/master/masterSelect', formData, this.beforeApplyPageHtml);
            return result;
        }
    }
    async getTargetUserInfo() {
        const result = { isSuccess: false };
        const formData = {
            searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
            searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
            loginUserCd: this.loginPid,
            applyAuthUserCd: this.targetPid,
            im_secure_token: this.applayPageInfo.secureTokenSeed,
        };
        const { data } = await this._postJsonResponse('https://mcsso3.mitsubishicorp.com/imart/kaiden/gadget/trvBaseInfo/search', formData);
        if (data?.data && data?.data.carrierBand) {
            this.targetUserInfo = data?.data;
            result.isSuccess = true;
            return result;
        }
        else {
            result.errorCode = Define.ERROR_CODES.E01008;
            this.log.warn('/gadget/trvBaseInfo/search', formData, this.beforeApplyPageHtml);
            return result;
        }
    }
    async getExpenseBurdenDestination() {
        const result = { isSuccess: false };
        const formData = {
            searchType: this.applayPageInfo.expenseList.searchType,
            searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
            businessTravelerCd: this.targetPid,
            searchCompany: this.applayPageInfo.expenseList.searchCompany,
            termCd: this.applayPageInfo.expenseList.termCd,
            im_secure_token: this.applayPageInfo.secureTokenSeed,
        };
        const { data } = await this._postJsonResponse('https://mcsso3.mitsubishicorp.com/imart/kaiden/gadget/trvExpensesBurdenDestinationDetail/search', formData);
        if (data?.data && data?.data.length > 0) {
            this.expensesBurdenDestinationList = data?.data;
            result.isSuccess = true;
            return result;
        }
        else {
            result.errorCode = Define.ERROR_CODES.E01008;
            this.log.warn('/trvExpensesBurdenDestinationDetail/search', formData, this.beforeApplyPageHtml);
            return result;
        }
    }
    async getTrvAllowanceDetails() {
        const result = { isSuccess: false };
        const formData = {
            searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
            applyAuthUserCd: this.targetPid,
            searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
            allowanceDiv: this.applayPageInfo.allowanceDiv,
            qualifyTypeCd: this.targetUserInfo.carrierBand,
            im_secure_token: this.applayPageInfo.secureTokenSeed,
        };
        const { data } = await this._postJsonResponse('https://mcsso3.mitsubishicorp.com/imart/kaiden/gadget/trvAllowanceDetail/search', formData);
        if (data?.data && data?.data.length > 0) {
            this.masterTrvAllowanceList = data?.data;
            result.isSuccess = true;
            return result;
        }
        else {
            result.errorCode = Define.ERROR_CODES.E01008;
            this.log.warn('/kaiden/gadget/trvAllowanceDetail/search', formData, this.beforeApplyPageHtml);
            return result;
        }
    }
    async _postJsonResponse(url, formData
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    ) {
        try {
            // POST送信情報
            const postData = new URLSearchParams();
            for (const key of Object.keys(formData)) {
                postData.append(key, formData[key]);
            }
            // 認証時のCookie情報
            const res = await this.intraClient.post(url, postData, { headers: this._getCycleRequestHeaders() }, { isApi: true });
            this._setJsessionIdVersion(res);
            const resData = res?.data;
            if (resData) {
                if (resData.length > 0) {
                    return { list: resData, data: {} };
                }
                else {
                    return { list: [], data: resData };
                }
            }
            else {
                return { list: [], data: {} };
            }
        }
        catch (error) {
            this.log.error(`${url} access error.`, error);
            return { list: [], data: {} };
        }
    }
    async get() {
        const result = { isSuccess: false };
        const formData = {
            searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
            applyAuthUserCd: this.targetPid,
            searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
            allowanceDiv: this.applayPageInfo.allowanceDiv,
            qualifyTypeCd: this.targetUserInfo.carrierBand,
            im_secure_token: this.applayPageInfo.secureTokenSeed,
        };
        const { data } = await this._postJsonResponse('https://mcsso3.mitsubishicorp.com/imart/kaiden/gadget/trvAllowanceDetail/search', formData);
        if (data?.data && data?.data.length > 0) {
            this.masterTrvAllowanceList = data?.data;
            result.isSuccess = true;
            return result;
        }
        else {
            result.errorCode = Define.ERROR_CODES.E01008;
            this.log.warn('/kaiden/gadget/trvAllowanceDetail/search', formData, this.beforeApplyPageHtml);
            return result;
        }
    }
    async _postAfterApply1(dPostData) {
        const result = { isSuccess: false };
        try {
            const url = DOMAIN + this.applayPageInfo.applyFormUrl;
            // POST送信情報
            const postData = new URLSearchParams();
            for (const name of Object.keys(this.applayPageInfo.applayForm)) {
                if (name === 'imwPageType') {
                    // 下書き保存は1にする?
                    postData.append(name, '1');
                }
                else if (name !== 'kaidenFormData' && name !== 'imwNodeSetting') {
                    postData.append(name, this.applayPageInfo.applayForm[name]);
                }
            }
            postData.append('kaidenFormData', dPostData.kaidenFormData);
            postData.append('imwNodeSetting', dPostData.nodeSetting);
            // 認証時のCookie情報
            const res = await this.intraClient.post(url, postData, { headers: this._getCycleRequestHeaders() });
            this._setJsessionIdVersion(res);
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!document) {
                result.errorCode = Define.ERROR_CODES.E01015;
                this.log.warn(url, dPostData, this.beforeApplyPageHtml);
                return result;
            }
            this.postBeforeApplyAfeterPage1.nextUrl =
                document.querySelector('form[name=imwProcMainForm]')?.getAttribute('action') || '';
            for (const ele of document.querySelectorAll('form[name=imwProcMainForm] > input')) {
                const name = ele.getAttribute('name');
                const value = ele.getAttribute('value') || '';
                if (name) {
                    this.postBeforeApplyAfeterPage1.imwProcMainFormData[name] = value;
                }
            }
            for (const ele of document.querySelectorAll('form[name=imwProcTopDataForm] > input')) {
                const name = ele.getAttribute('name');
                const value = ele.getAttribute('value') || '';
                if (name === 'imwUserParamsJSON') {
                    this.postBeforeApplyAfeterPage1.imwUserParamsJSON = value;
                }
            }
            if (Object.keys(this.postBeforeApplyAfeterPage1.imwProcMainFormData).length <= 0 ||
                !this.postBeforeApplyAfeterPage1.imwUserParamsJSON) {
                result.errorCode = Define.ERROR_CODES.E01015;
                this.log.warn(url, data);
                this.log.warn(this.beforeApplyPageHtml);
                return result;
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('_postAfterApply1 access error.', error);
            return result;
        }
    }
    async __afterApplyTempSavePage() {
        const result = { isSuccess: false };
        try {
            const url = BASE_URL + '/' + this.postBeforeApplyAfeterPage1.nextUrl;
            // POST送信情報
            const postData = new URLSearchParams();
            for (const name of Object.keys(this.postBeforeApplyAfeterPage1.imwProcMainFormData)) {
                postData.append(name, this.postBeforeApplyAfeterPage1.imwProcMainFormData[name]);
            }
            // 認証時のCookie情報
            const res = await this.intraClient.post(url, postData, { headers: this._getCycleRequestHeaders() });
            this._setJsessionIdVersion(res);
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!document) {
                result.errorCode = Define.ERROR_CODES.E01016;
                this.log.warn(url, data);
                this.log.warn(this.beforeApplyPageHtml);
                return result;
            }
            const reqParamObjEle = document.querySelector('form[name=form4JSON] > input[name=reqParamObj]');
            if (!reqParamObjEle) {
                result.errorCode = Define.ERROR_CODES.E01016;
                this.log.warn(url, data);
                this.log.warn(this.beforeApplyPageHtml);
                return result;
            }
            else {
                this.postBeforeApplyTempSavePage.reqParamObj = JSON.parse(reqParamObjEle.getAttribute('value') || '');
            }
            const tempSaveParamObjEle = document.querySelector('form[name=form4JSON] > input[name=tempSaveParamObj]');
            if (!tempSaveParamObjEle) {
                result.errorCode = Define.ERROR_CODES.E01016;
                this.log.warn(url, data);
                this.log.warn(this.beforeApplyPageHtml);
                return result;
            }
            else {
                this.postBeforeApplyTempSavePage.tempSaveParamObj = JSON.parse(tempSaveParamObjEle.getAttribute('value') || '');
            }
            const nextUrl = pickValue(data, [
                { keyword: 'jsActionTempSave["temporarySave"]', count: 1000 },
                { keyword: 'ImJsspRpc.sendJsspRpcRequest' },
                { keyword: '"', endKeyword: '"' },
            ]);
            if (!nextUrl) {
                result.errorCode = Define.ERROR_CODES.E01016;
                this.log.warn(url, data);
                this.log.warn(this.beforeApplyPageHtml);
                return result;
            }
            else {
                this.postBeforeApplyTempSavePage.nextUrl = nextUrl;
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            this.log.error('__afterApplyTempSavePage access error.', error);
            return result;
        }
    }
    async _afterApplyTempSaveFinish(title) {
        const result = { isSuccess: false };
        try {
            const url = this.postBeforeApplyTempSavePage.nextUrl;
            const tempSaveParams = this.postBeforeApplyTempSavePage.tempSaveParamObj;
            tempSaveParams['matterName'] = title;
            tempSaveParams['processComment'] = Define.MESSAGES.CYCLE_BEFORE_APPLY_COMMENT;
            // POST送信情報
            // POST送信情報
            const postJsonData = [
                {
                    tempSaveParams,
                    userParams: JSON.parse(this.postBeforeApplyAfeterPage1.imwUserParamsJSON),
                    imwUserDataId: this.postBeforeApplyTempSavePage.reqParamObj.imwUserDataId,
                },
            ];
            // 認証時のCookie情報
            const res = await this.intraClient.postJson(url, postJsonData, { headers: this._getCycleRequestHeaders() });
            this._setJsessionIdVersion(res);
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!document) {
                result.errorCode = Define.ERROR_CODES.E01017;
                this.log.warn(url, postJsonData, data);
                return result;
            }
            this.log.debug('temporary save page', data);
            if (data.resultFlag && !data.errorMessage) {
                result.isSuccess = true;
            }
            else if (data.errorMessage) {
                this.log.warn(`before apply temp save error. [errorMessage: ${data.errorMessage}]`, postJsonData);
            }
            return result;
        }
        catch (error) {
            this.log.error('_afterApplyTempSaveFinish access error.', error);
            return result;
        }
    }
    getAfterApplyDynamicPostData(expenseInfoForCycle) {
        const expensesBurdenDestinationInfo = this.makeExpensesBurdenDestinationDetails();
        const expensesBurdenDestinationDetailTotal = expensesBurdenDestinationInfo.total;
        const expensesBurdenDestinationDetails = expensesBurdenDestinationInfo.list;
        const trvAllowanceDetails = this.makeTrvAllowanceDetails();
        const kaidenFormData = {
            system_v01_0: {
                systemBlock: {},
            },
            trvCommon_v01_0: {
                trvCommon: { zeroAdjustFlag: '' },
            },
            trvBaseInfo_v01_0: {
                trvBaseInfo: {
                    departmentCd: this.targetUserInfo.departmentCd,
                    departmentSetCd: this.applayPageInfo.searchCriteriaCompany,
                    searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
                    imwApplyBaseDate: this.applayPageInfo.applayForm['imwApplyBaseDate'],
                    imwUserCode: this.targetUserInfo.contactPersonCd,
                    issuedDepartmentCd: this.targetUserInfo.issuedDepartmentCd,
                    issuedDepartmentNm: this.targetUserInfo.issuedDepartmentNm,
                    businessTravelerCd: this.targetUserInfo.businessTravelerCd,
                    businessTravelerName: this.targetUserInfo.businessTravelerCd,
                    userName: this.applayPageInfo.userName,
                    hidUserName: this.applayPageInfo.userName,
                    carrierBand: this.targetUserInfo.carrierBand,
                    carrierBandName: '',
                    contactPersonCd: this.targetUserInfo.contactPersonCd,
                    contactPersonName: this.applayPageInfo.contactPersonName,
                    telNum: '',
                    mailAddress: this.targetUserInfo.mailAddress,
                },
            },
            trvExpenseInfo_v05_0: {
                trvExpenseInfo: {
                    summary1: 'A00019-B',
                    summary2: '',
                    summary2ViewName: '',
                    applyType: '',
                    releaseFlag: '',
                    extensionD1: '',
                    extensionE1: '',
                    startDate1: '',
                    endDate1: '',
                    summary41: '',
                    summary51: '',
                    imwUserDataId: this.applayPageInfo.applayForm['imwUserDataId'],
                    imwSystemMatterId: this.applayPageInfo.applayForm['imwSystemMatterId'] || '',
                    imwApplyBaseDate: this.applayPageInfo.applayForm['imwApplyBaseDate'],
                    searchCriteriaCompany: this.applayPageInfo.applayForm['searchCriteriaCompany'],
                    applyAuthUserCd: this.targetUserInfo.businessTravelerCd,
                    businessSystemMatterId: '',
                    businessUserDataId: '',
                    adjustClass: '',
                    matterNumber: '',
                    startDate: '',
                    startDay: '',
                    endDate: '',
                    endDay: '',
                    extensionF: this.masterTrvExpenseInfoList[0].key,
                    extensionFViewName: this.masterTrvExpenseInfoList[0].itemName,
                    extensionD: '',
                    extensionE: '',
                    extensionC: '',
                    summary4: '',
                    summary5: '',
                    summary3: 'A00005-1',
                    summary3ViewName: '公開',
                    extensionB: 'A00010-2',
                    extensionBViewName: '計上', // 計上 or 非計上
                },
            },
            trvAllowanceDetail_v07_0: {
                allowanceDetailTotal: {
                    total: '0',
                },
                trvAllowanceDetail: trvAllowanceDetails,
            },
            system_v01_1: {
                systemBlock: {},
            },
            trvRouteDetail_v03_0: {
                trvRouteDetailHeader: {},
                caution: {},
                routeDetailTable: this.makeRouteDetailTable(expenseInfoForCycle),
            },
            trvLodgeDetail_v03_0: {
                trvLodgeDetail: this.makeLodgeDetail(expenseInfoForCycle),
            },
            trvExpenseDetail_v03_0: {
                trvExpenseDetail: this.makeTrvExpenseDetail(expenseInfoForCycle),
            },
            trvOverview_v01_0: {
                trvOverviewTotal: {
                    totalAmount: '0',
                },
                trvOverview: [],
            },
            settle_v02_0: {
                settle: {
                    imwApplyBaseDate: this.applayPageInfo.applayForm['imwApplyBaseDate'],
                    searchCriteriaCompany: this.applayPageInfo.applayForm['searchCriteriaCompany'],
                    payMethodCd: this.masterCompanyPaymentMethodList[0].payMethodCd,
                    payMethodName: this.masterCompanyPaymentMethodList[0].payMethodName,
                    expenseAmount: '0',
                    temporaryPayAmount: '0',
                    companyPayAmount: '0',
                    advanceAmount: '0',
                    adjustmentAmount: '0',
                    companyCurrencyCd: this.applayPageInfo.trvSettle.companyCurrencyCd,
                    extensionA: this.applayPageInfo.trvSettle.extensionA,
                    extensionB: this.applayPageInfo.trvSettle.extensionB,
                },
                amount: {
                    expenseAmount: '0',
                    temporaryPayAmount: '0',
                    adjustmentAmount: '0',
                    companyPayAmount: '0',
                },
            },
            trvExpensesBurdenDestination_v02_0: {
                expensesBurdenDestinationDetailTotal: {
                    total: expensesBurdenDestinationDetailTotal.toString(),
                    totalAmount: '0',
                },
                expensesBurdenDestinationDetail: expensesBurdenDestinationDetails,
            },
            trvGeneric_v01_0: {
                generic: {
                    note: '',
                    imwApplyBaseDate: this.applayPageInfo.applayForm['imwApplyBaseDate'],
                    currencyCd: this.applayPageInfo.trvGeneric.currencyCd,
                    amount: '0',
                    extensionA: this.applayPageInfo.applayForm['imwApplyBaseDate'],
                    extensionB: this.applayPageInfo.trvGeneric.extensionB,
                    extensionC: this.applayPageInfo.trvGeneric.extensionC,
                    extensionD: this.applayPageInfo.trvGeneric.extensionD,
                },
            },
            trvTurningRoute_v01_0: {
                trvTurningRoute: {
                    hlcRouteFlg: '0',
                    departmentCd: this.targetUserInfo.departmentCd,
                    searchTable: 'trv_m_approver_group_member',
                    responsiblePersonCd: '',
                    responsiblePersonName: '',
                },
            },
            trvCheckList_v02_0: {
                trvCheckList: [
                    {
                        checkFlag: '0',
                        rowNumber: '1',
                        tupleId: '0',
                    },
                    {
                        checkFlag: '0',
                        rowNumber: '2',
                        tupleId: '1',
                    },
                    {
                        checkFlag: '0',
                        rowNumber: '3',
                        tupleId: '2',
                    },
                    {
                        checkFlag: '0',
                        rowNumber: '4',
                        tupleId: '3',
                    },
                    {
                        checkFlag: '0',
                        rowNumber: '5',
                        tupleId: '4',
                    },
                ],
            },
            trvHistory_v01_0: {
                trvHistory: {},
            },
            routeSearch_v01_0: {
                routeSearchArea: {
                    date: '',
                    from: '',
                    to01: '',
                    to02: '',
                    to03: '',
                    to: '',
                    companyCd: '',
                    userCd: '',
                    mode: '',
                    connectId: '',
                    callGadgetId: '',
                    action: '',
                },
            },
        };
        const nodeSetting = {
            DCNodeSetting: {
                approve_02: {
                    // 設定対象のノードIDをプロパティ名とする
                    displayFlag: false,
                    processTargetConfigs: [
                        // 任意の処理対象者を指定
                        {
                            // ユーザ指定
                            extensionPointId: 'jp.co.intra_mart.workflow.plugin.authority.node.dynamic',
                            pluginId: 'jp.co.intra_mart.workflow.plugin.authority.node.dynamic.user',
                            parameter: '',
                        },
                    ],
                },
            },
        };
        return { kaidenFormData, nodeSetting };
    }
    _getCycleRequestHeaders(base) {
        const cookies = cloneDeep(this.baseCookies);
        cookies.push({ key: 'JSESSIONID_VERSION', value: this.jSessionIdVersion });
        if (base) {
            base['Cookie'] = this.intraClient.createRequestHeaderCookie(cookies);
            return base;
        }
        return { Cookie: this.intraClient.createRequestHeaderCookie(cookies) };
    }
    _setJsessionIdVersion(res) {
        const value = this.intraClient.getHeaderKeyValue(res?.headers, 'JSESSIONID_VERSION');
        if (!value) {
            this.log.error(CHANGE_ERROR_MASSAGE('set-cookie JSESSIONID_VERSION error.'));
        }
        this.jSessionIdVersion = value;
    }
    getSearchCriteriaCompany() {
        return this.applayPageInfo.searchCriteriaCompany || '';
    }
    getImwApplyBaseDate() {
        if (this.applayPageInfo.applayForm) {
            return this.applayPageInfo.applayForm['imwApplyBaseDate'] || '';
        }
        return '';
    }
    makeExpensesBurdenDestinationDetails() {
        const result = [];
        let count = 0;
        let total = 0;
        for (const exbd of this.expensesBurdenDestinationList) {
            const data = {
                imwApplyBaseDate: this.getImwApplyBaseDate(),
                imwSystemMatterId: '',
                searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
                searchMcCompany: this.applayPageInfo.expenseList.searchCompany,
                payMethodCd: '',
                usageTypeCd: '1',
                systemDate: this.systemDate,
                teamCd: exbd.teamCd,
                teamNmJpnm: exbd.teamCd,
                hdprsNmJpnm: '職能共通',
                hdprsCd: exbd.headquarters,
                buCd: exbd.buCd,
                mcuCd: exbd.mcuCd,
                expensesBurdenRate: exbd.expenseBurdenRate,
                expensesBurdenType: 'A00023-1',
                expensesBurdenAmount: '0',
                rowNumber: (count + 1).toString(),
                tupleId: count.toString(),
            };
            result.push(data);
            count++;
            total = total + Number(exbd.expenseBurdenRate);
        }
        return { total, list: result };
    }
    makeTrvAllowanceDetails() {
        const result = [];
        let count = 0;
        for (const masterTrvAllowance of this.masterTrvAllowanceList) {
            result.push({
                imwApplyBaseDate: this.getImwApplyBaseDate(),
                applyAuthUserCd: this.targetUserInfo.businessTravelerCd,
                searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
                allowanceCd: masterTrvAllowance.allowanceCd,
                quantity: '0',
                extensionC: this.applayPageInfo.trvAllowance.extensionC,
                extensionF: this.applayPageInfo.trvAllowance.extensionF,
                dollarRate: this.applayPageInfo.trvAllowance.dollarRate,
                extensionG: '0.00',
                extensionH: this.applayPageInfo.trvAllowance.extensionH,
                transAmount: round(masterTrvAllowance.amount, 2).toString(),
                transCurrencyCd: this.applayPageInfo.trvAllowance.transCurrencyCd,
                expTypeCd: masterTrvAllowance.expTypeInfo.expTypeCd,
                expTypeName: masterTrvAllowance.expTypeInfo.expTypeName,
                accountCd: masterTrvAllowance.expTypeInfo.accountCd,
                taxTypeCd: masterTrvAllowance.expTypeInfo.taxTypeCd,
                taxTypeName: masterTrvAllowance.expTypeInfo.taxTypeName,
                taxRate: round(masterTrvAllowance.expTypeInfo.taxRate, 2).toString(),
                payTypeCd: this.applayPageInfo.trvAllowance.payTypeCd,
                payMethodCd: this.applayPageInfo.trvAllowance.payMethodCd,
                extensionD: this.applayPageInfo.trvAllowance.extensionD,
                extensionB: this.applayPageInfo.trvAllowance.extensionB,
                extensionI: this.applayPageInfo.trvAllowance.extensionI,
                companyCurrencyCd: this.applayPageInfo.trvAllowance.companyCurrencyCd,
                companyRate: '0',
                companyAmount: '0',
                companyAmountExcTax: '0',
                companyAmountTax: '0',
                baseAmount: round(masterTrvAllowance.amount, 2).toString(),
                companyAmountSum: '0',
                rowNumber: (count + 1).toString(),
                tupleId: count.toString(),
            });
            count++;
        }
        return result;
    }
    makeRouteDetailTable(expenseInfoForCycle) {
        const expenseTransportations = expenseInfoForCycle.expenseTransportations;
        const result = [];
        let count = 0;
        for (const target of expenseTransportations) {
            const settlementDate = this.formatCycleDate(target.settlementDate);
            const currency = target.currency || 'JPY'; // 指定がない場合はJPYとする。
            const price = target.price ? target.price.toString() : '0';
            result.push({
                routeDate: settlementDate,
                hidDateOfUse: settlementDate,
                extensionJ: 'A00001-1',
                extensionJName: '',
                extensionB: target.extensionB || '',
                payTypeCd: this.applayPageInfo.trvRouteDetail.payTypeCd,
                payMethodCd: this.applayPageInfo.trvRouteDetail.payMethodCd,
                paymentFlag: this.applayPageInfo.trvRouteDetail.paymentFlag,
                roundTripFlag: this.applayPageInfo.trvRouteDetail.roundTripFlag,
                extensionE: this.applayPageInfo.trvRouteDetail.extensionE,
                extensionC: TransportationType[target.transportationType || '']?.extensionC || '',
                extensionCName: TransportationType[target.transportationType || '']?.extensionCName || '',
                classItemTypeCd: TransportationType[target.transportationType || '']?.classItemTypeCd || '',
                extensionD: TransportationType[target.transportationType || '']?.extensionD || '',
                extensionDName: TransportationType[target.transportationType || '']?.extensionDName || '',
                startingSpot: target.departureLocation || '',
                arrivalSpot: target.arrivalLocation || '',
                expTypeCategory: '海外出張_交通費',
                expTypeCd: ExpTypeTransportation[target.settlementType || '']?.expTypeCd || '',
                expTypeName: ExpTypeTransportation[target.settlementType || '']?.expTypeName || '',
                accountCd: ExpTypeTransportation[target.settlementType || '']?.accountCd || '',
                taxTypeCd: ExpTypeTransportation[target.settlementType || '']?.taxTypeCd || '',
                taxRate: ExpTypeTransportation[target.settlementType || '']?.taxRate || '',
                transAmount: price,
                transCurrencyCd: currency,
                companyRate: currency === 'JPY' ? '1' : '',
                extensionF: currency === 'JPY' ? '0' : '1',
                companyAmount: currency === 'JPY' ? price : '0',
                companyAmountSum: currency === 'JPY' ? price : '0',
                supplement: target.remark || '',
                routeLinkFlag: this.applayPageInfo.trvRouteDetail.routeLinkFlag,
                commutationRoute: this.applayPageInfo.trvRouteDetail.commutationRoute,
                searchCondition: this.applayPageInfo.trvRouteDetail.searchCondition,
                routeInfo: this.applayPageInfo.trvRouteDetail.routeInfo,
                assessDate: this.applayPageInfo.trvRouteDetail.assessDate,
                tranceMeansFlag: this.applayPageInfo.trvRouteDetail.tranceMeansFlag,
                assessFlag: this.applayPageInfo.trvRouteDetail.assessFlag,
                rowNumber: (count + 1).toString(),
                tupleId: count.toString(),
            });
            count++;
        }
        return result;
    }
    makeLodgeDetail(expenseInfoForCycle) {
        const expenseAccommodations = expenseInfoForCycle.expenseAccommodations;
        const result = [];
        let count = 0;
        for (const target of expenseAccommodations) {
            const settlementDate = this.formatCycleDate(target.settlementDate);
            const city = target.city || {};
            const currency = target.currency || 'JPY'; // 指定がない場合はJPYとする。
            const price = target.price ? target.price.toString() : '0';
            const companyAmountSum = currency === 'JPY' ? price : '0';
            const { excTax, tax } = this.calcTax(companyAmountSum, currency, ExpTypeAccomodation['海外宿泊費'].taxRate);
            result.push({
                searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
                imwApplyBaseDate: this.getImwApplyBaseDate(),
                searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
                hidDateOfUse: settlementDate,
                extensionD: settlementDate,
                extensionH: city?.countryCode || '',
                extensionHName: city?.country || '',
                extensionG: city?.cityCode || '',
                extensionJ: 'A00001-1',
                extensionJName: '領収書',
                extensionI: this.applayPageInfo.trvLodgeDetail.extensionI,
                extensionB: target.extensionB || '',
                expTypeCategory: '海外出張_宿泊',
                expTypeCd: ExpTypeAccomodation['海外宿泊費']?.expTypeCd || '',
                expTypeName: ExpTypeAccomodation['海外宿泊費']?.expTypeName || '',
                accountCd: ExpTypeAccomodation['海外宿泊費']?.accountCd || '',
                taxTypeCd: ExpTypeAccomodation['海外宿泊費']?.taxTypeCd || '',
                taxRate: ExpTypeAccomodation['海外宿泊費']?.taxRate || '',
                payTypeCd: this.applayPageInfo.trvLodgeDetail.payTypeCd,
                payMethodCd: this.applayPageInfo.trvLodgeDetail.payMethodCd,
                paymentFlag: this.applayPageInfo.trvLodgeDetail.paymentFlag,
                lodgeName: target.hotelName || '',
                startDate: this.formatCycleDate(target.checkInDate),
                endDate: this.formatCycleDate(target.checkOutDate),
                extensionC: target.remark || '',
                transAmount: price,
                transCurrencyCd: currency,
                transCurrencyName: currency,
                companyRate: currency === 'JPY' ? '1' : '',
                extensionF: currency === 'JPY' ? '0' : '1',
                companyAmount: currency === 'JPY' ? price : '0',
                quantity: '1',
                companyCurrencyCd: this.applayPageInfo.trvLodgeDetail.companyCurrencyCd,
                companyAmountSum,
                companyAmountExcTax: excTax,
                companyAmountTax: tax,
                rowNumber: (count + 1).toString(),
                tupleId: count.toString(),
            });
            count++;
        }
        return result;
    }
    makeTrvExpenseDetail(expenseInfoForCycle) {
        const expenseOthers = expenseInfoForCycle.expenseOthers;
        const result = [];
        let count = 0;
        for (const target of expenseOthers) {
            const settlementDate = this.formatCycleDate(target.settlementDate);
            const currency = target.currency || 'JPY'; // 指定がない場合はJPYとする。
            const price = target.price ? target.price.toString() : '0';
            const companyAmountSum = currency === 'JPY' ? price : '0';
            const { excTax, tax } = this.calcTax(companyAmountSum, currency, ExpTypeOther[target.settlementType || ''].taxRate);
            result.push({
                searchCriteriaDate: this.applayPageInfo.searchCriteriaDate,
                imwApplyBaseDate: this.getImwApplyBaseDate(),
                searchCriteriaCompany: this.applayPageInfo.searchCriteriaCompany,
                hidOccurDate: settlementDate,
                occurDate: settlementDate,
                extensionJ: 'A00001-1',
                extensionJName: '領収書',
                extensionI: this.applayPageInfo.trvExpenseDetail.extensionI,
                extensionB: target.extensionB || '',
                expTypeCategory: '海外出張_その他',
                expTypeCd: ExpTypeOther[target.settlementType || '']?.expTypeCd || '',
                expTypeName: ExpTypeOther[target.settlementType || '']?.expTypeName || '',
                accountCd: ExpTypeOther[target.settlementType || '']?.accountCd || '',
                taxTypeCd: ExpTypeOther[target.settlementType || '']?.taxTypeCd || '',
                taxRate: ExpTypeOther[target.settlementType || '']?.taxRate || '',
                payTypeCd: this.applayPageInfo.trvExpenseDetail.payTypeCd,
                payMethodCd: this.applayPageInfo.trvExpenseDetail.payMethodCd,
                paymentFlag: this.applayPageInfo.trvExpenseDetail.paymentFlag,
                transAmount: price,
                transCurrencyCd: currency,
                transCurrencyName: currency,
                companyRate: currency === 'JPY' ? '1' : '',
                extensionF: currency === 'JPY' ? '0' : '1',
                companyAmount: currency === 'JPY' ? price : '0',
                quantity: '1',
                companyCurrencyCd: this.applayPageInfo.trvExpenseDetail.companyCurrencyCd,
                companyAmountSum,
                companyAmountExcTax: excTax,
                companyAmountTax: tax,
                payRateAmount: this.applayPageInfo.trvExpenseDetail.payRateAmount,
                summary: target.remark || '',
                rowNumber: (count + 1).toString(),
                tupleId: count.toString(),
            });
            count++;
        }
        return result;
    }
    calcTax(companyAmountSum, currency, taxRate) {
        if (currency === 'JPY') {
            const sum = Number(companyAmountSum);
            if (!taxRate) {
                taxRate = '0';
            }
            if (sum > 0) {
                const excTax = round(sum / round(1 + Number(taxRate), 2), 0);
                const tax = round(sum - excTax, 0);
                return { excTax: excTax.toString(), tax: tax.toString() };
            }
        }
        return { excTax: '0', tax: '0' };
    }
    formatCycleDate(settlementDate) {
        try {
            if (settlementDate) {
                return formatUtcDateTime(new Date(settlementDate), 'yyyy/MM/dd');
            }
            return '';
        }
        catch (_error) {
            return '';
        }
    }
}
//# sourceMappingURL=cycleAfterApplyAccess.js.map