import { cloneDeep } from 'lodash-es';
import { getKeys, sleep } from '../../utils/index.js';
import { IntraAccessClient } from './intraAccessClient.js';
const CHANGE_ERROR_MASSAGE = (key) => {
    return `cycleAccessAgent cycle auth or site may be changed recently. [${key}]`;
};
export function getIwInfoIntra3Cookie(iwInfoIntra3) {
    if (!iwInfoIntra3) {
        iwInfoIntra3 = '';
    }
    return { key: 'IW_INFO_INTRA3', value: iwInfoIntra3 };
}
export class Mcsso3AuthAgent {
    /**
     * コンストラクタ
     * code情報を指定している場合は、インスタンス生成時点からログイン認証済として、accessToken、csrfKeyの取得をしておく
     * @param app
     */
    constructor(log, id, pass) {
        // サイトの初回アクセス先となるURL情報
        this.targetSiteRedirectUrl = '';
        this.cookierIwInfoIntra3 = '';
        // 認証アクセス時に取得した情報を保持する変数
        this.loginSiteLoadInfo = {
            host: '',
            path: '',
            nextPostData: {
                OPTION: 'PW',
                MODE: '',
                TOKEN: '',
                STATE: '',
            },
        };
        this.loginPageLoadInfo = {
            nextPostData: {
                ACCOUNTUID: '',
                PASSWORD: '',
                SUBMIT: '',
                MODE: '',
                TOKEN: '',
                STATE: '',
            },
        };
        this.loginActionInfoBase = {
            header: {
                MFA_INFO_INTRA3: '',
            },
            nextPath: '',
            redirectUrl: '',
            nextPostData: {
                TOKEN: '',
            },
        };
        this.loginActionInfos = [];
        this.log = log;
        this.loginPageLoadInfo.nextPostData.ACCOUNTUID = id;
        this.loginPageLoadInfo.nextPostData.PASSWORD = pass;
        this.intraClient = new IntraAccessClient(log);
    }
    /**
     * ログイン処理
     */
    async login() {
        let result = await this.loginSiteLoad();
        if (!result.isSuccess) {
            return result;
        }
        result = await this.loginPageLoad();
        if (!result.isSuccess) {
            return result;
        }
        result = await this.loginAction();
        if (!result.isSuccess || result.isLoginValidateError || result.isSecretUnset) {
            return result;
        }
        result = await this.redirectAction();
        return result;
    }
    getLoginResultInfo() {
        return {
            redirectUrl: this.targetSiteRedirectUrl,
            cookies: [getIwInfoIntra3Cookie(this.cookierIwInfoIntra3)],
        };
    }
    async loginSiteLoad() {
        const result = { isSuccess: false };
        try {
            const url = 'https://mcsso3.mitsubishicorp.com/imart/home';
            const resFirst = await this.intraClient.get(url);
            // 未ログインなので、ログイン画面の初回アクセスURLにリダイレクトされる。
            if (!resFirst?.headers.location) {
                this.log.error(CHANGE_ERROR_MASSAGE('loginSiteLoad1'));
                return result;
            }
            const res = await this.intraClient.get(resFirst.headers.location);
            const request = res?.request;
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!request || !document) {
                this.log.error(CHANGE_ERROR_MASSAGE('loginSiteLoad2'));
                return result;
            }
            this.loginSiteLoadInfo.host = request.host;
            this.loginSiteLoadInfo.path = request.path;
            const inputs = document.querySelectorAll('.btn-toolbar input');
            if (inputs.length <= 0) {
                this.log.error(CHANGE_ERROR_MASSAGE('loginSiteLoad3'));
                return result;
            }
            for (const input of inputs) {
                const name = input.getAttribute('name');
                const keys = getKeys(this.loginSiteLoadInfo.nextPostData);
                for (const key of keys) {
                    if (name === key) {
                        const value = input.getAttribute('value');
                        if (value) {
                            this.loginSiteLoadInfo.nextPostData[key] = value;
                        }
                        else {
                            this.log.error(CHANGE_ERROR_MASSAGE('loginSiteLoad3'));
                            return result;
                        }
                    }
                }
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            return result;
        }
    }
    async loginPageLoad() {
        const result = { isSuccess: false };
        try {
            const url = 'https://mcsso3.mitsubishicorp.com/fw/dfw/MFA/mfa/selector.iw';
            const postData = new URLSearchParams();
            const keys = getKeys(this.loginSiteLoadInfo.nextPostData);
            for (const key of keys) {
                postData.append(key, this.loginSiteLoadInfo.nextPostData[key]);
            }
            const res = await this.intraClient.post(url, postData, { headers: { Cookie: 'MFA_SEL_POSITION_INTERNET3=0' } });
            const request = res?.request;
            const data = res?.data;
            const document = this.intraClient.convertDom(data);
            if (!request || !document) {
                this.log.error(CHANGE_ERROR_MASSAGE('loginPageLoad1'));
                return result;
            }
            const inputs = document.querySelectorAll('#uid_form .center input');
            if (inputs.length <= 0) {
                this.log.error(CHANGE_ERROR_MASSAGE('loginPageLoad2'));
                return result;
            }
            for (const input of inputs) {
                const name = input.getAttribute('name');
                const keys = getKeys(this.loginPageLoadInfo.nextPostData);
                for (const key of keys) {
                    if (name === key) {
                        const value = input.getAttribute('value');
                        if (value) {
                            this.loginPageLoadInfo.nextPostData[key] = value;
                        }
                        else {
                            this.log.error(CHANGE_ERROR_MASSAGE('loginPageLoad3'));
                            return result;
                        }
                    }
                }
            }
            result.isSuccess = true;
            return result;
        }
        catch (error) {
            return result;
        }
    }
    async loginAction() {
        const url = 'https://mcsso3.mitsubishicorp.com/fw/dfw/MFA/mfa/pwd.iw';
        return this._loginActionInner(url, 0);
    }
    async _loginActionInner(url, count) {
        const loginActionInfo = cloneDeep(this.loginActionInfoBase);
        this.loginActionInfos.push(loginActionInfo);
        const result = { isSuccess: false };
        try {
            const postData = new URLSearchParams();
            const config = {
                headers: {},
            };
            if (count <= 0) {
                const keys = getKeys(this.loginPageLoadInfo.nextPostData);
                for (const key of keys) {
                    postData.append(key, this.loginPageLoadInfo.nextPostData[key]);
                }
            }
            else {
                const keys = getKeys(this.loginActionInfos[count - 1].nextPostData);
                for (const key of keys) {
                    postData.append(key, this.loginActionInfos[count - 1].nextPostData[key]);
                }
                if (!config.headers) {
                    throw new Error('programing error.');
                }
                config.headers['Cookie'] = `MFA_INFO_INTRA3=${this.loginActionInfos[count - 1].header.MFA_INFO_INTRA3}`;
            }
            const res = await this.intraClient.post(url, postData, config, { noLog: true });
            if (res?.status === 302 && res?.headers.location) {
                loginActionInfo.redirectUrl = res.headers.location;
                result.isSuccess = true;
                return result;
            }
            const request = res?.request;
            const data = res?.data;
            const mfaInfoIntra3 = this.intraClient.getHeaderKeyValue(res?.headers, 'MFA_INFO_INTRA3');
            const document = this.intraClient.convertDom(data);
            if (!request || !document) {
                this.log.error(CHANGE_ERROR_MASSAGE('loginAction1'));
                return result;
            }
            const title = document.querySelector('#body > .content-wrapper > h1');
            if (title && title.innerHTML === 'Login Error') {
                result.isLoginValidateError = true;
                this.log.info('mcsso3 login error. ID or password is not collect.');
                return result;
            }
            else if (title && title.innerHTML === '秘密の質問未登録') {
                result.isSecretUnset = true;
                this.log.info('mcsso3 login error. secret question is not set.');
                return result;
            }
            const bodyOnload = document.querySelector('body')?.getAttribute('onLoad');
            const path = document.querySelector('body > form')?.getAttribute('action');
            if (bodyOnload === 'document.myform.submit()' && path === '/fw/dfw/MFA/mfa/ctrl.iw' && mfaInfoIntra3) {
                loginActionInfo.header.MFA_INFO_INTRA3 = mfaInfoIntra3;
                const input = document.querySelector('body > form > input');
                if (input) {
                    const key = input.getAttribute('name');
                    const value = input.getAttribute('value');
                    if (key === 'TOKEN' && value) {
                        loginActionInfo.nextPostData.TOKEN = value;
                        if (count >= 100) {
                            return result;
                        }
                        else {
                            // sleepしながら繰り返しログイン処理完了を待つ
                            await sleep(100);
                            // まだ302になっていないので、繰り返し一連のログイン処理実施
                            return this._loginActionInner(`https://${this.loginSiteLoadInfo.host}${path}`, count + 1);
                        }
                    }
                }
            }
            this.log.error(CHANGE_ERROR_MASSAGE('loginAction2'), res.data);
            return result;
        }
        catch (error) {
            return result;
        }
    }
    async redirectAction() {
        const result = { isSuccess: false };
        try {
            const redirectUrl = this.loginActionInfos[this.loginActionInfos.length - 1].redirectUrl;
            const mfainfoIntra3 = this.loginActionInfos[this.loginActionInfos.length - 2].header.MFA_INFO_INTRA3;
            if (!redirectUrl || !mfainfoIntra3) {
                this.log.error(CHANGE_ERROR_MASSAGE('redirectAction1'));
            }
            const res = await this.intraClient.get(redirectUrl, {
                headers: { Cookie: 'MFA_INFO_INTRA3=' + mfainfoIntra3 },
            });
            const targetSiteRedirectUrl = res?.headers.location;
            const iwInfoIntra3 = this.intraClient.getHeaderKeyValue(res?.headers, 'IW_INFO_INTRA3');
            if (res?.status === 302 && targetSiteRedirectUrl && iwInfoIntra3) {
                this.targetSiteRedirectUrl = targetSiteRedirectUrl;
                this.cookierIwInfoIntra3 = iwInfoIntra3;
                result.isSuccess = true;
                return result;
            }
            this.log.error(CHANGE_ERROR_MASSAGE('redirectAction2'));
            return result;
        }
        catch (error) {
            return result;
        }
    }
}
//# sourceMappingURL=mcsso3AuthAgent.js.map