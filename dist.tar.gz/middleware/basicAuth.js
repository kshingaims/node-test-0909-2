// basicAuthMiddleware.ts
import basicAuth from 'basic-auth';
export const basicAuthMiddleware = (username, password) => {
    return (req, res, next) => {
        if (req.path === '/manifest.webmanifest' || req.path === '/sw.js') {
            // 特定のパスの場合は、ミドルウェアをスキップ
            return next();
        }
        else if (req.path === '/') {
            // User-Agentヘッダーを取得
            const userAgent = req.headers['user-agent'] || '';
            // iPhoneまたはiPadを含むかどうかチェック
            if (userAgent.includes('iPhone') || userAgent.includes('iPad')) {
                return next();
            }
        }
        const user = basicAuth(req);
        if (user && user.name === username && user.pass === password) {
            next();
        }
        else {
            res.setHeader('WWW-Authenticate', 'Basic realm="Private"');
            res.status(401).send('Authentication required.');
        }
    };
};
//# sourceMappingURL=basicAuth.js.map