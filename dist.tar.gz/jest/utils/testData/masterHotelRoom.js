const hotelRoomNames = [
    { hotelId: 1, name: 'Tranquil Haven Hotel Room 1', price: 6140, currency: 'EUR' },
    { hotelId: 1, name: 'Tranquil Haven Hotel Room 2', price: 6842, currency: 'EUR' },
    { hotelId: 2, name: 'Berlin Marriott Hotel 1', price: 5325, currency: 'EUR' },
    { hotelId: 2, name: 'Berlin Marriott Hotel 2', price: 7458, currency: 'EUR' },
    { hotelId: 3, name: 'Sofia Balkan Palace 1', price: 6298, currency: 'BGN' },
    { hotelId: 3, name: 'Sofia Balkan Palace 2', price: 7105, currency: 'BGN' },
    { hotelId: 4, name: 'Hotel Moscow St. Petersburg 1', price: 8920, currency: 'RUB' },
    { hotelId: 4, name: 'Hotel Moscow St. Petersburg 2', price: 9552, currency: 'RUB' },
    { hotelId: 5, name: 'Yekaterinburg 1', price: 7403, currency: 'RUB' },
    { hotelId: 5, name: 'Yekaterinburg 2', price: 8119, currency: 'RUB' },
    { hotelId: 6, name: 'Narada Boutique Hotel Shanghai Yu Garden 1', price: 4879, currency: 'CNY' },
    { hotelId: 6, name: 'Narada Boutique Hotel Shanghai Yu Garden 2', price: 5523, currency: 'CNY' },
    { hotelId: 7, name: 'Pu San Chan Motel 1', price: 4756, currency: 'KRW' },
    { hotelId: 7, name: 'Pu San Chan Motel 2', price: 5117, currency: 'KRW' },
    { hotelId: 8, name: 'Bangkok Marriott Hotel The Surawongse 1', price: 3680, currency: 'THB' },
    { hotelId: 8, name: 'Bangkok Marriott Hotel The Surawongse 2', price: 4220, currency: 'THB' },
    { hotelId: 9, name: 'The Ritz-Carlton Kuala Lumpur 1', price: 4155, currency: 'MYR' },
    { hotelId: 9, name: 'The Ritz-Carlton Kuala Lumpur 2', price: 4623, currency: 'MYR' },
    { hotelId: 10, name: 'Hokulani Waikiki Hilton Grand Vacation 1', price: 8542, currency: 'USD' },
    { hotelId: 10, name: 'Hokulani Waikiki Hilton Grand Vacation 2', price: 9136, currency: 'USD' },
    { hotelId: 11, name: 'Bangkok Palace Hotel Room 1', price: 3680, currency: 'THB' },
    { hotelId: 11, name: 'Bangkok Palace Hotel Room 2', price: 4220, currency: 'THB' },
    { hotelId: 12, name: 'Bangkok Holiday In Room 1', price: 3680, currency: 'THB' },
    { hotelId: 12, name: 'Bangkok Holiday In Room 2', price: 4220, currency: 'THB' },
    { hotelId: 13, name: 'Bangkok Hotel Marmaid Room 1', price: 3680, currency: 'THB' },
    { hotelId: 13, name: 'Bangkok Hotel Marmaid Room 2', price: 4220, currency: 'THB' },
];
export async function createTestHotelRooms(prisma) {
    for (const hotelRoomName of hotelRoomNames) {
        await prisma.hotelRoom.create({
            data: {
                hotelId: hotelRoomName.hotelId,
                name: hotelRoomName.name,
                price: hotelRoomName.price,
                currency: hotelRoomName.currency,
            },
        });
    }
}
//# sourceMappingURL=masterHotelRoom.js.map