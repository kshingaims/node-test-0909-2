import { TestDefine } from '../testDefine.js';
const drivers = [
    { name: 'John Doe', tel: '03-5555-1234', email: 'john@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    { name: 'Jane Smith', tel: '080-5555-5678', email: 'jane@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    { name: 'Bob Johnson', tel: '090-5555-7890', email: 'bob@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    { name: 'Alice Brown', tel: '050-5555-4567', email: 'alice@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    { name: 'David Wilson', tel: '06-5555-2345', email: 'david@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    { name: 'Eva Davis', tel: '070-5555-6789', email: 'eva@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    { name: 'Michael Lee', tel: '080-5555-8901', email: 'michael@example.com', mcSyozokuCd: '0500001', flgDelete: true },
    { name: 'Olivia Clark', tel: '04-5555-3456', email: 'olivia@example.com', mcSyozokuCd: '0500001', flgDelete: false },
    {
        name: 'Sophia Turner',
        tel: '072-5555-9012',
        email: 'sophia@example.com',
        mcSyozokuCd: '0500002',
        flgDelete: false,
    },
    {
        name: 'William Martinez',
        tel: '090-5555-6789',
        email: 'william@example.com',
        mcSyozokuCd: '0500002',
        flgDelete: false,
    },
];
export async function createTestDriverRooms(prisma) {
    for (const driver of drivers) {
        await prisma.driver.create({
            data: {
                name: driver.name,
                tel: driver.tel,
                email: driver.email,
                mcSyozokuCd: driver.mcSyozokuCd,
                flgDelete: driver.flgDelete,
                updatedBy: TestDefine.PID.FOREIGN1,
            },
        });
    }
}
//# sourceMappingURL=driver.js.map