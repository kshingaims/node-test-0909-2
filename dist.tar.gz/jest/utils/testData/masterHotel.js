import { TestDefine } from '../../../jest/utils/testDefine.js';
const hotels = [
    //id:1
    {
        cityId: 1,
        googlePlaceId: 'DUMMY_PLACE_ID',
        googleLocation: { lat: 48.8680986, lng: 2.3288931 },
        name: 'オテル・リッツ・パリ',
        address: '15 Pl. Vendôme, 75001 Paris, フランス',
        tel: '01 43 16 30 30',
        url: 'http://www.ritzparis.com',
    },
    //id:2
    {
        cityId: 2,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 52.510875,
            lng: 13.3762494,
        },
        name: 'ベルリンマリオットホテル',
        address: 'Inge-Beisheim-Platz 1, 10785 Berlin, ドイツ',
        tel: '030 220000',
        url: 'https://www.marriott.com/en-us/hotels/bermc-berlin-marriott-hotel/overview/?scid=f2ae0541-1279-4f24-b197-a979c79310b0',
    },
    //id:3
    {
        cityId: 3,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 42.6970261,
            lng: 23.3223047,
        },
        name: 'Sofia Balkan Palace',
        address: '5, пл. „Света Неделя“ Square, 1000 Old City Center, София, ブルガリア',
        tel: '02 981 6541',
        url: 'http://www.sofiabalkanpalace.com/',
    },
    //id:4
    {
        cityId: 5,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 59.92453,
            lng: 30.3862459,
        },
        name: 'オテリ・モスクワ・フ・サンクト＝ペテルブルゲ',
        address: "Ploshchad' Aleksandra Nevskogo, 2, Sankt-Peterburg, ロシア 191317",
        tel: '8 (812) 667-82-63',
        url: 'https://www.hotel-moscow.ru/',
    },
    //id:5
    {
        cityId: 6,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 56.8583726,
            lng: 60.6071779,
        },
        name: 'エカテリンブルグ',
        address: "Vokzal'naya Ulitsa, 23-27, Yekaterinburg, Sverdlovskaya oblast', ロシア 620027",
        tel: '',
        url: '',
    },
    //id:6
    {
        cityId: 10,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 31.2274189,
            lng: 121.484634,
        },
        name: 'Narada Boutique Hotel Shanghai Yu Garden',
        address: '839 Ren Min Lu, Huang Pu Qu, Shang Hai Shi, 中華人民共和国 200010',
        tel: '021 6326 5666',
        url: 'http://www.ssawhotel.com/cn/',
    },
    //id:7
    {
        cityId: 23,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 35.0934859,
            lng: 129.0233043,
        },
        name: 'プサン チャン モーテル',
        address: 'Chungmu-dong 3(sam)-ga, Seo-gu, Busan, 大韓民国',
        tel: '051-247-1371',
        url: '',
    },
    //id:8
    {
        cityId: 36,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 13.7273198,
            lng: 100.522248,
        },
        name: 'バンコク・マリオット・ホテル・ザ・スリウォン',
        address: '262 Surawong Road, Khwaeng Si Phraya, Khet Bang Rak, Krung Thep Maha Nakhon 10500 タイ',
        tel: '02 088 5666',
        url: 'https://www.marriott.com/en-us/hotels/bkkwo-bangkok-marriott-hotel-the-surawongse/overview/?scid=f2ae0541-1279-4f24-b197-a979c79310b0',
    },
    //id:9
    {
        cityId: 26,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 3.1469196,
            lng: 101.7153713,
        },
        name: 'ザ・リッツカールトン クアラルンプール',
        address: '168, Jln Imbi, Bukit Bintang, 55100 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur, マレーシア',
        tel: '03-2142 8000',
        url: 'https://www.ritzcarlton.com/en/hotels/kulrz-the-ritz-carlton-kuala-lumpur/overview/?scid=f2ae0541-1279-4f24-b197-a979c79310b0',
    },
    //id:10
    {
        cityId: 15,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 21.2799716,
            lng: -157.8303756,
        },
        name: 'ホクラニ ワイキキ ヒルトン グランド バケーション',
        address: '2181 Kalākaua Ave, Honolulu, HI 96815 アメリカ合衆国',
        tel: '(808) 462-4000',
        url: 'https://www.hilton.com/en/hotels/hnlwbgv-hilton-grand-vacations-club-hokulani-waikiki-honolulu/?SEO_id=GMB-AMER-GV-HNLWBGV&y_source=1_MTg1OTY4Ni03MTUtbG9jYXRpb24ud2Vic2l0ZQ%3D%3D', //websiteから取得
    },
    //id:11
    {
        cityId: 36,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 13.7527856,
            lng: 100.5476654,
        },
        name: 'バンコク パレス ホテル',
        address: '1091 336 New Petchaburi Rd, Khwaeng Makkasan, Khet Ratchathewi, Krung Thep Maha Nakhon 10400 タイ',
        tel: '02 890 9000',
        url: 'http://www.bangkokpalace.com/', //websiteから取得
    },
    //id:12
    {
        cityId: 36,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 13.7328725,
            lng: 100.5654739,
        },
        name: 'ホリデイ イン バンコク スクンビット',
        address: '1 Sukhumvit Soi 22, Klongton, Khet Khlong Toei, Krung Thep Maha Nakhon 10110 タイ',
        tel: '02 683 4888',
        url: 'https://www.ihg.com/holidayinn/hotels/us/en/bangkok/bkkhi/hoteldetail?cm_mmc=GoogleMaps-_-HI-_-TH-_-BKKHI', //websiteから取得
    },
    //id:13
    {
        cityId: 36,
        googlePlaceId: 'DUMMY_VALUE',
        googleLocation: {
            lat: 13.7344799,
            lng: 100.5654564,
        },
        name: 'ホテル マーメイド バンコク',
        address: '6 Soi Sukhumvit 29, Khwaeng Khlong Toei Nuea, Watthana, Krung Thep Maha Nakhon 10110 タイ',
        tel: '02 260 9026',
        url: 'http://www.hotelmermaidbangkok.com/', //websiteから取得
    },
];
export async function createTestHotels(prisma) {
    for (const hotel of hotels) {
        await prisma.hotel.create({
            data: {
                cityId: hotel.cityId,
                googlePlaceId: hotel.googlePlaceId,
                name: hotel.name,
                address: hotel.address,
                url: hotel.url,
                tel: hotel.tel,
                googleLocation: hotel.googleLocation,
                mcSyozokuCd: '0500001',
                flgDelete: false,
                updatedBy: TestDefine.PID.FOREIGN1,
            },
        });
    }
}
//# sourceMappingURL=masterHotel.js.map