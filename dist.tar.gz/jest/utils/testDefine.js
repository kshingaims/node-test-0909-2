/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
const TEST_DEFINE = {
    PID: {
        OWNER1: 'MC00000001',
        OWNER2: 'MC00000002',
        COMPANION1: 'MC10000001',
        COMPANION2: 'MC10000002',
        COMPANION3: 'MC10000003',
        COMPANION4: 'MC10000004',
        COMPANION5: 'MC10000005',
        DELEGATED1: 'MC80000001',
        DELEGATED2: 'MC80000002',
        DELEGATED3: 'MC80000003',
        FOREIGN1: 'MC90000001',
        FOREIGN2: 'MC90000002',
        ADMIN: 'MC20000001',
    },
    DB_ROLLBACK_TEST: {
        PID: 'MC99999999',
    },
};
export class TestDefine {
    static get PID() {
        return TEST_DEFINE.PID;
    }
    static get DB_ROLLBACK_TEST() {
        return TEST_DEFINE.DB_ROLLBACK_TEST;
    }
}
//# sourceMappingURL=testDefine.js.map