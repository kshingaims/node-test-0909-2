import { addMonths } from 'date-fns';
import { merge } from 'lodash-es';
import { TestDefine } from '../../jest/utils/testDefine.js';
import { create as userCreate } from '../../service/user/userService.js';
import { upsert as upsertDelegator } from '../../service/delegator/delegatorService.js';
import { formatDate } from '../../utils/index.js';
/**
 * テストで利用する各種ユーザを作成する
 * @param prisma
 * @returns 作成したユーザに紐つくUserオブジェクト
 */
export async function createTestUsers(prisma) {
    await createDelegatedTestUser(prisma, 1);
    await createDelegatedTestUser(prisma, 2);
    await createDelegatedTestUser(prisma, 3, [TestDefine.PID.DELEGATED1, TestDefine.PID.DELEGATED2]);
    await createOwnerTestUser(prisma, 1, [
        TestDefine.PID.DELEGATED1,
        TestDefine.PID.DELEGATED2,
        TestDefine.PID.DELEGATED3,
    ]);
    await createOwnerTestUser(prisma, 2, [TestDefine.PID.DELEGATED1]);
    await createCmpanionTestUser(prisma, 1, [TestDefine.PID.DELEGATED1, TestDefine.PID.DELEGATED2]);
    await createCmpanionTestUser(prisma, 2, [TestDefine.PID.DELEGATED1]);
    await createCmpanionTestUser(prisma, 3);
    await createCmpanionTestUser(prisma, 4);
    await createCmpanionTestUser(prisma, 5);
    await createForeignTestUser(prisma, 1);
    await createForeignTestUser(prisma, 2);
    await createAdminTestUser(prisma, [TestDefine.PID.DELEGATED1, TestDefine.PID.DELEGATED2]);
}
/**
 * 旅程オーナーとなるテストアカウント作成
 * @param prisma
 * @param index 1～2までの数字
 * @param delegatorPids 委任者IDの配列
 * @returns 作成したユーザに紐つくUserオブジェクト
 */
export async function createOwnerTestUser(prisma, index, delegatorPids = []) {
    if (index <= 0 || index > 2) {
        index = 1;
    }
    const lastNameKanas = ['オーナーユーザイチ', 'オーナーユーザニ'];
    const pids = [TestDefine.PID.OWNER1, TestDefine.PID.OWNER2];
    const user = merge(await userCreate(prisma, {
        pid: pids[index - 1],
        email: 'owner' + index + '@test.com',
        lastNameKana: lastNameKanas[index - 1],
        lastNameKanji: '所有者' + index,
        lastNameRoma: 'Owner' + index,
        firstNameKana: 'タロウ',
        firstNameKanji: '太郎',
        firstNameRoma: 'Taro',
        mcSyozokuGrpCd: '30',
        mcSyozokuGrpNameKanji: '金属',
        mcSyozokuGrpNameRoma: 'Metals',
        mcSyozokuCd: '0107790',
        mcSyozokuNameKanji: '製品）テストメタル事業部',
        mcSyozokuNameRoma: 'TEST METAL',
        corpCd: '0100000',
        userBunrui: '1111111',
        userBunruiNameKanji: '社員',
        userBunruiNameRoma: 'Employee',
    }), { roles: [] });
    for (const delegatorPid of delegatorPids) {
        upsertDelegator(prisma, user, delegatorPid, formatDate(addMonths(new Date(), 12)));
    }
}
/**
 * 同行者となるテストアカウント作成
 * @param prisma
 * @param index 1～5までの数字
 * @param delegatorPids 委任者IDの配列
 * @returns 作成したユーザに紐つくUserオブジェクト
 */
export async function createCmpanionTestUser(prisma, index, delegatorPids = []) {
    if (index <= 0 || index > 5) {
        index = 1;
    }
    const lastNameKanas = [
        'ドウコウシャユーザイチ',
        'ドウコウシャユーザニ',
        'ドウコウシャユーザサン',
        'ドウコウシャユーザヨン',
        'ドウコウシャユーザゴ',
    ];
    const pids = [
        TestDefine.PID.COMPANION1,
        TestDefine.PID.COMPANION2,
        TestDefine.PID.COMPANION3,
        TestDefine.PID.COMPANION4,
        TestDefine.PID.COMPANION5,
    ];
    const user = merge(await userCreate(prisma, {
        pid: pids[index - 1],
        email: 'companion' + index + '@test.com',
        lastNameKana: lastNameKanas[index - 1],
        lastNameKanji: '同行者' + index,
        lastNameRoma: 'Comanion' + index,
        firstNameKana: 'タロウ',
        firstNameKanji: '太郎',
        firstNameRoma: 'Taro',
        mcSyozokuGrpCd: '30',
        mcSyozokuGrpNameKanji: '金属',
        mcSyozokuGrpNameRoma: 'Metals',
        mcSyozokuCd: '0107790',
        mcSyozokuNameKanji: '製品）テストメタル事業部',
        mcSyozokuNameRoma: 'TEST METAL',
        corpCd: '0100000',
        userBunrui: '1111111',
        userBunruiNameKanji: '社員',
        userBunruiNameRoma: 'Employee',
    }), { roles: [] });
    for (const delegatorPid of delegatorPids) {
        upsertDelegator(prisma, user, delegatorPid, formatDate(addMonths(new Date(), 12)));
    }
}
/**
 * 委任者となるテストアカウント作成
 * 委託者となるpidを指定すること
 * @param prisma
 * @param index 1～3までの数字
 * @param delegatorPids 委任者IDの配列
 * @returns 作成したユーザに紐つくUserオブジェクト
 */
export async function createDelegatedTestUser(prisma, index, delegatorPids = []) {
    if (index <= 0 || index > 3) {
        index = 1;
    }
    const lastNameKanas = ['イニンシャイチ', 'イニンシャニ', 'イニンシャサン'];
    const pids = [TestDefine.PID.DELEGATED1, TestDefine.PID.DELEGATED2, TestDefine.PID.DELEGATED3];
    const user = merge(await userCreate(prisma, {
        pid: pids[index - 1],
        email: 'delegated' + index + '@test.com',
        lastNameKana: lastNameKanas[index - 1],
        lastNameKanji: '委任者' + index,
        lastNameRoma: 'Delegated' + index,
        firstNameKana: 'タロウ',
        firstNameKanji: '太郎',
        firstNameRoma: 'Taro',
        mcSyozokuGrpCd: '30',
        mcSyozokuGrpNameKanji: '金属',
        mcSyozokuGrpNameRoma: 'Metals',
        mcSyozokuCd: '0107790',
        mcSyozokuNameKanji: '製品）テストメタル事業部',
        mcSyozokuNameRoma: 'TEST METAL',
        corpCd: '0100000',
        userBunrui: '6110000',
        userBunruiNameKanji: '派遣社員',
        userBunruiNameRoma: 'HakenStaff',
    }), { roles: [] });
    for (const delegatorPid of delegatorPids) {
        upsertDelegator(prisma, user, delegatorPid, formatDate(addMonths(new Date(), 12)));
    }
}
/**
 * 海外拠点担当となるテストアカウント作成
 * @param prisma
 * @param index 1～2までの数字
 * @returns 作成したユーザに紐つくUserオブジェクト
 */
export async function createForeignTestUser(prisma, index) {
    if (index <= 0 || index > 2) {
        index = 1;
    }
    const lastNameKanas = ['カイガイキョテンタントウイチ', 'カイガイキョテンタントウニ'];
    const pids = [TestDefine.PID.FOREIGN1, TestDefine.PID.FOREIGN2];
    await userCreate(prisma, {
        pid: pids[index - 1],
        email: 'foreign' + index + '@test.com',
        lastNameKana: lastNameKanas[index - 1],
        lastNameKanji: '海外拠点担当' + index,
        lastNameRoma: 'ForeignStaff' + index,
        firstNameKana: 'タロウ',
        firstNameKanji: '太郎',
        firstNameRoma: 'Taro',
        mcSyozokuGrpCd: '99',
        mcSyozokuGrpNameKanji: '海外',
        mcSyozokuGrpNameRoma: '海外',
        mcSyozokuCd: '050000' + index,
        mcSyozokuNameKanji: '海外事業部',
        mcSyozokuNameRoma: 'FOREIGN OFFICE',
        corpCd: '0100000',
        userBunrui: 'UW10000',
        userBunruiNameKanji: 'ナショナルスタッフ',
        userBunruiNameRoma: 'NationalStaff',
    });
}
/**
 * Admin権限を持つテストアカウント作成
 * @param prisma
 * @param delegatorPids 委任者IDの配列
 * @returns 作成したユーザに紐つくUserオブジェクト
 */
export async function createAdminTestUser(prisma, delegatorPids = []) {
    const user = merge(await userCreate(prisma, {
        pid: TestDefine.PID.ADMIN,
        email: 'admin@test.com',
        lastNameKana: 'カンリシャ',
        lastNameKanji: '管理者',
        lastNameRoma: 'Admin',
        firstNameKana: 'タロウ',
        firstNameKanji: '太郎',
        firstNameRoma: 'Taro',
        mcSyozokuGrpCd: '31',
        mcSyozokuGrpNameKanji: 'ITサービス',
        mcSyozokuGrpNameRoma: 'IT Service',
        mcSyozokuCd: '010904',
        mcSyozokuNameKanji: 'ウェブ開発',
        mcSyozokuNameRoma: 'WEB Development',
        corpCd: '0100000',
        userBunrui: '1111111',
        userBunruiNameKanji: '社員',
        userBunruiNameRoma: 'Employee',
    }, true), { roles: [] });
    for (const delegatorPid of delegatorPids) {
        upsertDelegator(prisma, user, delegatorPid, formatDate(addMonths(new Date(), 12)));
    }
}
/**
 * usersテーブルから全てのアカウントを削除する
 * @param prisma
 */
export async function deleteAllUsers(prisma) {
    // 委託・委任テーブルデータも、ユーザ削除に紐ついて削除される
    await prisma.user.deleteMany();
}
/**
 * usersテーブルからPIDを指定してアカウントを削除する
 * @param prisma
 */
export async function deleteUsers(prisma, pid) {
    await prisma.user.delete({
        where: {
            pid: pid,
        },
    });
}
export async function updateDelegatorsExpired(prisma) {
    const targetDelegators = [TestDefine.PID.DELEGATED1, TestDefine.PID.DELEGATED2, TestDefine.PID.DELEGATED3];
    // 有効期限切れとなっているデータを取得
    const expiredList = await prisma.usersDelegator.findMany({
        where: { delegatorPid: { in: targetDelegators }, expiredAt: { lt: formatDate(new Date()) } },
    });
    for (const expired of expiredList) {
        await prisma.usersDelegator.update({
            data: { expiredAt: formatDate(addMonths(new Date(), 3)) },
            where: { assignerPid_delegatorPid: { assignerPid: expired.assignerPid, delegatorPid: expired.delegatorPid } },
        });
    }
}
export function getJestTimeout() {
    const timeoutMs = process.env.JEST_TEST_TIMEOUT;
    return timeoutMs || 5000;
}
//# sourceMappingURL=index.js.map