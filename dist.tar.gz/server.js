import app from './app.js';
import http from 'http';
import dotenv from 'dotenv';
import { log } from './utils/logger.js';
import { setAllJobs } from './jobs/JobManager.js';
dotenv.config();
const normalizePort = (val) => {
    const port = parseInt(val, 10);
    if (isNaN(port)) {
        // named pipe
        return val;
    }
    if (port >= 0) {
        // port number
        return port;
    }
    return val;
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const onError = (error) => {
    if (error.syscall !== 'listen') {
        throw error;
    }
    const bind = typeof port === 'string' ? 'Pipe ' + port : 'Port ' + port;
    // handle specific listen errors with friendly messages
    switch (error.code) {
        case 'EACCES':
            log.error(bind + ' requires elevated privileges');
            process.exit(1);
            break;
        case 'EADDRINUSE':
            log.error(bind + ' is already in use');
            process.exit(1);
            break;
        default:
            throw error;
    }
};
const onListening = () => {
    const addr = server.address();
    if (addr) {
        const bind = typeof addr === 'string' ? 'pipe ' + addr : 'port ' + addr.port;
        log.debug('Listening on ' + bind);
    }
    else {
        log.debug('[error] Listening failed');
    }
};
/**
 * Get port from environment and store in Express.
 */
const port = normalizePort(process.env.PORT || '3000');
app.set('port', port);
/**
 * Create HTTP server.
 */
const server = http.createServer(app);
const isMainCluster = parseInt(process.env.NODE_APP_INSTANCE || '', 10) === 0;
if (isMainCluster || !process.env.NODE_APP_INSTANCE) {
    setAllJobs();
}
/**
 * Listen on provided port, on all network interfaces.
 */
server.listen(port);
server.on('error', onError);
server.on('listening', onListening);
export default server;
//# sourceMappingURL=server.js.map