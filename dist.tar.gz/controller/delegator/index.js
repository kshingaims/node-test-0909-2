import { log } from '../../utils/logger.js';
import { upsert as upsertDelegator, getUsersDelegatorList, deleteUsersDelegator, isExistsUsersDelegators, sendSmtpMailToDelegator, } from '../../service/delegator/delegatorService.js';
import { isExistsDelegators } from '../../service/user/userService.js';
import { isBeforeToday } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
export const DELEGATOR_UPSERT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['delegatorPid', 'expiredAt'],
    properties: {
        delegatorPid: {
            type: 'string',
            maxLength: 15,
        },
        expiredAt: {
            type: 'string',
            format: 'date',
        },
    },
};
export const DELEGATOR_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['delegatorPid'],
    properties: {
        delegatorPid: {
            type: 'string',
            maxLength: 15,
        },
    },
};
export async function list(_props, { pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 一覧取得実施
    const list = await getUsersDelegatorList(prisma, pid);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export async function upsert(props, { prisma, pid, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // ==========  開始 入力チェックエラー(ajvで判定できない動的な入力チェック処理)  =============
    // 委任者指定のpidが自分自身となっている場合は、エラー(W00302)
    if (pid === props.delegatorPid) {
        result.error = { code: Define.ERROR_CODES.W00302, status: 200 };
        return result;
    }
    // 委任者指定のpidがユーザマスタに存在しているかチェック (W00301)
    const error = await isExistsDelegators(prisma, props.delegatorPid);
    if (error) {
        result.error = error;
        return result;
    }
    // 有効期限が現在日よりも前の日付かチェック
    if (isBeforeToday(new Date(props.expiredAt))) {
        result.error = { code: Define.ERROR_CODES.W00102, status: 200 };
        return result;
    }
    // ==========  終了 入力チェックエラー(ajvで判定できない動的な入力チェック処理)  =============
    await upsertDelegator(prisma, user, props.delegatorPid, props.expiredAt);
    // 代理者設定のメール通知
    await sendSmtpMailToDelegator(log, prisma, props.delegatorPid, user);
    result.isSuccess = true;
    return result;
}
export async function deleteDelegator(props, { prisma, pid, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // ==========  開始 入力チェックエラー(ajvで判定できない動的な入力チェック処理)  =============
    // 削除指定されているdelegatorPidとassignerPid(ログイン実施者のpid)で定義されているPKが、DBテーブル上に存在しているかチェック (W00106)
    const error = await isExistsUsersDelegators(prisma, props.delegatorPid, pid);
    if (error) {
        result.error = error;
        return result;
    }
    // ==========  終了 入力チェックエラー(ajvで判定できない動的な入力チェック処理)  =============
    await deleteUsersDelegator(prisma, user, props);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map