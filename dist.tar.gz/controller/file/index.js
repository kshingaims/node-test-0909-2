import { checkGetParamsNumber } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid, } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
import { checkExistingSchedTotalSizeOrReturnError, createSchedFile, deleteSchedFile, checkValidate, changeFilenameIfNotUnique, } from '../../service/file/schedFileService.js';
import { deleteExpenseAttachment, deleteSchedAttachment, deletePublicContainerAttachment, downloadExpenseAttachment, downloadPublicContainerAttachment, downloadSchedAttachment, saveExpenseAttachment, savePublicContainerAttachment, saveSchedAttachment, } from '../../utils/azureBlob.js';
import { checkExistingExpenseTotalSizeOrReturnError, createExpenseFile, deleteExpenseFile, getFileExpense, } from '../../service/file/expenseFileService.js';
import { checkExistingPublicContainerTotalSizeOrReturnError, createPublicContainerFile, deletePublicContainerFile, getFilePublicContainer, } from '../../service/file/publicContainerFileService.js';
// SCHED
export const SCHED_FILE_DOWNLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'schedType'],
    properties: {
        schedType: {
            enum: ['schedFlight', 'schedHotel', 'schedCompanyCar', 'schedTransportation', 'schedEvent'],
            description: '予定のタイプ',
        },
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: 'ファイルID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function fileSchedDownload(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 海外拠点担当者の場合の旅程ID(itinearryId)と対象アカウント(assignerPid)取得処理
    let checkForeignStaffAccessResult;
    const fileId = Number(props.id);
    const schedType = props.schedType;
    let foreignStaffItineraryId = undefined;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            foreignStaffItineraryId = checkForeignStaffAccessResult.itineraryId;
            // pidは手配実施者のものとして処理する。
            pid = checkForeignStaffAccessResult.assignerPid;
        }
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // ファイル予定IDを指定してDBから取得
    const fileSchedResult = await checkValidate(prisma, pid, schedType, fileId, foreignStaffItineraryId);
    // 入力チェックでエラーの場合
    if ('code' in fileSchedResult) {
        result.error = fileSchedResult;
        return result;
    }
    // ファイルの取得処理
    // 添付ファイルレコードの中にあるurl(path)を利用して、azure blobストレージにアクセスして、該当ファイルをダウンロードする。
    const base64FromDl = await downloadSchedAttachment(fileSchedResult.path);
    // 入力チェックでエラーの場合
    if ('error' in base64FromDl) {
        result.error = base64FromDl.error;
        return result;
    }
    // データ取得成功の場合
    result.isSuccess = true;
    result.data = {
        base64: base64FromDl.base64,
        originalFileName: fileSchedResult.originalFileName,
        size: fileSchedResult.size,
    };
    return result;
}
export const SCHED_FILE_UPLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['schedType', 'schedId', 'fileInfo'],
    properties: {
        schedType: {
            enum: ['schedFlight', 'schedHotel', 'schedCompanyCar', 'schedTransportation', 'schedEvent'],
            description: '予定のタイプ',
        },
        schedId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '予定ID',
        },
        fileInfo: {
            type: 'object',
            additionalProperties: false,
            required: ['base64', 'originalFileName', 'size'],
            properties: {
                base64: {
                    type: 'string',
                    description: 'Base64で文字列変換されたファイルデータ。画像圧縮時のbase64に含まれる「data:image/XXXXX;base64,」は取り除いたもの',
                },
                originalFileName: {
                    type: 'string',
                    maxLength: 270,
                    description: '元々のファイル名',
                },
                size: {
                    type: 'integer',
                    format: 'int64',
                    maximum: 4294967295,
                    minimum: 1,
                    description: 'ファイルサイズ',
                },
            },
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 該当するXXX予定に紐つく添付ファイルをアップロードする。
 * @param props
 * @param { pid, prisma, user }
 * @returns
 */
export async function fileSchedUpload(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let foreignStaffItineraryId = undefined;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else if (props.schedType === 'schedCompanyCar' ||
            props.schedType === 'schedFlight' ||
            props.schedType === 'schedHotel') {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        }
        else {
            foreignStaffItineraryId = checkForeignStaffAccessResult.itineraryId;
            // pidは手配実施者のものとして処理する。
            pid = checkForeignStaffAccessResult.assignerPid;
        }
    }
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkExistingSchedTotalSizeOrReturnError(pid, prisma, props.schedType, props.schedId, foreignStaffItineraryId);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        if ('error' in inputCheckResult) {
            result.error = inputCheckResult.error;
            return result;
        }
    }
    if (inputCheckResult?.totalFileSize === undefined) {
        // 入力チェックでエラーが発生していないため。totalFileSizeは必ず存在する前提
        throw new Error('unreachable error.');
    }
    // azure blobストレージにアップロードする
    const totalFileSize = inputCheckResult.totalFileSize;
    // 重複するファイル名があれば、ファイル名に枝番をつけてユニークなファイル名に変更しておく
    props.fileInfo.originalFileName = changeFilenameIfNotUnique(props.fileInfo.originalFileName, inputCheckResult.existFilenames);
    const saveSchedAttachmentResult = await saveSchedAttachment(props.fileInfo, props.schedType, totalFileSize);
    // 外部連携でエラーの場合
    if ('error' in saveSchedAttachmentResult) {
        result.error = saveSchedAttachmentResult.error;
        return result;
    }
    // azure blobストレージからのレスポンス結果情報(path/size)が存在するかチェック
    if (saveSchedAttachmentResult.path === undefined || saveSchedAttachmentResult.size === undefined) {
        // アップロードが成功していればここには到達しない前提
        throw new Error('unreachable error.');
    }
    // azure blobストレージにアップロードした添付ファイル情報をDBに新規登録
    const schedFile = await createSchedFile(prisma, pid, user, props.schedType, props.schedId, props.fileInfo.originalFileName, // クライアントからの値を利用
    saveSchedAttachmentResult.path, // azure blobストレージの結果を利用
    saveSchedAttachmentResult.size // azure blobストレージの結果を利用
    );
    if (schedFile === undefined) {
        // 今回作成したファイルは必ず存在する前提なのでここには到達しない
        throw new Error('unreachable error.');
    }
    result.data = schedFile;
    result.isSuccess = true;
    return result;
}
export const SCHED_FILE_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ファイル予定ID',
        },
        schedType: {
            enum: ['schedFlight', 'schedHotel', 'schedCompanyCar', 'schedTransportation', 'schedEvent'],
            description: '予定のタイプ',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function fileSchedDelete(props, { user, pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const fileId = props.id;
    const schedType = props.schedType;
    let checkForeignStaffAccessResult;
    let foreignStaffItineraryId = undefined;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
            // 海外拠点担当は、フライト予定・ホテル予定の編集はできないのでパラメータ不正として処理
        }
        else if (props.schedType === 'schedFlight' || props.schedType === 'schedHotel') {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        }
        else {
            foreignStaffItineraryId = checkForeignStaffAccessResult.itineraryId;
            // 海外拠点担当の場合は、pidとして、社有車手配を実施した出張者を利用する
            pid = checkForeignStaffAccessResult.assignerPid;
        }
    }
    // ファイル予定IDを指定してDBから取得
    const fileSchedResult = await checkValidate(prisma, pid, schedType, fileId, foreignStaffItineraryId, true);
    // 入力チェックでエラーの場合
    if ('code' in fileSchedResult) {
        result.error = fileSchedResult;
        return result;
    }
    // ファイルの物理削除処理
    // 添付ファイルレコードの中にあるurlを利用して、azure blobストレージにアクセスして、該当ファイルを削除(物理削除)する。
    if (fileSchedResult?.path === undefined) {
        // 今回取得したpathは必ず存在するはず
        throw new Error('unreachable error.');
    }
    // azure blobストレージからファイルを削除する
    const base64FromDelete = await deleteSchedAttachment(fileSchedResult.path);
    // 入力チェックでエラーの場合
    if ('error' in base64FromDelete) {
        result.error = base64FromDelete.error;
        return result;
    }
    // 該当する添付ファイルレコードをDBから削除する(物理削除)する。
    await deleteSchedFile(prisma, props.schedType, props.id);
    result.isSuccess = true;
    return result;
}
// EXPENSE
export const EXPENSE_FILE_DOWNLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'expenseType'],
    properties: {
        expenseType: {
            enum: ['expenseAccommodation', 'expenseTransportation', 'expenseOther'],
            description: '経費のタイプ',
        },
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: 'ファイルID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function fileExpenseDownload(props, // idはファイルID
{ pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const fileId = Number(props.id);
    const expenseType = props.expenseType;
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // ファイル経費IDを指定してDBから取得
    const fileExpenseResult = await getFileExpense(prisma, pid, expenseType, fileId);
    // 入力チェックでエラーの場合
    if ('code' in fileExpenseResult) {
        result.error = fileExpenseResult;
        return result;
    }
    // ファイルの取得処理
    // 添付ファイルレコードの中にあるurl(path)を利用して、azure blobストレージにアクセスして、該当ファイルをダウンロードする。
    const base64FromDl = await downloadExpenseAttachment(fileExpenseResult.path);
    // 入力チェックでエラーの場合
    if ('error' in base64FromDl) {
        result.error = base64FromDl.error;
        return result;
    }
    // データ取得成功の場合
    result.isSuccess = true;
    result.data = {
        base64: base64FromDl.base64,
        originalFileName: fileExpenseResult.originalFileName,
        size: fileExpenseResult.size,
    };
    return result;
}
export const EXPENSE_FILE_UPLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['expenseType', 'expenseCategoryId', 'fileInfo'],
    properties: {
        expenseType: {
            enum: ['expenseAccommodation', 'expenseTransportation', 'expenseOther'],
            description: '経費のタイプ',
        },
        expenseCategoryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費項目ID',
        },
        fileInfo: {
            type: 'object',
            additionalProperties: false,
            required: ['base64', 'originalFileName', 'size'],
            properties: {
                base64: {
                    type: 'string',
                    description: 'Base64で文字列変換されたファイルデータ。画像圧縮時のbase64に含まれる「data:image/XXXXX;base64,」は取り除いたもの',
                },
                originalFileName: {
                    type: 'string',
                    maxLength: 270,
                    description: '元々のファイル名',
                },
                size: {
                    type: 'integer',
                    format: 'int64',
                    maximum: 4294967295,
                    minimum: 1,
                    description: 'ファイルサイズ',
                },
            },
        },
    },
};
/**
 * 該当する経費項目に紐つく添付ファイルをアップロードする。
 * @param props
 * @param { pid, prisma, user }
 * @returns
 */
export async function fileExpenseUpload(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkExistingExpenseTotalSizeOrReturnError(pid, prisma, props.expenseType, props.expenseCategoryId);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        if ('error' in inputCheckResult) {
            result.error = inputCheckResult.error;
            return result;
        }
    }
    if (inputCheckResult?.totalFileSize === undefined) {
        // 入力チェックでエラーが発生していないため。totalFileSizeは必ず存在する前提
        throw new Error('unreachable error.');
    }
    // azure blobストレージにアップロードする
    const totalFileSize = inputCheckResult?.totalFileSize;
    const saveExpenseAttachmentResult = await saveExpenseAttachment(props.fileInfo, props.expenseType, totalFileSize);
    // 外部連携でエラーの場合
    if ('error' in saveExpenseAttachmentResult) {
        result.error = saveExpenseAttachmentResult.error;
        return result;
    }
    // azure blobストレージからのレスポンス結果情報(path/size)が存在するかチェック
    if (saveExpenseAttachmentResult.path === undefined || saveExpenseAttachmentResult.size === undefined) {
        // アップロードが成功していればここには到達しない前提
        throw new Error('unreachable error.');
    }
    // azure blobストレージにアップロードした添付ファイル情報をDBに新規登録
    const expenseFile = await createExpenseFile(prisma, pid, user, props.expenseType, props.expenseCategoryId, props.fileInfo.originalFileName, // クライアントからの値を利用
    saveExpenseAttachmentResult.path, // azure blobストレージの結果を利用
    saveExpenseAttachmentResult.size // azure blobストレージの結果を利用
    );
    if (expenseFile === undefined) {
        // 今回作成したファイルは必ず存在する前提なのでここには到達しない
        throw new Error('unreachable error.');
    }
    result.data = expenseFile;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_FILE_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ファイルID',
        },
        expenseType: {
            enum: ['expenseAccommodation', 'expenseTransportation', 'expenseOther'],
            description: '経費タイプ',
        },
    },
};
export async function fileExpenseDelete(props, { pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const fileId = Number(props.id);
    const expenseType = props.expenseType;
    // ファイル経費IDを指定してDBから取得
    const fileExpenseResult = await getFileExpense(prisma, pid, expenseType, fileId);
    // 入力チェックでエラーの場合
    if ('code' in fileExpenseResult) {
        result.error = fileExpenseResult;
        return result;
    }
    /**
     * ファイルの物理削除処理
     * 添付ファイルレコードの中にあるurlを利用して、azure blobストレージにアクセスして、該当ファイルを削除(物理削除)する。
     */
    if (fileExpenseResult?.path === undefined) {
        // 今回取得したpathは必ず存在するはず
        throw new Error('unreachable error.');
    }
    // azure blobストレージからファイルを削除する
    const base64FromDelete = await deleteExpenseAttachment(fileExpenseResult?.path);
    // 入力チェックでエラーの場合
    if ('error' in base64FromDelete) {
        result.error = base64FromDelete.error;
        return result;
    }
    // 該当する添付ファイルレコードをDBから削除する(物理削除)する。
    await deleteExpenseFile(prisma, props.expenseType, props.id);
    result.isSuccess = true;
    return result;
}
// PUBLIC CONTAINER
export const PUBLIC_CONTAINER_FILE_DOWNLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'publicContainerType'],
    properties: {
        publicContainerType: {
            enum: ['hotel', 'companyCar', 'driver'],
            description: 'ファイルのタイプ',
        },
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: 'ファイルID',
        },
    },
};
export async function filePublicContainerDownload(props, // idはファイルID
{ user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const fileId = Number(props.id);
    const publicContainerType = props.publicContainerType;
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // ファイル関連IDを指定してDBから取得
    const filePublicContainerResult = await getFilePublicContainer(prisma, user, publicContainerType, fileId);
    // 入力チェックでエラーの場合
    if ('code' in filePublicContainerResult) {
        result.error = filePublicContainerResult;
        return result;
    }
    // ファイルの取得処理
    // 添付ファイルレコードの中にあるurl(path)を利用して、azure blobストレージにアクセスして、該当ファイルをダウンロードする。
    const base64FromDl = await downloadPublicContainerAttachment(filePublicContainerResult.path);
    // 入力チェックでエラーの場合
    if ('error' in base64FromDl) {
        result.error = base64FromDl.error;
        return result;
    }
    // データ取得成功の場合
    result.isSuccess = true;
    result.data = {
        base64: base64FromDl.base64,
        originalFileName: filePublicContainerResult.originalFileName,
        size: filePublicContainerResult.size,
    };
    return result;
}
export const PUBLIC_CONTAINER_FILE_UPLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['publicContainerType', 'id', 'fileInfo'],
    properties: {
        publicContainerType: {
            enum: ['hotel', 'companyCar', 'driver'],
            description: 'ファイルのタイプ',
        },
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '関連テーブル情報のid',
        },
        fileInfo: {
            type: 'object',
            additionalProperties: false,
            required: ['base64', 'originalFileName', 'size'],
            properties: {
                base64: {
                    type: 'string',
                    description: 'Base64で文字列変換されたファイルデータ。画像圧縮時のbase64に含まれる「data:image/XXXXX;base64,」は取り除いたもの',
                },
                originalFileName: {
                    type: 'string',
                    maxLength: 270,
                    description: '元々のファイル名',
                },
                size: {
                    type: 'integer',
                    format: 'int64',
                    maximum: 4294967295,
                    minimum: 1,
                    description: 'ファイルサイズ',
                },
            },
        },
    },
};
/**
 * 該当する関連テーブル情報に紐つく添付ファイルをアップロードする。
 * @param props
 * @param { pid, prisma, user }
 * @returns
 */
export async function filePublicContainerUpload(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkExistingPublicContainerTotalSizeOrReturnError(user, prisma, props.publicContainerType, props.id);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        if ('error' in inputCheckResult) {
            result.error = inputCheckResult.error;
            return result;
        }
    }
    if (inputCheckResult?.totalFileSize === undefined) {
        // 入力チェックでエラーが発生していないため。totalFileSizeは必ず存在する前提
        throw new Error('unreachable error.');
    }
    // azure blobストレージにアップロードする
    const totalFileSize = inputCheckResult?.totalFileSize;
    const savePublicContainerAttachmentResult = await savePublicContainerAttachment(props.fileInfo, props.publicContainerType, totalFileSize);
    // 外部連携でエラーの場合
    if ('error' in savePublicContainerAttachmentResult) {
        result.error = savePublicContainerAttachmentResult.error;
        return result;
    }
    // azure blobストレージからのレスポンス結果情報(path/size)が存在するかチェック
    if (savePublicContainerAttachmentResult.path === undefined ||
        savePublicContainerAttachmentResult.size === undefined) {
        // アップロードが成功していればここには到達しない前提
        throw new Error('unreachable error.');
    }
    // azure blobストレージにアップロードした添付ファイル情報をDBに新規登録
    const publicContainerFile = await createPublicContainerFile(prisma, pid, user, props.publicContainerType, props.id, props.fileInfo.originalFileName, // クライアントからの値を利用
    savePublicContainerAttachmentResult.path, // azure blobストレージの結果を利用
    savePublicContainerAttachmentResult.size // azure blobストレージの結果を利用
    );
    if (publicContainerFile === undefined) {
        // 今回作成したファイルは必ず存在する前提なのでここには到達しない
        throw new Error('unreachable error.');
    }
    result.data = publicContainerFile;
    result.isSuccess = true;
    return result;
}
export const PUBLIC_CONTAINER_FILE_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ファイルID',
        },
        publicContainerType: {
            enum: ['hotel', 'companyCar', 'driver'],
            description: 'ファイルのタイプ',
        },
    },
};
export async function filePublicContainerDelete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const fileId = props.id;
    const publicContainerType = props.publicContainerType;
    // ファイル関連IDを指定してDBから取得
    const filePublicContainerResult = await getFilePublicContainer(prisma, user, publicContainerType, fileId);
    // 入力チェックでエラーの場合
    if ('code' in filePublicContainerResult) {
        result.error = filePublicContainerResult;
        return result;
    }
    // ファイルの物理削除処理
    // 添付ファイルレコードの中にあるurlを利用して、azure blobストレージにアクセスして、該当ファイルを削除(物理削除)する。
    if (filePublicContainerResult?.path === undefined) {
        // 今回取得したpathは必ず存在するはず
        throw new Error('unreachable error.');
    }
    // azure blobストレージからファイルを削除する
    const base64FromDelete = await deletePublicContainerAttachment(filePublicContainerResult.path);
    // 入力チェックでエラーの場合
    if ('error' in base64FromDelete) {
        result.error = base64FromDelete.error;
        return result;
    }
    // 該当する添付ファイルレコードをDBから削除する(物理削除)する。
    await deletePublicContainerFile(prisma, props.publicContainerType, props.id);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map