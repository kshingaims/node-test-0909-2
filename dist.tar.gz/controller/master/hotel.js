import { createHotel, updateHotel, deleteHotel, searchHotels, listHotels, } from '../../service/master/hotelService.js';
import { splitKeyword } from '../../utils/index.js';
import { cloneDeep } from 'lodash-es';
export const MASTER_HOTEL_SERACH_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['cityCodes'],
    properties: {
        keyword: {
            type: 'string',
            maxLength: 511,
        },
        cityCodes: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'string',
                maxLength: 7,
            },
        },
    },
};
export async function search(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const keywords = splitKeyword(props.keyword);
    const list = await searchHotels(prisma, keywords, props.cityCodes);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const MASTER_HOTEL_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        limitGroup: {
            type: 'string',
            maxLength: 1,
        },
    },
};
export async function list(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const list = await listHotels(prisma, user, props.limitGroup);
    result.data = list;
    result.isSuccess = true;
    return result;
}
const MASTER_HOTEL_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['cityId', 'googlePlaceId', 'name', 'googleLocation', 'hotelRooms'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ホテルID',
        },
        cityId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '都市ID',
        },
        googlePlaceId: {
            type: 'string',
            maxLength: 2047,
            description: 'Googleが提供する場所情報データベース（Google Places Database）内の特定の場所や施設を一意に識別するための識別子',
        },
        name: {
            type: 'string',
            maxLength: 255,
            description: 'ホテル名',
        },
        address: {
            type: 'string',
            maxLength: 511,
            description: '住所',
        },
        accessToOfficeMinute: {
            type: ['integer', 'null'],
            format: 'int64',
            maximum: 65535,
            minimum: 0,
            description: 'オフィスへのアクセス時間',
        },
        meansOfAccess: {
            enum: ['car', 'walk', 'train'],
        },
        checkInOut: {
            type: 'string',
            maxLength: 511,
            description: 'チェックイン/チェックアウト時間に関する情報',
        },
        url: {
            type: 'string',
            maxLength: 1023,
            description: 'ウェブサイトURL',
        },
        tel: {
            type: 'string',
            maxLength: 50,
            description: 'Tel',
        },
        hotelEmail: {
            type: ['string', 'null'],
            maxLength: 255,
            format: 'email',
            description: 'ホテルEmail',
        },
        reservationTel: {
            type: 'string',
            maxLength: 50,
            description: '予約用電話番号',
        },
        reservationEmail: {
            type: ['string', 'null'],
            maxLength: 255,
            format: 'email',
            description: 'ホテル予約用のEmail',
        },
        reservationInfo: {
            type: 'string',
            maxLength: 511,
            description: '予約先情報や予約コードなどの予約処理に関する情報',
        },
        breakfast: {
            type: 'string',
            maxLength: 511,
            description: 'ホテルの朝食に関する情報',
        },
        note: {
            type: 'string',
            maxLength: 1023,
            description: 'メモ',
        },
        recommendation: {
            type: ['integer', 'null'],
            format: 'int64',
            maximum: 5,
            minimum: 0,
            description: 'お勧め度(整数の0～5段階)',
        },
        recommendationPoint: {
            type: 'string',
            maxLength: 511,
            description: 'お勧めポイント',
        },
        googleRating: {
            type: 'number',
            maximum: 5,
            minimum: 0,
            validatePrecision: 1,
            description: 'googleの評価値',
        },
        googleLocation: {
            type: 'object',
            description: 'google mapで表示する際の緯度・経度情報',
            additionalProperties: false,
            required: ['lat', 'lng'],
            properties: {
                lat: {
                    type: 'number',
                    maximum: 90,
                    minimum: -90,
                    validatePrecision: 7,
                    description: '緯度',
                },
                lng: {
                    type: 'number',
                    maximum: 180,
                    minimum: -180,
                    validatePrecision: 7,
                    description: '経度',
                },
            },
        },
        hotelRooms: {
            type: 'array',
            minItems: 1,
            description: 'ホテルの部屋一覧',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['name', 'price', 'currency'],
                properties: {
                    id: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: 'ホテルルームID',
                    },
                    name: {
                        type: 'string',
                        maxLength: 255,
                        description: 'ホテル名',
                    },
                    price: {
                        type: 'number',
                        maximum: 99999999.99,
                        minimum: 0.01,
                        validatePrecision: 2,
                    },
                    currency: {
                        type: 'string',
                        maxLength: 3,
                        description: '通貨',
                    },
                    note: {
                        type: 'string',
                        maxLength: 1023,
                        description: 'メモ',
                    },
                },
            },
        },
    },
};
export const MASTER_HOTEL_CREATE_SCHEMA = cloneDeep(MASTER_HOTEL_SCHEMA);
export async function create(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Hotelの新規登録処理
    const hotel = await createHotel(prisma, user, props);
    result.data = hotel;
    result.isSuccess = true;
    return result;
}
export const MASTER_HOTEL_UPDATE_SCHEMA = cloneDeep(MASTER_HOTEL_SCHEMA);
MASTER_HOTEL_UPDATE_SCHEMA.required.push('id');
export async function update(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Hotelの更新処理
    const updateResult = await updateHotel(prisma, user, props);
    if (updateResult !== undefined) {
        result.error = updateResult;
    }
    else {
        result.isSuccess = true;
    }
    return result;
}
export const MASTER_HOTEL_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ホテルID。更新時は指定必須。',
        },
    },
};
// deleteが予約後であり、サービスにdeleteHotelが存在するのでhotelDeleteとする
export async function hotelDelete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Hotelの更新処理
    const deleteResult = await deleteHotel(prisma, user, props.id);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (deleteResult !== undefined) {
        result.error = deleteResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=hotel.js.map