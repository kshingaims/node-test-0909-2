import { getCompanions, searchUsers, updateCalendarSync as updateCalendarSyncService, updateWebpushDeviceInfo as updateWebpushDeviceInfoService, } from '../../service/user/userService.js';
import { checkGetParamsNumber, splitKeyword } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
import { getUserPhone } from '../../service/snowflake/snowflakeService.js';
export const USER_SERACH_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['keyword'],
    properties: {
        keyword: {
            type: 'string',
            maxLength: 511,
        },
    },
};
export async function search(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const keywords = splitKeyword(props.keyword);
    const list = await searchUsers(prisma, keywords);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const USER_EXPANSION_LIST = {
    type: 'object',
    additionalProperties: false,
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function getUserExpansionList(props, { user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let itineraryId = undefined;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        // assignerPidをpidとして利用
        // pid = checkForeignStaffAccessResult.assignerPid;
        itineraryId = checkForeignStaffAccessResult.itineraryId;
    }
    else {
        if (!props.itineraryId || !checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    const users = await getCompanions(prisma, itineraryId);
    // snowflakeからユーザの電話番号を取得する。
    await getUserPhone(users);
    result.data = users;
    result.isSuccess = true;
    return result;
}
export const USER_UPDATE_CALENDAR_SYNC_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['flgCalendarSync'],
    properties: {
        flgCalendarSync: {
            type: 'boolean',
            description: 'カレンダー同期設定フラグ。true：mircosoft calendar予定を取り込む。false：取り込まない',
        },
    },
};
export async function userUpdateCalendarSync(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    await updateCalendarSyncService(prisma, pid, props.flgCalendarSync);
    result.isSuccess = true;
    return result;
}
export const USER_UPDATE_WEBPUSH_DEVICE_INFO = {
    type: 'object',
    additionalProperties: false,
    required: ['webpushDeviceInfo'],
    properties: {
        webpushDeviceInfo: {
            type: 'object',
            description: 'web push実施対象端末のデバイス情報。JSONオブジェクト',
        },
    },
};
export async function updateWebpushDeviceInfo(
// eslint-disable-next-line @typescript-eslint/no-explicit-any
props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    await updateWebpushDeviceInfoService(prisma, user.pid, props.webpushDeviceInfo);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=user.js.map