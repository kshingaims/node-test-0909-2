import { getFaqs } from '../../service/master/faqService.js';
export async function faqList(_props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const list = await getFaqs(prisma);
    // FAQ一覧をカテゴリー毎にツリー構造上に変換する。
    result.data = formatFaqs(list);
    result.isSuccess = true;
    return result;
}
export function formatFaqs(faqs) {
    const result = [];
    const checker = {};
    for (const faq of faqs) {
        const cat1Key = faq.category1;
        const cat2Key = faq.category1 + faq.category2;
        let cat1;
        if (checker[cat1Key]) {
            cat1 = checker[cat1Key];
        }
        else {
            cat1 = { category: faq.category1, list: [] };
            checker[cat1Key] = cat1;
            result.push(cat1);
        }
        let cat2;
        if (checker[cat2Key]) {
            cat2 = checker[cat2Key];
        }
        else {
            cat2 = { category: faq.category2 };
            checker[cat2Key] = cat2;
            cat1.list.push(cat2);
        }
        if (faq.category3) {
            const cat3 = { category: faq.category3, linkUrl: faq.linkUrl };
            if (!cat2.list) {
                cat2.list = [];
            }
            cat2.list.push(cat3);
        }
        else {
            cat2.linkUrl = faq.linkUrl;
        }
    }
    return result;
}
//# sourceMappingURL=faq.js.map