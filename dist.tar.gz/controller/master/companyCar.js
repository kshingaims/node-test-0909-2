import { createCompanyCar, updateCompanyCar, deleteCompanyCar, listCompanyCars, searchCompanyCars, getNotVacantCompanyCarIds, } from '../../service/master/companyCarService.js';
import { Define } from '../../utils/define.js';
import { checkGetParamsNumber, splitKeyword } from '../../utils/index.js';
export const MASTER_COMPANY_CAR_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        limitGroup: {
            type: 'string',
            maxLength: 1,
            pattern: '^[01]+',
        },
    },
};
export async function list(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const list = await listCompanyCars(prisma, user, props.limitGroup);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const MASTER_COMPANY_CAR_SEARCH_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        keyword: {
            type: 'string',
            maxLength: 511,
        },
        checkVacancy: {
            type: 'string',
            maxLength: 1,
            pattern: '^[01]+',
            description: '海外拠点社有車予定の空き時間となっている社有車のみを取得対象とするかどうか。1:空き時間のみ取得。0:空き時間チェックしない',
        },
        from: {
            type: 'string',
            format: 'date-time',
            description: '海外拠点社有車予定の空き時間検索。利用開始時刻。日付フォーマットはISO8601形式。checkVacancy=1の時は必須。',
        },
        to: {
            type: 'string',
            format: 'date-time',
            description: '海外拠点社有車予定の空き時間検索。利用終了時刻。日付フォーマットはISO8601形式。checkVacancy=1の時は必須。',
        },
        limitGroup: {
            type: 'string',
            maxLength: 1,
            pattern: '^[01]+',
        },
        excludeForeignStaffSchedCompanyCarId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '空き状況社有車判定時に、チェック対象外とする海外拠点担当用社有車予定id',
        },
    },
};
export async function search(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let exculdeIds = [];
    let mcSyozokuCd = undefined;
    // 海外拠点社有車予定の空き時間チェックを実施する場合
    if (props.checkVacancy === Define.SETTINGS.GET_REQUEST_PARAM_TRUE) {
        if (!props.from || !props.to) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        if (!checkGetParamsNumber(props.excludeForeignStaffSchedCompanyCarId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        const foreignStaffSchedCompanyCarId = Number(props.excludeForeignStaffSchedCompanyCarId || 0);
        exculdeIds = await getNotVacantCompanyCarIds(prisma, props.from, props.to, foreignStaffSchedCompanyCarId);
    }
    if (props.limitGroup === Define.SETTINGS.LIMIT_GROUP.ONLY_MY_SYOZOKU_GROUP) {
        mcSyozokuCd = user.mcSyozokuCd;
    }
    const keywords = splitKeyword(props.keyword);
    const list = await searchCompanyCars(prisma, keywords, exculdeIds, mcSyozokuCd);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const MASTER_COMPANY_CAR_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['carNo', 'carModel', 'carColor'],
    properties: {
        carNo: {
            type: 'string',
            maxLength: 50,
            description: '自動車登録番号(ナンバープレート)',
        },
        carModel: {
            type: 'string',
            maxLength: 50,
            description: '車種',
        },
        carColor: {
            type: 'string',
            maxLength: 50,
            description: '車体カラー',
        },
        driverId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ドライバーID',
        },
    },
};
export async function create(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // driverIdの指定がある場合は、driverIdがDBに存在するかをチェック
    const driver = await prisma.driver.findFirst({
        where: { id: props.driverId, flgDelete: false, mcSyozokuCd: user.mcSyozokuCd },
    });
    if (!driver) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // CompanyCarの新規登録処理
    const createCompanyCarResult = await createCompanyCar(prisma, user, props);
    result.data = {
        id: createCompanyCarResult.id,
        carNo: createCompanyCarResult.carNo,
        carModel: createCompanyCarResult.carModel,
        carColor: createCompanyCarResult.carColor,
        driverId: createCompanyCarResult.driverId,
    };
    result.isSuccess = true;
    return result;
}
export const MASTER_COMPANY_CAR_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'carNo', 'carModel', 'carColor'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '社有車ID。更新時は指定必須。',
        },
        carNo: {
            type: 'string',
            maxLength: 50,
            description: '自動車登録番号(ナンバープレート)',
        },
        carModel: {
            type: 'string',
            maxLength: 50,
            description: '車種',
        },
        carColor: {
            type: 'string',
            maxLength: 50,
            description: '車体カラー',
        },
        driverId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ドライバーID',
        },
    },
};
export async function update(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // driverIdの指定がある場合は、driverIdがDBに存在するかをチェック
    const driver = await prisma.driver.findFirst({
        where: { id: props.driverId, flgDelete: false, mcSyozokuCd: user.mcSyozokuCd },
    });
    if (props.driverId && !driver) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // CompanyCarの更新処理
    const updateResult = await updateCompanyCar(prisma, user, props);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (updateResult !== undefined) {
        result.error = updateResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
export const MASTER_COMPANY_CAR_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '社有車ID',
        },
    },
};
// deleteが予約後であり、サービスにdeleteCompanyCarが存在するのでcompanyCarDeleteとする
export async function companyCarDelete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // CompanyCarの更新処理
    const deleteResult = await deleteCompanyCar(prisma, user, props.id);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (deleteResult !== undefined) {
        result.error = deleteResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=companyCar.js.map