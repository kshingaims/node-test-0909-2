import { isCityCodeUnique, createCity, updateCity, deleteCity, searchCities, searchCountryOrCity, listCities, } from '../../service/master/cityService.js';
import { log } from '../../utils/logger.js';
import { splitKeyword } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { getPlaceTimezoneByCordinates } from '../../service/azure/timezoneApiService.js';
export async function search(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const keywords = splitKeyword(props.keyword);
    const list = await searchCities(prisma, keywords);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const MASTER_CITY_SEARCH_FROM_COUNTRY_CITY_NAME_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['enCountry'],
    properties: {
        enCountry: {
            type: 'string',
            maxLength: 1023,
            description: '国名',
        },
        enCities: {
            type: 'array',
            items: {
                type: 'string',
                maxLength: 1023,
                description: '都市名(英語)',
            },
        },
    },
};
export async function searchFromCountryCityName(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const list = await searchCountryOrCity(prisma, props.enCountry, props.enCities);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export async function list(_props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const list = await listCities(prisma);
    result.data = list;
    result.isSuccess = true;
    return result;
}
const MASTER_CITY_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['countryCode', 'countryRoma', 'country', 'cityCode', 'currency'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '都市ID。更新時は指定必須。',
        },
        countryCode: {
            type: 'string',
            maxLength: 4,
            description: '国コード',
        },
        countryRoma: {
            type: 'string',
            maxLength: 50,
        },
        country: {
            type: 'string',
            maxLength: 50,
            description: '国',
        },
        cityCode: {
            type: 'string',
            maxLength: 7,
            description: '都市コード',
        },
        cityRoma: {
            type: 'string',
            maxLength: 50,
        },
        city: {
            type: 'string',
            maxLength: 50,
            description: '都市',
        },
        cityTimezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: '都市タイムゾーン',
        },
        currency: {
            type: 'string',
            maxLength: 3,
            pattern: '^[A-Z]{3}$',
            description: '通貨',
        },
        azureLocation: {
            type: 'object',
            description: 'azure timezone APIで利用する緯度・経度情報',
            additionalProperties: false,
            required: ['lat', 'lng'],
            properties: {
                lat: {
                    type: 'number',
                    maximum: 90,
                    minimum: -90,
                    validatePrecision: 4,
                },
                lng: {
                    type: 'number',
                    maximum: 180,
                    minimum: -180,
                    validatePrecision: 4,
                },
            },
        },
    },
};
export const MASTER_CITY_CREATE_SCHEMA = { ...MASTER_CITY_SCHEMA };
export async function create(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 都市コードがユニークであるかのチェック
    if (!(await isCityCodeUnique(prisma, props.cityCode))) {
        result.error = { code: Define.ERROR_CODES.W00502, status: 200 };
        return result;
    }
    const timezoneInfo = await getPlaceTimezoneByCordinates(log, props.azureLocation.lat, props.azureLocation.lng);
    props.timeTransitions = timezoneInfo.timeTransitions;
    props.timezoneLabel = timezoneInfo.timezoneLabel;
    props.cityTimezone = timezoneInfo.timezone || props.cityTimezone;
    if (!props.city) {
        props.city = '－';
    }
    if (!props.cityRoma) {
        props.cityRoma = '－';
    }
    // Cityの新規登録処理
    await createCity(prisma, user, props);
    result.isSuccess = true;
    return result;
}
export const MASTER_CITY_UPDATE_SCHEMA = { ...MASTER_CITY_SCHEMA };
MASTER_CITY_UPDATE_SCHEMA.required = ['id', 'countryCode', 'countryRoma', 'country', 'cityCode', 'currency'];
export async function update(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const timezoneInfo = await getPlaceTimezoneByCordinates(log, props.azureLocation.lat, props.azureLocation.lng);
    props.timeTransitions = timezoneInfo.timeTransitions;
    props.timezoneLabel = timezoneInfo.timezoneLabel;
    props.cityTimezone = timezoneInfo.timezone || props.cityTimezone;
    if (!props.city) {
        props.city = '－';
    }
    if (!props.cityRoma) {
        props.cityRoma = '－';
    }
    // Cityの更新処理
    const updateResult = await updateCity(prisma, user, props);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (updateResult !== undefined) {
        result.error = updateResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
export const MASTER_CITY_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '都市ID。更新時は指定必須。',
        },
    },
};
// deleteが予約後であり、サービスにdeleteCityが存在するのでcityDeleteとする
export async function cityDelete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Cityの更新処理
    const deleteResult = await deleteCity(prisma, user, props.id);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (deleteResult !== undefined) {
        result.error = deleteResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=city.js.map