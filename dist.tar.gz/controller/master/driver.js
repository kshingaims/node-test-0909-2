import { createDriver, updateDriver, deleteDriver, listDrivers, getNotVacantDriverIds, searchDrivers, } from '../../service/master/driverService.js';
import { Define } from '../../utils/define.js';
import { checkGetParamsNumber, splitKeyword } from '../../utils/index.js';
export const MASTER_DRIVER_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        limitGroup: {
            type: 'string',
            maxLength: 1,
            pattern: '^[01]+',
        },
    },
};
export async function list(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const list = await listDrivers(prisma, user, props.limitGroup);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const MASTER_DRIVER_SEARCH_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        keyword: {
            type: 'string',
            maxLength: 511,
        },
        checkVacancy: {
            type: 'string',
            maxLength: 1,
            pattern: '^[01]+',
            description: '海外拠点社有車予定の空き時間となっている社有車のみを取得対象とするかどうか。1:空き時間のみ取得。0:空き時間チェックしない',
        },
        from: {
            type: 'string',
            format: 'date-time',
            description: '海外拠点社有車予定の空き時間検索。利用開始時刻。日付フォーマットはISO8601形式。checkVacancy=1の時は必須。',
        },
        to: {
            type: 'string',
            format: 'date-time',
            description: '海外拠点社有車予定の空き時間検索。利用終了時刻。日付フォーマットはISO8601形式。checkVacancy=1の時は必須。',
        },
        limitGroup: {
            type: 'string',
            maxLength: 1,
            pattern: '^[01]+',
        },
        excludeForeignStaffSchedCompanyCarId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '空き状況社有車判定時に、チェック対象外とする海外拠点担当用社有車予定id',
        },
    },
};
export async function search(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let exculdeIds = [];
    let mcSyozokuCd = undefined;
    // 海外拠点社有車予定の空き時間チェックを実施する場合
    if (props.checkVacancy === Define.SETTINGS.GET_REQUEST_PARAM_TRUE) {
        if (!props.from || !props.to) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        if (!checkGetParamsNumber(props.excludeForeignStaffSchedCompanyCarId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        const foreignStaffSchedCompanyCarId = Number(props.excludeForeignStaffSchedCompanyCarId || 0);
        exculdeIds = await getNotVacantDriverIds(prisma, props.from, props.to, foreignStaffSchedCompanyCarId);
    }
    if (props.limitGroup === Define.SETTINGS.LIMIT_GROUP.ONLY_MY_SYOZOKU_GROUP) {
        mcSyozokuCd = user.mcSyozokuCd;
    }
    const keywords = splitKeyword(props.keyword);
    const list = await searchDrivers(prisma, keywords, exculdeIds, mcSyozokuCd);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const MASTER_DRIVER_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['name', 'tel'],
    properties: {
        name: {
            type: 'string',
            maxLength: 255,
            description: '氏名',
        },
        tel: {
            type: 'string',
            maxLength: 50,
            description: 'Tel',
        },
        email: {
            type: ['string', 'null'],
            format: 'email',
            maxLength: 255,
            description: 'Email',
        },
    },
};
export async function create(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Driverの新規登録処理
    const createResult = await createDriver(prisma, user, props);
    result.data = createResult;
    result.isSuccess = true;
    return result;
}
export const MASTER_DRIVER_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'name', 'tel'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ドライバーID。更新時は指定必須。',
        },
        name: {
            type: 'string',
            maxLength: 255,
            description: '氏名',
        },
        tel: {
            type: 'string',
            maxLength: 50,
            description: 'Tel',
        },
        email: {
            type: ['string', 'null'],
            format: 'email',
            maxLength: 255,
            description: 'Email',
        },
    },
};
export async function update(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Driverの更新処理
    const updateResult = await updateDriver(prisma, user, props);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (updateResult !== undefined) {
        result.error = updateResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
export const MASTER_DRIVER_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '社有車ID',
        },
    },
};
// deleteが予約後であり、サービスにdeleteDriverが存在するのでdriverDeleteとする
export async function driverDelete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // Driverの更新処理
    const deleteResult = await deleteDriver(prisma, user, props.id);
    // 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
    if (deleteResult !== undefined) {
        result.error = deleteResult;
        return result;
    }
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=driver.js.map