import { createFrontErrorLog } from '../../service/frontErrorLog/frontErrorLogService.js';
export const FRONT_ERROR_LOG_SEND_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['actionName', 'detail', 'url', 'clientInfo'],
    properties: {
        pid: {
            type: 'string',
            maxLength: 15,
            description: 'ログ送信実施したユーザID(PID)',
        },
        actionName: {
            type: 'string',
            maxLength: 255,
            description: 'フロント側処理内容。ユニークな名称となるようにしてください。',
        },
        detail: {
            type: 'string',
            maxLength: 2047,
            description: 'エラーの詳細内容。2047バイトでのサイズ制限があるので、サイズ制限を超えるエラー詳細内容は削除してください。',
        },
        url: {
            type: 'string',
            maxLength: 511,
            description: 'エラー発生したURL',
        },
        clientInfo: {
            type: 'string',
            maxLength: 511,
            description: 'クライアント端末情報(ユーザエージェント etc)',
        },
    },
};
export async function send(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    /**
     * 直近1週間(Define.SETTINGS.FRONT_ERROR_LOG_EXISTS_CHECK_TARGET_DAYS)で保存されているエラーログをチェックし、同じエラーを検知している場合はログ保存実施しないで終了。
     * エラーログが直近1週間で一度も検知していないものである場合は、ログのDB保存実施
     * */
    await createFrontErrorLog(prisma, props);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map