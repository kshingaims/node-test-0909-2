import { createTestUsers, updateDelegatorsExpired } from '../../jest/utils/index.js';
import { createTestHotels } from '../../jest/utils/testData/masterHotel.js';
import { createTestHotelRooms } from '../../jest/utils/testData/masterHotelRoom.js';
import { createTestDriverRooms } from '../../jest/utils/testData/driver.js';
import { TestDefine } from '../../jest/utils/testDefine.js';
import { isExists } from '../../service/user/userService.js';
import { log } from '../../utils/logger.js';
import { importCityMasterWithAccessAzureTimezoneApi } from '../../jobs/city/importCityMaster.js';
import { updateNotificationSettingJob } from '../../jobs/notification/updateNotificationSettingsJob.js';
export async function create(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // ==========  ユーザ作成処理
    if (!(await isExists(prisma, [
        TestDefine.PID.ADMIN,
        TestDefine.PID.OWNER1,
        TestDefine.PID.OWNER2,
        TestDefine.PID.COMPANION1,
        TestDefine.PID.COMPANION2,
        TestDefine.PID.COMPANION3,
        TestDefine.PID.COMPANION4,
        TestDefine.PID.COMPANION5,
        TestDefine.PID.DELEGATED1,
        TestDefine.PID.DELEGATED2,
        TestDefine.PID.DELEGATED3,
        TestDefine.PID.FOREIGN1,
        TestDefine.PID.FOREIGN2,
    ]))) {
        await createTestUsers(prisma);
    }
    // ==========  都市マスタ作成
    if ((await prisma.city.count()) <= 0) {
        await importCityMasterWithAccessAzureTimezoneApi(prisma, log);
    }
    // 委任者の有効期限切れがあれば有効期限以内に更新する
    await updateDelegatorsExpired(prisma);
    // ==========  ホテルマスタ作成
    if ((await prisma.hotel.count()) <= 0) {
        await createTestHotels(prisma);
    }
    // ==========  ホテルルームマスタ作成
    if ((await prisma.hotelRoom.count()) <= 0) {
        await createTestHotelRooms(prisma);
    }
    // ==========  ドライバーマスタ作成
    if ((await prisma.driver.count()) <= 0) {
        await createTestDriverRooms(prisma);
    }
    // 通知設定情報作成
    if ((await prisma.notificationSetting.count()) <= 0) {
        await updateNotificationSettingJob(log, prisma, 'to_do');
        await updateNotificationSettingJob(log, prisma, 'webpush');
        await updateNotificationSettingJob(log, prisma, 'site_notice');
        await updateNotificationSettingJob(log, prisma, 'smtp_mail');
    }
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map