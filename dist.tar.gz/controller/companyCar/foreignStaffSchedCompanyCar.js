import { checkGetParamsNumber, isFromDatetimeBeforeToDatetime, isTargetsValueEveryContained } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid, } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
import { getForeignStaffCompanyCarSchedList, createForeignStaffSchedCompanyCar, updateForeignStaffSchedCompanyCar, deleteForeignStaffSchedCompanyCar, checkValidateForSchedCreate, checkValidateForSchedUpdate, getForeignStaffCompanyCarSchedListForArrangeComplete, updateForeignStaffSchedChangeArrgt, } from '../../service/companyCar/foreignStaffCompanyCarService.js';
import { getCompanyCarSchedList, getSchedCompanyCarsForForeignStaffChangingFlgArrgt, sendArrgtFinishSmtpMailAndCreateSiteNotificationToCompanions, updateForeignStaffSchedCompanyIdByForeignStaff, updateSchedChangeArrgt, } from '../../service/companyCar/companyCarService.js';
import { isValid } from 'date-fns';
import { log } from '../../utils/logger.js';
export const FOREIGN_STAFF_SCHED_COMPANY_CAR_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['foreignStaffKey'],
    //必須プロパティはなし
    properties: {
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedList(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
    const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
    if ('error' in checkForeignStaffAccessResult) {
        result.error = checkForeignStaffAccessResult.error;
        return result;
    }
    const itineraryId = checkForeignStaffAccessResult.itineraryId;
    // 一覧取得実施
    result.data = await getForeignStaffCompanyCarSchedList(prisma, itineraryId);
    result.isSuccess = true;
    return result;
}
export const FOREIGN_STAFF_SCHED_COMPANY_CAR_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '社有車ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 指定された海外拠点用社有車予定IDに合致する海外拠点用社有車予定情報単数を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function sched(props, { user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
    const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
    if ('error' in checkForeignStaffAccessResult) {
        result.error = checkForeignStaffAccessResult.error;
        return result;
    }
    const itineraryId = checkForeignStaffAccessResult.itineraryId;
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const id = Number(props.id);
    // 一覧取得実施
    const list = await getForeignStaffCompanyCarSchedList(prisma, itineraryId, id);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const FOREIGN_STAFF_SCHED_COMPANY_CAR_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['foreignStaffKey', 'startDateTime', 'endDateTime', 'timezone', 'schedCompanyCarIds', 'arrangedCars'],
    properties: {
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
            description: '海外拠点アクセスキー。',
        },
        startDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        endDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        schedCompanyCarIds: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'integer',
                format: 'int64',
                maximum: 4294967295,
                minimum: 1,
                description: '社有車予定ID',
            },
        },
        arrangedCars: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                    companyCarId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '社有車ID',
                    },
                    carNo: {
                        type: 'string',
                        maxLength: 50,
                        description: '自動車登録番号(ナンバープレート)',
                    },
                    carModel: {
                        type: 'string',
                        maxLength: 50,
                        description: '車種',
                    },
                    carColor: {
                        type: 'string',
                        maxLength: 50,
                        description: '車体カラー',
                    },
                    driverId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: 'ドライバーID',
                    },
                    driverName: {
                        type: 'string',
                        maxLength: 255,
                        description: 'ドライバー氏名',
                    },
                    driverTel: {
                        type: 'string',
                        maxLength: 50,
                        description: 'ドライバーTel',
                    },
                    driverEmail: {
                        type: 'string',
                        maxLength: 255,
                        description: 'Email',
                    },
                },
            },
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
    },
};
export async function schedCreate(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // foreignStaffKeyを使って旅程情報へのアクセスが可能かをチェックし、可能であればitineraryIdを取得し、アクセス不可能の場合はerrorを取得する。
    const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
    if ('error' in checkForeignStaffAccessResult) {
        result.error = checkForeignStaffAccessResult.error;
        return result;
    }
    // itineraryIdは存在することが保証されているので、存在チェックは実施しない
    const itineraryId = checkForeignStaffAccessResult.itineraryId;
    const assignerPid = checkForeignStaffAccessResult.assignerPid;
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkValidateForSchedCreate(prisma, user, props);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 海外拠点担当用社有社予定の開始時間・終了時間に含まれている(候補となる)社有車予定を取得
    const items = await getSchedCompanyCarsForForeignStaffChangingFlgArrgt(prisma, itineraryId);
    const candidates = filterWithinInterval(items, props.startDateTime, props.endDateTime);
    // クライアントから紐付け対象として連携された社有車予定IDは、候補一覧に含まれている必要がある
    if (candidates.length <= 0 || !isTargetsValueEveryContained(props.schedCompanyCarIds, candidates)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 海外拠点用社有車予約の新規登録処理
    const foreignStaffSchedCompanyCar = await createForeignStaffSchedCompanyCar(prisma, user, props, itineraryId, assignerPid);
    // 社有車予定に紐付けを実施する。
    const ids = props.schedCompanyCarIds;
    await updateForeignStaffSchedCompanyIdByForeignStaff(prisma, itineraryId, ids, foreignStaffSchedCompanyCar.id);
    result.data = await getResponseDataForUpdate(prisma, assignerPid, itineraryId);
    result.data.createdForeignStaffSchedCompanyCarId = foreignStaffSchedCompanyCar.id;
    result.isSuccess = true;
    return result;
}
export const FOREIGN_STAFF_SCHED_COMPANY_CAR_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'foreignStaffKey', 'startDateTime', 'endDateTime', 'timezone', 'schedCompanyCarIds', 'arrangedCars'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '海外拠点担当用社有車予定ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
            description: '海外拠点アクセスキー。',
        },
        startDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        endDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        schedCompanyCarIds: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'integer',
                format: 'int64',
                maximum: 4294967295,
                minimum: 1,
                description: '社有車予定ID',
            },
        },
        arrangedCars: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                    id: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '海外拠点用手配社有車ID。更新時は指定必須',
                    },
                    companyCarId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '社有車ID',
                    },
                    carNo: {
                        type: 'string',
                        maxLength: 50,
                        description: '自動車登録番号(ナンバープレート)',
                    },
                    carModel: {
                        type: 'string',
                        maxLength: 50,
                        description: '車種',
                    },
                    carColor: {
                        type: 'string',
                        maxLength: 50,
                        description: '車体カラー',
                    },
                    driverId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: 'ドライバーID',
                    },
                    driverName: {
                        type: 'string',
                        maxLength: 255,
                        description: 'ドライバー氏名',
                    },
                    driverTel: {
                        type: 'string',
                        maxLength: 50,
                        description: 'ドライバーTel',
                    },
                    driverEmail: {
                        type: 'string',
                        maxLength: 255,
                        description: 'Email',
                    },
                },
            },
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
    },
};
export async function schedUpdate(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // foreignStaffKeyを使って旅程情報へのアクセスが可能かをチェックし、可能であればitineraryIdを取得し、アクセス不可能の場合はerrorを取得する。
    const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
    if ('error' in checkForeignStaffAccessResult) {
        result.error = checkForeignStaffAccessResult.error;
        return result;
    }
    const itineraryId = checkForeignStaffAccessResult.itineraryId;
    const assignerPid = checkForeignStaffAccessResult.assignerPid;
    // 更新前のforeignStaffSchedCompanyCar情報を取得
    const dbList = await getForeignStaffCompanyCarSchedList(prisma, itineraryId, props.id);
    if (dbList.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    const dbOriginal = dbList[0];
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkValidateForSchedUpdate(prisma, dbOriginal, user, props);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 海外拠点担当用社有社予定の開始時間・終了時間に含まれている(候補となる)社有車予定を取得
    const items = await getSchedCompanyCarsForForeignStaffChangingFlgArrgt(prisma, itineraryId);
    const candidates = filterWithinInterval(items, props.startDateTime, props.endDateTime);
    // クライアントから紐付け対象として連携された社有車予定IDは、候補一覧に含まれている必要がある
    if (candidates.length <= 0 || !isTargetsValueEveryContained(props.schedCompanyCarIds, candidates)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 社有車の更新処理
    await updateForeignStaffSchedCompanyCar(prisma, user, props, dbOriginal, itineraryId);
    // 社有車予定に紐付けを実施する。
    const ids = props.schedCompanyCarIds;
    await updateForeignStaffSchedCompanyIdByForeignStaff(prisma, itineraryId, ids, props.id, dbOriginal.flgArrgt);
    // 元々は紐付けされていたのに、今回は紐付け実施対象に入っていない社有車予定は、紐付け解除を実施する。
    const removeRelationIds = [];
    for (const item of items) {
        // 海外拠点用社有車予定に紐ついている社有車
        if (item.foreignStaffSchedCompanyCarId === props.id) {
            if (!ids.includes(item.id)) {
                removeRelationIds.push(item.id);
            }
        }
    }
    if (removeRelationIds.length > 0) {
        // 海外拠点担当用社有社予定の開始時間・終了時間に含まれなくなってしまった社有車予定は紐付け解除して未手配に変更する。
        await updateForeignStaffSchedCompanyIdByForeignStaff(prisma, itineraryId, removeRelationIds, null);
    }
    result.data = await getResponseDataForUpdate(prisma, assignerPid, itineraryId);
    result.isSuccess = true;
    return result;
}
export const FOREIGN_STAFF_SCHED_COMPANY_CAR_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'foreignStaffKey'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '海外拠点担当用社有車予定ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
            description: '海外拠点アクセスキー。',
        },
    },
};
export async function schedDelete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // foreignStaffKeyを使って旅程情報へのアクセスが可能かをチェックし、可能であればitineraryIdを取得し、アクセス不可能の場合はerrorを取得する。
    const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
    if ('error' in checkForeignStaffAccessResult) {
        result.error = checkForeignStaffAccessResult.error;
        return result;
    }
    const itineraryId = checkForeignStaffAccessResult.itineraryId;
    const assignerPid = checkForeignStaffAccessResult.assignerPid;
    const list = await getForeignStaffCompanyCarSchedList(prisma, itineraryId, props.id);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // CompanyCarSchedの削除処理
    await deleteForeignStaffSchedCompanyCar(prisma, user, itineraryId, props.id);
    // この海外拠点用社有車予定に紐ついている社有車予定については、紐付け解除して未手配に変更する。
    const items = await getSchedCompanyCarsForForeignStaffChangingFlgArrgt(prisma, itineraryId, props.id);
    const ids = items.map((item) => item.id);
    if (ids.length > 0) {
        // 紐付け解除して未手配に変更する。
        await updateForeignStaffSchedCompanyIdByForeignStaff(prisma, itineraryId, ids, null);
    }
    result.data = await getResponseDataForUpdate(prisma, assignerPid, itineraryId);
    result.isSuccess = true;
    return result;
}
export const FOREIGN_STAFF_SCHED_COMPANY_CAR_CHANGE_ARRGT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['foreignStaffKey'],
    properties: {
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
            description: '海外拠点アクセスキー。',
        },
    },
};
export async function schedArrgtComplete(props, { prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // foreignStaffKeyを使って旅程情報へのアクセスが可能かをチェックし、可能であればitineraryIdを取得し、アクセス不可能の場合はerrorを取得する。
    const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
    if ('error' in checkForeignStaffAccessResult) {
        result.error = checkForeignStaffAccessResult.error;
        return result;
    }
    const itineraryId = checkForeignStaffAccessResult.itineraryId;
    const assignerPid = checkForeignStaffAccessResult.assignerPid;
    // この旅程に紐つく全てのforeignStaffSchedCompanyCar情報を取得
    // 社有車手配を実施した出張者が管理となっている海外拠点担当用社有車予定のみ取得
    const dbList = await getForeignStaffCompanyCarSchedListForArrangeComplete(prisma, itineraryId, assignerPid);
    const targetFfSchedIds = [];
    const targetSchedIds = [];
    const targetEmails = [];
    const targetPids = [];
    const emailMap = {};
    const pidMap = {};
    let itineraryInfo = {};
    for (const ffSched of dbList) {
        if (ffSched.flgArrgt) {
            continue;
        }
        // まだ手配完了となっていないものに対して、手配完了処理をかけていく
        targetFfSchedIds.push(ffSched.id);
        // 紐ついている社有車予定
        for (const sched of ffSched.schedCompanyCars) {
            if (sched.flgDelete || sched.flgArrgt) {
                continue;
            }
            // まだ手配完了となっていないものに対して、手配完了処理をかけていく
            targetSchedIds.push(sched.id);
            // 未手配→手配済の変わるので、該当する予定の参加者には通知を実施する
            for (const schedIndividual of sched.schedCompanyCarIndividuals) {
                // 重複をチェックしながら、通知対象者を取得
                const email = schedIndividual.user.email;
                const pid = schedIndividual.user.pid;
                if (email && !emailMap[email]) {
                    targetEmails.push(email);
                }
                if (!pidMap[pid]) {
                    targetPids.push(pid);
                }
            }
        }
        // assinerPidが持っている旅程情報を取得する(2行目も同じ情報になるので最初のみ実行でOK)
        if (!itineraryInfo.id) {
            for (const itiIndividual of ffSched.itinerary.itineraryIndividuals) {
                if (itiIndividual.pid === assignerPid) {
                    itineraryInfo = {
                        id: itineraryId,
                        itineraryName: itiIndividual.itineraryName,
                        itineraryFrom: itiIndividual.itineraryFrom,
                        itineraryTo: itiIndividual.itineraryTo,
                    };
                    break;
                }
            }
        }
    }
    if (targetFfSchedIds.length > 0) {
        // 海外拠点担当用社有車予定の手配実施フラグ更新作業。
        await updateForeignStaffSchedChangeArrgt(prisma, user, itineraryId, targetFfSchedIds, true);
    }
    if (targetSchedIds.length > 0) {
        // 社有車予定の手配実施フラグ更新作業。
        await updateSchedChangeArrgt(prisma, user, itineraryId, targetSchedIds, true);
    }
    // 社有車手配完了のメール通知実施
    if (targetPids.length > 0 && targetEmails.length > 0) {
        await sendArrgtFinishSmtpMailAndCreateSiteNotificationToCompanions(log, prisma, targetEmails, targetPids, itineraryInfo);
    }
    result.data = await getResponseDataForUpdate(prisma, assignerPid, itineraryId);
    result.isSuccess = true;
    return result;
}
async function getResponseDataForUpdate(prisma, assignerPid, itineraryId) {
    return {
        foreignStaffSchedCompanyCars: await getForeignStaffCompanyCarSchedList(prisma, itineraryId),
        schedCompanyCars: await getCompanyCarSchedList(prisma, assignerPid, itineraryId, undefined),
    };
}
export function filterWithinInterval(list, start, end) {
    const baseStartDateTime = new Date(start);
    const baseEndDateTime = new Date(end);
    if (!isValid(baseStartDateTime) || !isValid(baseEndDateTime)) {
        return [];
    }
    const result = [];
    for (const item of list) {
        // 対象の社有車予定が社有車手配実行となっていないものは対象外
        if (!item.arrgtCompanyCarId) {
            // 何も処理しない
            continue;
        }
        else {
            const startDateTime = item.startDateTime;
            const endDateTime = item.endDateTime;
            // 社有車予定開始時刻が、海外拠点担当用社有車予定開始時刻よりも前の場合は何も処理しない
            if (isFromDatetimeBeforeToDatetime(startDateTime, baseStartDateTime)) {
                continue;
                // 海外拠点担当用社有車予定終了時刻が、社有車予定終了時刻よりも前の場合は何も処理しない
            }
            else if (isFromDatetimeBeforeToDatetime(baseEndDateTime, endDateTime)) {
                continue;
            }
            result.push(item);
        }
    }
    return result;
}
//# sourceMappingURL=foreignStaffSchedCompanyCar.js.map