import { log } from '../../utils/logger.js';
import { checkGetParamsNumber, replaceCRLF } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid, getCompanyCarArrgtTopUrl, } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
import { createArrgtCompanyCar, createArrgtCompanyCarValidate, createSchedCompanyCar, checkValidateForSchedCreate, deleteIfExists, deleteSchedCompanyCar, getArrgtCompanyCarList, getCompanyCarSchedList, updateSchedCompanyCar, checkValidateForSchedUpdate, getSchedCompanyCarForChecker, rejectSchedCompanyCarIndividual, createSchedCompanyCarForArrangement, } from '../../service/companyCar/companyCarService.js';
import { sendMail } from '../../service/azure/graphApiService.js';
import { convert2Buffer } from '../../utils/azureBlob.js';
import { addplanedSchedCompanyCars, getExcelDownloadItineraryInfo, makeItinerarySchedulesExcel, } from '../../service/excel/makeItinerarySchedules.js';
import { cloneDeep } from 'lodash-es';
export const COMPANY_CAR_ARRGT_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function arrgtList(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if ('foreignStaffKey' in props) {
        // 手配一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            isForeignStaff = true;
        }
    }
    else {
        if (!checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    // 一覧取得実施
    result.data = await getArrgtCompanyCarList(prisma, pid, itineraryId, undefined, isForeignStaff);
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_ARRGT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '社有車手配ID。',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 指定された社有車手配IDに合致する社有車手配情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function arrgt(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if ('foreignStaffKey' in props) {
        // 手配一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            isForeignStaff = true;
        }
    }
    else {
        if (!checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const arrgtCompanyCarId = Number(props.id);
    // 社有車手配IDを指定して一覧取得実施
    const list = await getArrgtCompanyCarList(prisma, pid, itineraryId, arrgtCompanyCarId, isForeignStaff);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_ARRGT_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['arrgt', 'schedCompanyCars', 'mail'],
    properties: {
        arrgt: {
            type: 'object',
            additionalProperties: false,
            required: ['itineraryId', 'emailTo', 'startDate', 'endDate', 'passengers'],
            properties: {
                id: {
                    type: 'integer',
                    format: 'int64',
                    maximum: 4294967295,
                    minimum: 1,
                    description: '社有車手配ID。更新時は指定必須',
                },
                itineraryId: {
                    type: 'integer',
                    format: 'int64',
                    maximum: 4294967295,
                    minimum: 1,
                    description: '旅程id',
                },
                emailTo: {
                    type: 'array',
                    minItems: 1,
                    description: '手配時のTo Emailアドレス。',
                    items: {
                        type: 'string',
                        format: 'email',
                        maxLength: 255,
                        description: '手配時のTOメールアドレス',
                    },
                },
                startDate: {
                    type: 'string',
                    format: 'date',
                    description: '利用開始日',
                },
                endDate: {
                    type: 'string',
                    format: 'date',
                    description: '利用終了日',
                },
                passengers: {
                    type: 'array',
                    minItems: 1,
                    description: 'この手配に紐つく社有車利用者の一覧',
                    items: {
                        type: 'string',
                        description: '社有車の利用者一覧',
                    },
                },
                otherPeopleCount: {
                    type: 'integer',
                    format: 'int64',
                    maximum: 65535,
                    minimum: 0,
                    description: '社外利用者の人数。defaultは0',
                },
                remark: {
                    type: 'string',
                    maxLength: 255,
                    description: '手配時の備考',
                },
                ownerPid: {
                    type: 'string',
                    maxLength: 15,
                    description: '社有車手配を作成したPersonal ID。閲覧時のみ連携され、更新系(新規登録含む)APIでは連携実施しない。',
                },
            },
        },
        schedCompanyCars: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['startDateTime', 'endDateTime', 'timezone'],
                properties: {
                    startDateTime: {
                        type: 'string',
                        format: 'date-time',
                    },
                    endDateTime: {
                        type: 'string',
                        format: 'date-time',
                    },
                    timezone: {
                        type: 'string',
                        maxLength: 6,
                        pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
                        description: 'タイムゾーン',
                    },
                    departureLocation: {
                        type: 'string',
                        maxLength: 255,
                        description: '出発地',
                    },
                },
            },
        },
        mail: {
            type: 'object',
            additionalProperties: false,
            description: 'mail情報。\nこちらの情報はDBに保存しないEmail情報となります。',
            required: ['cc', 'title', 'body'],
            properties: {
                cc: {
                    type: 'array',
                    description: '手配時に利用するCC Emailアドレス。',
                    items: {
                        type: 'string',
                        format: 'email',
                        maxLength: 255,
                    },
                },
                title: {
                    type: 'string',
                    maxLength: 255,
                    description: '手配時に利用するEmail件名。',
                },
                body: {
                    type: 'string',
                    maxLength: 65535,
                    description: '手配時に利用するEmail本文。',
                },
                fileInfo: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['base64', 'originalFileName'],
                    properties: {
                        base64: {
                            type: 'string',
                            description: 'Base64で文字列変換されたファイルデータ。画像圧縮時のbase64に含まれる「data:image/XXXXX;base64,」は取り除いたもの',
                        },
                        originalFileName: {
                            type: 'string',
                            maxLength: 270,
                            description: '元々のファイル名',
                        },
                        size: {
                            type: 'integer',
                            format: 'int64',
                            maximum: 4294967295,
                            minimum: 1,
                            description: 'ファイルサイズ',
                        },
                    },
                },
            },
        },
    },
};
export async function arrgtCreate(props, { pid, prisma, user, tokens }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const itineraryId = props.arrgt.itineraryId;
    const passengers = props.arrgt.passengers;
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await createArrgtCompanyCarValidate(pid, prisma, props);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 添付ファイルがある場合は、添付ファイルの最大サイズのチェック実施
    const bufAttachment = props.mail.fileInfo ? convert2Buffer(props.mail.fileInfo, 0) : undefined;
    let base64Attachment = '';
    if (props.mail.fileInfo && bufAttachment) {
        // ファイルサイズが設定された最大ファイルサイズを超えている場合はエラーとする。
        if (bufAttachment.code && bufAttachment.status) {
            result.error = bufAttachment;
            return result;
        }
        base64Attachment = props.mail.fileInfo.base64;
    }
    // ArrgtCompanyCarの新規登録処理
    const arrgtCompanyCarResult = await createArrgtCompanyCar(prisma, pid, user, props);
    // 一覧取得実施
    const list = await getArrgtCompanyCarList(prisma, pid, props.arrgt.itineraryId, arrgtCompanyCarResult.id);
    if (list.length !== 1) {
        // 今回作成した社有車予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    // 手配依頼を実施する社有車予定の登録処理
    for (const schedCompanyCar of props.schedCompanyCars) {
        // 社有車予約の新規登録処理
        await createSchedCompanyCarForArrangement(prisma, pid, user, itineraryId, arrgtCompanyCarResult.id, passengers, schedCompanyCar);
    }
    if (props.mail) {
        // 旅程Excelファイルがなければ、旅程Excelの取得実施
        if (!base64Attachment) {
            const planedScheds = cloneDeep(props.schedCompanyCars);
            for (const planedSched of planedScheds) {
                planedSched.companions = passengers.map((pid) => {
                    return { pid };
                });
            }
            // 対象PIDの旅程情報取得
            const excelData = await getExcelDownloadItineraryInfo(prisma, pid, itineraryId);
            if ('error' in excelData) {
                result.error = excelData.error;
                return result;
            }
            // 旅程表に追加したい社有車予定がある場合
            if ('planedSchedCompanyCars' in props) {
                addplanedSchedCompanyCars(excelData.schedCompanyCars, planedScheds);
            }
            // excel作成
            const bufExcel = await makeItinerarySchedulesExcel(excelData, 'en');
            base64Attachment = bufExcel.toString('base64');
        }
        // 文字列の置換
        const bodyContent = props.mail.body.replace(Define.SETTINGS.FOREIGN_STAFF.COMPANY_CAR_ARRGT_PATH.BASE, getCompanyCarArrgtTopUrl(props.arrgt.itineraryId.toString(), arrgtCompanyCarResult.id.toString(), arrgtCompanyCarResult.accessKey));
        // メール送信 (ccはユニークチェックして配列指定すること)
        const sendMailRes = await sendMail(log, tokens.adAEnc, {
            emailTo: props.arrgt.emailTo,
            emailCc: props.mail.cc,
            subject: props.mail.title,
            body: {
                contentType: 'Text',
                content: replaceCRLF(bodyContent),
            },
            attachments: [
                {
                    '@odata.type': '#microsoft.graph.fileAttachment',
                    contentBytes: base64Attachment,
                    contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    name: props.mail.fileInfo?.originalFileName || 'itinerary_schedules.xlsx',
                },
            ],
        });
        if (!sendMailRes.isSuccess) {
            result.isDbRollback = true;
            return result;
        }
    }
    result.data = list[0];
    // システム外部連携ができない環境の場合は、フロント側に、メールで連携れるリンクURLとキー情報を返却しておく
    if (Define.DEBUG.noExternalIntegration) {
        result.data.mailLink = getCompanyCarArrgtTopUrl(props.arrgt.itineraryId.toString(), arrgtCompanyCarResult.id.toString(), arrgtCompanyCarResult.accessKey);
        result.data.foreignStaffKey = arrgtCompanyCarResult.accessKey;
    }
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_SCHED_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
    },
};
export async function schedList(props, { pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.itineraryId)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const itineraryId = Number(props.itineraryId);
    // 一覧取得実施
    result.data = await getCompanyCarSchedList(prisma, pid, itineraryId, undefined);
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_SCHED_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '社有車ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 指定された社有車IDに合致する社有車予定情報単数を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function sched(props, { pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const schedCompanyCarId = Number(props.id);
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 社有車予定IDとpidを指定して一覧(単数)取得実施
    const list = await getCompanyCarSchedList(prisma, pid, undefined, schedCompanyCarId, false);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_SCHED_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId', 'startDateTime', 'endDateTime', 'timezone', 'arrangedCars'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
        },
        startDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        endDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        departureLocation: {
            type: 'string',
            maxLength: 255,
            description: '出発地',
        },
        arrangedCars: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                    id: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '手配社有車ID。更新時は指定必須',
                    },
                    companyCarId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '社有車ID',
                    },
                    carNo: {
                        type: 'string',
                        maxLength: 50,
                        description: '自動車登録番号(ナンバープレート)',
                    },
                    carModel: {
                        type: 'string',
                        maxLength: 50,
                        description: '車種',
                    },
                    carColor: {
                        type: 'string',
                        maxLength: 50,
                        description: '車体カラー',
                    },
                    driverId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: 'ドライバーID',
                    },
                    driverName: {
                        type: 'string',
                        maxLength: 255,
                        description: 'ドライバー氏名',
                    },
                    driverTel: {
                        type: 'string',
                        maxLength: 50,
                        description: 'ドライバーTel',
                    },
                    driverEmail: {
                        type: 'string',
                        maxLength: 255,
                        description: 'Email',
                    },
                },
            },
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        flgArrgt: {
            type: 'boolean',
        },
        companions: {
            type: 'array',
            description: '利用者一覧(利用者情報としてはpidのみ) 一人以上は必要',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '利用者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const itineraryId = props.itineraryId;
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkValidateForSchedCreate(prisma, itineraryId, user, pid, props);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 社有車予約の新規登録処理
    const schedCompanyCarId = await createSchedCompanyCar(prisma, pid, user, props, itineraryId);
    // 一覧取得実施
    const list = await getCompanyCarSchedList(prisma, pid, undefined, schedCompanyCarId, false);
    if (list.length !== 1) {
        // 今回作成したイベント予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_SCHED_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'itineraryId', 'startDateTime', 'endDateTime', 'timezone', 'flgArrgt'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '社有車予定ID',
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
        },
        startDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        endDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        departureLocation: {
            type: 'string',
            maxLength: 255,
            description: '出発地',
        },
        arrangedCars: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                    id: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '手配社有車ID。更新時は指定必須',
                    },
                    companyCarId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '社有車ID',
                    },
                    carNo: {
                        type: 'string',
                        maxLength: 50,
                        description: '自動車登録番号(ナンバープレート)',
                    },
                    carModel: {
                        type: 'string',
                        maxLength: 50,
                        description: '車種',
                    },
                    carColor: {
                        type: 'string',
                        maxLength: 50,
                        description: '車体カラー',
                    },
                    driverId: {
                        type: ['integer', 'null'],
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: 'ドライバーID',
                    },
                    driverName: {
                        type: 'string',
                        maxLength: 255,
                        description: 'ドライバー氏名',
                    },
                    driverTel: {
                        type: 'string',
                        maxLength: 50,
                        description: 'ドライバーTel',
                    },
                    driverEmail: {
                        type: 'string',
                        maxLength: 255,
                        description: 'Email',
                    },
                },
            },
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        flgArrgt: {
            type: 'boolean',
        },
        companions: {
            type: 'array',
            description: '利用者一覧(利用者情報としてはpidのみ) 一人以上は必要',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '利用者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const itineraryId = props.itineraryId;
    // DB情報を取得
    const dbSchedCompanyCar = await getSchedCompanyCarForChecker(prisma, props.id, itineraryId);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkValidateForSchedUpdate(prisma, itineraryId, user, pid, props, dbSchedCompanyCar);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 社有車の更新処理
    await updateSchedCompanyCar(prisma, pid, user, props, itineraryId, dbSchedCompanyCar);
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_SCHED_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '社有車予定ID',
        },
    },
};
export async function schedDelete(props, { prisma, user, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 削除対象となっている社有車予定の最新データ状況をDBから取得の上、処理実施する。
    const dbSchedCompanyCar = await getSchedCompanyCarForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await deleteIfExists(pid, dbSchedCompanyCar);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // CompanyCarSchedの削除処理
    await deleteSchedCompanyCar(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const COMPANY_CAR_SCHED_INDIVIDUAL_REJECT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'flgReject'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '社有車予定ID',
        },
        flgReject: {
            type: 'boolean',
            description: '拒否フラグ。予定参加を拒否しているかどうか',
        },
    },
};
/**
 * 予定参加拒否実施(予定作成者による拒否は不可)
 * @return
 */
export async function schedIndividualReject(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // DB情報を取得
    const schedCompanyCar = await getSchedCompanyCarForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // DBから移動予定情報が取得できない(W00109)
    if (!schedCompanyCar) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
        // 予定拒否実施しているのが、予定の作成者の場合
    }
    else if (schedCompanyCar.ownerPid === pid) {
        result.error = { code: Define.ERROR_CODES.W00121, status: 400 };
        return result;
    }
    // このpidに合致するindividualsテーブル情報が存在するかチェック
    let isIndividualData = false;
    for (const individualData of schedCompanyCar.schedCompanyCarIndividuals) {
        if (individualData.pid === pid && !individualData.flgDelete) {
            isIndividualData = true;
        }
    }
    if (!isIndividualData) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // SchedEventIndividualの更新処理
    await rejectSchedCompanyCarIndividual(prisma, pid, user, props.id, props.flgReject);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map