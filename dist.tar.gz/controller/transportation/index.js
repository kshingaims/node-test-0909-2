import { log } from '../../utils/logger.js';
import { createTransportationSchedIfNotExists, createSchedTransportation, getTransportationSchedList, updateIfExists, updateSchedTransportation, deleteIfExists, deleteSchedTransportation, rejectSchedTransportationIndividual, getTransportationSchedData, getSchedTransportationForChecker, sendSchedCreateMailAndSiteNotificationToCompanions, createExpenseTransportationsWhenSchedCreated, } from '../../service/transportation/transportationService.js';
import { checkGetParamsNumber } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
export const TRANSPORTATION_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedList(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
    }
    else {
        if (!checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    // 一覧取得実施
    result.data = await getTransportationSchedList(prisma, pid, itineraryId, undefined, false);
    result.isSuccess = true;
    return result;
}
export const TRANSPORTATION_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 指定された移動IDに合致する移動予定情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function sched(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    const id = Number(props.id);
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 移動予定IDを指定して一覧取得実施
    const list = await getTransportationSchedList(prisma, pid, itineraryId, id, false);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const TRANSPORTATION_SCHED_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['transportationMode', 'departureDateTime', 'arrivalDateTime', 'timezone'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
        transportationMode: {
            type: 'string',
            pattern: '^(?!^[\\s\\u3000]*$).+$',
            maxLength: 255,
            description: '移動手段',
        },
        departureDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        arrivalDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        departureLocation: {
            type: 'string',
            maxLength: 255,
            description: '出発地',
        },
        arrivalLocation: {
            type: 'string',
            maxLength: 255,
            description: '到着地',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            // pidは手配実施者のものとして処理する。
            pid = checkForeignStaffAccessResult.assignerPid;
        }
        isForeignStaff = true;
    }
    else if (props.itineraryId !== undefined) {
        itineraryId = props.itineraryId;
    }
    else {
        // japanStaffの場合は、id(旅程ID)の指定がないと入力チェックエラー (APIのリクエストパラメータが不正)
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await createTransportationSchedIfNotExists(pid, prisma, itineraryId, props.arrivalDateTime, props.departureDateTime, props.companions, isForeignStaff);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // TransportationSchedの新規登録処理
    const schedTransportationId = await createSchedTransportation(prisma, pid, user, props, itineraryId, isForeignStaff);
    if (isForeignStaff) {
        const data = await getTransportationSchedData(prisma, schedTransportationId);
        if (!data) {
            // 今回作成したイベント予定は必ず存在するはず
            throw new Error('unreachable error.');
        }
        // 海外拠点担当によって、各種移動の予定登録が実行されたことをサイト上の通知メッセージとメール通知実施
        await sendSchedCreateMailAndSiteNotificationToCompanions(log, prisma, schedTransportationId);
        result.data = data;
    }
    else {
        // 一覧取得実施
        const list = await getTransportationSchedList(prisma, pid, undefined, schedTransportationId, false);
        if (list.length !== 1) {
            // 今回作成した移動予定は必ず存在するはず
            throw new Error('unreachable error.');
        }
        result.data = list[0];
    }
    // 交通費の経費項目に新規追加実施
    await createExpenseTransportationsWhenSchedCreated(prisma, pid, user, result.data.schedTransportation.id);
    result.isSuccess = true;
    return result;
}
export const TRANSPORTATION_SCHED_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'transportationMode', 'departureDateTime', 'arrivalDateTime', 'timezone'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '移動予定ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        transportationMode: {
            type: 'string',
            pattern: '^(?!^[\\s\\u3000]*$).+$',
            maxLength: 255,
            description: '移動手段',
        },
        departureDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        arrivalDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        departureLocation: {
            type: 'string',
            maxLength: 255,
            description: '出発地',
        },
        arrivalLocation: {
            type: 'string',
            maxLength: 255,
            description: '到着地',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            // pidは手配実施者のものとして処理する。
            pid = checkForeignStaffAccessResult.assignerPid;
        }
        isForeignStaff = true;
    }
    else if (props.itineraryId !== undefined) {
        itineraryId = props.itineraryId;
    }
    else {
        // japanStaffの場合は、id(旅程ID)の指定がないと入力チェックエラー (APIのリクエストパラメータが不正)
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // DB情報を取得
    const schedTransportation = await getSchedTransportationForChecker(prisma, props.id, itineraryId);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await updateIfExists(pid, prisma, schedTransportation, itineraryId, props.arrivalDateTime, props.departureDateTime, props.companions, isForeignStaff);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // TransportationSchedの更新処理
    await updateSchedTransportation(prisma, pid, user, schedTransportation, props, isForeignStaff);
    result.isSuccess = true;
    return result;
}
export const TRANSPORTATION_SCHED_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '各種ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            isForeignStaff = true;
        }
    }
    // 削除対象となっている各種移動の最新データ状況をDBから取得の上、処理実施する。
    const schedTransportation = await getSchedTransportationForChecker(prisma, props.id, itineraryId);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const error = await deleteIfExists(pid, schedTransportation, isForeignStaff);
    if (error) {
        result.error = error;
        return result;
    }
    // TransportationSchedの削除処理
    await deleteSchedTransportation(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const TRANSPORTATION_SCHED_INDIVIDUAL_REJECT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'flgReject'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '移動予定ID',
        },
        flgReject: {
            type: 'boolean',
            description: '拒否フラグ。予定参加を拒否しているかどうか',
        },
    },
};
/**
 * 予定参加拒否実施(予定作成者による拒否は不可)
 * @return
 */
export async function schedIndividualReject(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // DB情報を取得
    const schedTransportation = await getSchedTransportationForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // DBから移動予定情報が取得できない(W00109)
    if (!schedTransportation) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
        // 予定拒否実施しているのが、予定の作成者の場合
    }
    else if (schedTransportation.ownerPid === pid) {
        result.error = { code: Define.ERROR_CODES.W00121, status: 400 };
        return result;
    }
    // このpidに合致するindividualsテーブル情報が存在するかチェック
    let isIndividualData = false;
    for (const individualData of schedTransportation.schedTransportationIndividuals) {
        if (individualData.pid === pid && !individualData.flgDelete) {
            isIndividualData = true;
        }
    }
    if (!isIndividualData) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // SchedTransportationIndividualの更新処理
    await rejectSchedTransportationIndividual(prisma, pid, user, props.id, props.flgReject);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map