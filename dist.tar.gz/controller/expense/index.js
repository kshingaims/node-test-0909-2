import { checkGetParamsNumber } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { createExpenseTransportation, deleteExpenseTransportation, getExpenseTransportation, updateExpenseTransportation, isCheckTransportationRequired, } from '../../service/expense/expenseTransportService.js';
import { createExpenseAccommodation, deleteExpenseAccommodation, getExpenseAccommodation, updateExpenseAccommodation, isCheckAccomodationRequired, } from '../../service/expense/expenseAccommodationService.js';
import { createExpenseOther, deleteExpenseOther, getExpenseOther, updateExpenseOther, isCheckOtherRequired, } from '../../service/expense/expenseOtherService.js';
import { getExpense, checkDynamicValidationForCreate, checkDynamicValidationForUpdate, } from '../../service/expense/expenseIndexService.js';
export const EXPENSE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //経費は常に旅程に、紐つけて検索
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
    },
};
export async function expense(props, { pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.itineraryId)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const itineraryId = Number(props.itineraryId);
    // 一覧取得実施
    result.data = await getExpense(prisma, pid, itineraryId);
    result.isSuccess = true;
    return result;
}
export const EXPENSE_TRANSPORTATION_INDEX_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '経費交通費id',
        },
    },
};
/**
 * 指定された経費交通費IDに合致する経費交通費情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function transportation(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const expenseTransportationId = Number(props.id);
    // 経費交通費IDを指定して経費項目(単数)取得実施
    const expenseTransportation = await getExpenseTransportation(prisma, pid, expenseTransportationId);
    if (expenseTransportation === undefined) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = expenseTransportation;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_TRANSPORTATION_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['expenseId'],
    properties: {
        expenseId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費id',
        },
        settlementDate: {
            type: ['string', 'null'],
            format: 'date',
            description: '支払日。出張期間終了後は入力必須。',
        },
        settlementType: {
            enum: ['海外交通費', '国内交通費（課税）', ''],
            description: '精算内容。出張期間終了後は入力必須。',
        },
        transportationType: {
            enum: ['電車（新幹線・特急）', '電車（新幹線・特急を除く）', 'タクシー', 'バス', 'その他', ''],
            description: '交通機関。出張期間終了後は入力必須。',
        },
        departureLocation: {
            type: 'string',
            maxLength: 250,
            description: '出発地。出張期間終了後は入力必須。',
        },
        arrivalLocation: {
            type: 'string',
            maxLength: 250,
            description: '到着地。出張期間終了後は入力必須。',
        },
        price: {
            type: ['number', 'null'],
            maximum: 99999999.99,
            minimum: 0,
            validatePrecision: 2,
        },
        currency: {
            enum: Define.SETTINGS.CYCLE_CURRENCY_PULLDOWNS,
            description: '通貨。',
        },
        remark: {
            type: 'string',
            maxLength: 250,
            description: '備考',
        },
    },
};
export async function expenseTransportationCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForCreate(prisma, pid, props.expenseId, () => {
        if (!isCheckTransportationRequired(props)) {
            return { code: Define.ERROR_CODES.W00904, status: 400 };
        }
        return undefined;
    });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費交通費の新規登録処理
    const expenseTransportationId = await createExpenseTransportation(prisma, user, props);
    // 経費交通費IDを指定して経費項目(単数)取得実施
    const expenseTransportation = await getExpenseTransportation(prisma, pid, expenseTransportationId);
    if (expenseTransportation === undefined) {
        // 今回作成したイベント予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    result.data = expenseTransportation;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_TRANSPORTATION_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費交通費id',
        },
        settlementDate: {
            type: ['string', 'null'],
            format: 'date',
            description: '支払日。出張期間終了後は入力必須。',
        },
        settlementType: {
            enum: ['海外交通費', '国内交通費（課税）', ''],
            description: '精算内容。出張期間終了後は入力必須。',
        },
        transportationType: {
            enum: ['電車（新幹線・特急）', '電車（新幹線・特急を除く）', 'タクシー', 'バス', 'その他', ''],
            description: '交通機関。出張期間終了後は入力必須。',
        },
        departureLocation: {
            type: 'string',
            maxLength: 250,
            description: '出発地。出張期間終了後は入力必須。',
        },
        arrivalLocation: {
            type: 'string',
            maxLength: 250,
            description: '到着地。出張期間終了後は入力必須。',
        },
        price: {
            type: ['number', 'null'],
            maximum: 99999999.99,
            minimum: 0,
            validatePrecision: 2,
        },
        currency: {
            enum: Define.SETTINGS.CYCLE_CURRENCY_PULLDOWNS,
            description: '通貨。',
        },
        remark: {
            type: 'string',
            maxLength: 250,
            description: '備考',
        },
    },
};
export async function expenseTransportationUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForUpdate(prisma, pid, { expenseTransportationId: props.id }, () => {
        if (!isCheckTransportationRequired(props)) {
            return { code: Define.ERROR_CODES.W00904, status: 400 };
        }
        return undefined;
    });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費交通費の更新処理
    await updateExpenseTransportation(prisma, user, props);
    result.isSuccess = true;
    return result;
}
export const EXPENSE_TRANSPORTATION_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費交通費ID',
        },
    },
};
export async function expenseTransportationDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForUpdate(prisma, pid, { expenseTransportationId: props.id });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費交通費の削除処理
    await deleteExpenseTransportation(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const EXPENSE_ACCOMMODATION_INDEX_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '経費宿泊費id',
        },
    },
};
/**
 * 指定された経費宿泊費IDに合致する経費宿泊費情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function accommodation(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const expenseAccommodationId = Number(props.id);
    // 経費宿泊費IDを指定して経費項目(単数)取得実施
    const expenseAccommodation = await getExpenseAccommodation(prisma, pid, expenseAccommodationId);
    if (expenseAccommodation === undefined) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = expenseAccommodation;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_ACCOMMODATION_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['expenseId'],
    properties: {
        expenseId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費id',
        },
        settlementDate: {
            type: ['string', 'null'],
            format: 'date',
            description: '支払日。出張期間終了後は入力必須。',
        },
        cityId: {
            type: ['integer', 'null'],
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '都市ID。出張期間終了後は入力必須。',
        },
        hotelName: {
            type: 'string',
            maxLength: 250,
            description: 'ホテル名。出張期間終了後は入力必須。',
        },
        checkInDate: {
            type: ['string', 'null'],
            format: 'date',
            description: 'チェックイン日時。日付フォーマットはISO8601形式。出張期間終了後は入力必須。',
        },
        checkOutDate: {
            type: ['string', 'null'],
            format: 'date',
            description: 'チェックアウト日時。日付フォーマットはISO8601形式。出張期間終了後は入力必須。',
        },
        price: {
            type: ['number', 'null'],
            maximum: 99999999.99,
            minimum: 0,
            validatePrecision: 2,
        },
        currency: {
            enum: Define.SETTINGS.CYCLE_CURRENCY_PULLDOWNS,
            description: '通貨。',
        },
        remark: {
            type: 'string',
            maxLength: 250,
            description: '備考',
        },
    },
};
export async function expenseAccommodationCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForCreate(prisma, pid, props.expenseId, () => {
        if (!isCheckAccomodationRequired(props)) {
            return { code: Define.ERROR_CODES.W00904, status: 400 };
        }
        return undefined;
    });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費宿泊費の新規登録処理
    const expenseAccommodationId = await createExpenseAccommodation(prisma, user, props);
    // 経費宿泊費IDを指定して経費項目(単数)取得実施
    const expenseAccommodation = await getExpenseAccommodation(prisma, pid, expenseAccommodationId);
    if (expenseAccommodation === undefined) {
        // 今回作成したイベント予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    result.data = expenseAccommodation;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_ACCOMMODATION_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費宿泊費ID',
        },
        settlementDate: {
            type: ['string', 'null'],
            format: 'date',
            description: '支払日。出張期間終了後は入力必須。',
        },
        cityId: {
            type: ['integer', 'null'],
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '都市ID。出張期間終了後は入力必須。',
        },
        hotelName: {
            type: 'string',
            maxLength: 250,
            description: 'ホテル名。出張期間終了後は入力必須。',
        },
        checkInDate: {
            type: ['string', 'null'],
            format: 'date',
            description: 'チェックイン日時。日付フォーマットはISO8601形式。出張期間終了後は入力必須。',
        },
        checkOutDate: {
            type: ['string', 'null'],
            format: 'date',
            description: 'チェックアウト日時。日付フォーマットはISO8601形式。出張期間終了後は入力必須。',
        },
        price: {
            type: ['number', 'null'],
            maximum: 99999999.99,
            minimum: 0,
            validatePrecision: 2,
        },
        currency: {
            enum: Define.SETTINGS.CYCLE_CURRENCY_PULLDOWNS,
            description: '通貨。',
        },
        remark: {
            type: 'string',
            maxLength: 250,
            description: '備考',
        },
    },
};
export async function expenseAccommodationUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForUpdate(prisma, pid, { expenseAccommodationId: props.id }, () => {
        if (!isCheckAccomodationRequired(props)) {
            return { code: Define.ERROR_CODES.W00904, status: 400 };
        }
        return undefined;
    });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費宿泊費の更新処理
    await updateExpenseAccommodation(prisma, user, props);
    result.isSuccess = true;
    return result;
}
export const EXPENSE_ACCOMMODATION_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費宿泊費ID',
        },
    },
};
export async function expenseAccommodationDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForUpdate(prisma, pid, { expenseAccommodationId: props.id });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費宿泊費の削除処理
    await deleteExpenseAccommodation(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const EXPENSE_OTHER_INDEX_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '経費その他id',
        },
    },
};
/**
 * 指定された経費その他IDに合致する経費その他情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function other(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const expenseOtherId = Number(props.id);
    // 経費その他IDを指定して経費項目(単数)取得実施
    const expenseOther = await getExpenseOther(prisma, pid, expenseOtherId);
    if (expenseOther === undefined) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = expenseOther;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_OTHER_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['expenseId'],
    properties: {
        expenseId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費id',
        },
        settlementDate: {
            type: ['string', 'null'],
            format: 'date',
            description: '支払日。出張期間終了後は入力必須。',
        },
        settlementType: {
            enum: [
                '海外通信費（非課税）',
                '海外通信費（課税）',
                '雑費（非課税）',
                '雑費（課税）',
                '国内通信費',
                '換金手数料',
                '出張中医療費',
                '旅券印紙代',
                '海外空港税',
                'ビザ代',
                'キャンセル料（非課税）',
                '払戻手数料（課税）',
                '',
            ],
            description: '精算内容。出張期間終了後は入力必須。',
        },
        price: {
            type: ['number', 'null'],
            maximum: 99999999.99,
            minimum: 0,
            validatePrecision: 2,
        },
        currency: {
            enum: Define.SETTINGS.CYCLE_CURRENCY_PULLDOWNS,
            description: '通貨。',
        },
        remark: {
            type: 'string',
            maxLength: 250,
            description: '備考',
        },
    },
};
export async function expenseOtherCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForCreate(prisma, pid, props.expenseId, () => {
        if (!isCheckOtherRequired(props)) {
            return { code: Define.ERROR_CODES.W00904, status: 400 };
        }
        return undefined;
    });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費その他の新規登録処理
    const expenseOtherId = await createExpenseOther(prisma, user, props);
    // 経費その他IDを指定して経費項目(単数)取得実施
    const expenseOther = await getExpenseOther(prisma, pid, expenseOtherId);
    if (expenseOther === undefined) {
        // 今回作成したイベント予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    result.data = expenseOther;
    result.isSuccess = true;
    return result;
}
export const EXPENSE_OTHER_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費その他ID',
        },
        settlementDate: {
            type: ['string', 'null'],
            format: 'date',
            description: '支払日。出張期間終了後は入力必須。',
        },
        settlementType: {
            enum: [
                '海外通信費（非課税）',
                '海外通信費（課税）',
                '雑費（非課税）',
                '雑費（課税）',
                '国内通信費',
                '換金手数料',
                '出張中医療費',
                '旅券印紙代',
                '海外空港税',
                'ビザ代',
                'キャンセル料（非課税）',
                '払戻手数料（課税）',
                '',
            ],
            description: '精算内容。出張期間終了後は入力必須。',
        },
        price: {
            type: ['number', 'null'],
            maximum: 99999999.99,
            minimum: 0,
            validatePrecision: 2,
        },
        currency: {
            enum: Define.SETTINGS.CYCLE_CURRENCY_PULLDOWNS,
            description: '通貨。',
        },
        remark: {
            type: 'string',
            maxLength: 250,
            description: '備考',
        },
    },
};
export async function expenseOtherUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForUpdate(prisma, pid, { expenseOtherId: props.id }, () => {
        if (!isCheckOtherRequired(props)) {
            return { code: Define.ERROR_CODES.W00904, status: 400 };
        }
        return undefined;
    });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費その他の更新処理
    await updateExpenseOther(prisma, user, props);
    result.isSuccess = true;
    return result;
}
export const EXPENSE_OTHER_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '経費その他ID',
        },
    },
};
export async function expenseOtherDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await checkDynamicValidationForUpdate(prisma, pid, { expenseOtherId: props.id });
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult) {
        result.error = inputCheckResult;
        return result;
    }
    // 経費その他の削除処理
    await deleteExpenseOther(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map