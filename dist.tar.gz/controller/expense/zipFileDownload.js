import { log } from '../../utils/logger.js';
import { setExtensionB } from '../../service/cycle/afterApply.js';
import { getExpense } from '../../service/expense/expenseIndexService.js';
import { createZip, getZipFileInfo, removeZipFile } from '../../service/expense/makeZipOfAllExpenseAttachments.js';
import { checkGetParamsNumber } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
export const EXPENSE_ZIPFILE_DOWNLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
    },
};
/**
 * 指定された経費その他IDに合致する経費その他情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function expenseZipFileDownload(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.itineraryId)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const itineraryId = Number(props.itineraryId);
    const expenseInfo = await getExpense(prisma, pid, itineraryId, true);
    if (!expenseInfo.id) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // この経費情報の元となる旅程を取得し、対象PIDにおけるitineraryIndividualStatusを取得する。
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const itineraryObj = expenseInfo.itinerary?.itineraryIndividuals[0];
    const cycleLinkStatus = itineraryObj.itineraryIndividualStatus?.cycleLinkStatus;
    const finishCycleIntegrateDate = itineraryObj.itineraryIndividualStatus?.finishCycleIntegrateDate;
    if (cycleLinkStatus !== Define.SETTINGS.CYCLE_LINK_STATUS.FINISH_AFTER_APPLY || !finishCycleIntegrateDate) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const zipFilename = setExtensionB(pid, finishCycleIntegrateDate, expenseInfo);
    // この経費に紐つく領収書ファイルがない
    if (!zipFilename) {
        result.error = { code: Define.ERROR_CODES.E00906, status: 200 };
        return result;
    }
    const zipRes = await createZip(log, expenseInfo, zipFilename);
    if (!zipRes) {
        result.error = { code: Define.ERROR_CODES.E00905, status: 500 };
        return result;
    }
    const fileInfo = await getZipFileInfo(zipFilename);
    if (fileInfo) {
        if (fileInfo.base64) {
            result.data = { zipFile: fileInfo };
            await removeZipFile(zipFilename);
        }
        else {
            // ZIPファイルが大きすぎてZIPファイルの送信ができない
            result.error = { code: Define.ERROR_CODES.W01010, status: 200 };
            return result;
        }
    }
    else {
        throw new Error('unreachable error.');
    }
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=zipFileDownload.js.map