import { log } from '../../utils/logger.js';
import { createSchedHotel, getHotelSchedList, createHotelSchedIfNotExists, createArrgtCheck, updateSchedHotel, deleteHotelSchedIfExists, deleteSchedHotel, createArrgtHotel, updateSchedHotelIndividual, rejectSchedHotelIndividual, getSchedHotelForChecker, updateHotelSchedIfExists, createExpenseAccommodationsWhenArrgtFinished, } from '../../service/hotel/hotelService.js';
import { checkGetParamsNumber, replaceCRLF } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
import { isExistsItineraryCompanionsForArrgt } from '../../service/itinerary/itineraryService.js';
import { sendMail } from '../../service/azure/graphApiService.js';
import { convert2Buffer } from '../../utils/azureBlob.js';
import { addplanedSchedHotels, getExcelDownloadItineraryInfo, makeItinerarySchedulesExcel, } from '../../service/excel/makeItinerarySchedules.js';
import { getHotelsByIds } from '../../service/master/hotelService.js';
export const HOTEL_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedList(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
        isForeignStaff = true;
    }
    else {
        if (!checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    // 一覧取得実施
    result.data = await getHotelSchedList(prisma, pid, itineraryId, undefined, isForeignStaff);
    result.isSuccess = true;
    return result;
}
export const HOTEL_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function sched(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let isForeignStaff = false;
    let itineraryId = undefined;
    const id = Number(props.id);
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
        isForeignStaff = true;
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // ホテル予定IDを指定して一覧取得実施
    const list = await getHotelSchedList(prisma, pid, itineraryId, id, isForeignStaff);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const HOTEL_SCHED_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId', 'checkInDateTime', 'checkOutDateTime', 'timezone', 'checkinOutInputStatus'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        name: {
            type: 'string',
            maxLength: 255,
            description: 'ホテル名',
        },
        cityId: {
            type: ['integer', 'null'],
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '国または都市名',
        },
        address: {
            type: 'string',
            maxLength: 511,
            description: '住所',
        },
        checkInDateTime: {
            type: 'string',
            format: 'date-time',
            description: 'チェックイン日時。日付フォーマットはISO8601形式',
        },
        checkOutDateTime: {
            type: 'string',
            format: 'date-time',
            description: 'チェックアウト日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        checkinOutInputStatus: {
            type: 'integer',
            format: 'int64',
            maximum: 3,
            minimum: 0,
            description: 'オフィスへのアクセス時間',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        flgArrgt: {
            type: 'boolean',
            description: '手配実施有無のフラグ情報',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await createHotelSchedIfNotExists(pid, prisma, props.itineraryId, props.checkInDateTime, props.checkOutDateTime, props.companions);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // HotelSchedの新規登録処理
    const schedHotelId = await createSchedHotel(prisma, pid, user, props);
    // 新規登録したschedHotelと紐づくschedHotelIndividualsのみ取得実施
    const list = await getHotelSchedList(prisma, pid, undefined, schedHotelId, false);
    if (list.length !== 1) {
        // 今回作成したホテル予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    // 今回確定済フラグがtrueとなっている場合は、
    // ホテル予定の参加者全員に対して宿泊費経費項目レコードの新規登録を実施する。
    if (props.flgArrgt) {
        await createExpenseAccommodationsWhenArrgtFinished(prisma, user, schedHotelId);
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const HOTEL_SCHED_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'itineraryId', 'checkInDateTime', 'checkOutDateTime', 'timezone', 'checkinOutInputStatus'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ホテル予定ID',
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        cityId: {
            type: ['integer', 'null'],
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '都市ID。ホテル手配時は、ホテルに紐つく都市IDがデフォルト指定される想定。',
        },
        name: {
            type: 'string',
            maxLength: 255,
            description: 'ホテル名',
        },
        address: {
            type: 'string',
            maxLength: 511,
            description: '住所',
        },
        checkInDateTime: {
            type: 'string',
            format: 'date-time',
            description: 'チェックイン日時。日付フォーマットはISO8601形式',
        },
        checkOutDateTime: {
            type: 'string',
            format: 'date-time',
            description: 'チェックアウト日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        checkinOutInputStatus: {
            type: 'integer',
            format: 'int64',
            maximum: 3,
            minimum: 0,
            description: 'オフィスへのアクセス時間',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        flgArrgt: {
            type: 'boolean',
            description: '手配実施有無のフラグ情報',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)。手配実施後に、同行者を設定しても設定は全て無視される。',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
        schedHotelIndividual: {
            type: 'object',
            additionalProperties: false,
            properties: {
                price: {
                    type: ['number', 'null'],
                    maximum: 99999999.99,
                    minimum: 0.01,
                    validatePrecision: 2,
                },
                remark: {
                    type: 'string',
                    maxLength: 255,
                    description: '備考',
                },
            },
        },
    },
};
export async function schedUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // DB情報を取得
    const schedHotel = await getSchedHotelForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await updateHotelSchedIfExists(pid, prisma, schedHotel, props.itineraryId, props.checkInDateTime, props.checkOutDateTime, props.companions);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // HotelSchedの更新処理
    await updateSchedHotel(prisma, pid, user, schedHotel, props);
    // もともとは確定済フラグがfalseだったのが、今回確定済フラグがtrueとなっている場合は、
    // ホテル予定の参加者全員に対して宿泊費経費項目レコードの新規登録を実施する。
    if (!schedHotel.flgArrgt && props.flgArrgt) {
        await createExpenseAccommodationsWhenArrgtFinished(prisma, user, props.id);
    }
    result.isSuccess = true;
    return result;
}
export const HOTEL_SCHED_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ホテル予定ID',
        },
    },
};
export async function schedDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 削除対象となっているホテル予定の最新データ状況をDBから取得の上、処理実施する。
    const schedHotel = await getSchedHotelForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const checkError = await deleteHotelSchedIfExists(pid, schedHotel);
    // 入力チェックでエラーとなった場合処理終了
    if (checkError) {
        result.error = checkError;
        return result;
    }
    // HotelSchedの削除処理
    await deleteSchedHotel(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const HOTEL_ARRGT_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId', 'schedHotels', 'mail'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程ID。ホテル予定作成、ホテル手配作成時、この旅程IDが使われる',
        },
        schedHotels: {
            type: 'array',
            minItems: 1,
            maxItems: 1,
            description: 'この手配に紐つくホテル予定一覧',
            items: {
                type: 'object',
                additionalProperties: false,
                required: [
                    'arrgtEmail',
                    'checkInDateTime',
                    'checkOutDateTime',
                    'timezone',
                    'checkinOutInputStatus',
                    'companions',
                ],
                properties: {
                    arrgtEmail: {
                        type: 'array',
                        minItems: 1,
                        description: 'ホテル手配時に利用するTo Emailアドレス。',
                        items: {
                            type: 'string',
                            format: 'email',
                            maxLength: 255,
                        },
                    },
                    hotelId: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '選択されたホテルマスタのホテルID。',
                    },
                    checkInDateTime: {
                        type: 'string',
                        format: 'date-time',
                        description: 'チェックイン日時。日付フォーマットはISO8601形式',
                    },
                    checkOutDateTime: {
                        type: 'string',
                        format: 'date-time',
                        description: 'チェックアウト日時。日付フォーマットはISO8601形式',
                    },
                    timezone: {
                        type: 'string',
                        maxLength: 6,
                        pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
                        description: 'タイムゾーン',
                    },
                    checkinOutInputStatus: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 3,
                        minimum: 0,
                        description: 'オフィスへのアクセス時間',
                    },
                    remark: {
                        type: 'string',
                        maxLength: 255,
                        description: '備考',
                    },
                    companions: {
                        type: 'array',
                        minItems: 1,
                        description: '同行者一覧(フライト手配情報含む)。フライト手配時は、フライト作成者自身もここに情報が含まれるようにする。',
                        items: {
                            type: 'object',
                            additionalProperties: false,
                            required: ['pid'],
                            properties: {
                                pid: {
                                    type: 'string',
                                    maxLength: 15,
                                    description: '同行者のPersonal ID',
                                },
                                hotelRoomId: {
                                    type: 'integer',
                                    format: 'int64',
                                    maximum: 4294967295,
                                    minimum: 1,
                                    description: '選択されたホテルルームマスタのホテルルームID。',
                                },
                                flgSmoking: {
                                    type: 'boolean',
                                    description: '禁煙か喫煙かの情報。false:禁煙。',
                                },
                                arrgtRemark: {
                                    type: 'string',
                                    maxLength: 255,
                                    description: '手配時の備考情報',
                                },
                            },
                        },
                    },
                },
            },
        },
        mail: {
            type: 'object',
            additionalProperties: false,
            description: 'DBに保存しないEmail情報',
            required: ['sendMailTarget', 'cc', 'title', 'body'],
            properties: {
                sendMailTarget: {
                    enum: ['foreignStaff', 'hotel'],
                },
                cc: {
                    type: 'array',
                    description: '手配時に利用するEmailアドレス。',
                    items: {
                        type: 'string',
                        format: 'email',
                        maxLength: 255,
                    },
                },
                title: {
                    type: 'string',
                    maxLength: 255,
                    description: '手配時に利用するEmail件名。',
                },
                body: {
                    type: 'string',
                    maxLength: 65535,
                    description: '手配時に利用するEmail本文。',
                },
                fileInfo: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['base64', 'originalFileName'],
                    properties: {
                        base64: {
                            type: 'string',
                            description: 'Base64で文字列変換されたファイルデータ。画像圧縮時のbase64に含まれる「data:image/XXXXX;base64,」は取り除いたもの',
                        },
                        originalFileName: {
                            type: 'string',
                            maxLength: 270,
                            description: '元々のファイル名',
                        },
                        size: {
                            type: 'integer',
                            format: 'int64',
                            maximum: 4294967295,
                            minimum: 1,
                            description: 'ファイルサイズ',
                        },
                    },
                },
            },
        },
    },
};
export async function arrgtCreate(props, { pid, prisma, user, tokens }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const isExistsItineraryCompanionsForArrgtError = await isExistsItineraryCompanionsForArrgt(prisma, pid, props.itineraryId, props.schedHotels);
    // 入力チェックでエラーとなった場合処理終了
    if (isExistsItineraryCompanionsForArrgtError !== undefined) {
        result.error = isExistsItineraryCompanionsForArrgtError;
        return result;
    }
    // 入力チェック
    const schedHotelsProps = props.schedHotels;
    const hotelSerchIds = [];
    for (const schedHotelsProp of schedHotelsProps) {
        // hotelId指定がある場合は、そのidに合致するホテルマスタを取得する
        if (schedHotelsProp.hotelId) {
            hotelSerchIds.push(schedHotelsProp.hotelId);
        }
    }
    // 手配作成の処理で参照使用するホテルマスタ関連の情報はここで一括取得(他では取得しない)
    const dbHotelMasters = await getHotelsByIds(prisma, hotelSerchIds);
    // 入力チェックで使用するホテルマスタ情報のデータ加工
    const dbHotelMastersMap = {};
    for (const hotelMaster of dbHotelMasters) {
        dbHotelMastersMap[hotelMaster.id] = hotelMaster;
    }
    for (const schedHotelsProp of schedHotelsProps) {
        const inputCheckResult = createArrgtCheck(schedHotelsProp, dbHotelMastersMap);
        // 入力チェックでエラーとなった場合処理終了
        if (inputCheckResult !== undefined) {
            result.error = inputCheckResult;
            return result;
        }
    }
    // 添付ファイルがある場合は、添付ファイルの最大サイズのチェック実施
    const bufAttachment = props.mail.sendMailTarget === 'foreignStaff' && props.mail.fileInfo
        ? convert2Buffer(props.mail.fileInfo, 0)
        : undefined;
    let base64Attachment = '';
    if (props.mail.fileInfo && bufAttachment) {
        // ファイルサイズが設定された最大ファイルサイズを超えている場合はエラーとする。
        if (bufAttachment.code && bufAttachment.status) {
            result.error = bufAttachment;
            return result;
        }
        base64Attachment = props.mail.fileInfo.base64;
    }
    // ホテル手配の新規登録処理
    await createArrgtHotel(prisma, pid, user, props, dbHotelMastersMap);
    // メール送信
    if (props.mail) {
        // 旅程Excelファイルがなければ、旅程Excelの取得実施
        if (props.mail.sendMailTarget === 'foreignStaff' && !base64Attachment) {
            // 対象PIDの旅程情報取得
            const excelData = await getExcelDownloadItineraryInfo(prisma, pid, props.itineraryId);
            if ('error' in excelData) {
                result.error = excelData.error;
                return result;
            }
            // 旅程表に追加したいホテル予定がある場合
            if ('planedSchedHotels' in props) {
                addplanedSchedHotels(excelData.schedHotels, props.schedHotels, dbHotelMastersMap);
            }
            // excel作成
            const bufExcel = await makeItinerarySchedulesExcel(excelData, 'en');
            base64Attachment = bufExcel.toString('base64');
        }
        const attachments = base64Attachment
            ? [
                {
                    '@odata.type': '#microsoft.graph.fileAttachment',
                    contentBytes: base64Attachment,
                    contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    name: props.mail.fileInfo?.originalFileName || 'itinerary_schedules.xlsx',
                },
            ]
            : undefined;
        const sendMailRes = await sendMail(log, tokens.adAEnc, {
            // ホテル手配は、1手配あたり、常に一つのホテル予約となるので配列が1つのみ常に存在すると考えて問題ない。
            emailTo: props.schedHotels[0].arrgtEmail,
            emailCc: props.mail.cc,
            subject: props.mail.title,
            body: {
                contentType: 'Text',
                content: replaceCRLF(props.mail.body),
            },
            attachments,
        });
        if (!sendMailRes.isSuccess) {
            result.isDbRollback = true;
            return result;
        }
    }
    result.isSuccess = true;
    return result;
}
export const HOTEL_SCHED_INDIVIDUAL_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ホテル予定ID',
        },
        price: {
            type: 'number',
            maximum: 99999999.99,
            minimum: 0.01,
            validatePrecision: 2,
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
    },
};
export async function schedIndividualUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 処理対象となっているホテル予定の最新データ状況をDBから取得の上、処理実施する。
    const schedHotel = await getSchedHotelForChecker(prisma, props.id, pid);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // フライト個人予定の編集は、手配実施済か手配実施完了時のみ実行可能
    if (![Define.SETTINGS.ARRGT_STATUS.START, Define.SETTINGS.ARRGT_STATUS.FINISHED].includes(schedHotel.arrgtStatus)) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // DBからホテル予定情報が取得できない(W00109)
    if (schedHotel === null) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // SchedHotelIndividualの更新処理
    await updateSchedHotelIndividual(prisma, pid, user, props.id, false, props.price, props.remark);
    result.isSuccess = true;
    return result;
}
export const HOTEL_SCHED_INDIVIDUAL_REJECT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'flgReject'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ホテル予定ID',
        },
        flgReject: {
            type: 'boolean',
            description: '拒否フラグ。予定参加を拒否しているかどうか',
        },
    },
};
export async function schedIndividualReject(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 処理対象となっているホテル予定の最新データ状況をDBから取得の上、処理実施する。
    const schedHotel = await getSchedHotelForChecker(prisma, props.id, pid);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // DBからホテル予定情報が取得できない(W00109)
    if (schedHotel === null) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // SchedHotelIndividualの更新処理
    await rejectSchedHotelIndividual(prisma, pid, user, props.id, props.flgReject);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map