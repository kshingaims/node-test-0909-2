import { getSiteNotices, getTo_doList, updateFlgFinishedById, setFirstDisplayDateToday, getTo_do, } from '../../service/notification/notificationService.js';
import { checkGetParamsNumber, formatDate } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
export const NOTIFICATION_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
    },
};
export async function shouldDoList(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.itineraryId)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const itineraryId = Number(props.itineraryId);
    const list = await getTo_doList(prisma, pid, itineraryId);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export async function siteNoticeList(props, { prisma, pid }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    if (!checkGetParamsNumber(props.itineraryId)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const itineraryId = Number(props.itineraryId);
    const list = await getSiteNotices(prisma, pid, itineraryId);
    const firstDisplayDateNullIds = [];
    const today = formatDate(new Date());
    for (const item of list) {
        // 初回表示日付がnullの場合は、本日を初回表示日とする。
        if (!item.firstDisplayDate) {
            firstDisplayDateNullIds.push(item.id);
            item.firstDisplayDate = today;
        }
    }
    if (firstDisplayDateNullIds.length > 0) {
        // DBに対しても、初回表示日付がnullの場合は、本日を初回表示日となるように反映をかける。
        await setFirstDisplayDateToday(prisma, pid, itineraryId, firstDisplayDateNullIds);
    }
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const UPDATE_FLG_FINISHED_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'itineraryId', 'flgFinished'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'ID',
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程ID。',
        },
        flgFinished: {
            type: 'boolean',
        },
    },
};
export async function updateFlgFinished(props, { prisma, pid, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    const res = await updateFlgFinishedById(prisma, props.id, pid, user, props.itineraryId, props.flgFinished);
    if (res) {
        result.error = res;
        return result;
    }
    result.data = await getTo_do(prisma, pid, props.id, props.itineraryId);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map