import { createEventSchedIfNotExists, createSchedEvent, getEventSchedList, updateIfExists, updateSchedEvent, deleteIfExists, deleteSchedEvent, rejectSchedEventIndividual, getEventSchedData, getSchedEventForChecker, } from '../../service/event/eventService.js';
import { checkGetParamsNumber } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
export const EVENT_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedList(props, { pid, user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
    }
    else {
        if (!checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    // 一覧取得実施
    result.data = await getEventSchedList(prisma, pid, itineraryId, undefined, false);
    result.isSuccess = true;
    return result;
}
export const EVENT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 指定されたイベントIDに合致するイベント予定情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function sched(props, { pid, user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    const id = Number(props.id);
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // イベント予定IDを指定して一覧取得実施
    const list = await getEventSchedList(prisma, pid, itineraryId, id, false);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const EVENT_SCHED_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['name', 'startDateTime', 'endDateTime', 'timezone', 'location'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
        name: {
            type: 'string',
            pattern: '^(?!^[\\s\\u3000]*$).+$',
            maxLength: 255,
            description: 'イベント名',
        },
        startDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        endDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        location: {
            type: 'string',
            pattern: '^(?!^[\\s\\u3000]*$).+$',
            maxLength: 255,
            description: '場所',
        },
        address: {
            type: 'string',
            maxLength: 511,
            description: '住所',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            // pidは手配実施者のものとして処理する。
            pid = checkForeignStaffAccessResult.assignerPid;
        }
        isForeignStaff = true;
    }
    else if (props.itineraryId !== undefined) {
        itineraryId = props.itineraryId;
    }
    else {
        // japanStaffの場合は、id(旅程ID)の指定がないと入力チェックエラー (APIのリクエストパラメータが不正)
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await createEventSchedIfNotExists(pid, prisma, itineraryId, props.startDateTime, props.endDateTime, props.companions, isForeignStaff);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // EventSchedの新規登録処理
    const schedEventId = await createSchedEvent(prisma, pid, user, props, itineraryId, isForeignStaff);
    if (isForeignStaff) {
        const data = await getEventSchedData(prisma, schedEventId);
        if (!data) {
            // 今回作成したイベント予定は必ず存在するはず
            throw new Error('unreachable error.');
        }
        result.data = data;
    }
    else {
        // 一覧取得実施
        const list = await getEventSchedList(prisma, pid, undefined, schedEventId, false);
        if (list.length !== 1) {
            // 今回作成したイベント予定は必ず存在するはず
            throw new Error('unreachable error.');
        }
        result.data = list[0];
    }
    result.isSuccess = true;
    return result;
}
export const EVENT_SCHED_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'name', 'startDateTime', 'endDateTime', 'timezone', 'location'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'イベント予定ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        name: {
            type: 'string',
            pattern: '^(?!^[\\s\\u3000]*$).+$',
            maxLength: 255,
            description: 'イベント名',
        },
        startDateTime: {
            type: 'string',
            format: 'date-time',
            description: '開始日時。日付フォーマットはISO8601形式',
        },
        endDateTime: {
            type: 'string',
            format: 'date-time',
            description: '終了日時。日付フォーマットはISO8601形式',
        },
        timezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: 'タイムゾーン',
        },
        location: {
            type: 'string',
            pattern: '^(?!^[\\s\\u3000]*$).+$',
            maxLength: 255,
            description: '場所',
        },
        address: {
            type: 'string',
            maxLength: 511,
            description: '住所',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            // pidは手配実施者のものとして処理する。
            pid = checkForeignStaffAccessResult.assignerPid;
        }
        isForeignStaff = true;
    }
    else if (props.itineraryId !== undefined) {
        itineraryId = props.itineraryId;
    }
    else {
        // japanStaffの場合は、id(旅程ID)の指定がないと入力チェックエラー (APIのリクエストパラメータが不正)
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // DB情報を取得
    const schedEvent = await getSchedEventForChecker(prisma, props.id, itineraryId);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await updateIfExists(pid, prisma, schedEvent, itineraryId, props.startDateTime, props.endDateTime, props.companions, isForeignStaff);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // EventSchedの更新処理
    await updateSchedEvent(prisma, pid, user, schedEvent, props, isForeignStaff);
    result.isSuccess = true;
    return result;
}
export const EVENT_SCHED_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'イベント予定ID',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if (props.foreignStaffKey) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            itineraryId = checkForeignStaffAccessResult.itineraryId;
            isForeignStaff = true;
        }
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // 削除対象となっているイベント予定の最新データ状況をDBから取得の上、処理実施する。
    const schedEvent = await getSchedEventForChecker(prisma, props.id, itineraryId);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const error = await deleteIfExists(pid, schedEvent, isForeignStaff);
    if (error) {
        result.error = error;
        return result;
    }
    // EventSchedの削除処理
    await deleteSchedEvent(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const EVENT_SCHED_INDIVIDUAL_REJECT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'flgReject'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'イベント予定ID',
        },
        flgReject: {
            type: 'boolean',
            description: '拒否フラグ。予定参加を拒否しているかどうか',
        },
    },
};
/**
 * 予定参加拒否実施(予定作成者による拒否は不可)
 * @return
 */
export async function schedIndividualReject(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // DB情報を取得
    const schedEvent = await getSchedEventForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // DBから移動予定情報が取得できない(W00109)
    if (!schedEvent) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
        // 予定拒否実施しているのが、予定の作成者の場合
    }
    else if (schedEvent.ownerPid === pid) {
        result.error = { code: Define.ERROR_CODES.W00121, status: 400 };
        return result;
    }
    // このpidに合致するindividualsテーブル情報が存在するかチェック
    let isIndividualData = false;
    for (const individualData of schedEvent.schedEventIndividuals) {
        if (individualData.pid === pid && !individualData.flgDelete) {
            isIndividualData = true;
        }
    }
    if (!isIndividualData) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // SchedEventIndividualの更新処理
    await rejectSchedEventIndividual(prisma, pid, user, props.id, props.flgReject);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map