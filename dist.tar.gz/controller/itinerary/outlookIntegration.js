import { get } from 'lodash-es';
import { log } from '../../utils/logger.js';
import { getItem, hide, reflectOutlookCalendar } from '../../service/itinerary/outlookCalendarEventService.js';
import { updateOutlookCalendarInfo } from '../../service/itinerary/itineraryService.js';
import { getOutlookEvents } from '../../service/itinerary/outlookCalendarEventService.js';
import { updateOutlookCalendarImportedAt } from '../../service/itinerary/itineraryIndividualStatusService.js';
import { getItineraryDetail } from '../../controller/itinerary/index.js';
import { format, formatDateTimeMiliSecond, getKeys, isBeforeToday, replaceCRLF } from '../../utils/index.js';
import { checkAndGetTargetCalendar } from '../../service/azure/graphApiService.js';
import { Define } from '../../utils/define.js';
import { deleteOutlookCalendarEvent, formatCompanyCar, formatEvent, formatFlight, formatTransportation, sendItinerary, sendSchedHotels, sendScheds, updateDatabaseSchedHotel, updateDbSched, } from '../../service/itinerary/syncOutlookEventService.js';
import { getUserByPid } from '../../service/user/userService.js';
import { sendSmtpMail } from '../../utils/smtpMail.js';
import { getNotificationSettingMapByIds } from '../../service/notification/notificationSettingService.js';
import { createSiteNotification } from '../../service/notification/notificationService.js';
// import { getTransportationSchedList } from '../../service/transportation/transportationService.js';
export const IMPORT_INDIVIDUAL_OUTLOOK_EVENT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
    },
};
export async function importIndividualOutlookEvent(props, { pid, prisma, user, tokens }) {
    // Outlook予定の取り込み実施
    const result = await reflectOutlookCalendar(prisma, log, pid, user, props.itineraryId, tokens.adAEnc);
    if (result.isSuccess && result.data?.isDbChenged) {
        await updateOutlookCalendarImportedAt(prisma, pid, user, props.itineraryId);
        // outlook予定情報取得
        result.data.outlookEvents = await getOutlookEvents(prisma, pid, props.itineraryId);
    }
    return result;
}
export const EXPORT_SCHED_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
    },
};
export async function exportSchedsIntoOutlookEvent(props, { pid, prisma, user, tokens }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // この旅程に紐つく全ての予定を取得
    const data = await getItineraryDetail(prisma, pid, props.itineraryId, false, true);
    if ('error' in data) {
        result.error = data.error;
        return result;
    }
    // 出張終了日が過去日になっている場合は何も処理しないで終了とする。
    if (isBeforeToday(new Date(data.itinerary.itineraryTo))) {
        result.isSuccess = true;
        result.data = { isPast: true };
        return result;
    }
    const { isSkip, token, isNoAccessRight, calendar } = await checkAndGetTargetCalendar(log, prisma, pid, user, tokens.adAEnc);
    if (isNoAccessRight) {
        result.isSuccess = false;
        result.error = { code: Define.ERROR_CODES.W01101, status: 200 };
        return result;
    }
    // このユーザがoutlook連携対象となっていない場合は処理終了
    if (isSkip) {
        result.isSuccess = false;
        result.error = { code: Define.ERROR_CODES.W01102, status: 200 };
        return result;
    }
    // 旅程がまだoutlook予定連携されていない場合か、前回のoutlook反映後に変更があった旅程のみとする。
    const itineraryTarget = data.itinerary.calendarUpdatedAt &&
        formatDateTimeMiliSecond(new Date(data.itinerary.calendarUpdatedAt)) ===
            formatDateTimeMiliSecond(new Date(data.itinerary.updatedAt))
        ? null
        : data.itinerary;
    // outlook event対象とする予定は、処理対象pidが予定のオーナーであり、且つ、新規追加予定か前回のoutlook反映後に変更のある予定のみとする。
    const flightTarget = filterScheds(pid, data.schedFlights, 'schedFlight', 'departureDateTime', 'arrivalDateTime');
    const hotelTarget = filterSchedHotels(pid, data.schedHotels);
    const cCarTarget = filterScheds(pid, data.schedCompanyCars, 'schedCompanyCar', 'startDateTime', 'endDateTime');
    const transportationTarget = filterScheds(pid, data.schedTransportations, 'schedTransportation', 'departureDateTime', 'arrivalDateTime');
    const eventTarget = filterScheds(pid, data.schedEvents, 'schedEvent', 'startDateTime', 'endDateTime');
    // outlook event作成&添付メール連係処理
    // 旅程
    const itineraryORes = await sendItinerary(pid, itineraryTarget, calendar, token);
    // 予定
    const flightORes = await sendScheds(pid, flightTarget.updated, formatFlight, (schedIndividual) => {
        const schedFiles = get(schedIndividual, 'schedFlight.schedFlightFiles', []);
        return schedFiles;
    }, calendar, token);
    const hotelORes = await sendSchedHotels(pid, hotelTarget.updated, calendar, token);
    const cCarORes = await sendScheds(pid, cCarTarget.updated, formatCompanyCar, (schedIndividual) => {
        const schedFiles = get(schedIndividual, 'schedCompanyCar.schedCompanyCarFiles', []);
        return schedFiles;
    }, calendar, token);
    const transportationORes = await sendScheds(pid, transportationTarget.updated, formatTransportation, (schedIndividual) => {
        const schedFiles = get(schedIndividual, 'schedTransportation.schedTransportationFiles', []);
        return schedFiles;
    }, calendar, token);
    const eventORes = await sendScheds(pid, eventTarget.updated, formatEvent, (schedIndividual) => {
        const schedFiles = get(schedIndividual, 'schedEvent.schedEventFiles', []);
        return schedFiles;
    }, calendar, token);
    // outlook event削除処理
    const deleteOres = await deleteOutlookEvents(prisma, user, calendar, token, {
        flight: flightTarget.deleted,
        hotel: hotelTarget.deleted,
        companyCar: cCarTarget.deleted,
        transportation: transportationTarget.deleted,
        event: eventTarget.deleted,
    });
    const isItineraryDbUpdate = itineraryORes?.updatedData
        ? await updateOutlookCalendarInfo(prisma, pid, itineraryORes.updatedData.id, itineraryORes.updatedData.outlookEventId, itineraryORes.updatedData.lastModifiedDateTime, itineraryORes.updatedData.iCalUId)
        : true;
    const flightRes = await updateDbSched({ prisma, user }, 'flight', flightORes);
    const hotelRes = await updateDatabaseSchedHotel({ prisma, user }, hotelORes);
    const cCarRes = await updateDbSched({ prisma, user }, 'companyCar', cCarORes);
    const transRes = await updateDbSched({ prisma, user }, 'transportation', transportationORes);
    const eventRes = await updateDbSched({ prisma, user }, 'event', eventORes);
    if (!itineraryORes.isSuccess ||
        flightRes.isApiError ||
        hotelRes.isApiError ||
        cCarRes.isApiError ||
        transRes.isApiError ||
        eventRes.isApiError ||
        deleteOres.isApiError) {
        result.error = { code: Define.ERROR_CODES.W01104, status: 200 };
        if (!isItineraryDbUpdate ||
            flightRes.isDbError ||
            hotelRes.isDbError ||
            cCarRes.isDbError ||
            transRes.isDbError ||
            eventRes.isDbError ||
            deleteOres.isDbError) {
            result.error = { code: Define.ERROR_CODES.W01105, status: 200 };
        }
    }
    else {
        result.isSuccess = true;
        if (flightRes.isSuccess &&
            hotelRes.isSuccess &&
            cCarRes.isSuccess &&
            transRes.isSuccess &&
            eventRes.isSuccess &&
            deleteOres.isSuccess) {
            result.isSuccess = true;
        }
        if (flightRes.isDbError ||
            hotelRes.isDbError ||
            cCarRes.isDbError ||
            transRes.isDbError ||
            eventRes.isDbError ||
            deleteOres.isDbError) {
            result.error = { code: Define.ERROR_CODES.W01105, status: 200 };
        }
        // 代理者によってoutlook連携実行されたことをメール＆MCサイト内での通知実施
        if (pid !== user.pid) {
            await sendSmtpMailAndCreateSiteNotificationToAssigner(log, prisma, pid, user, props.itineraryId);
        }
    }
    return result;
}
function filterScheds(pid, schedIndividuals, key, keyStartTime, keyEndTime, filterCb) {
    const updated = [];
    const deleted = [];
    for (const schedIndividual of schedIndividuals) {
        const sched = schedIndividual[key];
        // 予定の開始日時、終了日時がきちんと定義されている予定のみを抽出とする
        if (sched[keyStartTime] && sched[keyEndTime]) {
            if (_isExportTargetSched(pid, sched)) {
                if (sched.flgDelete) {
                    if (sched.calendarId) {
                        deleted.push(sched);
                    }
                }
                else {
                    if (filterCb && !filterCb(sched)) {
                        // コールバック関数側でoutlook連携対象外と判断されたので、処理対象外とする
                    }
                    else {
                        updated.push(schedIndividual);
                    }
                }
            }
        }
    }
    return { updated, deleted };
}
function filterSchedHotels(pid, schedIndividuals) {
    const updated = [];
    const deleted = [];
    for (const schedIndividual of schedIndividuals) {
        const sched = schedIndividual.schedHotel;
        // 予定の開始日時、終了日時がきちんと定義されている予定のみを抽出とする
        if (sched.checkInDateTime && sched.checkOutDateTime) {
            if (_isExportTargetSched(pid, sched)) {
                if (sched.flgDelete) {
                    if (sched.calendarId) {
                        deleted.push(sched);
                    }
                }
                else {
                    updated.push(schedIndividual);
                }
            }
        }
    }
    return { updated, deleted };
}
function _isExportTargetSched(pid, sched) {
    if (pid !== sched.ownerPid) {
        return false;
    }
    else if (sched.calendarUpdatedAt &&
        formatDateTimeMiliSecond(new Date(sched.calendarUpdatedAt)) === formatDateTimeMiliSecond(new Date(sched.updatedAt))) {
        return false;
    }
    return true;
}
/**
 * 前回のoutlook予定連携後に、削除された予定について、Outlook予定の削除実施と共に、DB更新処理も合わせて実施する
 * @param prisma
 * @param user
 * @param pid
 * @param calendar
 * @param token
 * @param delFlight
 * @param delHotel
 * @param delCCar
 * @param delTransportion
 * @param delEvent
 * @returns
 */
async function deleteOutlookEvents(prisma, user, calendar, token, targets) {
    const result = {
        isSuccess: true,
    };
    for (const key of getKeys(targets)) {
        const scheds = targets[key];
        for (const sched of scheds) {
            const apiRes = await deleteOutlookCalendarEvent(prisma, user, token, calendar, sched, key);
            if (!apiRes.isSuccess) {
                result.isSuccess = false;
            }
            if (apiRes.isApiError) {
                result.isApiError = true;
            }
            if (apiRes.isDbError) {
                result.isDbError = true;
            }
        }
    }
    return result;
}
export const HIDE_OUTLOOK_EVENT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId', 'iCalUId'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        iCalUId: {
            type: 'string',
            maxLength: 255,
            description: '旅程id',
        },
    },
};
export async function hideOutlookEvent(props, { pid, prisma, user }) {
    const result = { isSuccess: false };
    const res = await hide(prisma, pid, user, props.itineraryId, props.iCalUId);
    if (res) {
        result.data = await getItem(prisma, pid, props.itineraryId, props.iCalUId);
        result.isSuccess = true;
    }
    return result;
}
async function sendSmtpMailAndCreateSiteNotificationToAssigner(log, prisma, targetPid, loginUser, itineraryId) {
    const settingMap = await getNotificationSettingMapByIds(prisma, [
        'delegator_sched_sync_to_outlook',
        'delegator_sched_sync_to_outlook_site_notification',
    ]);
    // SMTP通知処理
    const smtpSetting = settingMap['delegator_sched_sync_to_outlook'];
    if (!smtpSetting.title || !smtpSetting.content || !smtpSetting.linkUrl) {
        throw new Error('title, content linkUrl is necessary.');
    }
    const user = await getUserByPid(prisma, targetPid);
    if (!user || !user.email) {
        throw new Error(`user or user.email must be exist. [pid: ${targetPid}]`);
    }
    // リンクURL整形
    let linkUrl = format(smtpSetting.linkUrl, { domain: Define.DOMAIN, itineraryId });
    // メール本文整形
    const body = replaceCRLF(format(smtpSetting.content, { loginUser, linkUrl }));
    // メール送信
    sendSmtpMail(log, { to: [user.email], title: smtpSetting.title || '', body });
    // サイト上での通知実施
    const setting = settingMap['delegator_sched_sync_to_outlook_site_notification'];
    if (!setting.content || !setting.linkUrl) {
        throw new Error('content, linkUrl is necessary.');
    }
    linkUrl = format(setting.linkUrl, { domain: Define.DOMAIN, itineraryId });
    await createSiteNotification(prisma, targetPid, itineraryId, setting.content, linkUrl);
}
//# sourceMappingURL=outlookIntegration.js.map