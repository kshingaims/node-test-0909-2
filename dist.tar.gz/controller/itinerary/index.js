/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { merge, uniqWith, isEqual } from 'lodash-es';
import { log } from '../../utils/logger.js';
import { formatDate, getPageIndexAndMaxPage } from '../../utils/index.js';
import { isBeforeToday, isFromDateBeforeToDate, checkGetParamsNumber } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { checkForeignStaffAccessAndGetTargetPid } from '../../utils/foreignStaff.js';
import { getUserByPid, isExistsCompanions } from '../../service/user/userService.js';
import { isExistsCities } from '../../service/master/cityService.js';
import { create as createItinerary, updateItineraryIndividual, createItineraryIndividual, deleteItineraryIndividual, getItineraryIndividualList, getItineraryIndividual, searchItineraryList, formatItineraryPlaces, deleteItinerary, sendSmtpMailAndCreateSiteNotificationToCompanion, } from '../../service/itinerary/itineraryService.js';
import { getFlightSchedList } from '../../service/flight/flightService.js';
import { getHotelSchedList } from '../../service/hotel/hotelService.js';
import { getTransportationSchedList } from '../../service/transportation/transportationService.js';
import { getEventSchedList } from '../../service/event/eventService.js';
import { getCompanyCarSchedList } from '../../service/companyCar/companyCarService.js';
import { addplanedSchedCompanyCars, addplanedSchedHotels, getExcelDownloadItineraryInfo, makeItinerarySchedulesExcel, } from '../../service/excel/makeItinerarySchedules.js';
import { getOutlookEvents } from '../../service/itinerary/outlookCalendarEventService.js';
import { createExpense } from '../../service/expense/expenseIndexService.js';
import { createTo_doList } from '../../service/notification/notificationService.js';
import { getNotificationSettingMapByIds } from '../../service/notification/notificationSettingService.js';
import { getForeignStaffCompanyCarSchedList } from '../../service/companyCar/foreignStaffCompanyCarService.js';
import { getHotelsByIds } from '../../service/master/hotelService.js';
export const ITINERARY_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        pageIndex: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 9,
        },
        maxPage: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 9,
        },
        year: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            minLength: 4,
            maxLength: 4,
        },
    },
};
export async function list(props, { pid, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // yearが1999～9999の間でなければ、W99002(400)エラー
    if (!checkGetParamsNumber(props.year, 1999, 9999) && !checkGetParamsNumber(props.itineraryId)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    const { pageIndex, maxPage } = getPageIndexAndMaxPage({ pageIndex: props.pageIndex, maxPage: props.maxPage });
    // const itineraryIds = props.itineraryId ? [Number(props.itineraryId)] : [];
    const itineraryIds = await searchItineraryList(prisma, pid, pageIndex, maxPage, props.year ? Number(props.year) : undefined);
    const list = await getItineraryIndividualList(prisma, pid, itineraryIds);
    result.data = list;
    result.isSuccess = true;
    return result;
}
export const ITINERARY_INDEX_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        targetPid: {
            type: 'string',
            pattern: '^(?!^[s\u3000]*$).+$',
            maxLength: 15,
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function detail(props, { pid, user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let itineraryId = undefined;
    let isForeignStaff = false;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        // targetPidが指定されている場合は、assignerPidではなく、targetPidを利用する。
        pid = props.targetPid ? props.targetPid : checkForeignStaffAccessResult.assignerPid;
        itineraryId = checkForeignStaffAccessResult.itineraryId;
        isForeignStaff = true;
    }
    else {
        if (!props.itineraryId || !checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    // 旅程情報取得
    const data = await getItineraryDetail(prisma, pid, itineraryId, isForeignStaff);
    if ('error' in data) {
        result.error = data.error;
        return result;
    }
    result.data = data;
    const targetUser = await getUserByPid(prisma, pid);
    // outlook連携設定がONの場合のみ情報取得実施
    if (targetUser && targetUser.flgCalendarSync) {
        // outlook予定情報取得
        result.data.outlookEvents = await getOutlookEvents(prisma, pid, itineraryId, isForeignStaff);
    }
    else {
        result.data.outlookEvents = [];
    }
    if (isForeignStaff) {
        result.data.foreignStaffSchedCompanyCars = await getForeignStaffCompanyCarSchedList(prisma, itineraryId);
    }
    else {
        result.data.foreignStaffSchedCompanyCars = [];
    }
    result.isSuccess = true;
    return result;
}
const ITINERARY_CREATE_REQUIRED = ['itineraryName', 'places'];
const ITINERARY_UPDATE_REQUIRED = ['itineraryId', 'itineraryName', 'places'];
const ITINERARY_CREATE_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        itineraryName: {
            type: 'string',
            pattern: '^(?!^[s\u3000]*$).+$',
            maxLength: 255,
            description: '出張名',
        },
        places: {
            type: 'array',
            minItems: 1,
            description: '出張カード一覧',
            items: {
                type: 'object',
                additionalProperties: false,
                description: '出張カード情報',
                required: ['cityId', 'stayDurationFrom', 'stayDurationTo'],
                properties: {
                    cityId: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                    },
                    stayDurationFrom: {
                        type: 'string',
                        format: 'date',
                    },
                    stayDurationTo: {
                        type: 'string',
                        format: 'date',
                    },
                },
            },
        },
        companions: {
            type: 'array',
            nullable: true,
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                    },
                },
            },
        },
    },
};
export const ITINERARY_CREATE_SCHEMA = merge({ required: ITINERARY_CREATE_REQUIRED }, ITINERARY_CREATE_UPDATE_SCHEMA);
export const ITINERARY_UPDATE_SCHEMA = merge({ required: ITINERARY_UPDATE_REQUIRED }, ITINERARY_CREATE_UPDATE_SCHEMA);
export const ITINERARY_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        itineraryId: {
            type: 'number',
            maximum: 4294967295,
            minimum: 1,
            multipleOf: 1,
            description: '旅程id',
        },
    },
};
export async function create(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // ==========  開始 入力チェックエラー(ajvで判定できない動的な入力チェック処理)  =============
    // 同行者設定されている配列の数だけ、pidを取得する
    let companionPids = props.companions?.map((item) => {
        return item.pid;
    });
    // 旅程作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
    if (companionPids) {
        companionPids.push(pid);
    }
    else {
        companionPids = [pid];
    }
    // 指定されているpidが、実際に存在するユーザとなっているかをチェック
    if (companionPids) {
        const error = await isExistsCompanions(prisma, companionPids);
        if (error) {
            result.error = error;
            return result;
        }
    }
    // 指定されているcityIdが都市マスタにあるものかをチェック(W00105)
    // user存在チェック同様、service/ciry/にcityServiceを作り、そこでcityIdの存在チェック実施
    const placeCityIds = props.places?.map((item) => {
        return item.cityId;
    });
    if (placeCityIds) {
        const error = await isExistsCities(prisma, placeCityIds);
        if (error) {
            result.error = error;
            return result;
        }
    }
    // stayDurationFromが処理実施日よりも前になっている場合は入力チェックエラーとする(W00102)。
    // stayDurationFromがstayDurationToよりも後になっている場合は入力チェックエラーとする(W00103)。
    // どちらも、date-fnsのisBefore, isAfter関数を利用すると良い。
    // 期間の判定は他の機能でも使うので、utils関数として定義して欲しいです。
    for (const place of props.places) {
        if (isBeforeToday(new Date(place.stayDurationFrom))) {
            result.error = { code: Define.ERROR_CODES.W00102, status: 200 };
            return result;
        }
        if (isFromDateBeforeToDate(new Date(place.stayDurationTo), new Date(place.stayDurationFrom))) {
            result.error = { code: Define.ERROR_CODES.W00103, status: 200 };
            return result;
        }
    }
    // 出張カード情報(places)に、出張先(都市id)、出張開始日、出張終了日が全く同じものが複数存在している(W00205)
    const uniqPlaces = uniqWith(props.places, isEqual);
    if (props.places.length !== uniqPlaces.length) {
        result.error = { code: Define.ERROR_CODES.W00205, status: 200 };
        return result;
    }
    // ==========  終了 入力チェックエラー(ajvで判定できない動的な入力チェック処理)  =============
    // itineraryの新規登録処理
    const itineraryId = await createItinerary(log, prisma, pid, user, props);
    const listData = await getItineraryIndividualList(prisma, pid, [itineraryId]);
    result.data = listData[0];
    result.isSuccess = true;
    return result;
}
export async function update(props, { pid, prisma, user }) {
    const result = { isSuccess: false };
    // 同行者指定のpidがユーザマスタ存在していない(W00104)
    let companionPids = props.companions?.map((item) => {
        return item.pid;
    });
    // 旅程作成者も、旅程の作成者/同行者に含まれている必要があるので、チェック対象に追加しておく
    if (companionPids) {
        companionPids.push(pid);
    }
    else {
        companionPids = [pid];
    }
    if (companionPids) {
        const error = await isExistsCompanions(prisma, companionPids);
        if (error) {
            result.error = error;
            return result;
        }
    }
    // 出張先の都市idが都市マスタに存在していない(W00105)
    const placeCityIds = props.places?.map((item) => {
        return item.cityId;
    });
    if (placeCityIds) {
        const error = await isExistsCities(prisma, placeCityIds);
        if (error) {
            result.error = error;
            return result;
        }
    }
    const { itineraryFrom, itineraryTo, places } = formatItineraryPlaces(props.places);
    let isItineraryFromBeforeToday = false;
    for (const place of props.places) {
        // places(出張カード)内の、出張開始日が現在日よりも前の日付(W00102)
        if (isBeforeToday(new Date(place.stayDurationFrom))) {
            // このタイミングでは、出張中における出張期間の延長の可能性もあるので、入力チェックエラーにするかどうか保留
            isItineraryFromBeforeToday = true;
        }
        // places(出張カード)内の、出張開始日が出張終了日よりも前の日程となっている(W00103)
        if (isFromDateBeforeToDate(new Date(place.stayDurationTo), new Date(place.stayDurationFrom))) {
            result.error = { code: Define.ERROR_CODES.W00103, status: 200 };
            return result;
        }
    }
    // 出張カード情報(places)に、出張先(都市id)、出張開始日、出張終了日が全く同じものが複数存在している(W00205)
    const uniqPlaces = uniqWith(props.places, isEqual);
    if (props.places.length !== uniqPlaces.length) {
        result.error = { code: Define.ERROR_CODES.W00205, status: 200 };
        return result;
    }
    // 旅程の出張代表者でもなければ、同行者にもなっていない利用者が旅程更新処理しようとしている(W00201)
    const itineraryIndividual = await getItineraryIndividual(prisma, pid, props.itineraryId, false);
    if (!itineraryIndividual) {
        result.error = { code: Define.ERROR_CODES.W00201, status: 401 };
        return result;
    }
    else if (isItineraryFromBeforeToday && formatDate(new Date(itineraryIndividual.itineraryFrom)) !== itineraryFrom) {
        // places(出張カード)内の、出張開始日が現在日よりも前の日付(W00102)
        result.error = { code: Define.ERROR_CODES.W00102, status: 200 };
        return result;
    }
    const itinerary = itineraryIndividual.itinerary;
    // クライアント側から取得した旅程情報で、自分自身の旅程個人情報を更新する。
    const deleteCompanionsPids = []; // 削除対象となる同行者一覧
    const reCreateCompanionsPids = []; // 同行者に復活となる同行者一覧
    const createCompanionsPids = []; // 新規追加とな同行者一覧
    const existsCompanionPidMap = {}; // 元々同行者となっていた同行者のマップ情報
    if (itineraryIndividual.itinerary.ownerPid === pid) {
        if (props.companions) {
            for (const companionItineraryIndividual of itinerary.itineraryIndividuals) {
                // DBから取得した同行者(過去同行者指定されたアカウント含む)が、今回の変更後も同行者指定となっている
                if (companionPids.includes(companionItineraryIndividual.user.pid)) {
                    // DBから取得した削除状態な同行者
                    if (companionItineraryIndividual.flgDelete) {
                        // 復活する同行者
                        reCreateCompanionsPids.push(companionItineraryIndividual.user.pid);
                    }
                    existsCompanionPidMap[companionItineraryIndividual.user.pid] = true;
                }
                else {
                    // DBから取得した有効な同行者
                    if (!companionItineraryIndividual.flgDelete) {
                        // 今回削除対象となる同行者
                        deleteCompanionsPids.push(companionItineraryIndividual.user.pid);
                    }
                }
            }
            for (const deleteCompanionPid of deleteCompanionsPids) {
                // 既に予定が登録されている同行者を、旅程の同行者から削除しようとしている(W00204)
                const schedFlights = await getFlightSchedList(prisma, deleteCompanionPid, itinerary.id, undefined, false);
                const schedHotels = await getHotelSchedList(prisma, deleteCompanionPid, itinerary.id, undefined, false);
                const schedCompanyCars = await getCompanyCarSchedList(prisma, deleteCompanionPid, itinerary.id, undefined, false);
                const schedTransportations = await getTransportationSchedList(prisma, deleteCompanionPid, itinerary.id, undefined, false);
                const schedEvents = await getEventSchedList(prisma, deleteCompanionPid, itinerary.id, undefined, false);
                if (schedFlights.length > 0 ||
                    schedHotels.length > 0 ||
                    schedCompanyCars.length > 0 ||
                    schedTransportations.length > 0 ||
                    schedEvents.length > 0) {
                    result.error = { code: Define.ERROR_CODES.W00204, status: 401 };
                    return result;
                }
            }
            // 今回新たに追加となる同行者一覧を取得
            for (const companionPid of companionPids) {
                if (!existsCompanionPidMap[companionPid]) {
                    createCompanionsPids.push(companionPid);
                }
            }
        }
    }
    else {
        // 正式な出張代表者ではないのに、同行者(companions)情報がリクエストパラメータで連携されている(W00202)
        if (props.companions) {
            result.error = { code: Define.ERROR_CODES.W00202, status: 401 };
            return result;
        }
    }
    const itineraryName = props.itineraryName;
    // itinerary作成者(自分自身)のitineraryIndividual更新処理
    await updateItineraryIndividual(prisma, pid, pid, user, itinerary.id, itineraryName, itineraryFrom, itineraryTo, places);
    // itinerary作成者のみ処理を実施
    if (itineraryIndividual.itinerary.ownerPid === pid) {
        // 元々同行者となっていた人の旅程情報が、同行者によって改変されていない場合は、itinerary作成者の旅程情報を利用して更新実施
        for (const companionItineraryIndividual of itinerary.itineraryIndividuals) {
            const existPid = companionItineraryIndividual.user.pid;
            // 元々同行者となっていた人の場合
            if (existsCompanionPidMap[existPid]) {
                // 同行者本人によって旅程が改変されていない場合
                if (companionItineraryIndividual.ownerPid === pid) {
                    // 同行者によって改変されていない場合は、itinerary作成者の旅程情報を利用して更新実施
                    await updateItineraryIndividual(prisma, pid, existPid, user, itinerary.id, itineraryName, itineraryFrom, itineraryTo, places);
                }
            }
        }
        // 旅程の同行者へのメール通知実施,サイト内通知用のテンプレート取得
        const settingMap = createCompanionsPids.length > 0 || reCreateCompanionsPids.length > 0
            ? await getNotificationSettingMapByIds(prisma, [
                'add_itinerary_companion_mail',
                'add_itinerary_companion_site_notification',
            ])
            : {};
        // 復活した同行者のitineraryIndividual更新処理
        for (const reCreateCompanionPid of reCreateCompanionsPids) {
            await updateItineraryIndividual(prisma, pid, reCreateCompanionPid, user, itinerary.id, itineraryName, itineraryFrom, itineraryTo, places);
            // 同行者設定されたことをメールで通知実施
            const itineraryInfo = { itineraryName, itineraryFrom, itineraryTo, id: itinerary.id };
            await sendSmtpMailAndCreateSiteNotificationToCompanion(log, prisma, reCreateCompanionPid, user, itineraryInfo, settingMap);
        }
        // 新規追加となる同行者のitineraryIndividual新規登録処理
        for (const createCompanionsPid of createCompanionsPids) {
            await createItineraryIndividual(prisma, pid, createCompanionsPid, user, itinerary.id, itineraryName, itineraryFrom, itineraryTo, places);
            // 経費登録
            await createExpense(prisma, createCompanionsPid, user, itinerary.id);
            // to_doリスト作成
            await createTo_doList(prisma, createCompanionsPid, user, itinerary.id, false);
            // 同行者設定されたことをメールで通知実施
            const itineraryInfo = { itineraryName, itineraryFrom, itineraryTo, id: itinerary.id };
            await sendSmtpMailAndCreateSiteNotificationToCompanion(log, prisma, createCompanionsPid, user, itineraryInfo, settingMap);
        }
        // 同行者の削除(論理削除)
        for (const deleteCompanionsPid of deleteCompanionsPids) {
            await deleteItineraryIndividual(prisma, deleteCompanionsPid, user, itinerary.id);
        }
    }
    result.isSuccess = true;
    return result;
}
export async function itineraryDelete(props, { pid, prisma, user }) {
    const result = { isSuccess: false };
    const itinerary = await prisma.itinerary.findFirst({
        select: {
            id: true,
            ownerPid: true,
            schedFlights: { select: { itineraryId: true }, distinct: ['itineraryId'], where: { flgDelete: false } },
            schedHotels: { select: { itineraryId: true }, distinct: ['itineraryId'], where: { flgDelete: false } },
            schedCompanyCars: { select: { itineraryId: true }, distinct: ['itineraryId'], where: { flgDelete: false } },
            schedTransportations: { select: { itineraryId: true }, distinct: ['itineraryId'], where: { flgDelete: false } },
            schedEvents: { select: { itineraryId: true }, distinct: ['itineraryId'], where: { flgDelete: false } },
        },
        where: {
            id: props.itineraryId,
            flgDelete: false,
        },
    });
    // 削除指定されているidが、DBテーブル上に既に存在しない状態(W00106)
    if (!itinerary) {
        result.error = { code: Define.ERROR_CODES.W00106, status: 200 };
        return result;
    }
    // 出張代表者(旅程作成者)ではないのに、旅程を削除しようとしている(W00203)
    if (pid !== itinerary.ownerPid) {
        result.error = { code: Define.ERROR_CODES.W00203, status: 401 };
        return result;
    }
    // 正式な出張代表者(旅程作成者)が、既に予定が登録されている旅程を削除しようとしている(W00207)
    if (itinerary.schedFlights.length > 0 ||
        itinerary.schedHotels.length > 0 ||
        itinerary.schedCompanyCars.length > 0 ||
        itinerary.schedEvents.length > 0 ||
        itinerary.schedTransportations.length > 0) {
        result.error = { code: Define.ERROR_CODES.W00207, status: 200 };
        return result;
    }
    // itineraryの削除処理
    await deleteItinerary(prisma, user, itinerary.id);
    result.isSuccess = true;
    return result;
}
export const ITINERARY_EXCEL_DOWNLOAD_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程ID',
        },
        targetPid: {
            type: 'string',
            pattern: '^(?!^[s\u3000]*$).+$',
            maxLength: 15,
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
        isAll: {
            type: 'boolean',
        },
        planedSchedCompanyCars: {
            type: 'array',
            minItems: 1,
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['startDateTime', 'endDateTime', 'timezone', 'companions'],
                properties: {
                    startDateTime: {
                        type: 'string',
                        format: 'date-time',
                    },
                    endDateTime: {
                        type: 'string',
                        format: 'date-time',
                    },
                    timezone: {
                        type: 'string',
                        maxLength: 6,
                        pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
                        description: 'タイムゾーン',
                    },
                    departureLocation: {
                        type: 'string',
                        maxLength: 255,
                        description: '出発地',
                    },
                    companions: {
                        type: 'array',
                        minItems: 1,
                        description: '同行者一覧(同行者情報としてはpidのみ)',
                        items: {
                            type: 'object',
                            additionalProperties: false,
                            required: ['pid'],
                            properties: {
                                pid: {
                                    type: 'string',
                                    maxLength: 15,
                                },
                            },
                        },
                    },
                },
            },
        },
        planedSchedHotels: {
            type: 'array',
            minItems: 1,
            maxItems: 1,
            description: 'この手配に紐つくホテル予定一覧',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['checkInDateTime', 'checkOutDateTime', 'timezone', 'checkinOutInputStatus', 'companions'],
                properties: {
                    hotelId: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 4294967295,
                        minimum: 1,
                        description: '選択されたホテルマスタのホテルID。',
                    },
                    checkInDateTime: {
                        type: 'string',
                        format: 'date-time',
                        description: 'チェックイン日時。日付フォーマットはISO8601形式',
                    },
                    checkOutDateTime: {
                        type: 'string',
                        format: 'date-time',
                        description: 'チェックアウト日時。日付フォーマットはISO8601形式',
                    },
                    timezone: {
                        type: 'string',
                        maxLength: 6,
                        pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
                        description: 'タイムゾーン',
                    },
                    checkinOutInputStatus: {
                        type: 'integer',
                        format: 'int64',
                        maximum: 3,
                        minimum: 0,
                        description: 'オフィスへのアクセス時間',
                    },
                    companions: {
                        type: 'array',
                        minItems: 1,
                        description: '同行者一覧(同行者情報としてはpidのみ)',
                        items: {
                            type: 'object',
                            additionalProperties: false,
                            required: ['pid'],
                            properties: {
                                pid: {
                                    type: 'string',
                                    maxLength: 15,
                                },
                            },
                        },
                    },
                },
            },
        },
        lang: {
            enum: ['ja', 'en'],
        },
    },
};
export async function excelDownload(props, { pid, user, prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let itineraryId = undefined;
    let isForeignStaff = false;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        pid = checkForeignStaffAccessResult.assignerPid;
        itineraryId = checkForeignStaffAccessResult.itineraryId;
        isForeignStaff = true;
    }
    else {
        itineraryId = props.itineraryId;
    }
    const excelData = await getExcelDownloadItineraryInfo(prisma, pid, itineraryId);
    if ('error' in excelData) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // 旅程表に追加したい社有車予定がある場合
    if ('planedSchedCompanyCars' in props) {
        addplanedSchedCompanyCars(excelData.schedCompanyCars, props.planedSchedCompanyCars);
    }
    // 旅程表に追加したいホテル予定がある場合
    const dbHotelMastersMap = {};
    if ('planedSchedHotels' in props) {
        const hotelSerchIds = [];
        for (const schedHotelsProp of props.planedSchedHotels) {
            // hotelId指定がある場合は、そのidに合致するホテルマスタを取得する
            if (schedHotelsProp.hotelId) {
                hotelSerchIds.push(schedHotelsProp.hotelId);
            }
        }
        // 手配作成の処理で参照使用するホテルマスタ関連の情報はここで一括取得(他では取得しない)
        const dbHotelMasters = await getHotelsByIds(prisma, hotelSerchIds);
        // 指定されたhotelIdが存在しない
        if (hotelSerchIds.length !== dbHotelMasters.length) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        for (const hotelMaster of dbHotelMasters) {
            dbHotelMastersMap[hotelMaster.id] = hotelMaster;
        }
        addplanedSchedHotels(excelData.schedHotels, props.planedSchedHotels, dbHotelMastersMap);
    }
    const lang = props.lang ? props.lang : isForeignStaff ? 'en' : 'ja';
    // excel作成
    const excelBuffer = await makeItinerarySchedulesExcel(excelData, lang);
    result.data = {
        base64: excelBuffer.toString('base64'),
        originalFileName: 'itinerary_schedule.xlsx',
    };
    result.isSuccess = true;
    return result;
}
// export async function excelDownloadOld(
//   props:
//     | { foreignStaffKey: string; targetPid?: string; isAll?: boolean; lang?: Lang }
//     | {
//         itineraryId: number;
//         isAll?: boolean;
//         planedSchedCompanyCars: Pick<
//           SchedCompanyCarProps,
//           'startDateTime' | 'endDateTime' | 'timezone' | 'departureLocation'
//         >[];
//         planedSchedHotels: Pick<
//           HotelArrgtCreateSchedHotelProps,
//           'checkInDateTime' | 'checkOutDateTime' | 'timezone' | 'checkinOutInputStatus' | 'hotelId'
//         >[];
//         lang?: Lang;
//       },
//   { pid, user, prisma }: IControllerTools
// ): Promise<IContollerResponse> {
//   // APIのレスポンスとなるJSONデータ
//   const result: IContollerResponse = { isSuccess: false };
//   let itineraryId: number | undefined = undefined;
//   let isForeignStaff = false;
//   const isAll = props.isAll || false;
//   if ('foreignStaffKey' in props) {
//     // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
//     const checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(
//       prisma,
//       props.foreignStaffKey,
//       user
//     );
//     if ('error' in checkForeignStaffAccessResult) {
//       result.error = checkForeignStaffAccessResult.error;
//       return result;
//     }
//     // targetPidが指定されている場合は、assignerPidではなく、targetPidを利用する。
//     pid = props.targetPid ? props.targetPid : checkForeignStaffAccessResult.assignerPid;
//     itineraryId = checkForeignStaffAccessResult.itineraryId;
//     isForeignStaff = true;
//   } else {
//     itineraryId = props.itineraryId;
//   }
//   const excelDatas = [] as {
//     itinerary: {
//       itinerary: { itineraryIndividuals: { user: User }[] };
//     };
//     schedFlights: unknown[];
//     schedHotels: unknown[];
//     schedCompanyCars: unknown[];
//     schedTransportations: unknown[];
//     schedEvents: unknown[];
//   }[];
//   const targetPids: string[] = [];
//   // 対象PIDの旅程情報取得
//   const excelData = await getItineraryDetail(prisma, pid, itineraryId, isForeignStaff);
//   if ('error' in excelData) {
//     result.error = excelData.error;
//     return result;
//   }
//   // 旅程表に追加したい社有車予定がある場合
//   if ('planedSchedCompanyCars' in props) {
//     addplanedSchedCompanyCars(excelData.schedCompanyCars, props.planedSchedCompanyCars);
//   }
//   // 旅程表に追加したいホテル予定がある場合
//   const dbHotelMastersMap: { [hotelId: number]: HotelMaster } = {};
//   if ('planedSchedHotels' in props) {
//     const hotelSerchIds: number[] = [];
//     for (const schedHotelsProp of props.planedSchedHotels) {
//       // hotelId指定がある場合は、そのidに合致するホテルマスタを取得する
//       if (schedHotelsProp.hotelId) {
//         hotelSerchIds.push(schedHotelsProp.hotelId);
//       }
//     }
//     // 手配作成の処理で参照使用するホテルマスタ関連の情報はここで一括取得(他では取得しない)
//     const dbHotelMasters = await getHotelsByIds(prisma, hotelSerchIds);
//     // 指定されたhotelIdが存在しない
//     if (hotelSerchIds.length !== dbHotelMasters.length) {
//       result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
//       return result;
//     }
//     for (const hotelMaster of dbHotelMasters) {
//       dbHotelMastersMap[hotelMaster.id] = hotelMaster;
//     }
//     addplanedSchedHotels(excelData.schedHotels, props.planedSchedHotels, dbHotelMastersMap);
//   }
//   excelDatas.push(excelData);
//   targetPids.push(pid);
//   // isAll指定時は、旅程の同行者全員分の旅程情報取得実施
//   if (isAll) {
//     const itineraryIndividuals = excelData.itinerary.itinerary.itineraryIndividuals;
//     for (const itineraryIndividual of itineraryIndividuals) {
//       const targetPid = itineraryIndividual.user.pid;
//       if (targetPid !== pid) {
//         const companionsExcelData = await getItineraryDetail(prisma, targetPid, itineraryId, isForeignStaff);
//         if ('error' in companionsExcelData) {
//           result.error = companionsExcelData.error;
//           return result;
//         }
//         // 旅程表に追加したい社有車予定がある場合
//         if ('planedSchedCompanyCars' in props) {
//           addplanedSchedCompanyCars(companionsExcelData.schedCompanyCars, props.planedSchedCompanyCars);
//         }
//         // 旅程表に追加したいホテル予定がある場合
//         if ('planedSchedHotels' in props) {
//           addplanedSchedHotels(excelData.schedHotels, props.planedSchedHotels, dbHotelMastersMap);
//         }
//         excelDatas.push(companionsExcelData);
//         targetPids.push(targetPid);
//       }
//     }
//   }
//   const lang: Lang = props.lang ? props.lang : isForeignStaff ? 'en' : 'ja';
//   // excel作成
//   const excelBuffer = await makeItinerarySchedulesExcel(targetPids, excelDatas, lang);
//   result.data = {
//     base64: excelBuffer.toString('base64'), // base64形式でクライアントに返却する。
//     originalFileName: 'itinerary_schedule.xlsx',
//   };
//   result.isSuccess = true;
//   return result;
// }
export async function getItineraryDetail(prisma, pid, itineraryId, isForeignStaff, isInternal = false) {
    // 対象PIDの旅程情報取得
    const list = await getItineraryIndividualList(prisma, pid, [itineraryId], isInternal);
    if (!list || list.length !== 1) {
        return { error: { code: Define.ERROR_CODES.W00109, status: 400 } };
    }
    return {
        itinerary: list[0],
        schedFlights: await getFlightSchedList(prisma, pid, itineraryId, undefined, isForeignStaff, isInternal),
        schedHotels: await getHotelSchedList(prisma, pid, itineraryId, undefined, isForeignStaff, isInternal),
        schedCompanyCars: await getCompanyCarSchedList(prisma, pid, itineraryId, undefined, isInternal),
        schedTransportations: await getTransportationSchedList(prisma, pid, itineraryId, undefined, isInternal),
        schedEvents: await getEventSchedList(prisma, pid, itineraryId, undefined, isInternal),
    };
}
//# sourceMappingURL=index.js.map