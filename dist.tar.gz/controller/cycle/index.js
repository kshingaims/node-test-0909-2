import { log } from '../../utils/logger.js';
import { applyBeforeBusinessTrip as applyBeforeBusinessTripExcecute } from '../../service/cycle/beforeApply.js';
import { applyAfterBusinessTrip as applyAfterBusinessTripExcecute } from '../../service/cycle/afterApply.js';
import { Define } from '../../utils/define.js';
import { getZipFileInfo, removeZipFile } from '../../service/expense/makeZipOfAllExpenseAttachments.js';
export const CYCLE_APPLY_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId'],
    properties: {
        iwInfoIntra3: {
            type: 'string',
            maxLength: 65535,
            description: 'Cycleシステムがログイン完了していた場合に、Cookie(IW_INFO_INTRA3)にセットされている文字列',
        },
        password: {
            type: 'string',
            maxLength: 65535,
            description: 'CycleシステムへPersonalIDでのログイン実施時に利用するパスワード',
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        _noDbUpdate: {
            type: 'boolean',
            description: 'Cycle事前申請正常成功時であっても、DB更新を実施しないかどうかのフラグ値',
        },
    },
};
export async function applyBeforeBusinessTrip(props, { pid, prisma, user }) {
    const result = { isSuccess: false };
    const requiedCheck = checkRequiredPasswordOrCookie(props);
    if (requiedCheck) {
        result.error = requiedCheck;
        return result;
    }
    const id = (props.password) ? user.pid : undefined;
    const applayRes = await applyBeforeBusinessTripExcecute(log, { prisma, user, pid, itineraryId: props.itineraryId, _noDbUpdate: props._noDbUpdate }, { cookieIwInfoIntra3: props.iwInfoIntra3, id, pass: props.password });
    if (applayRes.isSuccess) {
        if (applayRes.isDbUpdate) {
            result.isSuccess = true;
        }
        else {
            result.error = { code: Define.ERROR_CODES.W01005, status: 200 };
        }
    }
    else {
        // Cycleログインができていない or 認証エラー発生 or Cycleシステムで対象のPIDに対して代理者が処理する権限を持っていない
        if (applayRes.isLoginValidateError || applayRes.isSecretUnset) {
            if (applayRes.errorCode === Define.ERROR_CODES.W01001) {
                result.error = { code: Define.ERROR_CODES.W01001, status: 200 };
            }
            else {
                result.error = { code: Define.ERROR_CODES.W01002, status: 200 };
            }
            // パラメータ不正アクセス
        }
        else if (applayRes.isInvalidAccess) {
            // 処理可能な旅程情報取得に失敗
            if (applayRes.errorCode) {
                result.error = { code: applayRes.errorCode, status: 400 };
            }
            else {
                // 既にCycle連携実行済
                result.error = { code: Define.ERROR_CODES.W01004, status: 200 };
            }
        }
        else {
            result.error = { code: Define.ERROR_CODES.W01003, status: 200 };
        }
    }
    return result;
}
export async function applyAfterBusinessTrip(props, { pid, prisma, user }) {
    const result = { isSuccess: false };
    const requiedCheck = checkRequiredPasswordOrCookie(props);
    if (requiedCheck) {
        result.error = requiedCheck;
        return result;
    }
    const id = (props.password) ? user.pid : undefined;
    const applayRes = await applyAfterBusinessTripExcecute(log, { prisma, user, pid, itineraryId: props.itineraryId, _noDbUpdate: props._noDbUpdate }, { cookieIwInfoIntra3: props.iwInfoIntra3, id, pass: props.password });
    if (applayRes.isSuccess) {
        if (applayRes.isDbUpdate) {
            result.isSuccess = true;
            // ZIPファイルがあれば、返却実施
            if (applayRes.zipFilename) {
                const fileInfo = await getZipFileInfo(applayRes.zipFilename);
                if (fileInfo) {
                    if (fileInfo.base64) {
                        result.data = { zipFile: fileInfo };
                        await removeZipFile(applayRes.zipFilename);
                    }
                    else {
                        // ZIPファイルが大きすぎてZIPファイルの送信ができない
                        result.error = { code: Define.ERROR_CODES.W01010, status: 200 };
                    }
                }
            }
        }
        else {
            result.error = { code: Define.ERROR_CODES.W01008, status: 200 };
        }
    }
    else {
        // Cycleログインができていない or 認証エラー発生 or Cycleシステムで対象のPIDに対して代理者が処理する権限を持っていない
        if (applayRes.isLoginValidateError || applayRes.isSecretUnset) {
            if (applayRes.errorCode === Define.ERROR_CODES.W01001) {
                result.error = { code: Define.ERROR_CODES.W01001, status: 200 };
            }
            else {
                result.error = { code: Define.ERROR_CODES.W01002, status: 200 };
            }
            // パラメータ不正アクセス
        }
        else if (applayRes.isInvalidAccess) {
            // 処理可能な旅程情報取得に失敗
            if (applayRes.errorCode) {
                const status = Define.ERROR_CODES.W01009 === applayRes.errorCode ? 200 : 400;
                result.error = { code: applayRes.errorCode, status };
            }
            else {
                // 既にCycle連携実行済
                result.error = { code: Define.ERROR_CODES.W01007, status: 200 };
            }
        }
        else {
            result.error = { code: Define.ERROR_CODES.W01006, status: 200 };
        }
    }
    return result;
}
function checkRequiredPasswordOrCookie(props) {
    if (!props.iwInfoIntra3 && !props.password) {
        return { code: Define.ERROR_CODES.W99002 };
    }
    return undefined;
}
//# sourceMappingURL=index.js.map