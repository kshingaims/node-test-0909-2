import express from 'express';
import { Define } from '../utils/define.js';
import { getHandler, postHandler } from '../controller/routeHandler.js';
import { AUTH_SCHEMA, authCheck, auth } from '../controller/auth/index.js';
import { create as seedCreate } from '../controller/seed/index.js';
import { dbRollbackTest, errorTest, checkAlive, integrationTest, excelDownloadTest } from '../controller/test/index.js';
import { MASTER_CITY_CREATE_SCHEMA, MASTER_CITY_UPDATE_SCHEMA, MASTER_CITY_DELETE_SCHEMA, MASTER_CITY_SEARCH_FROM_COUNTRY_CITY_NAME_SCHEMA, create as masterCityCreate, update as masterCityUpdate, cityDelete as masterCityDelete, search as masterCitySearch, searchFromCountryCityName, list as masterCityList, } from '../controller/master/city.js';
import { MASTER_HOTEL_CREATE_SCHEMA, MASTER_HOTEL_UPDATE_SCHEMA, MASTER_HOTEL_DELETE_SCHEMA, create as masterHotelCreate, update as masterHotelUpdate, hotelDelete as masterHotelDelete, search as masterHotelSearch, list as masterHotelList, MASTER_HOTEL_LIST_SCHEMA, MASTER_HOTEL_SERACH_SCHEMA, } from '../controller/master/hotel.js';
import { MASTER_COMPANY_CAR_CREATE_SCHEMA, MASTER_COMPANY_CAR_UPDATE_SCHEMA, MASTER_COMPANY_CAR_DELETE_SCHEMA, create as masterCampanyCarCreate, update as masterCampanyCarUpdate, companyCarDelete as masterCampanyCarDelete, list as masterCampanyCarList, search as masterCampanyCarSearch, MASTER_COMPANY_CAR_LIST_SCHEMA, MASTER_COMPANY_CAR_SEARCH_SCHEMA, } from '../controller/master/companyCar.js';
import { MASTER_DRIVER_SEARCH_SCHEMA, MASTER_DRIVER_CREATE_SCHEMA, MASTER_DRIVER_UPDATE_SCHEMA, MASTER_DRIVER_DELETE_SCHEMA, create as masterDriverCreate, update as masterDriverUpdate, driverDelete as masterDriverDelete, search as masterDriverSearch, list as masterDriverList, MASTER_DRIVER_LIST_SCHEMA, } from '../controller/master/driver.js';
import { USER_SERACH_SCHEMA, USER_EXPANSION_LIST, USER_UPDATE_CALENDAR_SYNC_SCHEMA, USER_UPDATE_WEBPUSH_DEVICE_INFO, updateWebpushDeviceInfo, search as userSearch, getUserExpansionList, userUpdateCalendarSync, } from '../controller/master/user.js';
import { ITINERARY_CREATE_SCHEMA, ITINERARY_DELETE_SCHEMA, ITINERARY_LIST_SCHEMA, ITINERARY_INDEX_SCHEMA, create as itineraryCreate, update as itineraryUpdate, itineraryDelete, list as itineraryIndividualList, detail as itineraryDetail, ITINERARY_UPDATE_SCHEMA, excelDownload as itineraryExcelDownload, ITINERARY_EXCEL_DOWNLOAD_SCHEMA, } from '../controller/itinerary/index.js';
import { DELEGATOR_UPSERT_SCHEMA, DELEGATOR_DELETE_SCHEMA, list as usersDelegatorList, upsert as usersDelegatorUpsert, deleteDelegator as usersDelegatorDelete, } from '../controller/delegator/index.js';
import { FLIGHT_LIST_SCHEMA, FLIGHT_SCHED_CREATE_SCHEMA, FLIGHT_SCHED_UPDATE_SCHEMA, FLIGHT_SCHED_INDIVIDUAL_UPDATE_SCHEMA, FLIGHT_SCHED_INDIVIDUAL_REJECT_SCHEMA, FLIGHT_SCHED_DELETE_SCHEMA, FLIGHT_ARRGT_CREATE_SCHEMA, schedList as flightSchedList, sched as flightSched, schedCreate as flightSchedCreate, schedUpdate as flightSchedUpdate, schedIndividualUpdate as flightSchedIndividualUpdate, schedIndividualReject as flightSchedIndividualReject, schedDelete as flightSchedDelete, arrgtCreate as flightArrgtCreate, FLIGHT_SCHEMA, } from '../controller/flight/index.js';
import { TRANSPORTATION_LIST_SCHEMA, TRANSPORTATION_SCHED_CREATE_SCHEMA, TRANSPORTATION_SCHED_UPDATE_SCHEMA, TRANSPORTATION_SCHED_DELETE_SCHEMA, TRANSPORTATION_SCHEMA, TRANSPORTATION_SCHED_INDIVIDUAL_REJECT_SCHEMA, schedList as transportationSchedList, sched as transportationSched, schedCreate as transportationSchedCreate, schedUpdate as transportationSchedUpdate, schedDelete as transportationSchedDelete, schedIndividualReject as transportationSchedIndividualReject, } from '../controller/transportation/index.js';
import { EVENT_LIST_SCHEMA, EVENT_SCHED_CREATE_SCHEMA, EVENT_SCHED_UPDATE_SCHEMA, EVENT_SCHED_DELETE_SCHEMA, EVENT_SCHEMA, EVENT_SCHED_INDIVIDUAL_REJECT_SCHEMA, schedList as eventSchedList, sched as eventSched, schedCreate as eventSchedCreate, schedUpdate as eventSchedUpdate, schedDelete as eventSchedDelete, schedIndividualReject as eventSchedIndividualReject, } from '../controller/event/index.js';
import { HOTEL_SCHEMA, HOTEL_LIST_SCHEMA, HOTEL_SCHED_CREATE_SCHEMA, HOTEL_SCHED_UPDATE_SCHEMA, HOTEL_SCHED_INDIVIDUAL_UPDATE_SCHEMA, HOTEL_SCHED_INDIVIDUAL_REJECT_SCHEMA, HOTEL_SCHED_DELETE_SCHEMA, HOTEL_ARRGT_CREATE_SCHEMA, sched as hotelSched, schedList as hotelSchedList, schedCreate as hotelSchedCreate, schedUpdate as hotelSchedUpdate, schedIndividualUpdate as hotelSchedIndividualUpdate, schedIndividualReject as hotelSchedIndividualReject, schedDelete as hotelSchedDelete, arrgtCreate as hotelArrgtCreate, } from '../controller/hotel/index.js';
import { EXPENSE_SCHEMA, EXPENSE_TRANSPORTATION_INDEX_SCHEMA, EXPENSE_TRANSPORTATION_CREATE_SCHEMA, EXPENSE_TRANSPORTATION_UPDATE_SCHEMA, EXPENSE_TRANSPORTATION_DELETE_SCHEMA, expense, transportation, expenseTransportationCreate, expenseTransportationUpdate, expenseTransportationDelete, accommodation, EXPENSE_ACCOMMODATION_INDEX_SCHEMA, expenseAccommodationCreate, EXPENSE_ACCOMMODATION_CREATE_SCHEMA, expenseAccommodationUpdate, EXPENSE_ACCOMMODATION_UPDATE_SCHEMA, expenseAccommodationDelete, EXPENSE_ACCOMMODATION_DELETE_SCHEMA, EXPENSE_OTHER_INDEX_SCHEMA, other, expenseOtherCreate, EXPENSE_OTHER_CREATE_SCHEMA, expenseOtherUpdate, EXPENSE_OTHER_UPDATE_SCHEMA, expenseOtherDelete, EXPENSE_OTHER_DELETE_SCHEMA, } from '../controller/expense/index.js';
import { SCHED_FILE_DOWNLOAD_SCHEMA, SCHED_FILE_UPLOAD_SCHEMA, SCHED_FILE_DELETE_SCHEMA, fileSchedUpload, fileSchedDownload, fileSchedDelete, fileExpenseDownload, EXPENSE_FILE_DOWNLOAD_SCHEMA, fileExpenseUpload, EXPENSE_FILE_UPLOAD_SCHEMA, fileExpenseDelete, EXPENSE_FILE_DELETE_SCHEMA, filePublicContainerDownload, PUBLIC_CONTAINER_FILE_DOWNLOAD_SCHEMA, filePublicContainerUpload, PUBLIC_CONTAINER_FILE_UPLOAD_SCHEMA, filePublicContainerDelete, PUBLIC_CONTAINER_FILE_DELETE_SCHEMA, } from '../controller/file/index.js';
import { FRONT_ERROR_LOG_SEND_SCHEMA, send } from '../controller/frontErrorLog/index.js';
import { COMPANY_CAR_ARRGT_CREATE_SCHEMA, COMPANY_CAR_ARRGT_LIST_SCHEMA, COMPANY_CAR_ARRGT_SCHEMA, arrgtList as companyCarArrgtList, arrgt as companyCarArrgt, arrgtCreate as companyCarArrgtCreate, COMPANY_CAR_SCHED_CREATE_SCHEMA, COMPANY_CAR_SCHED_UPDATE_SCHEMA, COMPANY_CAR_SCHED_DELETE_SCHEMA, COMPANY_CAR_SCHED_LIST_SCHEMA, COMPANY_CAR_SCHED_SCHEMA, schedList as companyCarSchedList, sched as companyCarSched, schedCreate as companyCarSchedCreate, schedUpdate as companyCarSchedUpdate, schedDelete as companyCarSchedDelete, COMPANY_CAR_SCHED_INDIVIDUAL_REJECT_SCHEMA, schedIndividualReject as companyCarSchedIndividualReject, } from '../controller/companyCar/index.js';
import { FOREIGN_STAFF_SCHED_COMPANY_CAR_CREATE_SCHEMA, FOREIGN_STAFF_SCHED_COMPANY_CAR_DELETE_SCHEMA, FOREIGN_STAFF_SCHED_COMPANY_CAR_LIST_SCHEMA, FOREIGN_STAFF_SCHED_COMPANY_CAR_SCHEMA, FOREIGN_STAFF_SCHED_COMPANY_CAR_UPDATE_SCHEMA, FOREIGN_STAFF_SCHED_COMPANY_CAR_CHANGE_ARRGT_SCHEMA, schedList as foreignStaffSchedCompanyCarList, sched as foreignStaffSchedCompanyCarIndex, schedCreate as foreignStaffSchedCompanyCarCreate, schedUpdate as foreignStaffSchedCompanyCarUpdate, schedDelete as foreignStaffSchedCompanyCarDelete, schedArrgtComplete as foreignStaffSchedCompanyCarArrgtComplete, } from '../controller/companyCar/foreignStaffSchedCompanyCar.js';
import { CYCLE_APPLY_SCHEMA, applyBeforeBusinessTrip, applyAfterBusinessTrip } from '../controller/cycle/index.js';
import { importIndividualOutlookEvent, IMPORT_INDIVIDUAL_OUTLOOK_EVENT_SCHEMA, EXPORT_SCHED_SCHEMA, exportSchedsIntoOutlookEvent, hideOutlookEvent, HIDE_OUTLOOK_EVENT_SCHEMA, } from '../controller/itinerary/outlookIntegration.js';
import { faqList } from '../controller/master/faq.js';
import { NOTIFICATION_LIST_SCHEMA, UPDATE_FLG_FINISHED_SCHEMA, shouldDoList, siteNoticeList, updateFlgFinished, } from '../controller/notification/index.js';
import { EXPENSE_ZIPFILE_DOWNLOAD_SCHEMA, expenseZipFileDownload } from '../controller/expense/zipFileDownload.js';
const router = express.Router();
// ======== 認証機能 ========
getHandler({
    router,
    path: '/auth/check',
    actionName: 'auth check',
    controller: authCheck,
    isAuthorised: false,
});
postHandler({
    router,
    path: '/auth/auth',
    actionName: 'login',
    controller: auth,
    validateSchema: AUTH_SCHEMA,
    isAuthorised: false,
});
// ======== マスタ関連機能 =========
// ======== 都市マスタ =========
getHandler({
    router,
    path: '/master/city/search',
    actionName: 'search master city',
    controller: masterCitySearch,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/master/city/searchFromCountryCityName',
    actionName: 'search master city from county city name',
    controller: searchFromCountryCityName,
    validateSchema: MASTER_CITY_SEARCH_FROM_COUNTRY_CITY_NAME_SCHEMA,
    isAllowDelegatorAccess: false,
    roles: { foreignStaff: true },
});
getHandler({
    router,
    path: '/master/city/list',
    actionName: 'list master city',
    controller: masterCityList,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/master/city/create',
    actionName: 'create master city',
    controller: masterCityCreate,
    validateSchema: MASTER_CITY_CREATE_SCHEMA,
    roles: { admin: true },
});
postHandler({
    router,
    path: '/master/city/update',
    actionName: 'update master city',
    controller: masterCityUpdate,
    validateSchema: MASTER_CITY_UPDATE_SCHEMA,
    roles: { admin: true },
});
postHandler({
    router,
    path: '/master/city/delete',
    actionName: 'delete master city',
    controller: masterCityDelete,
    validateSchema: MASTER_CITY_DELETE_SCHEMA,
    roles: { admin: true },
});
// ======== ホテルマスタ =========
getHandler({
    router,
    path: '/master/hotel/search',
    actionName: 'search master hotel',
    controller: masterHotelSearch,
    isAllowDelegatorAccess: true,
    validateSchema: MASTER_HOTEL_SERACH_SCHEMA,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/master/hotel/list',
    actionName: 'list master hotel',
    controller: masterHotelList,
    validateSchema: MASTER_HOTEL_LIST_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/hotel/create',
    actionName: 'create master hotel',
    controller: masterHotelCreate,
    validateSchema: MASTER_HOTEL_CREATE_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/hotel/update',
    actionName: 'update master hotel',
    controller: masterHotelUpdate,
    validateSchema: MASTER_HOTEL_UPDATE_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/hotel/delete',
    actionName: 'delete master hotel',
    controller: masterHotelDelete,
    validateSchema: MASTER_HOTEL_DELETE_SCHEMA,
    roles: { foreignStaff: true },
});
// ======== 社有車マスタ =========
getHandler({
    router,
    path: '/master/companyCar/search',
    actionName: 'search master companyCar',
    controller: masterCampanyCarSearch,
    isAllowDelegatorAccess: true,
    validateSchema: MASTER_COMPANY_CAR_SEARCH_SCHEMA,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/master/companyCar/list',
    actionName: 'list master companyCar',
    controller: masterCampanyCarList,
    validateSchema: MASTER_COMPANY_CAR_LIST_SCHEMA,
    roles: { foreignStaff: true, japanStaff: true },
});
postHandler({
    router,
    path: '/master/companyCar/create',
    actionName: 'create master companyCar',
    controller: masterCampanyCarCreate,
    validateSchema: MASTER_COMPANY_CAR_CREATE_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/companyCar/update',
    actionName: 'update master companyCar',
    controller: masterCampanyCarUpdate,
    validateSchema: MASTER_COMPANY_CAR_UPDATE_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/companyCar/delete',
    actionName: 'delete master companyCar',
    controller: masterCampanyCarDelete,
    validateSchema: MASTER_COMPANY_CAR_DELETE_SCHEMA,
    roles: { foreignStaff: true },
});
// ======== ドライバーマスタ =========
getHandler({
    router,
    path: '/master/driver/search',
    actionName: 'search master driver',
    controller: masterDriverSearch,
    validateSchema: MASTER_DRIVER_SEARCH_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/master/driver/list',
    actionName: 'list master driver',
    controller: masterDriverList,
    validateSchema: MASTER_DRIVER_LIST_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/driver/create',
    actionName: 'create master driver',
    controller: masterDriverCreate,
    validateSchema: MASTER_DRIVER_CREATE_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/driver/update',
    actionName: 'update master driver',
    controller: masterDriverUpdate,
    validateSchema: MASTER_DRIVER_UPDATE_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/master/driver/delete',
    actionName: 'delete master driver',
    controller: masterDriverDelete,
    validateSchema: MASTER_DRIVER_DELETE_SCHEMA,
    roles: { foreignStaff: true },
});
// ======== ユーザ =========
getHandler({
    router,
    path: '/user/search',
    actionName: 'search master user',
    controller: userSearch,
    isAllowDelegatorAccess: true,
    validateSchema: USER_SERACH_SCHEMA,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/user/getUserExpansionList',
    actionName: 'user phone get list',
    controller: getUserExpansionList,
    isAllowDelegatorAccess: true,
    validateSchema: USER_EXPANSION_LIST,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/user/updateCalendarSync',
    actionName: 'update calendar sync',
    controller: userUpdateCalendarSync,
    isAllowDelegatorAccess: true,
    validateSchema: USER_UPDATE_CALENDAR_SYNC_SCHEMA,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/user/updateWebpushDeviceInfo',
    actionName: 'update web push device info',
    controller: updateWebpushDeviceInfo,
    validateSchema: USER_UPDATE_WEBPUSH_DEVICE_INFO,
    roles: { japanStaff: true },
});
// ======== 委任機能 ========
// getパラメータ指定無し
getHandler({
    router,
    path: '/delegator/list',
    actionName: 'delegator get list',
    controller: usersDelegatorList,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/delegator/upsert',
    actionName: 'delegator upsert',
    controller: usersDelegatorUpsert,
    validateSchema: DELEGATOR_UPSERT_SCHEMA,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/delegator/delete',
    actionName: 'delegator delete',
    controller: usersDelegatorDelete,
    validateSchema: DELEGATOR_DELETE_SCHEMA,
    roles: { japanStaff: true },
});
// ======== 旅程機能 ========
getHandler({
    router,
    path: '/itinerary/list',
    actionName: 'itinerary get list',
    controller: itineraryIndividualList,
    validateSchema: ITINERARY_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
getHandler({
    router,
    path: '/itinerary/detail',
    actionName: 'itinerary get detail',
    controller: itineraryDetail,
    validateSchema: ITINERARY_INDEX_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/itinerary/excelDownload',
    actionName: 'itinerary excel download',
    controller: itineraryExcelDownload,
    validateSchema: ITINERARY_EXCEL_DOWNLOAD_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/itinerary/create',
    actionName: 'itinerary create',
    controller: itineraryCreate,
    validateSchema: ITINERARY_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/itinerary/update',
    actionName: 'itinerary update',
    controller: itineraryUpdate,
    validateSchema: ITINERARY_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/itinerary/delete',
    actionName: 'itinerary delete',
    controller: itineraryDelete,
    validateSchema: ITINERARY_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== Outlook連携 ========
postHandler({
    router,
    path: '/itinerary/importIndividualOutlookEvent',
    actionName: 'import outlook event to mctrip',
    controller: importIndividualOutlookEvent,
    validateSchema: IMPORT_INDIVIDUAL_OUTLOOK_EVENT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
    dbOptions: { disableTransaction: false, transactionTimeout: 60000 },
});
postHandler({
    router,
    path: '/itinerary/exportSchedsIntoOutlookEvent',
    actionName: 'export scheds into outlook event',
    controller: exportSchedsIntoOutlookEvent,
    validateSchema: EXPORT_SCHED_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
    dbOptions: { disableTransaction: false, transactionTimeout: 120000 },
});
postHandler({
    router,
    path: '/itinerary/hideOutlookEvent',
    actionName: 'hide outlook event',
    controller: hideOutlookEvent,
    validateSchema: HIDE_OUTLOOK_EVENT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== フライト予定/手配機能 ========
getHandler({
    router,
    path: '/flight/schedList',
    actionName: 'flight get schedList',
    controller: flightSchedList,
    validateSchema: FLIGHT_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/flight/sched',
    actionName: 'flight get sched',
    controller: flightSched,
    validateSchema: FLIGHT_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/flight/schedCreate',
    actionName: 'flight schedCreate',
    controller: flightSchedCreate,
    validateSchema: FLIGHT_SCHED_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/flight/schedUpdate',
    actionName: 'flight schedUpdate',
    controller: flightSchedUpdate,
    validateSchema: FLIGHT_SCHED_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/flight/schedDelete',
    actionName: 'flight schedDelete',
    controller: flightSchedDelete,
    validateSchema: FLIGHT_SCHED_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/flight/arrgtCreate',
    actionName: 'flight arrgtCreate',
    controller: flightArrgtCreate,
    validateSchema: FLIGHT_ARRGT_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/flight/schedIndividualUpdate',
    actionName: 'flight schedIndividualUpdate',
    controller: flightSchedIndividualUpdate,
    validateSchema: FLIGHT_SCHED_INDIVIDUAL_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/flight/schedIndividualReject',
    actionName: 'flight schedIndividualReject',
    controller: flightSchedIndividualReject,
    validateSchema: FLIGHT_SCHED_INDIVIDUAL_REJECT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== ホテル予定/手配機能 ========
getHandler({
    router,
    path: '/hotel/sched',
    actionName: 'hotel get sched',
    controller: hotelSched,
    validateSchema: HOTEL_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/hotel/schedList',
    actionName: 'hotel get list',
    controller: hotelSchedList,
    validateSchema: HOTEL_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/hotel/schedCreate',
    actionName: 'hotel schedCreate',
    controller: hotelSchedCreate,
    validateSchema: HOTEL_SCHED_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/hotel/schedUpdate',
    actionName: 'hotel schedUpdate',
    controller: hotelSchedUpdate,
    validateSchema: HOTEL_SCHED_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/hotel/schedDelete',
    actionName: 'hotel schedDelete',
    controller: hotelSchedDelete,
    validateSchema: HOTEL_SCHED_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/hotel/arrgtCreate',
    actionName: 'hotel arrgtCreate',
    controller: hotelArrgtCreate,
    validateSchema: HOTEL_ARRGT_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/hotel/schedIndividualUpdate',
    actionName: 'hotel schedIndividualUpdate',
    controller: hotelSchedIndividualUpdate,
    validateSchema: HOTEL_SCHED_INDIVIDUAL_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/hotel/schedIndividualReject',
    actionName: 'hotel schedIndividualReject',
    controller: hotelSchedIndividualReject,
    validateSchema: HOTEL_SCHED_INDIVIDUAL_REJECT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== 移動予定機能 ========
getHandler({
    router,
    path: '/transportation/schedList',
    actionName: 'transportation get schedList',
    controller: transportationSchedList,
    validateSchema: TRANSPORTATION_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/transportation/sched',
    actionName: 'transportation get sched',
    controller: transportationSched,
    validateSchema: TRANSPORTATION_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/transportation/schedCreate',
    actionName: 'transportation schedCreate',
    controller: transportationSchedCreate,
    validateSchema: TRANSPORTATION_SCHED_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/transportation/schedUpdate',
    actionName: 'transportation schedUpdate',
    controller: transportationSchedUpdate,
    validateSchema: TRANSPORTATION_SCHED_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/transportation/schedDelete',
    actionName: 'transportation schedDelete',
    controller: transportationSchedDelete,
    validateSchema: TRANSPORTATION_SCHED_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/transportation/schedIndividualReject',
    actionName: 'transportation schedIndividualReject',
    controller: transportationSchedIndividualReject,
    validateSchema: TRANSPORTATION_SCHED_INDIVIDUAL_REJECT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== イベント予定機能 ========
getHandler({
    router,
    path: '/event/schedList',
    actionName: 'event get schedList',
    controller: eventSchedList,
    validateSchema: EVENT_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/event/sched',
    actionName: 'event get sched',
    controller: eventSched,
    validateSchema: EVENT_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/event/schedCreate',
    actionName: 'event schedCreate',
    controller: eventSchedCreate,
    validateSchema: EVENT_SCHED_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: false },
});
postHandler({
    router,
    path: '/event/schedUpdate',
    actionName: 'event schedUpdate',
    controller: eventSchedUpdate,
    validateSchema: EVENT_SCHED_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: false },
    dbOptions: { disableTransaction: false, transactionTimeout: 60000 },
});
postHandler({
    router,
    path: '/event/schedDelete',
    actionName: 'event schedDelete',
    controller: eventSchedDelete,
    validateSchema: EVENT_SCHED_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: false },
});
postHandler({
    router,
    path: '/event/schedIndividualReject',
    actionName: 'event schedIndividualReject',
    controller: eventSchedIndividualReject,
    validateSchema: EVENT_SCHED_INDIVIDUAL_REJECT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== 社有車手配機能 ========
getHandler({
    router,
    path: '/companyCar/arrgtList',
    actionName: 'companyCar get arrgtList',
    controller: companyCarArrgtList,
    validateSchema: COMPANY_CAR_ARRGT_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/companyCar/arrgt',
    actionName: 'companyCar get arrgt',
    controller: companyCarArrgt,
    validateSchema: COMPANY_CAR_ARRGT_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/companyCar/arrgtCreate',
    actionName: 'companyCar arrgtCreate',
    controller: companyCarArrgtCreate,
    validateSchema: COMPANY_CAR_ARRGT_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== 社有車予定機能 ========
getHandler({
    router,
    path: '/companyCar/schedList',
    actionName: 'companyCar get schedList',
    controller: companyCarSchedList,
    validateSchema: COMPANY_CAR_SCHED_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
getHandler({
    router,
    path: '/companyCar/sched',
    actionName: 'companyCar get sched',
    controller: companyCarSched,
    validateSchema: COMPANY_CAR_SCHED_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/companyCar/schedCreate',
    actionName: 'companyCar schedCreate',
    controller: companyCarSchedCreate,
    validateSchema: COMPANY_CAR_SCHED_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/companyCar/schedUpdate',
    actionName: 'companyCar schedUpdate',
    controller: companyCarSchedUpdate,
    validateSchema: COMPANY_CAR_SCHED_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/companyCar/schedDelete',
    actionName: 'companyCar schedCompanyCarDelete',
    controller: companyCarSchedDelete,
    validateSchema: COMPANY_CAR_SCHED_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/companyCar/schedIndividualReject',
    actionName: 'companyCar schedIndividualReject',
    controller: companyCarSchedIndividualReject,
    validateSchema: COMPANY_CAR_SCHED_INDIVIDUAL_REJECT_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== 海外拠点用社有車予定機能 ========
getHandler({
    router,
    path: '/foreignStaffSchedCompanyCar/schedList',
    actionName: 'foreignStaffSchedCompanyCar get schedList',
    controller: foreignStaffSchedCompanyCarList,
    validateSchema: FOREIGN_STAFF_SCHED_COMPANY_CAR_LIST_SCHEMA,
    isRequiredForeignStaffKey: true,
    roles: { foreignStaff: true },
});
getHandler({
    router,
    path: '/foreignStaffSchedCompanyCar/sched',
    actionName: 'foreignStaffSchedCompanyCar get sched',
    controller: foreignStaffSchedCompanyCarIndex,
    validateSchema: FOREIGN_STAFF_SCHED_COMPANY_CAR_SCHEMA,
    isRequiredForeignStaffKey: true,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/foreignStaffSchedCompanyCar/schedCreate',
    actionName: 'foreignStaffSchedCompanyCar schedCreate',
    controller: foreignStaffSchedCompanyCarCreate,
    validateSchema: FOREIGN_STAFF_SCHED_COMPANY_CAR_CREATE_SCHEMA,
    isRequiredForeignStaffKey: true,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/foreignStaffSchedCompanyCar/schedUpdate',
    actionName: 'foreignStaffSchedCompanyCar schedUpdate',
    controller: foreignStaffSchedCompanyCarUpdate,
    validateSchema: FOREIGN_STAFF_SCHED_COMPANY_CAR_UPDATE_SCHEMA,
    isRequiredForeignStaffKey: true,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/foreignStaffSchedCompanyCar/schedDelete',
    actionName: 'foreignStaffSchedCompanyCar schedCompanyCarDelete',
    controller: foreignStaffSchedCompanyCarDelete,
    validateSchema: FOREIGN_STAFF_SCHED_COMPANY_CAR_DELETE_SCHEMA,
    isRequiredForeignStaffKey: true,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/foreignStaffSchedCompanyCar/arrangeComplete',
    actionName: 'foreignStaffSchedCompanyCar arrangeComplete',
    controller: foreignStaffSchedCompanyCarArrgtComplete,
    validateSchema: FOREIGN_STAFF_SCHED_COMPANY_CAR_CHANGE_ARRGT_SCHEMA,
    isRequiredForeignStaffKey: true,
    roles: { foreignStaff: true },
});
// ======== 経費機能 ========
//共通
getHandler({
    router,
    path: '/expense/',
    actionName: 'expense',
    controller: expense,
    validateSchema: EXPENSE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// 交通費
getHandler({
    router,
    path: '/expense/transportation/',
    actionName: 'expenseTransportation',
    controller: transportation,
    validateSchema: EXPENSE_TRANSPORTATION_INDEX_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/transportation/create',
    actionName: 'expense transportationCreate',
    controller: expenseTransportationCreate,
    validateSchema: EXPENSE_TRANSPORTATION_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/transportation/update',
    actionName: 'expense transportationUpdate',
    controller: expenseTransportationUpdate,
    validateSchema: EXPENSE_TRANSPORTATION_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/transportation/delete',
    actionName: 'expense transportationDelete',
    controller: expenseTransportationDelete,
    validateSchema: EXPENSE_TRANSPORTATION_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// 宿泊費
getHandler({
    router,
    path: '/expense/accommodation/',
    actionName: 'expenseAccommodation',
    controller: accommodation,
    validateSchema: EXPENSE_ACCOMMODATION_INDEX_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/accommodation/create',
    actionName: 'expense accommodationCreate',
    controller: expenseAccommodationCreate,
    validateSchema: EXPENSE_ACCOMMODATION_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/accommodation/update',
    actionName: 'expense accommodationUpdate',
    controller: expenseAccommodationUpdate,
    validateSchema: EXPENSE_ACCOMMODATION_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/accommodation/delete',
    actionName: 'expense accommodationDelete',
    controller: expenseAccommodationDelete,
    validateSchema: EXPENSE_ACCOMMODATION_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// その他
getHandler({
    router,
    path: '/expense/other/',
    actionName: 'expenseOther',
    controller: other,
    validateSchema: EXPENSE_OTHER_INDEX_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/other/create',
    actionName: 'expense otherCreate',
    controller: expenseOtherCreate,
    validateSchema: EXPENSE_OTHER_CREATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/other/update',
    actionName: 'expense otherUpdate',
    controller: expenseOtherUpdate,
    validateSchema: EXPENSE_OTHER_UPDATE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/expense/other/delete',
    actionName: 'expense otherDelete',
    controller: expenseOtherDelete,
    validateSchema: EXPENSE_OTHER_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
getHandler({
    router,
    path: '/expense/zipFileDownload',
    actionName: 'expense zip file download',
    controller: expenseZipFileDownload,
    validateSchema: EXPENSE_ZIPFILE_DOWNLOAD_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// ======== Cycle連携機能 ========
postHandler({
    router,
    path: '/cycle/applyBeforeBusinessTrip',
    actionName: 'cycle applyBeforeBusinessTrip',
    controller: applyBeforeBusinessTrip,
    validateSchema: CYCLE_APPLY_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
    dbOptions: { disableTransaction: true },
});
postHandler({
    router,
    path: '/cycle/applyAfterBusinessTrip',
    actionName: 'cycle applyAfterBusinessTrip',
    controller: applyAfterBusinessTrip,
    validateSchema: CYCLE_APPLY_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
    dbOptions: { disableTransaction: true },
});
// ======== ファイルダウンロード・アップロード機能 ========
// sched
getHandler({
    router,
    path: '/file/schedDownload',
    actionName: 'file schedDownload',
    controller: fileSchedDownload,
    validateSchema: SCHED_FILE_DOWNLOAD_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/file/schedUpload',
    actionName: 'file schedUpload',
    controller: fileSchedUpload,
    validateSchema: SCHED_FILE_UPLOAD_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
postHandler({
    router,
    path: '/file/schedDelete',
    actionName: 'file schedDelete',
    controller: fileSchedDelete,
    validateSchema: SCHED_FILE_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    isRequiredForeignStaffKey: true,
    roles: { japanStaff: true, foreignStaff: true },
});
// expense
getHandler({
    router,
    path: '/file/expenseDownload',
    actionName: 'file expenseDownload',
    controller: fileExpenseDownload,
    validateSchema: EXPENSE_FILE_DOWNLOAD_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/file/expenseUpload',
    actionName: 'file expenseUpload',
    controller: fileExpenseUpload,
    validateSchema: EXPENSE_FILE_UPLOAD_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
postHandler({
    router,
    path: '/file/expenseDelete',
    actionName: 'file expenseDelete',
    controller: fileExpenseDelete,
    validateSchema: EXPENSE_FILE_DELETE_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true },
});
// publicContainer
getHandler({
    router,
    path: '/file/publicContainerDownload',
    actionName: 'file publicContainerDownload',
    controller: filePublicContainerDownload,
    validateSchema: PUBLIC_CONTAINER_FILE_DOWNLOAD_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/file/publicContainerUpload',
    actionName: 'file publicContainerUpload',
    controller: filePublicContainerUpload,
    validateSchema: PUBLIC_CONTAINER_FILE_UPLOAD_SCHEMA,
    roles: { foreignStaff: true },
});
postHandler({
    router,
    path: '/file/publicContainerDelete',
    actionName: 'file publicContainerDelete',
    controller: filePublicContainerDelete,
    validateSchema: PUBLIC_CONTAINER_FILE_DELETE_SCHEMA,
    roles: { foreignStaff: true },
});
// ======== フロントエラーログ送信機能 ========
postHandler({
    router,
    path: '/frontErrorLog/send',
    actionName: 'frontErrorLog send',
    controller: send,
    validateSchema: FRONT_ERROR_LOG_SEND_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, foreignStaff: true },
});
// ======== FAQ機能 ========
getHandler({
    router,
    path: '/master/faq/list',
    actionName: 'faq get list',
    controller: faqList,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, foreignStaff: true, admin: true },
});
// ======== 通知機能(To_do機能) ========
getHandler({
    router,
    path: '/notification/shouldDoList',
    actionName: 'to_do get list',
    controller: shouldDoList,
    validateSchema: NOTIFICATION_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, admin: true },
});
getHandler({
    router,
    path: '/notification/siteNoticeList',
    actionName: 'siteNotice get list',
    controller: siteNoticeList,
    validateSchema: NOTIFICATION_LIST_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, admin: true },
});
postHandler({
    router,
    path: '/notification/updateFlgFinished',
    actionName: 'siteNotice get list',
    controller: updateFlgFinished,
    validateSchema: UPDATE_FLG_FINISHED_SCHEMA,
    isAllowDelegatorAccess: true,
    roles: { japanStaff: true, admin: true },
});
// ======== その他 ========
// 死活監視用API
router.get('/test/checkAlive', async (req, res) => {
    const response = await checkAlive(req.query, req.ips);
    res.status(200).json(response);
});
// DEBUGでAPIからのseed作成が許可されている場合は、API定義実施
if (Define.DEBUG.isSetSeedApis) {
    getHandler({
        router,
        path: '/seeds',
        actionName: 'db data seed',
        controller: seedCreate,
        isAuthorised: false,
    });
    getHandler({
        router,
        path: '/test/errorTest',
        actionName: 'api error test',
        controller: errorTest,
        isAuthorised: false,
        dbOptions: { disableTransaction: false },
    });
    getHandler({
        router,
        path: '/test/dbRollback',
        actionName: 'db rollback test',
        controller: dbRollbackTest,
        isAuthorised: false,
        dbOptions: { disableTransaction: false },
    });
    getHandler({
        router,
        path: '/test/integrationTest',
        actionName: 'integrationTest test',
        controller: integrationTest,
        isAuthorised: false,
        dbOptions: { disableTransaction: false },
    });
    // 死活監視用API
    router.get('/test/excelDownloadTest', async (req, res) => {
        await excelDownloadTest(req, res);
    });
}
router.get('*', (_req, res) => {
    res.status(404).json({ isSuccess: false });
});
export default router;
//# sourceMappingURL=index.js.map