import { isFinite, omit } from 'lodash-es';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import prismaOriginal from '../utils/prismaClient.js';
import baseConfig from 'config';
import { log } from '../utils/logger.js';
import { formatDate, omitSecretRequestParameters } from '../utils/index.js';
import { Define } from '../utils/define.js';
import { verifyTokenAndSendErrorResponse } from '../utils/jwtToken.js';
import { isAfter } from 'date-fns';
import { validatePrecision } from '../utils/customAjvValidate.js';
const ajv = new Ajv(baseConfig.get('validator.ajvOptions'));
ajv.addKeyword({
    keyword: 'validatePrecision',
    type: 'number',
    validate: validatePrecision,
});
const dbTransactions = baseConfig.get('db.transactions');
const showErrorCause = Define.DEBUG.showErrorCause;
const isApiErrorTest = Define.DEBUG.isApiErrorTest;
addFormats(ajv);
export function getHandler(options) {
    routerHandler('get', options);
}
export function postHandler(options) {
    routerHandler('post', options);
}
function routerHandler(method, options) {
    if (!options.path) {
        log.error('router path is necesarry.');
    }
    const validate = options.validateSchema ? ajv.compile(options.validateSchema) : null;
    if (method === 'get') {
        if (!options.dbOptions) {
            options.dbOptions = { disableTransaction: true };
        }
        if (options.dbOptions.disableTransaction !== false) {
            options.dbOptions.disableTransaction = true;
        }
        options.router.get(options.path, (req, res, next) => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const props = req.query;
            handlerMain(req, res, next, validate, props, options);
        });
    }
    else {
        options.router.post(options.path, (req, res, next) => {
            handlerMain(req, res, next, validate, req.body, options);
        });
    }
}
async function handlerMain(req, res, _next, validate, props, { actionName, controller, isAuthorised = true, roles = { japanStaff: false, foreignStaff: false, admin: false }, isAllowDelegatorAccess = false, isRequiredForeignStaffKey = false, dbOptions = {}, }) {
    let user = {};
    const tokens = {};
    let delegatedPid = '';
    try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const parameters = props;
        // フロントエンド側、開発環境(dev環境)でのAPIエラー検証用に、debugモード時のみ、強制エラー返却可能な機能を用意
        if (isApiErrorTest) {
            if (parameters._status || parameters._errorCode) {
                const response = { isSuccess: false };
                if (parameters._errorCode) {
                    response.error = { code: parameters._errorCode, status: Number(parameters._status) };
                }
                sendResponse(res, response, Number(parameters._status));
                return;
            }
        }
        let result = null;
        // POST時はDB TransactionをONにする。
        await prismaTransactionIfNeed(dbOptions, async (prisma) => {
            if (isAuthorised) {
                // アクセストークンの認証チェック(この関数の中で、レスポンスを返している)
                const authCheck = verifyTokenAndSendErrorResponse(req, res);
                // アクセストークンの認証チェックでNG判定となった場合は処理終了
                if (authCheck.errorCode) {
                    return;
                }
                else if (authCheck.jwtTokenOjb) {
                    user = authCheck.jwtTokenOjb.user;
                    tokens.adAEnc = authCheck.jwtTokenOjb.adAEnc;
                    tokens.adREnc = authCheck.jwtTokenOjb.adREnc;
                }
                else {
                    throw new Error('unreachable error.');
                }
                let isRollCheckValid = false;
                // roleチェック(委託者のロールではなく、自分自身のロールで権限チェック実施)
                for (const userRole of user.roles) {
                    if (userRole === 'japanStaff' && roles.japanStaff) {
                        isRollCheckValid = true;
                        break;
                    }
                    else if (userRole === 'foreignStaff' && roles.foreignStaff) {
                        if (isRequiredForeignStaffKey) {
                            if (parameters.foreignStaffKey) {
                                isRollCheckValid = true;
                            }
                        }
                        else {
                            isRollCheckValid = true;
                        }
                        break;
                    }
                    else if (userRole === 'admin' && roles.admin) {
                        isRollCheckValid = true;
                        break;
                    }
                }
                if (!isRollCheckValid) {
                    log.warn(`[pid: ${getPid(user)}] ${actionName} invalid role check.`);
                    const resData = {
                        isSuccess: false,
                        error: { code: Define.ERROR_CODES.W99006 },
                    };
                    sendResponse(res, resData, 401);
                    return;
                }
                // 代理承認チェック
                if (parameters.delegatedPid) {
                    delegatedPid = parameters.delegatedPid;
                    // delegatedPidは予約語扱いとし、controllerに連携するpropsに含まれないように削除しておく
                    delete parameters.delegatedPid;
                    const delegatorCheckError = checkDelegatorAccess(delegatedPid, user, actionName, isAllowDelegatorAccess);
                    // エラーオブジェクトがあれば、権限チェックエラー
                    if (delegatorCheckError) {
                        sendResponse(res, { isSuccess: false, error: delegatorCheckError }, 401);
                        return;
                    }
                }
                else {
                    delegatedPid = user.pid;
                }
            }
            if (validate) {
                if (!validate(props)) {
                    log.warn(`[pid: ${getPid(user)}] ${actionName} invalid request. ${JSON.stringify(omitSecretRequestParameters(props))}`, validate.errors);
                    const resData = {
                        isSuccess: false,
                        error: { code: Define.ERROR_CODES.W99002, status: 400 },
                    };
                    if (showErrorCause) {
                        resData.error.cause = validate.errors;
                    }
                    sendResponse(res, resData, 400);
                    return;
                }
            }
            if (delegatedPid && delegatedPid !== user.pid) {
                log.info(`[pid: ${getPid(user)}] [delegatedPid: ${delegatedPid}] ${actionName} start.`);
            }
            else {
                log.info(`[pid: ${getPid(user)}] ${actionName} start.`);
            }
            // 個別機能側の処理を実施する
            result = await controller(props, { prisma, pid: delegatedPid, user, req, res, tokens });
            if (result.isDbRollback) {
                // ロールバック処理実施する為、エラー扱いとする
                throw new Error(`${Define.ERROR_CODES.W99101}${Define.SYSTEM.ERROR_CODE_SEP}rollback transaction.`);
            }
        });
        // DBトランザクションが終了してからレスポンス送信
        if (result) {
            if (result.status) {
                res.status(result.status);
            }
            res.json(omit(result, ['isDbRollback']));
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        const allMessage = error.message;
        const errorSep = allMessage.indexOf(Define.SYSTEM.ERROR_CODE_SEP);
        const errorCode = errorSep > 0 ? allMessage.substring(0, errorSep) : Define.ERROR_CODES.E99001;
        const errorMessage = errorSep > 0 ? allMessage.substring(errorSep + Define.SYSTEM.ERROR_CODE_SEP.length) : allMessage;
        log.info(`${errorCode} ${errorMessage}`);
        const resData = { isSuccess: false, error: { code: errorCode } };
        if (errorCode === Define.ERROR_CODES.W99101 && errorMessage === 'rollback transaction.') {
            if (delegatedPid && user && delegatedPid !== user.pid) {
                log.info(`[pid: ${getPid(user)}] [delegatedPid: ${delegatedPid}] ${actionName} [rollback transaction] ${JSON.stringify(omitSecretRequestParameters(props))}`);
            }
            else {
                log.info(`[pid: ${getPid(user)}] ${actionName} [rollback transaction] ${JSON.stringify(omitSecretRequestParameters(props))}`);
            }
            sendResponse(res, resData, 200);
        }
        else {
            if (delegatedPid && delegatedPid !== user.pid) {
                log.error(`[pid: ${getPid(user)}] [delegatedPid: ${delegatedPid}] ${actionName} api error. ${JSON.stringify(omitSecretRequestParameters(props))}`, error);
            }
            else {
                log.error(`[pid: ${getPid(user)}] ${actionName} api error. ${JSON.stringify(omitSecretRequestParameters(props))}`, error);
            }
            if (showErrorCause) {
                resData.error.cause = {
                    message: allMessage,
                    stack: error.stack,
                };
            }
            sendResponse(res, resData, 500);
        }
    }
    finally {
        // 永続化サービスの場合は、new PrismaClient()は1回しか実施しないのでdisconnect()しない
        // if (prismaBase) {
        //   await prismaBase.$disconnect();
        // }
        if (delegatedPid && delegatedPid !== user.pid) {
            log.info(`[pid: ${getPid(user)}] [delegatedPid: ${delegatedPid}] ${actionName} end.`);
        }
        else {
            log.info(`[pid: ${getPid(user)}] ${actionName} end.`);
        }
    }
}
function sendResponse(res, response, status) {
    try {
        if (status && isFinite(Number(status))) {
            res.status(status).json(response);
        }
        else {
            res.json(response);
        }
    }
    catch (error) {
        // ignore
    }
}
async function prismaTransactionIfNeed(dbOptions, cb) {
    if (dbOptions.disableTransaction) {
        await cb(prismaOriginal);
    }
    else {
        await prismaOriginal.$transaction(async (tx) => {
            await cb(tx);
        }, {
            timeout: dbOptions.transactionTimeout || dbTransactions.timeout,
            maxWait: dbOptions.transactionMaxWait || dbTransactions.maxWait,
        });
    }
}
function getPid(user) {
    if (user?.pid) {
        return user.pid || 'unknown';
    }
    return 'unknown';
}
/**
 * 委任者が正式に処理可能なユーザであるかどうかをチェックする
 * 権限がないユーザの場合は、ApiErrorオブジェクトを返却する。
 * @param delegatedPid
 * @param user
 * @param actionName
 * @returns
 */
export function checkDelegatorAccess(delegatedPid, user, actionName, isAllowDelegatorAccess = false) {
    if (!isAllowDelegatorAccess) {
        log.warn(`[pid: ${getPid(user)}] ${actionName} this api is not allowed to access with delegated pid.`);
        const error = { code: Define.ERROR_CODES.W99008, status: 401 };
        return error;
    }
    else if (user.pid === delegatedPid) {
        log.warn(`[pid: ${getPid(user)}] ${actionName} invalid request. wrong delegated pid.`);
        const error = { code: Define.ERROR_CODES.W99002, status: 400 };
        if (showErrorCause) {
            error.cause = 'invalid request. wrong delegated pid.';
        }
        return error;
    }
    let isDelegatedAllowed = false;
    // このユーザが正式に委任されたユーザかどうかをチェック
    if (user.assigners && user.assigners.length > 0) {
        for (const assignerInfo of user.assigners) {
            // このユーザの委託者の中に、該当するdelegatedPidがあるので正式な委任者であると判断
            if (assignerInfo.user.pid === delegatedPid) {
                // このシステムの日にち情報
                const today = formatDate(new Date());
                // 有効期限以内となっている
                if (!isAfter(new Date(today), new Date(assignerInfo.expiredAt))) {
                    isDelegatedAllowed = true;
                    break;
                }
            }
        }
    }
    if (!isDelegatedAllowed) {
        log.warn(`[pid: ${getPid(user)}] [delegatedPid: ${delegatedPid}] ${actionName} invalid delegatedPid access.`);
        const error = { code: Define.ERROR_CODES.W99007, status: 401 };
        return error;
    }
    else {
        return null;
    }
}
//# sourceMappingURL=routeHandler.js.map