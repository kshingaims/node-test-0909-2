import axios from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import baseConfig from 'config';
import { getUserByPid, create as userCreate } from '../../service/user/userService.js';
import { TestDefine } from '../../jest/utils/testDefine.js';
import prismaOriginal from '../../utils/prismaClient.js';
import { Define } from '../../utils/define.js';
import { log } from '../../utils/logger.js';
import { formatDateTimeMiliSecond } from '../../utils/index.js';
import { deleteSchedAttachment, downloadSchedAttachment, saveSchedAttachment } from '../../utils/azureBlob.js';
import { getAllUsers, getSabunUsers } from '../../service/mcidm/mcidmApiService.js';
import { makeTestExcel } from '../../service/excel/makeItinerarySchedules.js';
import { sendNotification } from '../../utils/webPush.js';
const httpsAgent = Define.SYSTEM.PROXY.isUseProxy
    ? new HttpsProxyAgent(`${Define.SYSTEM.PROXY.protocol}://${Define.SYSTEM.PROXY.host}:${Define.SYSTEM.PROXY.port}`)
    : undefined;
export async function dbRollbackTest(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false, isDbRollback: false };
    await createDbRollbackUser(prisma);
    const count = await prisma.user.count({ where: { pid: TestDefine.DB_ROLLBACK_TEST.PID } });
    if (count !== 1) {
        result.data = { isDataCreateError: true };
        return result;
    }
    else if (props.pattern === '1') {
        throw new Error(`${Define.ERROR_CODES.E99102}${Define.SYSTEM.ERROR_CODE_SEP}db rollback test dummy error`);
    }
    else {
        result.isDbRollback = true;
        return result;
    }
}
export async function checkAlive(query, ips) {
    // APIのレスポンスとなるJSONデータ
    const result = {
        isSuccess: false,
        data: {
            timezone: process.env.TZ,
            ipAddresses: ips,
            presentTime: formatDateTimeMiliSecond(new Date()),
            nodeEnv: process.env.NODE_ENV,
            debug: Define.DEBUG,
        },
    };
    if (query.pattern === '1') {
        try {
            const httpRes = await axios.get('https://www.google.com', { proxy: false, httpsAgent });
            if (httpRes.status === 200 && httpRes.data) {
                result.isSuccess = true;
            }
        }
        catch (error) {
            // ignore
        }
    }
    else {
        try {
            const city = await prismaOriginal.city.findFirst({
                select: {
                    id: true,
                },
            });
            if (city?.id) {
                result.data.isDbAccess = true;
                result.isSuccess = true;
            }
            else {
                result.data.isDbAccess = false;
            }
        }
        catch (error) {
            result.data.isDbAccess = false;
            // ignore
        }
    }
    return result;
}
export async function errorTest(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = {
        isSuccess: true,
        data: {},
    };
    await createDbRollbackUser(prisma);
    if (props.pattern === '1') {
        const arrayObj = [{ key: 'test' }];
        // array out of index error
        result.data.test = arrayObj[1].key;
    }
    else {
        await prisma.$queryRaw `SELECT * FROM userss`;
    }
    return result;
}
async function createDbRollbackUser(prisma) {
    await userCreate(prisma, {
        pid: TestDefine.DB_ROLLBACK_TEST.PID,
        email: 'foreignDBRollback@test.com',
        lastNameKana: 'デービーロールバック',
        lastNameKanji: 'DBロールバック',
        lastNameRoma: 'dbRollback',
        firstNameKana: 'タロウ',
        firstNameKanji: '太郎',
        firstNameRoma: 'Taro',
        mcSyozokuGrpCd: '99',
        mcSyozokuGrpNameKanji: '海外',
        mcSyozokuGrpNameRoma: '海外',
        mcSyozokuCd: '0500001',
        mcSyozokuNameKanji: '海外事業部',
        mcSyozokuNameRoma: 'FOREIGN OFFICE',
        corpCd: '0100000',
        userBunrui: 'UW10000',
        userBunruiNameKanji: 'ナショナルスタッフ',
        userBunruiNameRoma: 'NationalStaff',
    });
}
export async function integrationTest(props, { prisma }) {
    // APIのレスポンスとなるJSONデータ
    const result = {
        isSuccess: false,
        data: {},
    };
    // Blob Storageアクセステスト
    if (props.pattern === '1') {
        // 予定に対する添付ファイルupload実施
        const fileInfo = {
            originalFileName: 'text.txt',
            size: 12,
            base64: 'dGVzdHRlc3R0ZXN0', // testtesttest
        };
        const totalFileSize = 20;
        const uploadResult = await saveSchedAttachment(fileInfo, 'schedFlight', totalFileSize);
        const dlRes = await downloadSchedAttachment(uploadResult.path);
        // ファイル削除実施
        const delRes = await deleteSchedAttachment(uploadResult.path);
        // ダウンロード取得したbase64文字列と、アップロード実施時に指定したbase64が同じである
        // 削除に成功している
        if (dlRes.base64 === fileInfo.base64 && delRes.isSuccess) {
            result.isSuccess = true;
            result.data = {
                isBlobAccess: true,
                isBlobWrite: true,
            };
        }
        // azure app service internet access test
    }
    else if (props.pattern === '2') {
        try {
            const httpRes = await axios.get('https://www.google.com', { proxy: false, httpsAgent });
            if (httpRes.status === 200 && httpRes.data) {
                result.isSuccess = true;
            }
        }
        catch (error) {
            // ignore
        }
    }
    else if (props.pattern === '3') {
        try {
            if (props.pid) {
                const user = await getUserByPid(prisma, props.pid);
                if (!user || !user.webpushDeviceInfo) {
                    result.error = { code: 'DUMMY', cause: 'no user or no webpushDeviceInfo' };
                    return result;
                }
                // web pushテスト送信
                result.isSuccess = await sendNotification(log, user, {
                    title: '[test] MCTriip webpush タイトル',
                    body: '[test] MCTriip webpush 本文①②',
                    url: baseConfig.get('domain'),
                });
            }
            else {
                result.error = { code: 'DUMMY', cause: 'no pid' };
                return result;
            }
        }
        catch (error) {
            // ignore
            log.error('web push error', error);
            result.error = { code: 'DUMMY', cause: error };
        }
        // WEB PUSH通知テスト
    }
    else if (props.pattern === '10') {
        try {
            const users = await getAllUsers(log);
            result.data = users;
            result.isSuccess = true;
        }
        catch (error) {
            // ignore
        }
    }
    else if (props.pattern === '11') {
        try {
            const users = await getSabunUsers(log, true);
            result.data = users;
            result.isSuccess = true;
        }
        catch (error) {
            // ignore
        }
    }
    return result;
}
export async function excelDownloadTest(_req, res) {
    const buffer = await makeTestExcel();
    if (buffer) {
        res.set('Content-Disposition', 'attachment; filename=' + 'sampleExcel.xlsx');
        res.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.status(200).send(buffer);
    }
}
//# sourceMappingURL=index.js.map