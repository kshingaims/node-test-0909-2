import { getUserWithRole } from '../../service/user/userService.js';
import { formatDate } from '../../utils/index.js';
import { Define } from '../../utils/define.js';
import { onlyEncrypt } from '../../utils/crypt.js';
import { verifyTokenAndSendErrorResponse, createToken, decodeToken } from '../../utils/jwtToken.js';
import { log } from '../../utils/logger.js';
import { getAzureAadToken, getMcidmToken, refleshAzureAadToken } from '../../service/azure/authService.js';
import { getLoginUser } from '../../service/azure/graphApiService.js';
export const AUTH_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['aadCode'],
    properties: {
        aadCode: {
            type: 'string',
        },
        mcidmCode: {
            type: 'string',
        },
    },
};
const isDummySso = Define.DEBUG.isDummySso;
const isStaging = process.env.NODE_ENV === 'staging';
export async function authCheck(_props, { prisma, req, res }) {
    const verifyResult = verifyTokenAndSendErrorResponse(req, res, false);
    // 認証エラー時はエラーレスポンスを返却
    if (verifyResult.errorCode) {
        return { isSuccess: false, error: { code: verifyResult.errorCode }, status: 401 };
    }
    else if (verifyResult.jwtTokenOjb) {
        // 認証成功時はJWTトークンの再作成。CSRFキーの再作成。ユーザ情報の最新化
        const csrf = getCsrfKey();
        const user = await getUserWithRole(prisma, verifyResult.jwtTokenOjb.user.pid);
        // userが取れない。改ざんされている可能性あり。
        if (!user.pid) {
            log.warn('access token check failed. token is not collect.');
            return { isSuccess: false, error: { code: Define.ERROR_CODES.W99004 }, status: 401 };
        }
        // ADのアクセストークンをリフレッシュする
        const refleshTokenResult = await refleshAzureAadToken(log, verifyResult.jwtTokenOjb.adREnc);
        const accessToken = createToken({
            csrf,
            user: getFilteredUser(user),
            adAEnc: refleshTokenResult.tokenEnc,
            adREnc: refleshTokenResult.refleshTokenEnc,
        });
        return { isSuccess: true, data: { user, accessToken, csrfKey: csrf } };
    }
    else {
        // ここには処理が入らない
        throw new Error('unreachable error.');
    }
}
export async function auth(props, { prisma }) {
    let pid = '';
    let adAEnc = '';
    let adREnc = '';
    let user = undefined;
    if (isDummySso) {
        pid = props.aadCode;
        adAEnc = 'dummy';
        adREnc = 'dummy';
        user = await getUserWithRole(prisma, pid);
    }
    else {
        if (!isStaging) {
            if (!props.mcidmCode) {
                return { isSuccess: false, error: { code: Define.ERROR_CODES.W99002 }, status: 400 };
            }
            // iceWall側のログイン認証実施
            const authResult = await getMcidmToken(log, props.mcidmCode);
            const decodedUser = decodeToken(authResult.idToken);
            if (decodedUser?.uid) {
                pid = decodedUser.uid;
                // icewall認証成功時は、icewallから取得したPIDからユーザ情報取得実施
                user = await getUserWithRole(prisma, pid);
            }
            else {
                return { isSuccess: false, status: 401 };
            }
        }
        // Azure AD認証処理と連携させる。アクセストークン、リフレッシュトークンを取得する。
        const authResult = await getAzureAadToken(log, props.aadCode);
        if (authResult.tokenEnc) {
            adAEnc = authResult.tokenEnc;
            adREnc = authResult.refleshTokenEnc;
            const meResult = await getLoginUser(log, authResult.tokenEnc);
            const userPrincipalName = meResult.userPrincipalName;
            const email = meResult.email;
            if (user) {
                // userPrincipalIdとユーザテーブルのemailが同じとなっているPIDが取得できていない
                if (userPrincipalName !== user.email && email !== user.email) {
                    return { isSuccess: false, status: 401, error: { code: Define.ERROR_CODES.W99009 } };
                }
            }
            else {
                if (meResult.userPrincipalName) {
                    user = await getUserWithRole(prisma, undefined, meResult.userPrincipalName);
                }
            }
        }
        else {
            return { isSuccess: false, status: 401 };
        }
    }
    if (user && user.pid) {
        // CSRKキー、アクセストークン生成実施
        const csrf = getCsrfKey();
        const accessToken = createToken({ csrf, user: getFilteredUser(user), adAEnc, adREnc });
        return { isSuccess: true, data: { user, accessToken, csrfKey: csrf } };
    }
    else {
        return { isSuccess: false };
    }
}
function getCsrfKey() {
    // CSRKキーを、現在時刻情報をベースに文字列生成
    const nowStr = formatDate(new Date(), 'hh上にyyyy初めてmmddきまMMこSSSににss');
    return onlyEncrypt(nowStr);
}
function getFilteredUser(user) {
    return {
        pid: user.pid,
        firstNameKanji: user.firstNameKanji,
        lastNameKanji: user.lastNameKanji,
        firstNameRoma: user.firstNameRoma,
        lastNameRoma: user.lastNameRoma,
        mcSyozokuNameKanji: user.mcSyozokuNameKanji,
        mcSyozokuNameRoma: user.mcSyozokuNameRoma,
        mcSyozokuCd: user.mcSyozokuCd,
        email: user.email,
        roles: user.roles,
        assigners: user.assigners,
        flgAdmin: user.flgAdmin,
        flgCalendarSync: user.flgCalendarSync,
    };
}
//# sourceMappingURL=index.js.map