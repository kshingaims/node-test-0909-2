import { log } from '../../utils/logger.js';
import { createFlightSchedIfNotExists, createSchedFlight, getFlightSchedList, updateIfExists, updateSchedFlight, deleteIfExists, deleteSchedFlight, createArrgtIfNotExists, createArrgtFlight, updateSchedFlightIndividual, rejectSchedFlightIndividual, getSchedFlightForChecker, } from '../../service/flight/flightService.js';
import { checkGetParamsNumber, replaceCRLF } from '../../utils/index.js';
import { checkForeignStaffAccessAndGetTargetPid } from '../../utils/foreignStaff.js';
import { Define } from '../../utils/define.js';
import { isExistsItineraryCompanionsForArrgt } from '../../service/itinerary/itineraryService.js';
import { sendMail } from '../../service/azure/graphApiService.js';
export const FLIGHT_LIST_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        itineraryId: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
export async function schedList(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let itineraryId = undefined;
    let isForeignStaff = false;
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
        isForeignStaff = true;
    }
    else {
        if (!checkGetParamsNumber(props.itineraryId)) {
            result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
            return result;
        }
        itineraryId = Number(props.itineraryId);
    }
    // 一覧取得実施
    result.data = await getFlightSchedList(prisma, pid, itineraryId, undefined, isForeignStaff);
    result.isSuccess = true;
    return result;
}
export const FLIGHT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'string',
            pattern: '^[1-9]+[0-9]*$',
            maxLength: 10,
            description: '旅程個人id',
        },
        foreignStaffKey: {
            type: 'string',
            maxLength: 255,
        },
    },
};
/**
 * 指定されたフライトIDに合致するフライト予定情報を取得する
 * @param props
 * @param param1
 * @returns
 */
export async function sched(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    let checkForeignStaffAccessResult;
    let isForeignStaff = false;
    let itineraryId = undefined;
    const id = Number(props.id);
    if ('foreignStaffKey' in props) {
        // 予約一覧へのアクセスが可能かをチェックし、可能であればitineraryIdとassignerPidを取得し、アクセス不可能の場合はerrorを取得する。
        checkForeignStaffAccessResult = await checkForeignStaffAccessAndGetTargetPid(prisma, props.foreignStaffKey, user);
        if ('error' in checkForeignStaffAccessResult) {
            result.error = checkForeignStaffAccessResult.error;
            return result;
        }
        else {
            pid = checkForeignStaffAccessResult.assignerPid;
            itineraryId = checkForeignStaffAccessResult.itineraryId;
        }
        isForeignStaff = true;
    }
    if (!checkGetParamsNumber(props.id)) {
        result.error = { code: Define.ERROR_CODES.W99002, status: 400 };
        return result;
    }
    // フライト予定IDを指定して一覧取得実施
    const list = await getFlightSchedList(prisma, pid, itineraryId, id, isForeignStaff);
    if (list.length !== 1) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const FLIGHT_SCHED_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId', 'departureDateTime', 'departureTimezone', 'arrivalDateTime', 'arrivalTimezone'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        departureDateTime: {
            type: 'string',
            format: 'date-time',
            description: '予定_出発日時。日付フォーマットはISO8601形式',
        },
        departureAirport: {
            type: 'string',
            maxLength: 255,
            description: '予定_出発空港',
        },
        departureTerminal: {
            type: 'string',
            maxLength: 50,
            description: '予定_出発ターミナル',
        },
        departureCity: {
            type: 'string',
            maxLength: 255,
            description: '予定_出発都市',
        },
        departureTimezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: '予定_出発タイムゾーン',
        },
        arrivalDateTime: {
            type: 'string',
            format: 'date-time',
            description: '予定_到着日時。日付フォーマットはISO8601形式',
        },
        arrivalAirport: {
            type: 'string',
            maxLength: 255,
            description: '予定_到着空港',
        },
        arrivalTerminal: {
            type: 'string',
            maxLength: 50,
            description: '予定_到着ターミナル',
        },
        arrivalCity: {
            type: 'string',
            maxLength: 255,
            description: '予定_到着都市',
        },
        arrivalTimezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: '予定_到着タイムゾーン',
        },
        flightNumber: {
            type: 'string',
            maxLength: 50,
            description: '予定_フライト番号',
        },
        airline: {
            type: 'string',
            maxLength: 255,
            description: '予定_航空会社',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '予定_備考',
        },
        flgArrgt: {
            type: 'boolean',
            description: '手配実施有無のフラグ情報',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
    },
};
export async function schedCreate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await createFlightSchedIfNotExists(pid, prisma, props.itineraryId, props.arrivalDateTime, props.departureDateTime, props.companions);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // FlightSchedの新規登録処理
    const schedFlightId = await createSchedFlight(prisma, pid, user, props);
    // 一覧取得実施
    const list = await getFlightSchedList(prisma, pid, undefined, schedFlightId, false);
    if (list.length !== 1) {
        // 今回作成したフライト予定は必ず存在するはず
        throw new Error('unreachable error.');
    }
    result.data = list[0];
    result.isSuccess = true;
    return result;
}
export const FLIGHT_SCHED_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'itineraryId', 'departureDateTime', 'departureTimezone', 'arrivalDateTime', 'arrivalTimezone'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'フライト予定ID',
        },
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程id',
        },
        departureDateTime: {
            type: 'string',
            format: 'date-time',
            description: '出発日時。日付フォーマットはISO8601形式',
        },
        departureAirport: {
            type: 'string',
            maxLength: 255,
            description: '出発空港',
        },
        departureTerminal: {
            type: 'string',
            maxLength: 50,
            description: '予定_出発ターミナル',
        },
        departureCity: {
            type: 'string',
            maxLength: 255,
            description: '出発都市',
        },
        departureTimezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: '出発タイムゾーン',
        },
        arrivalDateTime: {
            type: 'string',
            format: 'date-time',
            description: '到着日時。日付フォーマットはISO8601形式',
        },
        arrivalAirport: {
            type: 'string',
            maxLength: 255,
            description: '到着空港',
        },
        arrivalTerminal: {
            type: 'string',
            maxLength: 50,
            description: '予定_到着ターミナル',
        },
        arrivalCity: {
            type: 'string',
            maxLength: 255,
            description: '到着都市',
        },
        arrivalTimezone: {
            type: 'string',
            maxLength: 6,
            pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
            description: '到着タイムゾーン',
        },
        flightNumber: {
            type: 'string',
            maxLength: 50,
            description: 'フライト番号',
        },
        airline: {
            type: 'string',
            maxLength: 255,
            description: '航空会社',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
        flgArrgt: {
            type: 'boolean',
            description: '手配実施有無のフラグ情報',
        },
        companions: {
            type: ['array', 'null'],
            description: '同行者一覧(同行者情報としてはpidのみ)。手配実施後に、同行者を設定しても設定は全て無視される。',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['pid'],
                properties: {
                    pid: {
                        type: 'string',
                        maxLength: 15,
                        description: '同行者のPersonal ID',
                    },
                },
            },
        },
        schedFlightIndividual: {
            type: 'object',
            additionalProperties: false,
            properties: {
                eticket: {
                    type: 'string',
                    maxLength: 50,
                    description: 'eticket番号',
                },
                seatNo: {
                    type: 'string',
                    maxLength: 10,
                    description: '座席番号',
                },
                remark: {
                    type: 'string',
                    maxLength: 255,
                    description: '備考',
                },
            },
        },
    },
};
export async function schedUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // DB情報を取得
    const schedFlight = await getSchedFlightForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const inputCheckResult = await updateIfExists(pid, prisma, schedFlight, props.itineraryId, props.arrivalDateTime, props.departureDateTime, props.companions);
    // 入力チェックでエラーとなった場合処理終了
    if (inputCheckResult !== undefined) {
        result.error = inputCheckResult;
        return result;
    }
    // FlightSchedの更新処理
    await updateSchedFlight(prisma, pid, user, schedFlight, props);
    result.isSuccess = true;
    return result;
}
export const FLIGHT_SCHED_DELETE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    //必須プロパティはなし
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'フライト予定ID',
        },
    },
};
export async function schedDelete(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 削除対象となっているフライト予定の最新データ状況をDBから取得の上、処理実施する。
    const schedFlight = await getSchedFlightForChecker(prisma, props.id);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const checkError = await deleteIfExists(pid, schedFlight);
    // 入力チェックでエラーとなった場合処理終了
    if (checkError) {
        result.error = checkError;
        return result;
    }
    // FlightSchedの削除処理
    await deleteSchedFlight(prisma, user, props.id);
    result.isSuccess = true;
    return result;
}
export const FLIGHT_ARRGT_CREATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['itineraryId', 'schedFlights', 'arrgtFlight'],
    properties: {
        itineraryId: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: '旅程ID。フライト予定作成、フライト手配作成時、この旅程IDが使われる',
        },
        schedFlights: {
            type: 'array',
            minItems: 1,
            description: 'この手配に紐つくフライト予定一覧',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['flgArrgtFlightNumber', 'arrgtDateType', 'companions'],
                properties: {
                    departureDateTime: {
                        type: 'string',
                        format: 'date-time',
                        description: '出発日時。日付フォーマットはISO8601形式  \n手配指定日タイプが出発日となっている場合は、入力必須  \n「フライト番号を使って手配を進めるかどうか」がtrueの場合は、時刻は00:00:00となる想定。',
                    },
                    departureAirport: {
                        type: 'string',
                        maxLength: 255,
                        description: '出発空港',
                    },
                    departureCity: {
                        type: 'string',
                        maxLength: 255,
                        description: '出発都市',
                    },
                    departureTimezone: {
                        type: 'string',
                        maxLength: 6,
                        pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
                        description: '出発タイムゾーン  \n手配指定日タイプが出発日となっている場合は、入力必須  \n「フライト番号を使って手配を進めるかどうか」がtrueの場合は、時刻は00:00:00となる想定。',
                    },
                    arrivalDateTime: {
                        type: 'string',
                        format: 'date-time',
                        description: '到着日時。日付フォーマットはISO8601形式\n手配指定日タイプが到着日　となっている場合は、入力必須',
                    },
                    arrivalAirport: {
                        type: 'string',
                        maxLength: 255,
                        description: '到着空港',
                    },
                    arrivalCity: {
                        type: 'string',
                        maxLength: 255,
                        description: '到着都市',
                    },
                    arrivalTimezone: {
                        type: 'string',
                        maxLength: 6,
                        pattern: '^[+-](?:[0-1][0-9]|2[0-3]):[0-5][0-9]$',
                        description: '到着タイムゾーン',
                    },
                    flightNumber: {
                        type: 'string',
                        maxLength: 50,
                        description: 'フライト番号。「フライト番号を使って手配を進めるかどうか」がtrueの場合は、必須。',
                    },
                    airline: {
                        type: 'string',
                        maxLength: 255,
                        description: '航空会社',
                    },
                    remark: {
                        type: 'string',
                        maxLength: 255,
                        description: '備考',
                    },
                    flgArrgtFlightNumber: {
                        type: 'boolean',
                        description: 'フライト番号を使って手配を進めるかどうか',
                    },
                    arrgtDateType: {
                        enum: ['departure', 'arrival'],
                        description: '手配指定日タイプ  \n- departure: 出発日\n- arrival: 到着日',
                    },
                    companions: {
                        type: 'array',
                        minItems: 1,
                        description: '同行者一覧(フライト手配情報含む)。フライト手配時は、フライト作成者自身もここに情報が含まれるようにする。',
                        items: {
                            type: 'object',
                            additionalProperties: false,
                            required: ['pid'],
                            properties: {
                                pid: {
                                    type: 'string',
                                    maxLength: 15,
                                    description: '同行者のPersonal ID',
                                },
                                seatClass: {
                                    enum: ['F', 'C', 'PY', 'Y'],
                                    description: '座席クラス  \n- 『F』ファーストクラス\n- 『C』ビジネスクラス\n- 『PY』プレミアムエコノミー\n- 『Y』エコノミー',
                                },
                                arrgtRemark: {
                                    type: 'string',
                                    maxLength: 255,
                                    description: '手配_備考',
                                },
                                flgArrgtTarget: {
                                    type: 'boolean',
                                    description: '手配実施対象フラグ。このアカウントが手配対象者となっているかどうかのフラグ。指定がない場合は、デフォルトはtrue判定とする',
                                },
                            },
                        },
                    },
                },
            },
        },
        arrgtFlight: {
            type: 'object',
            additionalProperties: false,
            required: ['emailTo'],
            properties: {
                emailTo: {
                    type: 'array',
                    minItems: 1,
                    description: '手配時に利用するTo Emailアドレス。',
                    items: {
                        type: 'string',
                        format: 'email',
                        maxLength: 255,
                    },
                },
            },
        },
        mail: {
            type: 'object',
            description: 'DBに保存しないEmail情報',
            required: ['cc', 'title', 'body'],
            properties: {
                cc: {
                    type: 'array',
                    description: '手配時に利用するEmailアドレス。',
                    items: {
                        type: 'string',
                        format: 'email',
                        maxLength: 255,
                    },
                },
                title: {
                    type: 'string',
                    maxLength: 255,
                    description: '手配時に利用するEmail件名。',
                },
                body: {
                    type: 'string',
                    maxLength: 65535,
                    description: '手配時に利用するEmail本文。',
                },
            },
        },
    },
};
export async function arrgtCreate(props, { pid, prisma, user, tokens }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    const isExistsItineraryCompanionsForArrgtError = await isExistsItineraryCompanionsForArrgt(prisma, pid, props.itineraryId, props.schedFlights);
    // 入力チェックでエラーとなった場合処理終了
    if (isExistsItineraryCompanionsForArrgtError !== undefined) {
        result.error = isExistsItineraryCompanionsForArrgtError;
        return result;
    }
    const schedFlightsProps = props.schedFlights;
    for (const schedFlightsProp of schedFlightsProps) {
        const inputCheckResult = createArrgtIfNotExists(schedFlightsProp);
        // 入力チェックでエラーとなった場合処理終了
        if (inputCheckResult !== undefined) {
            result.error = inputCheckResult;
            return result;
        }
    }
    // フライト手配の新規登録処理
    await createArrgtFlight(prisma, pid, user, props);
    // メール送信
    if (props.mail) {
        const sendMailRes = await sendMail(log, tokens.adAEnc, {
            emailTo: props.arrgtFlight.emailTo,
            emailCc: props.mail.cc,
            subject: props.mail.title,
            body: {
                contentType: 'Text',
                content: replaceCRLF(props.mail.body),
            },
        });
        if (!sendMailRes.isSuccess) {
            result.isDbRollback = true;
            return result;
        }
    }
    result.isSuccess = true;
    return result;
}
export const FLIGHT_SCHED_INDIVIDUAL_UPDATE_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'フライト予定ID',
        },
        eticket: {
            type: 'string',
            maxLength: 50,
            description: 'eticket番号',
        },
        seatNo: {
            type: 'string',
            maxLength: 10,
            description: '座席番号',
        },
        remark: {
            type: 'string',
            maxLength: 255,
            description: '備考',
        },
    },
};
export async function schedIndividualUpdate(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 削除対象となっているフライト予定の最新データ状況をDBから取得の上、処理実施する。
    const schedFlight = await getSchedFlightForChecker(prisma, props.id, pid);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // フライト個人予定の編集は、手配実施済か手配実施完了時のみ実行可能
    if (![Define.SETTINGS.ARRGT_STATUS.START, Define.SETTINGS.ARRGT_STATUS.FINISHED].includes(schedFlight.arrgtStatus)) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // DBからフライト予定情報が取得できない(W00109)
    if (schedFlight === null) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
    }
    // SchedFlightIndividualの更新処理
    await updateSchedFlightIndividual(prisma, pid, user, props.id, false, props.eticket, props.remark, props.seatNo);
    result.isSuccess = true;
    return result;
}
export const FLIGHT_SCHED_INDIVIDUAL_REJECT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'flgReject'],
    properties: {
        id: {
            type: 'integer',
            format: 'int64',
            maximum: 4294967295,
            minimum: 1,
            description: 'フライト予定ID',
        },
        flgReject: {
            type: 'boolean',
            description: '拒否フラグ。予定参加を拒否しているかどうか',
        },
    },
};
export async function schedIndividualReject(props, { pid, prisma, user }) {
    // APIのレスポンスとなるJSONデータ
    const result = { isSuccess: false };
    // 処理対象となっているフライト予定の最新データ状況をDBから取得の上、処理実施する。
    const schedFlight = await getSchedFlightForChecker(prisma, props.id, pid);
    // 入力チェックエラー(ajvで判定できない動的な入力チェック処理)
    // DBからフライト予定情報が取得できない(W00109)
    if (schedFlight === null) {
        result.error = { code: Define.ERROR_CODES.W00109, status: 400 };
        return result;
        // 予定拒否実施しているのが、予定の作成者の場合
    }
    else if (schedFlight.ownerPid === pid) {
        result.error = { code: Define.ERROR_CODES.W00121, status: 400 };
        return result;
    }
    // SchedFlightIndividualの更新処理
    await rejectSchedFlightIndividual(prisma, pid, user, props.id, props.flgReject);
    result.isSuccess = true;
    return result;
}
//# sourceMappingURL=index.js.map