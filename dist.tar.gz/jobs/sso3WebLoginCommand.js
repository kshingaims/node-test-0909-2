import { exit } from 'process';
import dotenv from 'dotenv';
import { batchLog } from '../utils/logger.js';
import { Mcsso3AuthAgent } from '../service/cycle/mcsso3AuthAgent.js';
import { sleep } from '../utils/index.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    else if (!process.argv[3] || !process.argv[4]) {
        batchLog.warn('arg[3] is ID. arg[4] is password.');
        exit(0);
    }
    const main = async () => {
        batchLog.info('sso3WebLoginCommand start.');
        try {
            const mcsso3AuthAgent = new Mcsso3AuthAgent(batchLog, process.argv[3], process.argv[4]);
            const authResult = await mcsso3AuthAgent.login();
            if (authResult.isLoginValidateError) {
                batchLog.info('sso3WebLoginCommand login failed. id or password is not collect.');
            }
            else if (authResult.isSecretUnset) {
                batchLog.info('sso3WebLoginCommand login failed. secret question is not set.');
            }
            else if (authResult.isSuccess) {
                const authInfo = mcsso3AuthAgent.getLoginResultInfo();
                batchLog.info('cookie: ' + authInfo.cookies[0].value);
            }
            else {
                batchLog.warn('sso3WebLoginCommand login failed. something wrong.');
            }
        }
        catch (error) {
            batchLog.error('sso3WebLoginCommand error.', error);
        }
        batchLog.info('sso3WebLoginCommand end.');
        await sleep(10);
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('sso3WebLoginCommand error.', error);
    exit(1);
}
//# sourceMappingURL=sso3WebLoginCommand.js.map