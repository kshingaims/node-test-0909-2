import { exit } from 'process';
import dotenv from 'dotenv';
import prisma from '../utils/prismaClient.js';
import { batchLog } from '../utils/logger.js';
import { joinStr, sleep } from '../utils/index.js';
import { NOTIFICATION_SETTING_TYPES, } from '../service/notification/notificationSettingService.js';
import { updateNotificationSettingJob } from './notification/updateNotificationSettingsJob.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    // 2番目の引数は取り込み対象とするCSVファイルの種類(タイプ)
    if (!process.argv[3] || !NOTIFICATION_SETTING_TYPES.includes(process.argv[3])) {
        batchLog.warn(`type is not correct you should set the time. [type: ${joinStr(NOTIFICATION_SETTING_TYPES, ' or ')}]`);
        exit(0);
    }
    const main = async () => {
        const type = process.argv[3];
        batchLog.info('updateNotificationSettingsCommand start.');
        await updateNotificationSettingJob(batchLog, prisma, type);
        batchLog.info('updateNotificationSettingsCommand end.');
        await sleep(10);
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('updateNotificationSettingsCommand error.', error);
    exit(1);
}
//# sourceMappingURL=updateNotificationSettingsCommand.js.map