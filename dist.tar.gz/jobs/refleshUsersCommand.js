/**
 * このコマンドは、ユーザ全情報の最新化を実施する処理となります。
 */
import { exit } from 'process';
import dotenv from 'dotenv';
import prisma from '../utils/prismaClient.js';
import { batchLog } from '../utils/logger.js';
import { updateUserMaster } from '../jobs/user/updateUserMaster.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    const main = async () => {
        batchLog.info('refleshUsersCommand start.');
        try {
            // ユーザ全件の最新化実施
            await updateUserMaster(prisma, batchLog, true);
        }
        catch (error) {
            batchLog.error('refleshUsersCommand error.', error);
        }
        batchLog.info('refleshUsersCommand end.');
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('refleshUsersCommand error.', error);
    exit(1);
}
//# sourceMappingURL=refleshUsersCommand.js.map