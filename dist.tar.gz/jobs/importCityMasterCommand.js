import { exit } from 'process';
import dotenv from 'dotenv';
import prisma from '../utils/prismaClient.js';
import { batchLog } from '../utils/logger.js';
import { importCityMasterWithAccessAzureTimezoneApi } from '../jobs/city/importCityMaster.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    const main = async () => {
        batchLog.info('importCityMaster start.');
        try {
            await importCityMasterWithAccessAzureTimezoneApi(prisma, batchLog);
        }
        catch (error) {
            batchLog.error('importCityMaster error.', error);
        }
        batchLog.info('importCityMaster end.');
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('importCityMaster error.', error);
    exit(1);
}
//# sourceMappingURL=importCityMasterCommand.js.map