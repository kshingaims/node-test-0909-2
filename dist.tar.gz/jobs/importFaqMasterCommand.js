import { exit } from 'process';
import dotenv from 'dotenv';
import { readFile } from 'fs/promises';
import papaparse from 'papaparse';
import prisma from '../utils/prismaClient.js';
import { batchLog } from '../utils/logger.js';
import { sleep } from '../utils/index.js';
import { convertFullPath } from '../utils/localFile.js';
import { createFaq, deleteAllFaqs } from '../service/master/faqService.js';
// mctripのtempフォルダからの相対パス情報
const CSV_FILE_RELATIVE_PATH = 'config/template/faq/faq.csv';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    const targetCount = process.argv[3];
    // 2番目の引数は取り込み対象の合計レコード数
    if (!targetCount || !isFinite(Number(targetCount)) || Number(targetCount) <= 0) {
        batchLog.warn('process.argv[3] is the total count of faq records.');
        exit(0);
    }
    const main = async (targetCount) => {
        batchLog.info('importFaqMasterCommand start.');
        try {
            const filePath = convertFullPath(CSV_FILE_RELATIVE_PATH);
            let faqs = [];
            try {
                // FAQ取り込み対象CSVファイルを読み込む
                const csvData = await readFile(filePath, { encoding: 'utf-8' });
                const parseJsonResult = papaparse.parse(csvData, {
                    dynamicTyping: true,
                    header: true,
                    skipEmptyLines: true,
                });
                faqs = parseJsonResult.data;
            }
            catch (e) {
                batchLog.info(`csv file is not exists or csv file is broken. [path: ${filePath}]`);
                await sleep(10);
                exit(0);
            }
            // CSVデータ件数が取り込みしたいFAQの件数と一致しない場合は、安全の為処理は行わない。
            if (faqs.length !== targetCount) {
                batchLog.info(`csv file row count is not same. [expected: ${targetCount}] [actual: ${faqs.length}]`);
                await sleep(10);
                exit(0);
            }
            // CSVデータのフォーマット異常がないかのチェック
            let checkCount = 1;
            for (const faq of faqs) {
                const validateResult = checkFaqValidate(faq);
                if (!validateResult.isSuccess) {
                    batchLog.info(`csv validate error. ${validateResult.errorMessage} [row: ${checkCount}]`);
                    await sleep(10);
                    exit(0);
                }
                checkCount++;
            }
            // faqマスタの更新処理
            // トランザクション処理実施
            await prisma.$transaction(async (tx) => {
                // 最初のFAQマスタのレコード全削除実施
                if (!(await deleteAllFaqs(tx))) {
                    throw new Error('faq record delete error.');
                }
                for (const faq of faqs) {
                    const res = await createFaq(tx, faq);
                    if (!res || !res.id) {
                        throw new Error('faq record create error.');
                    }
                }
            }, {
                timeout: 30000,
                maxWait: 5000,
            });
        }
        catch (error) {
            batchLog.error('importFaqMasterCommand error.', error);
        }
        batchLog.info('importFaqMasterCommand end.');
        await sleep(10);
        exit(0);
    };
    main(Number(targetCount));
}
catch (error) {
    batchLog.error('importFaqMasterCommand error.', error);
    exit(1);
}
function checkFaqValidate(faq) {
    const result = { isSuccess: true };
    if (!faq.category1) {
        result.errorMessage = 'category1 is necessary.';
    }
    else if (!faq.category2) {
        result.errorMessage = 'category2 is necessary.';
    }
    else if (!faq.linkUrl) {
        result.errorMessage = 'linkUrl is necessary.';
    }
    else if (faq.category1.length > 50) {
        result.errorMessage = 'category1 is less than 50 characters.';
    }
    else if (faq.category2.length > 255) {
        result.errorMessage = 'category2 is less than 255 characters.';
    }
    else if (faq.category3 && faq.category3.length > 255) {
        result.errorMessage = 'category3 is less than 255 characters.';
    }
    else if (faq.linkUrl.length > 511) {
        result.errorMessage = 'linkUrl is less than 511 characters.';
    }
    if (result.errorMessage) {
        result.isSuccess = false;
    }
    return result;
}
//# sourceMappingURL=importFaqMasterCommand.js.map