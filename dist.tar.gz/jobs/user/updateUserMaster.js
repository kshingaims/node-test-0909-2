import { getSabunUsers } from '../../service/mcidm/mcidmApiService.js';
import prisma from '../../utils/prismaClient.js';
import { create, deleteUserByPid, update, upsert } from '../../service/user/userService.js';
const KOUSIN_KBN_DELETE = 'D';
const ALL_USER_ACTION = {
    READY: 1,
    FINISH: 2,
};
// const MAX_USER_GET_COUNT = 2;
/**
 * 認証基盤から取得した最新ユーザ情報の更新処理
 * DBコネクションを利用者側を優先したいので、処理はシングルスレッドで実施する
 * @param _prisma
 * @param log
 */
export async function updateUserMaster(_prisma, log, forceAll = false) {
    // ユーザ全件取得
    const allUsers = await prisma.user.findMany({ select: { pid: true }, where: { flgDelete: false } });
    const isNoUser = allUsers.length <= 0;
    const allUsersMap = new Map();
    for (const dbUser of allUsers) {
        allUsersMap.set(dbUser.pid, ALL_USER_ACTION.READY);
    }
    // 初回アクセス時はユーザ全件取得実施。それ以外は原則差分取得
    const { users: mcidmUsers, isAll } = await getSabunUsers(log, isNoUser || forceAll);
    if (mcidmUsers && mcidmUsers.length > 0) {
        for (const mcidmUser of mcidmUsers) {
            const pid = mcidmUser['ns1:PersonalID'].toString();
            const isDelete = mcidmUser['ns1:Kousin_Kbn'] === KOUSIN_KBN_DELETE;
            const user = {
                pid,
                lastNameRoma: mcidmUser['ns1:LastName_Roma'],
                lastNameKanji: mcidmUser['ns1:LastName_Kanji'],
                lastNameKana: mcidmUser['ns1:LastName_Kana'],
                firstNameRoma: mcidmUser['ns1:FirstName_Roma'],
                firstNameKanji: mcidmUser['ns1:FirstName_Kanji'],
                firstNameKana: mcidmUser['ns1:FirstName_Kana'],
                email: mcidmUser['ns1:Email'],
                mcSyozokuCd: mcidmUser['ns1:Mc_Syozoku_Cd'].toString(),
                mcSyozokuNameKanji: mcidmUser['ns1:Mc_Syozoku_Name_Kanji'],
                mcSyozokuNameRoma: mcidmUser['ns1:Mc_Syozoku_Name_Roma'],
                mcSyozokuGrpCd: mcidmUser['ns1:Mc_Syozoku_Grp_Cd'].toString(),
                mcSyozokuGrpNameKanji: mcidmUser['ns1:Mc_Syozoku_Grp_Name_Kanji'],
                mcSyozokuGrpNameRoma: mcidmUser['ns1:Mc_Syozoku_Grp_Name_Roma'],
                userBunrui: mcidmUser['ns1:User_Bunrui'].toString(),
                userBunruiNameKanji: mcidmUser['ns1:User_Bunrui_Name_Kanji'],
                userBunruiNameRoma: mcidmUser['ns1:User_Bunrui_Name_Roma'],
                corpCd: mcidmUser['ns1:Corp_Cd'].toString(),
                flgDelete: isDelete,
            };
            if (isNoUser) {
                if (!isDelete) {
                    await create(prisma, user);
                }
            }
            else {
                // 既にユーザいるのが明確ならば、update実施
                if (allUsersMap.has(pid)) {
                    await update(prisma, user);
                    allUsersMap.set(pid, ALL_USER_ACTION.FINISH);
                }
                else {
                    // 論理削除が立っているユーザがいるかもしれないので、ユーザ新規登録はupsertを利用
                    await upsert(prisma, user);
                }
            }
        }
        // 全件取得時は、MCTripが持っているユーザ情報の中でなにも処理がかかっていないユーザーは削除されたものと判定
        if (isAll) {
            const dbExistsPids = allUsersMap.keys();
            for (const dbExistsPid of dbExistsPids) {
                if (allUsersMap.get(dbExistsPid) === ALL_USER_ACTION.READY) {
                    await deleteUserByPid(prisma, dbExistsPid);
                    log.info(`user deleted. [pid: ${dbExistsPid}]`);
                }
            }
        }
    }
}
//# sourceMappingURL=updateUserMaster.js.map