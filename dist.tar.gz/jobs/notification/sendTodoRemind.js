import { orderBy } from 'lodash-es';
import { addDays } from 'date-fns';
import { getNotificationSettingById, } from '../../service/notification/notificationSettingService.js';
import { getTargetsOfSendRemindsAfterTrip, getTargetsOfSendRemindsBeforeTrip, } from '../../service/notification/itineraryNotificationService.js';
import { convertListToMapByUniqueKey, format, joinStr, replaceCRLF } from '../../utils/index.js';
import { sendSmtpMail } from '../../utils/smtpMail.js';
import { STR_TO_DO, updateSendRemindDateByIds } from '../../service/notification/notificationService.js';
const RETURN = '\n';
/**
 * 出張前におけるto_doリストのリマインドメール送信ジョブ
 * @param prisma
 * @param log
 */
export async function sendTo_doRemindBeforeTrip(prisma, log) {
    const result = [];
    const id = 'to_do_remind_before_itinerary';
    const { setting, targetDate } = await getRemindNotificationSettingAndTargetDate(prisma, log, id);
    if (!setting || !targetDate) {
        return result;
    }
    const itineraryList = await getTargetsOfSendRemindsBeforeTrip(prisma, targetDate);
    for (const itinerary of itineraryList) {
        const itineraryIndividualsMap = convertListToMapByUniqueKey(itinerary.itineraryIndividuals, 'pid');
        // pid毎に並べ替えを行い、pid毎にリマインド対象の全to_do情報がまとめられるようにしておく
        const notifications = orderBy(filterNotifications(itinerary.notifications), ['pid', 'id'], ['asc', 'asc']);
        const targetTo_dos = {};
        for (const notification of notifications) {
            const pid = notification.pid;
            if (!targetTo_dos[pid]) {
                targetTo_dos[pid] = [];
            }
            const presentTo_dos = targetTo_dos[pid];
            const options = notification.notificationSetting?.options;
            // リマインド実行が出張前となっているto_do情報のみを抽出対象とする。
            if (options.remindBefore) {
                presentTo_dos.push(notification);
            }
        }
        // pid毎に、リマインドするto_do情報がある場合は、メールでリマインド送信実施
        for (const pid of Object.keys(targetTo_dos)) {
            const remindCount = targetTo_dos[pid].length;
            if (remindCount > 0) {
                await _sendRemind(prisma, log, setting, itineraryIndividualsMap[pid], targetTo_dos[pid]);
                const itineraryName = itineraryIndividualsMap[pid].itineraryName;
                const email = itineraryIndividualsMap[pid].user.email || '';
                result.push({ itineraryId: itinerary.id, itineraryName, pid, email, remindCount });
            }
        }
    }
    log.info('send to_do remind before trip finished.');
    return result;
}
/**
 * 出張後におけるto_doリストのリマインドメール送信ジョブ
 * @param prisma
 * @param log
 */
export async function sendTo_doRemindAfterTrip(prisma, log) {
    const result = [];
    const id = 'to_do_remind_after_itinerary';
    const { setting, targetDate } = await getRemindNotificationSettingAndTargetDate(prisma, log, id);
    if (!setting || !targetDate) {
        return result;
    }
    const itineraryList = await getTargetsOfSendRemindsAfterTrip(prisma, targetDate);
    for (const itinerary of itineraryList) {
        const itineraryIndividualsMap = convertListToMapByUniqueKey(itinerary.itineraryIndividuals, 'pid');
        // pid毎に並べ替えを行い、pid毎にリマインド対象の全to_do情報がまとめられるようにしておく
        const notifications = orderBy(filterNotifications(itinerary.notifications), ['pid', 'id'], ['asc', 'asc']);
        const targetTo_dos = {};
        for (const notification of notifications) {
            const pid = notification.pid;
            if (!targetTo_dos[pid]) {
                targetTo_dos[pid] = [];
            }
            const presentTo_dos = targetTo_dos[pid];
            const options = notification.notificationSetting?.options;
            // リマインド実行が出張後となっているto_do情報のみを抽出対象とする。
            if (options.remindAfter) {
                presentTo_dos.push(notification);
            }
        }
        // pid毎に、リマインドするto_do情報がある場合は、メールでリマインド送信実施
        for (const pid of Object.keys(targetTo_dos)) {
            const remindCount = targetTo_dos[pid].length;
            if (remindCount > 0) {
                await _sendRemind(prisma, log, setting, itineraryIndividualsMap[pid], targetTo_dos[pid]);
                const itineraryName = itineraryIndividualsMap[pid].itineraryName;
                const email = itineraryIndividualsMap[pid].user.email || '';
                result.push({ itineraryId: itinerary.id, itineraryName, pid, email, remindCount });
            }
        }
    }
    log.info('send to_do remind after trip finished.');
    return result;
}
export async function getRemindNotificationSettingAndTargetDate(prisma, log, id) {
    const setting = await getNotificationSettingById(prisma, id);
    if (!setting) {
        log.warn(`no notificationSetting data [id: ${id}]`);
        return {};
    }
    const options = setting.options;
    if (!options.whenCreate || !isFinite(options.whenCreate)) {
        throw new Error('whenCreate must be number.');
    }
    return { setting, targetDate: addDays(new Date(), options.whenCreate) };
}
async function _sendRemind(prisma, log, setting, itinearryIndividual, notifications) {
    if (!itinearryIndividual.user.email) {
        throw new Error('programing error. email must be exist.');
    }
    // メール本文メッセージ生成処理
    let messages = '';
    for (const notification of notifications) {
        if (messages) {
            messages = messages + RETURN + RETURN;
        }
        messages = messages + joinStr(['・' + notification.content, notification.linkUrl], RETURN);
    }
    const body = replaceCRLF(format(setting.content || '', { messages, itinearryIndividual }));
    // メール送信
    const res = await sendSmtpMail(log, { to: [itinearryIndividual.user.email], title: setting.title || '', body });
    if (res) {
        const ids = notifications.map((notification) => notification.id);
        // DBデータ上でリマインドメール送信完了にする
        if (!(await updateSendRemindDateByIds(prisma, ids))) {
            log.error('something wrong. db update count is not collect.');
        }
    }
}
/**
 * 旅程に紐つくnotifications一覧情報の中から、以下に該当するデータのみをfilter実施する。
 * ・typeがto_doとなっているもの
 * ・to_do完了チェックが入っていないもの
 * ・リマインド通知が一度も行われていないもの
 * @param notifications
 * @returns
 */
function filterNotifications(notifications) {
    if (!notifications || notifications.length <= 0) {
        return notifications;
    }
    const result = [];
    for (const notification of notifications) {
        if (notification.type === STR_TO_DO && !notification.flgFinished && !notification.sendRemindDate) {
            result.push(notification);
        }
    }
    return result;
}
//# sourceMappingURL=sendTodoRemind.js.map