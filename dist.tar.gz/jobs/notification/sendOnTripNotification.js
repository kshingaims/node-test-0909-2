/**
 * 通知ジョブ実行
 * @param _prisma
 * @param log
 */
export async function sendOnTripNotification(_prisma, log) {
    log.info('send OnTrip Notification execute.');
}
//# sourceMappingURL=sendOnTripNotification.js.map