import { readFile } from 'fs/promises';
import papaparse from 'papaparse';
import { joinStr } from '../../utils/index.js';
import { convertFullPath } from '../../utils/localFile.js';
import { NOTIFICATION_SETTING_TYPES, TARGET_PERSIONS, TO_DO_TARGET_PERSONS, TO_DO_WHEN_CREATES, createNotificationSetting, deleteNotificationSettingByType, } from '../../service/notification/notificationSettingService.js';
// mctripのtempフォルダからの相対パス情報
const TO_DO_CSV_RELATIVE_PATH = 'config/template/notification/to_do_settings.csv';
const SITE_NOTICE_CSV_RELATIVE_PATH = 'config/template/notification/site_notification_settings.csv';
const WEB_PUSH_CSV_RELATIVE_PATH = 'config/template/notification/webpush_settings.csv';
const SMTP_MAIL_CSV_RELATIVE_PATH = 'config/template/notification/smtp_mail_settings.csv';
export async function updateNotificationSettingJob(log, prisma, type) {
    log.info('updateNotificationSettingJob start.');
    try {
        let relativePath = '';
        let formatter;
        if (type === 'to_do') {
            relativePath = TO_DO_CSV_RELATIVE_PATH;
            formatter = _formatTo_DoNSettings;
        }
        else if (type === 'webpush') {
            relativePath = WEB_PUSH_CSV_RELATIVE_PATH;
            formatter = _formatWebpushNSettings;
        }
        else if (type === 'smtp_mail') {
            relativePath = SMTP_MAIL_CSV_RELATIVE_PATH;
            formatter = _formatSmtpMailNSettings;
        }
        else if (type === 'site_notice') {
            relativePath = SITE_NOTICE_CSV_RELATIVE_PATH;
            formatter = _formatSiteNoticeNSettings;
        }
        else {
            log.info('type azure_mail is not defined.');
            return;
        }
        const filePath = convertFullPath(relativePath);
        let nSettings = [];
        try {
            // 通知タイミング設定(取り込み)対象CSVファイルを読み込む
            const csvData = await readFile(filePath, { encoding: 'utf-8' });
            const parseJsonResult = papaparse.parse(csvData, {
                dynamicTyping: true,
                header: true,
                skipEmptyLines: true,
            });
            nSettings = parseJsonResult.data;
        }
        catch (e) {
            log.info(`csv file is not exists or csv file is broken. [path: ${filePath}]`);
            return;
        }
        // CSVデータのフォーマット異常がないかのチェック
        let checkCount = 1;
        const keyCheckerMap = {};
        for (const nSetting of nSettings) {
            // options設定の整形処理とoption設定部分の入力チェック
            const formatterResult = formatter(nSetting);
            nSetting.type = type;
            if (!formatterResult.isSuccess || formatterResult.errorMessage) {
                log.info(`csv validate error. ${formatterResult.errorMessage} [row: ${checkCount}]`);
                return;
            }
            const validateResult = checkNSettingValidate(keyCheckerMap, nSetting);
            if (!validateResult.isSuccess) {
                log.info(`csv validate error. ${validateResult.errorMessage} [row: ${checkCount}]`);
                return;
            }
            checkCount++;
        }
        // faqマスタの更新処理
        // トランザクション処理実施
        await prisma.$transaction(async (tx) => {
            // 同一typeのデータを全削除しておく
            await deleteNotificationSettingByType(tx, type);
            for (const nSetting of nSettings) {
                const res = await createNotificationSetting(tx, nSetting);
                if (!res || !res.id) {
                    throw new Error('notificationSetting upsert error.');
                }
            }
        }, {
            timeout: 5000,
            maxWait: 5000,
        });
    }
    catch (error) {
        log.error('updateNotificationSettingJob error.', error);
    }
    log.info('updateNotificationSettingJob end.');
}
function checkNSettingValidate(keyCheckerMap, nSetting) {
    const result = { isSuccess: true };
    if (!nSetting.id) {
        result.errorMessage = 'id is necessary.';
    }
    else if (keyCheckerMap[nSetting.id]) {
        result.errorMessage = 'id is not unique.';
    }
    else if (!nSetting.type || !NOTIFICATION_SETTING_TYPES.includes(nSetting.type)) {
        result.errorMessage = `type is not correct [${joinStr(NOTIFICATION_SETTING_TYPES, ',')}]`;
    }
    else if (nSetting.id.length > 50) {
        result.errorMessage = 'id is less than 50 characters.';
    }
    else if (nSetting.content && nSetting.content.length > 511) {
        result.errorMessage = 'content is less than 511 characters.';
    }
    else if (nSetting.title && nSetting.title.length > 255) {
        result.errorMessage = 'title is less than 255 characters.';
    }
    else if (nSetting.linkUrl && nSetting.linkUrl.length > 511) {
        result.errorMessage = 'linkUrl is less than 511 characters.';
    }
    if (!nSetting.options) {
        nSetting.options = {};
    }
    if (result.errorMessage) {
        result.isSuccess = false;
    }
    keyCheckerMap[nSetting.id] = true;
    return result;
}
function _formatTo_DoNSettings(nSetting) {
    const result = { isSuccess: true };
    if (!nSetting.content) {
        result.errorMessage = 'content is necessary.';
        result.isSuccess = false;
        return result;
    }
    const item = nSetting;
    if (!item.whenCreate || !TO_DO_WHEN_CREATES.includes(item.whenCreate)) {
        result.errorMessage = `whenCreate is not correct [${joinStr(TO_DO_WHEN_CREATES, ' or ')}]`;
    }
    else if (!item.targetPerson || !TO_DO_TARGET_PERSONS.includes(item.targetPerson)) {
        result.errorMessage = `targetPerson is not correct [${joinStr(TO_DO_TARGET_PERSONS, ' or ')}]`;
    }
    else if (!item.sort || !isFinite(Number(item.sort))) {
        result.errorMessage = 'sort is not number';
    }
    if (result.errorMessage) {
        result.isSuccess = false;
        return result;
    }
    const options = {
        whenCreate: item.whenCreate,
        sort: Number(item.sort),
        targetPerson: item.targetPerson,
        remindBefore: !!item.remindBefore,
        remindAfter: !!item.remindAfter,
    };
    nSetting.options = options;
    return result;
}
function _formatWebpushNSettings(nSetting) {
    const result = { isSuccess: true };
    if (!nSetting.title) {
        result.errorMessage = 'title is necessary.';
        result.isSuccess = false;
        return result;
    }
    const item = nSetting;
    if (!item.targetPerson || !TARGET_PERSIONS.includes(item.targetPerson)) {
        result.errorMessage = `targetPerson is not correct [${joinStr(TARGET_PERSIONS, ' or ')}]`;
    }
    else if (item.whenCreate == null || !isFinite(item.whenCreate)) {
        result.errorMessage = 'whenCreate is number(minutes).';
    }
    else if (item.targetSpanMinutes == null || !isFinite(item.targetSpanMinutes)) {
        result.errorMessage = 'targetSpanMinutes is number(minutes).';
    }
    if (result.errorMessage) {
        result.isSuccess = false;
        return result;
    }
    const options = {
        whenCreate: item.whenCreate,
        targetSpanMinutes: item.targetSpanMinutes,
        targetPerson: item.targetPerson,
    };
    nSetting.options = options;
    return result;
}
function _formatSiteNoticeNSettings(nSetting) {
    const result = { isSuccess: true };
    if (!nSetting.content) {
        result.errorMessage = 'content is necessary.';
        result.isSuccess = false;
        return result;
    }
    const item = nSetting;
    if (!item.targetPerson || !TARGET_PERSIONS.includes(item.targetPerson)) {
        result.errorMessage = `targetPerson is not correct [${joinStr(TARGET_PERSIONS, ' or ')}]`;
    }
    else if (item.whenCreate == null || !isFinite(item.whenCreate)) {
        result.errorMessage = 'whenCreate is number(minutes).';
    }
    else if (item.targetSpanMinutes == null || !isFinite(item.targetSpanMinutes)) {
        result.errorMessage = 'targetSpanMinutes is number(minutes).';
    }
    if (result.errorMessage) {
        result.isSuccess = false;
        return result;
    }
    const options = {
        whenCreate: item.whenCreate,
        targetSpanMinutes: item.targetSpanMinutes,
        targetPerson: item.targetPerson,
    };
    nSetting.options = options;
    return result;
}
function _formatSmtpMailNSettings(nSetting) {
    const result = { isSuccess: true };
    const item = nSetting;
    if (!nSetting.content) {
        result.errorMessage = 'content is necessary.';
        result.isSuccess = false;
        return result;
    }
    else if (!nSetting.title) {
        result.errorMessage = 'title is necessary.';
        result.isSuccess = false;
        return result;
    }
    if (item.whenCreate && !isFinite(item.whenCreate)) {
        result.errorMessage = 'whenCreate is number(day).';
    }
    if (result.errorMessage) {
        result.isSuccess = false;
        return result;
    }
    const options = {
        whenCreate: item.whenCreate,
    };
    nSetting.options = options;
    return result;
}
//# sourceMappingURL=updateNotificationSettingsJob.js.map