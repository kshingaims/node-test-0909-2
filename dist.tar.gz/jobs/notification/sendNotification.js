import { merge } from 'lodash-es';
import { addMinutes, differenceInHours, addSeconds } from 'date-fns';
import { Define } from '../../utils/define.js';
import { calcDifferenceInMinutes, convertListToMapByUniqueKey, format, formatUtcDateTime, getLocalDate } from '../../utils/index.js';
import { sendNotification as sendWebpush } from '../../utils/webPush.js';
import { getNotificationSettingMapByIds } from '../../service/notification/notificationSettingService.js';
import { getCompanyCarSchedListForNotification, getFlightSchedListForNotification, } from '../../service/notification/itineraryNotificationService.js';
import { getWebpushDeviceInfos } from '../../service/user/userService.js';
import { createSiteNotification } from '../../service/notification/notificationService.js';
import { updateNotificationStatus } from '../../service/flight/flightService.js';
import { updateNotificationStatus as updateCompanycarNotificationStatus } from '../../service/companyCar/companyCarService.js';
/**
 * 通知ジョブ実行
 * @param prisma
 * @param log
 */
export async function sendNotification(prisma, log) {
    const presentDatetime = new Date(formatUtcDateTime(new Date(), 'yyyy-MM-dd HH:mm:00XXX'));
    const presentDatetimePlusOneSecond = addSeconds(presentDatetime, 1);
    const settingMap = await getNotificationSettingMapByIds(prisma, [
        'flight_remind_site_notification',
        'flight_remind_site_final_notification',
        'flight_remind_webpush',
        'flight_remind_final_webpush',
        'company_car_remind_site_notification',
        'company_car_remind_webpush',
    ]);
    // フライト24時間前通知実施
    let options = getSearchDateInfo(settingMap, presentDatetime, 'flight_remind_site_notification');
    let schedFlights = await getFlightSchedListForNotification(prisma, options);
    let webpushDeviceMap = convertListToMapByUniqueKey(await getUserDevices(prisma, schedFlights, 'schedFlightIndividuals'), 'pid');
    if (schedFlights.length <= 0) {
        log.debug(`no flight notification target. [targetDatetime: ${options.targetDatetime}]`);
    }
    for (const schedFlight of schedFlights) {
        // 出発時間が未確定の場合は処理しない
        if (!schedFlight.departureDateTime || !schedFlight.departureTimezone) {
            continue;
        }
        // 通知するメッセージ情報の生成
        // 出発時間の整形
        const departureDateTime = formatUtcDateTime(getLocalDate(schedFlight.departureDateTime, schedFlight.departureTimezone), 'yyyy/MM/dd HH:mm');
        // 出発前何時間かの情報
        const beforeHour = differenceInHours(schedFlight.departureDateTime, presentDatetimePlusOneSecond) + 1;
        for (const schedIndividual of schedFlight.schedFlightIndividuals) {
            if (!schedIndividual.flgDelete && !schedIndividual.flgReject) {
                // WEBサイト通知レコードの新規追加
                await createSiteNotificationForFlightNotification(prisma, settingMap['flight_remind_site_notification'], webpushDeviceMap[schedIndividual.pid], { beforeHour, departureDateTime, schedFlight, schedIndividual });
                // WEB PUSH通知実施
                sendWebpushForFlightNotification(log, settingMap['flight_remind_webpush'], webpushDeviceMap[schedIndividual.pid], { beforeHour, departureDateTime, schedFlight, schedIndividual });
            }
        }
        // DB更新実施
        await updateNotificationStatus(prisma, schedFlight.id, Define.SETTINGS.NOTIFICATION_STATUS.SEND);
    }
    // フライト3時間前通知実施
    options = getSearchDateInfo(settingMap, presentDatetime, 'flight_remind_site_final_notification');
    schedFlights = await getFlightSchedListForNotification(prisma, options, true);
    webpushDeviceMap = convertListToMapByUniqueKey(await getUserDevices(prisma, schedFlights, 'schedFlightIndividuals'), 'pid');
    if (schedFlights.length <= 0) {
        log.debug(`no flight notification target. [targetDatetime: ${options.targetDatetime}]`);
    }
    for (const schedFlight of schedFlights) {
        // 出発時間が未確定の場合は処理しない
        if (!schedFlight.departureDateTime || !schedFlight.departureTimezone) {
            continue;
        }
        // 通知するメッセージ情報の生成
        // 出発時間の整形
        const departureDateTime = formatUtcDateTime(getLocalDate(schedFlight.departureDateTime, schedFlight.departureTimezone), 'yyyy/MM/dd HH:mm');
        // 出発前何時間かの情報
        const beforeHour = differenceInHours(schedFlight.departureDateTime, presentDatetimePlusOneSecond) + 1;
        for (const schedIndividual of schedFlight.schedFlightIndividuals) {
            if (!schedIndividual.flgDelete && !schedIndividual.flgReject) {
                // WEBサイト通知レコードの新規追加
                await createSiteNotificationForFlightNotification(prisma, settingMap['flight_remind_site_final_notification'], webpushDeviceMap[schedIndividual.pid], { beforeHour, departureDateTime, schedFlight, schedIndividual });
                // WEB PUSH通知実施
                sendWebpushForFlightNotification(log, settingMap['flight_remind_final_webpush'], webpushDeviceMap[schedIndividual.pid], { beforeHour, departureDateTime, schedFlight, schedIndividual });
            }
        }
        // DB更新実施
        await updateNotificationStatus(prisma, schedFlight.id, Define.SETTINGS.NOTIFICATION_STATUS.SEND_FINAL);
    }
    // 社有車30分前通知実施
    options = getSearchDateInfo(settingMap, presentDatetime, 'company_car_remind_site_notification');
    const schedCompanyCars = await getCompanyCarSchedListForNotification(prisma, options);
    webpushDeviceMap = convertListToMapByUniqueKey(await getUserDevices(prisma, schedCompanyCars, 'schedCompanyCarIndividuals'), 'pid');
    if (schedCompanyCars.length <= 0) {
        log.debug(`no company car notification target. [targetDatetime: ${options.targetDatetime}]`);
    }
    for (const schedCompanyCar of schedCompanyCars) {
        // タイムゾーン指定のない社有車予定は通知送信しない
        if (!schedCompanyCar.timezone) {
            continue;
        }
        // 通知するメッセージ情報の生成
        // 出発時間の整形
        const startDateTime = formatUtcDateTime(getLocalDate(schedCompanyCar.startDateTime, schedCompanyCar.timezone), 'yyyy/MM/dd HH:mm');
        // 出発前何分前(15分間隔)かの情報
        const beforeMinute = calcDifferenceInMinutes(schedCompanyCar.startDateTime, presentDatetimePlusOneSecond, 'ceil', 15);
        for (const schedIndividual of schedCompanyCar.schedCompanyCarIndividuals) {
            if (!schedIndividual.flgDelete && !schedIndividual.flgReject) {
                // WEBサイト通知レコードの新規追加
                await createSiteNotificationForCompanyCarNotification(prisma, settingMap['company_car_remind_site_notification'], webpushDeviceMap[schedIndividual.pid], { beforeMinute, startDateTime, schedCompanyCar, schedIndividual });
                // WEB PUSH通知実施
                sendWebpushForCompanyCarNotification(log, settingMap['company_car_remind_webpush'], webpushDeviceMap[schedIndividual.pid], { beforeMinute, startDateTime, schedCompanyCar, schedIndividual });
            }
        }
        // DB更新実施
        await updateCompanycarNotificationStatus(prisma, schedCompanyCar.id, Define.SETTINGS.NOTIFICATION_STATUS.SEND);
    }
    log.info('send Notification finish.');
}
export function sendWebpushForFlightNotification(log, setting, target, data) {
    if (!setting.title) {
        throw new Error('notificationSettings title is required.');
    }
    const title = format(setting.title, { beforeHour: data.beforeHour });
    const content = setting.content ? format(setting.content, data) : undefined;
    const linkUrl = setting.linkUrl ? format(setting.linkUrl, merge({ domain: Define.DOMAIN }, data)) : undefined;
    sendWebpush(log, target, { title, body: content, url: linkUrl });
}
export async function createSiteNotificationForFlightNotification(prisma, setting, target, data) {
    if (!setting.content) {
        throw new Error('notificationSettings content is required.');
    }
    const content = format(setting.content, data);
    const linkUrl = setting.linkUrl ? format(setting.linkUrl, merge({ domain: Define.DOMAIN }, data)) : undefined;
    await createSiteNotification(prisma, target.pid, data.schedFlight.itineraryId, content, linkUrl);
}
export function sendWebpushForCompanyCarNotification(log, setting, target, data) {
    if (!setting.title) {
        throw new Error('notificationSettings title is required.');
    }
    const title = format(setting.title, { beforeMinute: data.beforeMinute });
    const content = setting.content ? format(setting.content, data) : undefined;
    const linkUrl = setting.linkUrl ? format(setting.linkUrl, merge({ domain: Define.DOMAIN }, data)) : undefined;
    sendWebpush(log, target, { title, body: content, url: linkUrl });
}
export async function createSiteNotificationForCompanyCarNotification(prisma, setting, target, data) {
    if (!setting.content) {
        throw new Error('notificationSettings content is required.');
    }
    const content = format(setting.content, data);
    const linkUrl = setting.linkUrl ? format(setting.linkUrl, merge({ domain: Define.DOMAIN }, data)) : undefined;
    await createSiteNotification(prisma, target.pid, data.schedCompanyCar.itineraryId, content, linkUrl);
}
export async function getUserDevices(prisma, scheds, type) {
    const pidMap = {};
    const pids = [];
    for (const sched of scheds) {
        const individuals = sched[type];
        if (!individuals) {
            throw new Error('unreachable error.');
        }
        for (const individual of individuals) {
            if (!individual.flgDelete && !individual.flgReject) {
                const pid = individual.pid;
                if (!pidMap[pid]) {
                    pids.push(pid);
                    pidMap[pid] = true;
                }
            }
        }
    }
    if (pids.length > 0) {
        return await getWebpushDeviceInfos(prisma, pids);
    }
    else {
        return [];
    }
}
function getSearchDateInfo(map, presentDatetime, id) {
    const options = map[id].options;
    return {
        targetDatetime: addMinutes(presentDatetime, options.whenCreate),
        targetSpanMinutes: options.targetSpanMinutes,
    };
}
//# sourceMappingURL=sendNotification.js.map