import { exit } from 'process';
import dotenv from 'dotenv';
import { batchLog } from '../utils/logger.js';
import { getAzureAadToken, getMcidmToken, refleshAzureAadToken } from '../service/azure/authService.js';
import { getLoginUser } from '../service/azure/graphApiService.js';
import { decodeToken } from '../utils/jwtToken.js';
import { sleep } from '../utils/index.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    else if (!process.argv[3]) {
        batchLog.warn('arg[3] is code got by login redirect url(get parameter)');
        exit(0);
    }
    else if (!process.argv[4] || (process.argv[4] !== 'aad' && process.argv[4] !== 'mcidm')) {
        batchLog.warn('arg[4] is type(aad or mcidm)');
        exit(0);
    }
    const main = async () => {
        batchLog.info('ssoAuthTestCommand start.');
        try {
            // トークン取得処理
            if (process.argv[4] === 'aad') {
                const authResult = await getAzureAadToken(batchLog, process.argv[3]);
                batchLog.debug('get aad token', authResult);
                if (authResult.tokenEnc) {
                    const ureResult = await getLoginUser(batchLog, authResult.tokenEnc);
                    const decodedUser = decodeToken(authResult.idToken);
                    batchLog.debug('graph api /me', ureResult, decodedUser);
                    if (authResult.refleshTokenEnc) {
                        const refleshResult = await refleshAzureAadToken(batchLog, authResult.refleshTokenEnc);
                        batchLog.debug('reflesh aad token', refleshResult);
                    }
                }
            }
            else if (process.argv[4] === 'mcidm') {
                const authResult = await getMcidmToken(batchLog, process.argv[3]);
                const decodedUser = decodeToken(authResult.idToken);
                batchLog.debug('get mcidm token', authResult, decodedUser);
            }
            else {
                // ignore
            }
        }
        catch (error) {
            batchLog.error('ssoAuthTestCommand error.', error);
        }
        batchLog.info('ssoAuthTestCommand end.');
        await sleep(10);
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('ssoAuthTestCommand error.', error);
    exit(1);
}
//# sourceMappingURL=ssoAuthTestCommand.js.map