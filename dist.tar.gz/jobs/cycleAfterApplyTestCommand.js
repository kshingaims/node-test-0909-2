import { exit } from 'process';
import dotenv from 'dotenv';
import { addDays } from 'date-fns';
import prisma from '../utils/prismaClient.js';
import { batchLog } from '../utils/logger.js';
import { Define } from '../utils/define.js';
import { applyAfterBusinessTrip } from '../service/cycle/afterApply.js';
import { formatDate, formatDateTime, sleep } from '../utils/index.js';
import { create as itineraryCreate } from '../controller/itinerary/index.js';
import { getUserByPid } from '../service/user/userService.js';
import { expense, expenseAccommodationCreate, expenseOtherCreate, expenseTransportationCreate, } from '../controller/expense/index.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    else if (!process.argv[3] || !process.argv[4]) {
        batchLog.warn('arg[3] is ID. arg[4] is password.');
        exit(0);
    }
    else if (!process.argv[5]) {
        batchLog.warn('arg[5] is MCTrip user pid.');
        exit(0);
    }
    const main = async () => {
        batchLog.info('cycleAfterApplyTestCommand start.');
        const pid = process.argv[5];
        let createDataRes = {};
        try {
            const options = { id: '', pass: '', cookieIwInfoIntra3: '' };
            if (process.argv[3] === 'cookie') {
                options.cookieIwInfoIntra3 = process.argv[4];
            }
            else {
                options.id = process.argv[3];
                options.pass = process.argv[4];
            }
            // test時に旅程作成、テスト用の経費データ作成実施
            createDataRes = await createTestData(pid);
            const itineraryId = createDataRes.itineraryId;
            if (!itineraryId) {
                return;
            }
            // 事前伺い申請処理実施
            const result = await applyAfterBusinessTrip(batchLog, { prisma, pid, user: { pid: '9ZPWD016' }, itineraryId }, options);
            if (result.errorCode) {
                if (result.errorCode.indexOf('E') >= 0) {
                    batchLog.error(`cycle operation error. cycle site may be changed recently. [errorCode:${result.errorCode}]`);
                }
                else if (result.errorCode === Define.ERROR_CODES.W01001) {
                    batchLog.warn(`this user do not have delegator access rights in cycle system. [errorCode:${result.errorCode}]`);
                }
                else {
                    batchLog.warn(`cycle operation error. [errorCode:${result.errorCode}]`);
                }
            }
            if (result.isSuccess) {
                batchLog.info('cycleAfterApplyTestCommand success.');
            }
            else {
                batchLog.warn('cycleAfterApplyTestCommand failed.');
            }
            if (!result.isDbUpdate) {
                batchLog.warn('cycleAfterApplyTestCommand cycleLinkStatus update failed.');
            }
        }
        catch (error) {
            batchLog.error('cycleAfterApplyTestCommand error.', error);
        }
        finally {
            if (createDataRes.itineraryId) {
                // テスト作成したitineraryデータを削除
                await prisma.itinerary.delete({ where: { id: createDataRes.itineraryId } });
            }
            batchLog.info('cycleAfterApplyTestCommand end.');
            await sleep(10);
            exit(0);
        }
    };
    main();
}
catch (error) {
    batchLog.error('cycleAfterApplyTestCommand base error.', error);
    exit(1);
}
async function createTestData(pid) {
    const req = {};
    const res = {};
    const tokens = {};
    // 指定されたpidがMCTripシステムのusersとして存在していない場合は、終了
    const user = await getUserByPid(prisma, pid);
    if (!user.pid) {
        return {};
    }
    const settlementDate = new Date();
    // テスト用のItineraryを作成する
    const props = {
        itineraryName: '旅程名',
        places: [
            {
                cityId: 1,
                stayDurationFrom: formatDate(settlementDate),
                stayDurationTo: formatDate(addDays(settlementDate, 5)),
            },
            {
                cityId: 2,
                stayDurationFrom: formatDate(addDays(settlementDate, 5)),
                stayDurationTo: formatDate(addDays(settlementDate, 8)),
            },
        ],
        companions: [],
    };
    const result = await itineraryCreate(props, { prisma, pid, user, req, res, tokens });
    const itineraryId = result.data.itinerary.id;
    const expenseRes = await expense({ itineraryId: itineraryId.toString() }, { pid, prisma, user, req, res, tokens });
    // 経費作成
    const expenseId = expenseRes.data.id;
    await createExpenseData(expenseId, settlementDate, { prisma, pid, user, req, res, tokens });
    return { itineraryId };
}
async function createExpenseData(expenseId, settlementDate, controllerTools) {
    // 経費交通費新規登録
    const expenseTransportationCreatePropsList = [
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: '国内交通費（課税）',
            transportationType: '電車（新幹線・特急を除く）',
            departureLocation: '自宅',
            arrivalLocation: '成田',
            price: 10000,
            currency: 'JPY',
            remark: '備考1',
        },
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: '海外交通費',
            transportationType: '電車（新幹線・特急を除く）',
            departureLocation: 'Pari Hotel',
            arrivalLocation: 'Pari Office',
            price: 100.15,
            currency: 'THB',
            remark: '備考2',
        },
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: '海外交通費',
            transportationType: '電車（新幹線・特急）',
            departureLocation: 'Pari Office',
            arrivalLocation: 'Pari Hotel',
            price: 99.87,
            currency: 'THB',
            remark: '備考3',
        },
    ];
    for (const expenseTransportationCreateProps of expenseTransportationCreatePropsList) {
        await expenseTransportationCreate(expenseTransportationCreateProps, controllerTools);
    }
    // 経費宿泊費新規登録
    const expenseAccommodationCreatePropsList = [
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            cityId: 1,
            hotelName: 'Hilton Bangkok Siam Hotel',
            checkInDate: formatDateTime(settlementDate),
            checkOutDate: formatDateTime(addDays(settlementDate, 2)),
            price: 12400,
            currency: 'THB',
            remark: '備考1',
        },
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            cityId: 1,
            hotelName: 'Hilton Australia Siam Hotel',
            checkInDate: formatDateTime(addDays(settlementDate, 5)),
            checkOutDate: formatDateTime(addDays(settlementDate, 7)),
            price: 1090,
            currency: 'AUD',
            remark: '備考2',
        },
    ];
    for (const expenseAccommodationCreateProps of expenseAccommodationCreatePropsList) {
        await expenseAccommodationCreate(expenseAccommodationCreateProps, controllerTools);
    }
    // 経費その他新規登録
    const expenseOtherCreatePropsList = [
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: '海外通信費（課税）',
            price: 720.56,
            currency: 'THB',
            remark: '備考1',
        },
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: 'ビザ代',
            price: 5620,
            currency: 'JPY',
            remark: '備考2',
        },
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: '雑費（課税）',
            price: 9998,
            currency: 'JPY',
            remark: '備考3',
        },
        {
            expenseId,
            settlementDate: formatDate(settlementDate),
            settlementType: '旅券印紙代',
            price: 90.85,
            currency: 'AUD',
            remark: '備考4',
        },
    ];
    for (const expenseOtherCreateProps of expenseOtherCreatePropsList) {
        await expenseOtherCreate(expenseOtherCreateProps, controllerTools);
    }
}
//# sourceMappingURL=cycleAfterApplyTestCommand.js.map