import { Cron } from 'croner';
import { merge } from 'lodash-es';
import baseConfig from 'config';
import prisma from '../utils/prismaClient.js';
import { getKeys } from '../utils/index.js';
import { batchLog } from '../utils/logger.js';
import { sendNotification } from '../jobs/notification/sendNotification.js';
import { updateUserMaster } from '../jobs/user/updateUserMaster.js';
import { updateCityMasterWithAccessAzureTimezoneApi } from '../jobs/city/updateCityMaster.js';
import { sendTo_doRemindAfterTrip, sendTo_doRemindBeforeTrip } from '../jobs/notification/sendTodoRemind.js';
const jobPatterns = baseConfig.get('jobs');
const ALL_JOBS = {
    sendNotification: {
        func: sendNotification,
    },
    sendTodoRemindBeforeTrip: {
        func: sendTo_doRemindBeforeTrip,
    },
    sendTodoRemindAfterTrip: {
        func: sendTo_doRemindAfterTrip,
    },
    updateUserMaster: {
        func: updateUserMaster,
    },
    updateCityMasterTimezone: {
        func: updateCityMasterWithAccessAzureTimezoneApi,
    },
};
const jobs = [];
export function setAllJobs() {
    for (const jobType of getKeys(ALL_JOBS)) {
        const cronJob = ALL_JOBS[jobType];
        if (jobPatterns[jobType]?.pattern) {
            const log = batchLog;
            const options = merge({
                context: { log, prisma, jobType, mainFunc: cronJob.func },
                // Jobエラー検知時の処理
                catch: (error) => {
                    log.error(`job scheduler execute error. [jobType: ${jobType}]`, error);
                },
                protect: () => {
                    log.info(`job scheduler is skipped because this job is now working. [jobType: ${jobType}]`);
                },
                timezone: 'Asia/Tokyo',
            }, cronJob.options);
            // job schedule設定
            const job = Cron(jobPatterns[jobType].pattern, options, _executeJob);
            jobs.push(job);
            log.info(`set job scheduler. [jobType: ${jobType}] [pattern: ${jobPatterns[jobType].pattern}]`);
        }
    }
}
async function _executeJob(self, { log, prisma, jobType, mainFunc }) {
    log.info(`job scheduler start. [jobType: ${jobType}]`);
    try {
        await mainFunc(prisma, log);
    }
    catch (error) {
        log.error(`job scheduler error. [jobType: ${jobType}]`, error);
    }
    log.info(`job scheduler end. [jobType: ${jobType}]`);
}
//# sourceMappingURL=JobManager.js.map