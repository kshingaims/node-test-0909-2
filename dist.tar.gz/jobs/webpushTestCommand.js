import { exit } from 'process';
import dotenv from 'dotenv';
import baseConfig from 'config';
import { batchLog } from '../utils/logger.js';
import prisma from '../utils/prismaClient.js';
import { sendNotification } from '../utils/webPush.js';
import { getUserByPid } from '../service/user/userService.js';
import { sleep } from '../utils/index.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    else if (!process.argv[3]) {
        batchLog.warn('arg[3] is pid.');
        exit(0);
    }
    const main = async () => {
        batchLog.info('webpushTestCommand start.' + process.argv[3]);
        try {
            const user = await getUserByPid(prisma, process.argv[3]);
            // web pushテスト送信
            await sendNotification(batchLog, user, {
                title: '[test] MCTriip webpush タイトル',
                body: '[test] MCTriip webpush 本文①②',
                url: baseConfig.get('domain'),
            });
        }
        catch (error) {
            batchLog.error('webpushTestCommand error.', error);
        }
        batchLog.info('webpushTestCommand end.');
        await sleep(10);
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('webpushTestCommand error.', error);
    exit(1);
}
//# sourceMappingURL=webpushTestCommand.js.map