import { exit } from 'process';
import dotenv from 'dotenv';
import prisma from '../utils/prismaClient.js';
import { batchLog } from '../utils/logger.js';
import { updateCityMasterWithAccessAzureTimezoneApi } from '../jobs/city/updateCityMaster.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    const main = async () => {
        batchLog.info('updateCityMasterCommand start.');
        try {
            await updateCityMasterWithAccessAzureTimezoneApi(prisma, batchLog);
        }
        catch (error) {
            batchLog.error('updateCityMasterCommand error.', error);
        }
        batchLog.info('updateCityMasterCommand end.');
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('importCityMaster error.', error);
    exit(1);
}
//# sourceMappingURL=updateCityMasterCommand.js.map