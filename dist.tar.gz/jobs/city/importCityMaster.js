import { createCity } from '../../service/master/cityService.js';
import { readFileSync, existsSync } from 'fs';
import { convertFullPath } from '../../utils/localFile.js';
import papaparse from 'papaparse';
import { Define } from '../../utils/define.js';
import { getPlaceTimezoneByCordinates } from '../../service/azure/timezoneApiService.js';
/**
 * 都市マスタCSVファイルから、都市マスタデータの新規追加を実施する。
 * 取得した「緯度」「経度」情報を利用して、azure timezone APIにアクセスしてサマータイム情報etcを取得する
 */
export async function importCityMasterWithAccessAzureTimezoneApi(prisma, log) {
    const filePath = convertFullPath('prisma/masterCity.csv');
    if (!filePath || !existsSync(filePath)) {
        throw new Error('master city csv file is not exists.');
    }
    const csvData = readFileSync(filePath, 'utf-8');
    const parseJsonResult = papaparse.parse(csvData, {
        dynamicTyping: true,
        header: true,
        skipEmptyLines: true,
    });
    const resultData = parseJsonResult.data;
    for (const row of resultData) {
        if (row.lat && row.lng && row.timezone) {
            const newRow = { ...row };
            // if (newRow.city === '－') {
            //   delete newRow.city;
            // }
            // if (newRow.cityRoma === '－') {
            //   delete newRow.cityRoma;
            // }
            log.debug(`create city. ${newRow.country} ${newRow.city} ${newRow.timezone} start.`);
            const timezoneInfo = await getPlaceTimezoneByCordinates(log, newRow.lat, newRow.lng);
            if (newRow.timezone !== timezoneInfo.timezone) {
                log.info(`timezone difference ${newRow.country} ${newRow.city} [master: ${newRow.timezone}] [azure: ${timezoneInfo.timezone}]`, timezoneInfo.timeTransitions);
            }
            await createCity(prisma, { pid: Define.SETTINGS.ADMIN_PID }, {
                countryCode: newRow.countryCode,
                countryRoma: newRow.countryRoma,
                country: newRow.country,
                cityCode: newRow.cityCode,
                cityRoma: newRow.cityRoma,
                city: newRow.city,
                currency: newRow.currency,
                cityTimezone: newRow.timezone,
                timezoneLabel: timezoneInfo.timezoneLabel,
                azureLocation: { lat: Number(newRow.lat), lng: Number(newRow.lng) },
                timeTransitions: timezoneInfo.timeTransitions,
            });
        }
    }
}
//# sourceMappingURL=importCityMaster.js.map