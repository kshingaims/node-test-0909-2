import { listCities } from '../../service/master/cityService.js';
import { getPlaceTimezoneByCordinates } from '../../service/azure/timezoneApiService.js';
import { Define } from '../../utils/define.js';
const noAzureTimezoneApi = Define.DEBUG.noAzureTimezoneApi;
/**
 * azure timezone APIにアクセスして、最新サマータイム情報etcを取得する
 * 都市マスタデータの更新を実施する。
 */
export async function updateCityMasterWithAccessAzureTimezoneApi(prisma, log) {
    const cities = await listCities(prisma);
    const processMultiCount = 4;
    let threads = [];
    let targetCounts = 0;
    let resultCounts = 0;
    for (const row of cities) {
        if (row.azureLocation) {
            const location = row.azureLocation;
            if (isFinite(location.lat) && isFinite(location.lng)) {
                targetCounts++;
                // この行データの都市について、azure timezone APIからの情報取得と都市マスタ更新を実施
                threads.push(updateCityMasterUsingAzureTimezoneApi(prisma, log, row, location));
                if (threads.length >= processMultiCount) {
                    // マルチスレッドでまとめて処理実施
                    const results = await Promise.all(threads);
                    for (const result of results) {
                        if (result) {
                            resultCounts++;
                        }
                    }
                    threads = [];
                }
            }
        }
    }
    if (threads.length > 0) {
        // マルチスレッドでまとめて処理実施
        const results = await Promise.all(threads);
        for (const result of results) {
            if (result) {
                resultCounts++;
            }
        }
    }
    log.info(`update city master finished. [target: ${targetCounts}] [result: ${resultCounts}]`);
}
async function updateCityMasterUsingAzureTimezoneApi(prisma, log, city, location) {
    try {
        const timezoneInfo = await getPlaceTimezoneByCordinates(log, location.lat, location.lng);
        if (city.cityTimezone !== timezoneInfo.timezone) {
            log.info(`timezone difference ${city.country} ${city.city} [id: ${city.id}] [master: ${city.cityTimezone}] [azure: ${timezoneInfo.timezone}]`, timezoneInfo.timeTransitions);
        }
        if (timezoneInfo.timeTransitions && timezoneInfo.timezone) {
            await prisma.city.update({
                where: { id: city.id },
                data: {
                    cityTimezone: timezoneInfo.timezone,
                    timezoneLabel: timezoneInfo.timezoneLabel,
                    timeTransitions: timezoneInfo.timeTransitions,
                },
            });
            return true;
        }
        else {
            if (noAzureTimezoneApi) {
                return true;
            }
            return false;
        }
    }
    catch (error) {
        log.error('update city master error using azure timezone api.', error);
        return false;
    }
}
//# sourceMappingURL=updateCityMaster.js.map