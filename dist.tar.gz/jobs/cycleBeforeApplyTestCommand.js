import { exit } from 'process';
import dotenv from 'dotenv';
import { batchLog } from '../utils/logger.js';
import { Define } from '../utils/define.js';
import { applyBeforeBusinessTrip } from '../service/cycle/beforeApply.js';
import { sleep } from '../utils/index.js';
try {
    dotenv.config();
    const BATCH_EXE_SECRET = process.env.BATCH_EXE_SECRET;
    // バッチ実行用のシークレット文字列がない
    if (!BATCH_EXE_SECRET) {
        batchLog.warn('BATCH_EXE_SECRET is not set. [settings error]');
        exit(0);
    }
    // 最初の引数はバッチ実行用のシークレット文字列
    if (BATCH_EXE_SECRET !== process.argv[2]) {
        batchLog.warn('batch key is not collect');
        exit(0);
    }
    else if (!process.argv[3] || !process.argv[4]) {
        batchLog.warn('arg[3] is ID. arg[4] is password.');
        exit(0);
    }
    const main = async () => {
        batchLog.info('cycleBeforeApplyTestCommand start.');
        try {
            const options = { id: '', pass: '', cookieIwInfoIntra3: '' };
            if (process.argv[3] === 'cookie') {
                options.cookieIwInfoIntra3 = process.argv[4];
            }
            else {
                options.id = process.argv[3];
                options.pass = process.argv[4];
            }
            // 事前伺い申請処理実施
            const result = await applyBeforeBusinessTrip(batchLog, { pid: 'MC220076', user: { pid: '9ZPWD016' } }, options);
            if (result.errorCode) {
                if (result.errorCode.indexOf('E') >= 0) {
                    batchLog.error(`cycle operation error. cycle site may be changed recently. [errorCode:${result.errorCode}]`);
                }
                else if (result.errorCode === Define.ERROR_CODES.W01001) {
                    batchLog.warn(`this user do not have delegator access rights in cycle system. [errorCode:${result.errorCode}]`);
                }
                else {
                    batchLog.warn(`cycle operation error. [errorCode:${result.errorCode}]`);
                }
            }
            if (result.isSuccess) {
                batchLog.info('cycleBeforeApplyTestCommand success.');
            }
            else {
                batchLog.warn('cycleBeforeApplyTestCommand failed.');
            }
            if (!result.isDbUpdate) {
                batchLog.warn('cycleBeforeApplyTestCommand cycleLinkStatus update failed.');
            }
        }
        catch (error) {
            batchLog.error('cycleBeforeApplyTestCommand error.', error);
        }
        batchLog.info('cycleBeforeApplyTestCommand end.');
        await sleep(10);
        exit(0);
    };
    main();
}
catch (error) {
    batchLog.error('cycleBeforeApplyTestCommand error.', error);
    exit(1);
}
//# sourceMappingURL=cycleBeforeApplyTestCommand.js.map