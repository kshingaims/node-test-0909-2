import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import baseConfig from 'config';
import mcTripApi from './controller/index.js';
import { Define } from './utils/define.js';
import { basicAuthMiddleware } from './middleware/basicAuth.js';
import { convertFullPath } from './utils/localFile.js';
const app = express();
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            'script-src': [
                "'self'",
                "'unsafe-inline'",
                "'unsafe-eval'",
                'https://*.googleapis.com',
                'https://*.gstatic.com',
                '*.google.com',
                'https://*.ggpht.com',
                '*.googleusercontent.com',
                'blob:',
            ],
            'img-src': [
                "'self'",
                'https://*.googleapis.com',
                'https://*.gstatic.com',
                '*.google.com',
                '*.googleusercontent.com',
                '*.blob.core.windows.net',
                'data:',
                'blob:',
            ],
            'frame-src': ['*.google.com'],
            'connect-src': [
                "'self'",
                'https://*.googleapis.com',
                '*.google.com',
                'https://*.gstatic.com',
                'data:',
                'blob:',
            ],
            'font-src': ['https://fonts.gstatic.com'],
            'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
            'worker-src': ["'self'", 'blob:'],
        },
    },
}));
// APIと.htmlに対しては、no-cache設定
// eslint-disable-next-line @typescript-eslint/no-unused-vars,@typescript-eslint/no-explicit-any
app.use((req, res, next) => {
    const url = req.url.toLowerCase();
    if (url.endsWith('.html') || url.startsWith('/api') || url === '/') {
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.set('Pragma', 'no-cache');
        res.set('Expires', '0');
    }
    next();
});
app.use(cors());
//POSTパラメータをJSONで取得する場合に利用
app.use(express.json({ limit: '64mb' }));
// プロキシサーバを信頼
app.set('trust proxy', true);
//POSTパラメータをform submitで取得する場合に利用(利用しない想定)
// app.use(express.urlencoded({ extended: false, limit: '20mb' }));
app.use('/api', mcTripApi);
const wwwRoot = baseConfig.get('staticWWWRoot');
if (Define.DEBUG.isStaticBasicAuth) {
    const AUTH_USER = 'mc';
    const AUTH_PASS = 'mctrip';
    app.use(basicAuthMiddleware(AUTH_USER, AUTH_PASS));
}
app.use('/', express.static(convertFullPath(wwwRoot)));
app.get('*', function (request, response) {
    response.sendFile(convertFullPath(`${wwwRoot}/index.html`));
});
// error handler
// eslint-disable-next-line @typescript-eslint/no-unused-vars,@typescript-eslint/no-explicit-any
app.use(function (err, _req, res, _next) {
    // render the error page
    res.status(err.status || 500);
    res.json({ isSuccess: false, error: { code: 'E00000' } });
});
export default app;
//# sourceMappingURL=app.js.map