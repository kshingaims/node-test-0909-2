import exceljs from 'exceljs';
import { log } from '../utils/logger.js';
import { cloneDeep } from 'lodash-es';
import { convertFullPath } from '../utils/localFile.js';
export async function openExcelFromTemplateFile(tempalteFileName) {
    try {
        const fileFullPath = convertFullPath('config/template/excel/' + tempalteFileName);
        const workbook = new exceljs.Workbook();
        await workbook.xlsx.readFile(fileFullPath);
        return workbook;
    }
    catch (error) {
        log.error('template excel open error.', error);
        throw error;
    }
}
export async function writeFile(workbook, outputFileName) {
    const fileFullPath = convertFullPath('config/template/excel/' + outputFileName);
    await workbook.xlsx.writeFile(fileFullPath);
    return;
}
export async function writeBuffer(workbook) {
    const buffer = await workbook.xlsx.writeBuffer();
    return buffer;
}
export function getWorksheetByName(workbook, sheetName) {
    return workbook.getWorksheet(sheetName);
}
export function getWorksheet(workbook, index = 0) {
    const length = workbook.worksheets.length;
    if (index < 0) {
        index = 0;
    }
    if (length <= 0) {
        return undefined;
    }
    if (length > 0 && length > index) {
        return workbook.worksheets[index];
    }
    else {
        return undefined;
    }
}
export function copyWorksheet(workbook, copeidSheet, newSheetName) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const cloneModel = cloneDeep(copeidSheet.model);
    cloneModel.mergeCells = copeidSheet.model.merges;
    // シートコピーした内容からシート名を変更する。
    cloneModel.name = newSheetName;
    const addSheet = workbook.addWorksheet(newSheetName);
    addSheet.model = cloneModel;
    return addSheet;
}
//# sourceMappingURL=excel.js.map