/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import { get } from 'lodash-es';
const LANG_TEMPLATE = {
    excelDownload: {
        title: {
            flight: {
                ja: 'フライト',
                en: 'Flight',
            },
            hotel: {
                ja: 'ホテル',
                en: 'Hotel',
            },
            transportation: {
                ja: '{{ transportationMode }}移動',
                en: 'Transportation {{ transportationMode }}',
            },
            companyCar: {
                ja: '社有車移動',
                en: 'Company Car',
            },
        },
        hotel: {
            checkOut: {
                ja: 'チェックアウト',
                en: 'Check Out',
            },
        },
    },
    flgArrgt: {
        arranged: {
            ja: '手配済',
            en: 'Arranged',
        },
        notArranged: {
            ja: '未手配',
            en: 'Not Arranged',
        },
    },
};
// パス引数に対して入力補完を有効にする
export function getLangValue(path, lang) {
    const value = get(LANG_TEMPLATE, `${path}.${lang}`);
    if (value) {
        return value;
    }
    else {
        throw new Error(`Invalid path or language: ${path}, ${lang}`);
    }
}
//# sourceMappingURL=lang.js.map