import jwt from 'jsonwebtoken';
import { log } from '../utils/logger.js';
import { Define } from '../utils/define.js';
const TOKEN_SECRET = process.env.JWT_SECRET;
export const LOGIN_TOKEN_EXPIRED_SECOND = 60 * 60 - 20; // 1時間
/**
 * MCTrip用のJWTトークン生成を実施する。
 * 有効期限ありのトークン生成実施。
 * @param jwtObject MCTripでトークン化実施するように定義しているオブジェクト情報
 * @returns トークン文字列
 */
export function createToken(jwtObject, isShortToken = false) {
    if (!TOKEN_SECRET || TOKEN_SECRET.length < 32) {
        throw new Error('jwt token secret is empty or secret length is too short(32).');
    }
    return jwt.sign({ data: jwtObject }, TOKEN_SECRET, {
        expiresIn: isShortToken ? 180 : LOGIN_TOKEN_EXPIRED_SECOND,
    });
}
/**
 * MCTrip用のJWTトークン生成を実施する。
 * 有効期限なしのトークン生成実施。トークンが流出した場合を想定して有効期限なしトークンは別途、
 * トークン利用の無効化ができる仕組みをDBと連携して作成する必要がある。
 * @param jwtObject MCTripでトークン化実施するように定義しているオブジェクト情報
 * @returns トークン文字列
 */
export function createUnlimitedToken(jwtObject) {
    if (!TOKEN_SECRET || TOKEN_SECRET.length < 32) {
        throw new Error('jwt token secret is empty or secret length is too short(32).');
    }
    return jwt.sign({ data: jwtObject }, TOKEN_SECRET);
}
/**
 * リクエストヘッダーからJWTトークン情報を取得し、復号化してオブジェクトを返す。
 * @param req リクエスト
 * @returns オブジェクト情報または、エラー内容
 */
export function verify(req) {
    try {
        const authHeader = req.headers['authorization'];
        if (authHeader !== undefined) {
            const [bearer, token] = authHeader.split(' ');
            if (bearer && token && bearer === 'Bearer') {
                const { data } = jwt.verify(token, TOKEN_SECRET);
                return {
                    jwtTokenObject: data,
                };
            }
        }
        // トークンが見つからないエラー
        return { error: { notfound: true } };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }
    catch (error) {
        if (error.name === 'TokenExpiredError') {
            // トークンの有効期限が切れているエラー
            return { error: { timeout: true } };
        }
        else {
            // その他、トークン復号化できないエラー
            return { error: {} };
        }
    }
}
export function verifyTokenAndSendErrorResponse(req, res, sendResponseJson = true) {
    const checkResult = verify(req);
    if (checkResult.error) {
        let errorCode = '';
        if (checkResult.error.notfound) {
            errorCode = Define.ERROR_CODES.W99003;
            log.warn('access token check failed. access token not found.');
        }
        else if (checkResult.error.timeout) {
            errorCode = Define.ERROR_CODES.W99005;
            log.info('access token check failed. token timeout.');
        }
        else {
            errorCode = Define.ERROR_CODES.W99004;
            log.warn('access token check failed. token is not collect.');
        }
        if (sendResponseJson) {
            res.status(401).json({
                isSuccess: false,
                error: { code: errorCode },
            });
        }
        return { errorCode };
    }
    else {
        return { jwtTokenOjb: checkResult.jwtTokenObject };
    }
}
export function verifyToken(req) {
    const checkResult = verify(req);
    if (checkResult.error) {
        return {};
    }
    else {
        return { jwtTokenOjb: checkResult.jwtTokenObject };
    }
}
export function decodeToken(token) {
    if (!token) {
        return null;
    }
    return jwt.decode(token, { json: true });
}
//# sourceMappingURL=jwtToken.js.map