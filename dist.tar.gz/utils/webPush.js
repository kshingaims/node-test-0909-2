import webpush from 'web-push';
import baseConfig from 'config';
import { Define } from '../utils/define.js';
const noWebpush = Define.DEBUG.noWebpush;
const privateKey = process.env.WEBPUSH_PRIVATE_KEY;
const { publicKey, from } = baseConfig.get('webpush');
const proxy = Define.SYSTEM.PROXY.isUseProxy
    ? `${Define.SYSTEM.PROXY.protocol}://${Define.SYSTEM.PROXY.host}:${Define.SYSTEM.PROXY.port}`
    : undefined;
webpush.setVapidDetails('mailto:' + from, publicKey, privateKey);
export async function sendNotification(log, user, payload) {
    try {
        if (!noWebpush) {
            if (!user || !user.pid) {
                log.warn('no user');
                return false;
            }
            else if (!user.webpushDeviceInfo || !user.webpushDeviceInfo.endpoint || !user.webpushDeviceInfo.keys) {
                log.info(`web push device is not set. [pid: ${user.pid}]`);
                return true;
            }
            const stringPayload = JSON.stringify(payload);
            const result = await webpush.sendNotification(user.webpushDeviceInfo, stringPayload, { proxy });
            log.debug('web push result', result, stringPayload, proxy);
        }
        else {
            const deviceStr = user?.webpushDeviceInfo ? JSON.stringify(user.webpushDeviceInfo) : 'undefined';
            log.debug(`[debug] web push send. [device: ${deviceStr}]`, payload.title, payload.body, payload.url);
        }
        return true;
    }
    catch (error) {
        log.warn('web push access error.', error);
        return false;
    }
}
//# sourceMappingURL=webPush.js.map