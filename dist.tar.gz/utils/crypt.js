import CryptoJs from 'crypto-js';
import { lpad } from '../utils/index.js';
const SECRET = process.env.CRYPT_SECRET;
/**
 * 複号化可能な暗号化実施
 * @param target 対象文字列
 * @returns 暗号化された文字列
 */
export function encrypt(target) {
    if (!target) {
        return target;
    }
    if (!SECRET || SECRET.length < 32) {
        throw new Error('jwt token secret is empty or secret length is too short(32).');
    }
    return CryptoJs.AES.encrypt(target, SECRET).toString();
}
/**
 * 暗号化された文字列を復号化する
 * @param cipherText 暗号化文字列
 * @returns 復号化された文字列
 */
export function decrypt(cipherText) {
    if (!cipherText) {
        return '';
    }
    if (!SECRET || SECRET.length < 32) {
        throw new Error('jwt token secret is empty or secret length is too short(32).');
    }
    try {
        const bytes = CryptoJs.AES.decrypt(cipherText, SECRET);
        return bytes.toString(CryptoJs.enc.Utf8);
    }
    catch (error) {
        // 正しく暗号化された文字列が連携されていないケースがあるので、空文字を返却する
        return '';
    }
}
/**
 * 文字列を復号化困難な形で暗号化する
 * @param target 対象文字列
 * @returns 暗号化された文字列
 */
export function onlyEncrypt(target) {
    if (!target) {
        return target;
    }
    if (!SECRET || SECRET.length < 32) {
        throw new Error('jwt token secret is empty or secret length is too short(32).');
    }
    const secret = lpad(SECRET + target, 'Z', 32);
    return CryptoJs.AES.encrypt(target, secret).toString();
}
//# sourceMappingURL=crypt.js.map