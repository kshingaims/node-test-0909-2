import { mkdirSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// ${projectRoot}/dist/utils/localFile.js
const __filename = fileURLToPath(import.meta.url);
// ${projectRoot}/dist/utils
const __dirname = path.dirname(__filename);
// package.jsonファイルのフルパス(${projectRoot}/package.json)
const rootPackageJsonFullPath = path.resolve(__dirname, '../../package.json');
// プロジェクトルート
const projectRoot = path.dirname(rootPackageJsonFullPath);
// tempディレクトリ
let tempDir = process.env.TEMP_DIR || '';
// 絶対パス指定となっていない場合は、ドキュメントルートを相対パスとしてtempディレクトリを用意
if (tempDir.indexOf('/') === 0 || tempDir.indexOf(':\\') > 0) {
    tempDir = path.resolve(tempDir, 'mctrip');
}
else {
    tempDir = path.resolve(projectRoot, tempDir + '/mctrip');
}
const tempExpenseDirDir = path.resolve(tempDir, 'zipExpense');
mkdirSync(tempExpenseDirDir, { recursive: true });
export function getProjectRootDir() {
    return projectRoot;
}
/**
 * プロジェクトルートからの相対パスを、実際のフルパスへ変換する
 * @param relarivePath プロジェクトルートからの相対パス
 * @returns ファイルのフルパス
 */
export function convertFullPath(relarivePath) {
    return path.resolve(projectRoot, relarivePath);
}
export function convertTempFullPath(relativePath) {
    return path.resolve(tempDir, relativePath);
}
/**
 * 経費のzip添付ファイル保存ディレクトリからの相対パスを、実際のフルパスへ変換する
 * @param relarivePath 経費のzip添付ファイル保存ディレクトリからの相対パス
 * @returns ファイルのフルパス
 */
export function convertxpenseZipFullPath(relarivePath) {
    return path.resolve(tempExpenseDirDir, relarivePath);
}
//# sourceMappingURL=localFile.js.map