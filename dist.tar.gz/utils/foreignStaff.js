import { v4 as uuidv4 } from 'uuid';
import { filter } from 'lodash-es';
import { addDays } from 'date-fns';
import { decrypt, encrypt } from '../utils/crypt.js';
import { Define } from '../utils/define.js';
import { log } from '../utils/logger.js';
import { isBeforeToday } from '../utils/index.js';
/**
 * uuid文字列とuuid文字列を暗号化した文字列も生成して返却する。
 * @returns uuid文字列と、uuid文字列を暗号化した文字列
 */
export function createItineraryAccessKey() {
    const uuid = uuidv4();
    return { uuid, accessKey: encrypt(uuid) };
}
/**
 * 海外拠点担当者が旅程と旅程に紐つく予定を参照する際に利用するアクセスキーを復号化して、
 * DBに保存されている
 * @param uuid uuid文字列
 * @returns uuid文字列を暗号化した文字列
 */
export function makeAccesskeyFromUuid(uuid) {
    return encrypt(uuid);
}
/**
 * 海外拠点担当者が旅程と旅程に紐つく予定を参照する際に利用するアクセスキーを復号化して、
 * DBに保存されている
 * @param accesssKey APIのパラメータで連携されたアクセスキー情報
 * @returns 復号化されたuuid文字列
 */
export function decryptAccessKey(accesssKey) {
    return decrypt(accesssKey);
}
/**
 * 海外拠点担当者の場合の旅程ID(itinearryId)と対象アカウント(assignerPid)取得処理
 * @returns CheckForeignStaffAccessAndGetTargetPidType
 */
export async function checkForeignStaffAccessAndGetTargetPid(prisma, foreignStaffKey, user) {
    let error;
    const decrypted = decryptAccessKey(foreignStaffKey);
    // 復号化文字列が取れない場合は、パラメータ異常
    if (!decrypt) {
        error = { error: { code: Define.ERROR_CODES.W99002, status: 400 } };
        return error;
    }
    // pidとaccessUuidKeyを検索条件にitinerary, itineraryIndidualをrelationとして取得
    const itineraryAccessForeignStaffs = await prisma.itineraryAccessForeignStaff.findMany({
        where: { accessUuidKey: decrypted, itinerary: { flgDelete: false } },
        select: {
            itineraryId: true,
            assignerPid: true,
            itinerary: { select: { itineraryIndividuals: true } },
        },
    });
    // 該当するレコードが0件の場合または、ログインユーザーの権限が海外拠点担当でなかった場合は、W00107エラーを返却し、レスポンスコードは401とする。
    if (itineraryAccessForeignStaffs.length === 0 ||
        !user.roles ||
        !user.roles.includes(Define.SETTINGS.ROLES.FOREIGN_STAFF)) {
        error = { error: { code: Define.ERROR_CODES.W00107, status: 401 } };
        log.info('uuid is not correct.');
        return error;
    }
    // ３階層以降はwhereが使えないためオブジェクトをfilterする
    for (const itineraryAccessForeignStaff of itineraryAccessForeignStaffs) {
        itineraryAccessForeignStaff.itinerary.itineraryIndividuals = filter(itineraryAccessForeignStaff.itinerary.itineraryIndividuals, ['flgDelete', false]);
        for (const itineraryIndividual of itineraryAccessForeignStaff.itinerary.itineraryIndividuals) {
            if (itineraryIndividual.pid === itineraryAccessForeignStaff.assignerPid) {
                const accessibleDays = addDays(new Date(itineraryIndividual.itineraryTo), Define.FOREIGN_STAFF.ENABLE_ITINERARY_VIEW_AFTER_DAYS);
                // 閲覧実施日が対象アカウントが保持する出張完了日のXX日後よりも後である場合は、W00108エラーを返却し、レスポンスコードは401とする。
                if (isBeforeToday(accessibleDays)) {
                    error = { error: { code: Define.ERROR_CODES.W00108, status: 401 } };
                    return error;
                }
                return {
                    assignerPid: itineraryAccessForeignStaff.assignerPid,
                    itineraryId: itineraryAccessForeignStaff.itineraryId,
                };
            }
        }
    }
    throw new Error('unreachable error.');
}
/**
 * 海外拠点担当への手配メールの本文に記載するリンク先URL情報を取得する
 * @param itineraryId 旅程ID
 * @param arrgtCompanyCarId 社有車手配ID
 * @param foreignStaffKey 海外拠点担当がitineraryアクセスする際に利用するトークン
 */
export function getCompanyCarArrgtTopUrl(itineraryId, arrgtCompanyCarId, foreignStaffKey) {
    if (!itineraryId || !foreignStaffKey) {
        throw new Error('unreachable error.');
    }
    let url = Define.DOMAIN + Define.SETTINGS.FOREIGN_STAFF.COMPANY_CAR_ARRGT_PATH.TARGET_PATH;
    // トークンには、URLエンコード必要な文字列が入るので、URLエンコード実施する
    url = url + itineraryId + '/' + arrgtCompanyCarId + '?key=' + encodeURIComponent(foreignStaffKey);
    return url;
}
//# sourceMappingURL=foreignStaff.js.map