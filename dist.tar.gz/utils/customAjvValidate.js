/**
 * 小数点XX桁以内の数値かどうかのチェックを実施
 * @param schema
 * @param data
 * @returns
 */
export function validatePrecision(schema, data) {
    // dataが数値でない場合、検証を失敗させる
    if (typeof data !== 'number') {
        return false;
    }
    // 小数部分の桁数を計算する
    const precision = getDecimalPlaces(data);
    // 指定された桁数と一致するかどうかを検証する
    return precision <= schema;
}
function getDecimalPlaces(num) {
    // 指数表記を処理するため、数値を文字列に変換
    const numStr = num.toString();
    // 指数表記かどうかチェック
    if (numStr.includes('e')) {
        // 指数表記の場合、小数点位置と指数部分を取得
        const parts = numStr.split('e-');
        const base = parts[0].includes('.') ? parts[0].split('.')[1].length : 0;
        const exponent = parseInt(parts[1], 10);
        // 実際の小数部分の桁数を計算
        return base + exponent;
    }
    else {
        // 通常の小数表記の場合、小数点以下の桁数を取得
        const decimalPart = numStr.includes('.') ? numStr.split('.')[1] : '';
        return decimalPart.length;
    }
}
//# sourceMappingURL=customAjvValidate.js.map