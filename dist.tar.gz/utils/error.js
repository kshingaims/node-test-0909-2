/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
/* eslint @typescript-eslint/no-explicit-any: ["off"] */
import { Define } from '../utils/define.js';
/**
 * 更新処理結果が0件の場合は、W99002エラー(レスポンスコード：400)
 * @param target
 */
export function isUpdateNotFound(error) {
    if (error && error.meta && error.meta.cause === 'Record to update not found.') {
        return { code: Define.ERROR_CODES.W99002, status: 400 };
    }
}
//# sourceMappingURL=error.js.map