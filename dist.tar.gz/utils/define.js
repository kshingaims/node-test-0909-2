/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
import baseConfig from 'config';
const debugInfo = baseConfig.get('debug');
const DEFINE = {
    MESSAGES: {
        CYCLE_BEFORE_APPLY_COMMENT: 'MCTripシステム連携による一時保存。内容確認実施の上、申請をお願い致します。',
    },
    DOMAIN: baseConfig.get('domain'),
    SECRET_DB_FIELDS: ['password', 'base64', 'fileName', 'originalFileName', 'pass', 'PASSWORD', 'contentBytes'],
    // エラーコードの採番ルール。エラーコード情報はエラー一覧として定める
    // APIエラー定義追加・修正時は、エラーメッセージ一覧資料への追記・修正を実施する。
    // https://suuiiisya.sharepoint.com/:x:/s/qualita-teams-MCTrip/EVW8nNKJ3VlArEEAk7Ts950BC1qFQcBnrxRhU0eSD4x2FA?e=DwfIDN
    // ■接頭語：
    // W: warning。クライアントから取得したパラメータ情報の入力チェックエラー。
    // E: error。エラー発生。
    // ■数字3桁
    // 001:個別機能の中で汎用的に利用される入力チェックエラー
    // 002:itinerary機能
    // 003:設定機能
    // 004:ファイル機能
    // 005:各種マスタ機能
    // 006:flight機能
    // 007:hotel機能
    // 008:社有車機能
    // 009:経費機能
    // 010:Cycle連携機能
    // 011:graph api連携機能
    // ・・・
    // 990:共通機能で検知するエラー
    // 991:DBに関するエラー
    ERROR_CODES: {
        E99001: 'E99001',
        W99002: 'W99002',
        W99003: 'W99003',
        W99004: 'W99004',
        W99005: 'W99005',
        W99006: 'W99006',
        W99007: 'W99007',
        W99008: 'W99008',
        W99009: 'W99009',
        W99101: 'W99101',
        E99102: 'E99102',
        W00101: 'W00101',
        W00102: 'W00102',
        W00103: 'W00103',
        W00104: 'W00104',
        W00105: 'W00105',
        W00106: 'W00106',
        W00107: 'W00107',
        W00108: 'W00108',
        W00109: 'W00109',
        W00110: 'W00110',
        W00111: 'W00111',
        W00112: 'W00112',
        W00113: 'W00113',
        W00114: 'W00114',
        W00115: 'W00115',
        W00116: 'W00116',
        W00117: 'W00117',
        W00118: 'W00118',
        W00119: 'W00119',
        W00120: 'W00120',
        W00121: 'W00121',
        W00122: 'W00122',
        W00123: 'W00123',
        W00124: 'W00124',
        W00125: 'W00125',
        W00201: 'W00201',
        W00202: 'W00202',
        W00203: 'W00203',
        W00204: 'W00204',
        W00205: 'W00205',
        W00206: 'W00206',
        W00207: 'W00207',
        W00301: 'W00301',
        W00302: 'W00302',
        W00401: 'W00401',
        W00402: 'W00402',
        W00403: 'W00403',
        W00404: 'W00404',
        W00405: 'W00405',
        W00406: 'W00406',
        W00501: 'W00501',
        W00502: 'W00502',
        W00801: 'W00801',
        W00802: 'W00802',
        W00803: 'W00803',
        W00901: 'W00901',
        W00902: 'W00902',
        W00903: 'W00903',
        W00904: 'W00904',
        E00905: 'E00905',
        E00906: 'E00906',
        W01001: 'W01001',
        W01002: 'W01002',
        W01003: 'W01003',
        W01004: 'W01004',
        W01005: 'W01005',
        W01006: 'W01006',
        W01007: 'W01007',
        W01008: 'W01008',
        W01009: 'W01009',
        W01010: 'W01010',
        E01002: 'E01002',
        E01003: 'E01003',
        E01004: 'E01004',
        E01005: 'E01005',
        E01006: 'E01006',
        E01007: 'E01007',
        E01008: 'E01008',
        E01009: 'E01009',
        E01010: 'E01010',
        E01011: 'E01011',
        E01012: 'E01012',
        E01013: 'E01013',
        E01014: 'E01014',
        E01015: 'E01015',
        E01016: 'E01016',
        E01017: 'E01017',
        W01101: 'W01101',
        W01102: 'W01102',
        W01103: 'W01103',
        W01104: 'W01104',
        W01105: 'W01105', // MCTrip予定のoutlook予定への反映が成功したが、DB更新エラー(200)
    },
    SYSTEM: {
        ERROR_CODE_SEP: '::_::',
        PROXY: baseConfig.get('proxy'),
    },
    FOREIGN_STAFF: {
        ENABLE_ITINERARY_VIEW_AFTER_DAYS: 7, // 海外拠点担当が付与された旅程を見ることができる期間(出張終了後XX日まで)の指定
    },
    SETTINGS: {
        ADMIN_PID: '40094286',
        MAX_PAGE: baseConfig.get('paging.maxPage'),
        UPLOAD: baseConfig.get('upload'),
        AZURE_AAD: baseConfig.get('azureAad'),
        AZURE_BLOG: baseConfig.get('azureBlob'),
        FRONT_ERROR_LOG_EXISTS_CHECK_TARGET_DAYS: 7,
        OUTLOOK_INTEGRATION: baseConfig.get('outlookIntegration'),
        ARRGT_STATUS: {
            START: 1,
            FINISHED: 2,
            NO_ARRGT: 9,
        },
        FLG_ARRGT_TEXT: {
            0: '未確定',
            1: '確定済み',
            2: '手配中',
        },
        NOTIFICATION_STATUS: {
            NO_SEND: 0,
            SEND: 1,
            SEND_FINAL: 2,
        },
        ARRGT_DATE_TYPE: {
            // フライト手配時で利用するDATE_TYPE情報
            DEPARTTURE: 'departure',
            ARRIVAL: 'arrival',
        },
        SCHED_HOTEL: {
            CHECKIN_OUT_INPUT_STATUS: {
                NO_INPUT: 0,
                ONLY_CHECKIN: 1,
                ONLY_CHECKUOT: 2,
                INPUT_ALL: 3,
            },
        },
        SCHED_TYPE: {
            FLIGHT: 'schedFlight',
            HOTEL: 'schedHotel',
            COMPANYCAR: 'schedCompanyCar',
            TRANSPORTATION: 'schedTransportation',
            EVENT: 'schedEvent',
        },
        // フライト手配時に利用するフライト予測時間(単位 m)
        ESTIMATED_MINUTES: 120,
        FOREIGN_STAFF: {
            COMPANY_CAR_ARRGT_PATH: {
                BASE: '{{(※[SYSTEM] [削除不可] ここにサイトへのリンクが追加されます。)}}',
                TARGET_PATH: '/foreignCompanyCar/',
            },
        },
        // 経費ファイル関連で利用する
        EXPENSE_TYPE: {
            ACCOMMODATION: 'expenseAccommodation',
            TRANSPORTATION: 'expenseTransportation',
            OTHER: 'expenseOther',
        },
        // パブリックコンテナファイル関連で利用する
        PUBLIC_CONTAINER_TYPE: {
            COMPANY_CAR: 'companyCar',
            HOTEL: 'hotel',
            DRIVER: 'driver',
        },
        ROLES: {
            ADMIN: 'admin',
            FOREIGN_STAFF: 'foreignStaff',
            JAPAN_STAFF: 'japanStaff',
        },
        LIMIT_GROUP: {
            NO_LIMIT: '0',
            ONLY_MY_SYOZOKU_GROUP: '1',
        },
        CYCLE_LINK_STATUS: {
            NOT_START: 0,
            FINISH_BEFORE_APPLY: 1,
            FINISH_AFTER_APPLY: 2,
        },
        GET_REQUEST_PARAM_TRUE: '1',
        GET_REQUEST_PARAM_FLSE: '0',
        CYCLE_CURRENCY_PULLDOWNS: [
            'JPY',
            'USD',
            'EUR',
            'GBP',
            'CNY',
            'INR',
            'IDR',
            'KRW',
            'AED',
            'AMD',
            'ANG',
            'AON',
            'ARS',
            'AUD',
            'AZN',
            'BDT',
            'BGL',
            'BHD',
            'BND',
            'BOB',
            'BRL',
            'BYR',
            'CAD',
            'CHF',
            'CLP',
            'COP',
            'CRC',
            'CZK',
            'DKK',
            'DOP',
            'DZD',
            'EGP',
            'ETB',
            'GEL',
            'GHC',
            'GTQ',
            'HKD',
            'HNL',
            'HRK',
            'HUF',
            'ILS',
            'IQD',
            'IRR',
            'ISK',
            'JOD',
            'KES',
            'KWD',
            'KZT',
            'LAK',
            'LKR',
            'LRD',
            'LTL',
            'LYD',
            'MAD',
            'MMK',
            'MNT',
            'MOP',
            'MUR',
            'MVR',
            'MWK',
            'MXN',
            'MYR',
            'MZM',
            'NGN',
            'NIO',
            'NOK',
            'NPR',
            'NZD',
            'OMR',
            'PAB',
            'PEN',
            'PGK',
            'PHP',
            'PKR',
            'PLN',
            'PYG',
            'QAR',
            'RON',
            'RSD',
            'RUB',
            'SAR',
            'SDG',
            'SEK',
            'SGD',
            'SOS',
            'SVC',
            'SYP',
            'THB',
            'TMT',
            'TND',
            'TRY',
            'TTD',
            'TWD',
            'TZS',
            'UAH',
            'UYU',
            'UZS',
            'VEF',
            'VES',
            'VND',
            'XAF',
            'XPF',
            'YER',
            'ZAR',
            'ZMK',
            'ZMW',
            'ZWD',
            '',
        ],
    },
};
export class Define {
    static get DOMAIN() {
        return DEFINE.DOMAIN;
    }
    static get MESSAGES() {
        return DEFINE.MESSAGES;
    }
    static get ERROR_CODES() {
        return DEFINE.ERROR_CODES;
    }
    static get SECRET_DB_FIELDS() {
        return DEFINE.SECRET_DB_FIELDS;
    }
    static get DEBUG() {
        return debugInfo;
    }
    static get SETTINGS() {
        return DEFINE.SETTINGS;
    }
    static get SYSTEM() {
        return DEFINE.SYSTEM;
    }
    static get FOREIGN_STAFF() {
        return DEFINE.FOREIGN_STAFF;
    }
}
//# sourceMappingURL=define.js.map