import { BlobServiceClient } from '@azure/storage-blob';
import { v4 as uuidv4 } from 'uuid';
import { Define } from '../utils/define.js';
import { log } from '../utils/logger.js';
import { format } from 'date-fns';
import { getFileExp } from './index.js';
const noAzureBlob = Define.DEBUG.noAzureBlob;
const AZURE_STORAGE_CONNECTION_STRING = process.env.AZURE_BLOG_CONNECTION_STRING;
export async function saveSchedAttachment(fileInfo, type, totalFileSize) {
    return await uploadFile(fileInfo, type, totalFileSize);
}
export async function saveExpenseAttachment(fileInfo, type, totalFileSize) {
    return await uploadFile(fileInfo, type, totalFileSize);
}
export async function savePublicContainerAttachment(fileInfo, type, totalFileSize) {
    return await uploadFile(fileInfo, type, totalFileSize, true);
}
export async function downloadSchedAttachment(path) {
    return await downloadFileToBase64(path);
}
export async function downloadExpenseAttachment(path) {
    return await downloadFileToBase64(path);
}
export async function downloadPublicContainerAttachment(path) {
    return await downloadFileToBase64(path, true);
}
export async function deleteSchedAttachment(path) {
    return await deleteBlobIfItExists(path);
}
export async function deleteExpenseAttachment(path) {
    return await deleteBlobIfItExists(path);
}
export async function deletePublicContainerAttachment(path) {
    return await deleteBlobIfItExists(path, true);
}
export async function uploadFile(fileInfo, type, totalFileSize = 0, isPublic = false) {
    if (noAzureBlob) {
        return { path: 'dummyPath', size: 10 };
    }
    else {
        // base64形式のファイルをBuffer変換
        const bufferFile = convert2Buffer(fileInfo, totalFileSize);
        // ファイルサイズが設定された最大ファイルサイズを超えている場合はエラーとする。
        if (bufferFile.code && bufferFile.status) {
            return { error: bufferFile };
        }
        const containerClient = isPublic ? getMcTripPublicConainer() : getMcTripPrivateConainer();
        const fullPath = makeBlobFullPath(type, fileInfo.originalFileName);
        // Get a block blob client
        const blockBlobClient = containerClient.getBlockBlobClient(fullPath);
        // アップロード実施
        const uploadRes = await blockBlobClient.uploadData(bufferFile);
        if (uploadRes.errorCode) {
            log.error(`[Azure Blob Service] unexpected error. [errorCode: ${uploadRes.errorCode}]`);
            return { error: { code: Define.ERROR_CODES.W00406 } };
        }
        log.info(`file upload success. ${fileInfo.originalFileName} [path: ${fullPath}] [requestId: ${uploadRes.requestId}]`);
        return { path: fullPath, size: bufferFile.byteLength };
    }
}
/**
 *
 * @param path ファイルのパス(blob name)
 * @param isPublic
 * @returns ダウンロード取得したファイルのbase64変換した文字列
 */
export async function downloadFile(path, isPublic = false) {
    if (noAzureBlob) {
        return Buffer.from('dGVzdHRlc3R0ZXN0', 'base64');
    }
    else {
        const containerClient = isPublic ? getMcTripPublicConainer() : getMcTripPrivateConainer();
        const blobClient = containerClient.getBlobClient(path);
        return await blobClient.downloadToBuffer();
    }
}
/**
 *
 * @param path ファイルのパス(blob name)
 * @param isPublic
 * @returns ダウンロード取得したファイルのbase64変換した文字列
 */
export async function downloadFileToBase64(path, isPublic = false) {
    if (noAzureBlob) {
        return { base64: 'dGVzdHRlc3R0ZXN0' };
    }
    else {
        const containerClient = isPublic ? getMcTripPublicConainer() : getMcTripPrivateConainer();
        const blobClient = containerClient.getBlobClient(path);
        const buffer = await blobClient.downloadToBuffer();
        return { base64: buffer.toString('base64') };
    }
}
export async function deleteBlobIfItExists(path, isPublic = false) {
    if (noAzureBlob) {
        return { isSuccess: true };
    }
    else {
        const containerClient = isPublic ? getMcTripPublicConainer() : getMcTripPrivateConainer();
        // Create blob client from container client
        const blockBlobClient = containerClient.getBlockBlobClient(path);
        // include: Delete the base blob and all of its snapshots.
        // only: Delete only the blob's snapshots and not the blob itself.
        const delResult = await blockBlobClient.deleteIfExists({ deleteSnapshots: 'include' });
        if (delResult.errorCode) {
            log.error(`[Azure Blob Service] unexpected error. [errorCode: ${delResult.errorCode}]`);
            return { isSuccess: false, error: { code: Define.ERROR_CODES.W00406 } };
        }
        log.info(`file delete success. [path: ${path}] [requestId: ${delResult.requestId}]`);
        return { isSuccess: true };
    }
}
export function convert2Buffer(fileInfo, totalFileSize) {
    if (fileInfo && fileInfo.base64) {
        const buffer = Buffer.from(fileInfo.base64, 'base64');
        if (totalFileSize + buffer.byteLength >= Define.SETTINGS.UPLOAD.outlookTotalFilesSize) {
            return { code: Define.ERROR_CODES.W00405, status: 400 };
        }
        if (buffer.byteLength >= Define.SETTINGS.UPLOAD.maxFileSize) {
            return { code: Define.ERROR_CODES.W00404, status: 400 };
        }
        else {
            return buffer;
        }
    }
    throw new Error('no base64 data in fileInfo');
}
export function makeBlobFullPath(type, fileName) {
    const yearMonth = format(new Date(), 'yyyy/MM');
    const uuid = uuidv4();
    return Define.SETTINGS.AZURE_BLOG.subDirectory[type] + '/' + yearMonth + '/' + uuid + getFileExp(fileName);
}
/**
 * privateアクセスのみ可能なBlob Storageコンテナを返す
 * @returns
 */
export function getMcTripPrivateConainer() {
    return getBlobServiceClient().getContainerClient(Define.SETTINGS.AZURE_BLOG.privateContainer);
}
/**
 * publicアクセス可能なBlob Storageコンテナを返す
 * @returns
 */
export function getMcTripPublicConainer() {
    return getBlobServiceClient().getContainerClient(Define.SETTINGS.AZURE_BLOG.publicContainer);
}
/**
 * Azure Blog Storageにアクセス実施するサービスクライアントを取得
 * @returns
 */
function getBlobServiceClient() {
    return BlobServiceClient.fromConnectionString(AZURE_STORAGE_CONNECTION_STRING);
}
//# sourceMappingURL=azureBlob.js.map