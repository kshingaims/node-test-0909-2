import pkg from 'log4js';
import baseConfig from 'config';
function formatMessage(level, message, category = '') {
    return `[${level}] ${category} - ${message}`;
}
/**
 * PM2によるマルチスレッド化を実施すると、log4jsのログ出力が全スレッドで有効化にならずにログ出力ができなくなる。
 * pm2のサブモジュールを導入することで、PM2マルチスレッド環境下でのlog4js出力も可能だが、azure app service
 * 標準で、グローバルに導入されているPM2ではそのサブモジュールがインストールされていないので、azure app service
 * を利用する場合で、PM2マルチスレッド化する場合は、log4jsを利用しないでログ出力実施(console出力利用)できるようにする。
 */
export class Logger {
    constructor(log4jsOjb, level, category) {
        this.config = undefined;
        this.level = undefined;
        this.category = undefined;
        this.log4jsObj = undefined;
        if (!log4jsOjb && !level) {
            throw new Error('programing error. log4jsOjb and level is both null');
        }
        this.log4jsObj = log4jsOjb;
        this.level = level;
        this.category = category;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    debug(message, ...args) {
        if (this.log4jsObj) {
            this.log4jsObj.debug(message, args);
        }
        else if (this.level === 'debug') {
            // eslint-disable-next-line no-console
            console.log(formatMessage('debug', message, this.category), args);
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    info(message, ...args) {
        if (this.log4jsObj) {
            this.log4jsObj.info(message, args);
        }
        else if (this.level === 'info' || this.level === 'debug') {
            // eslint-disable-next-line no-console
            console.info(formatMessage('info', message, this.category), args);
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    warn(message, ...args) {
        if (this.log4jsObj) {
            this.log4jsObj.warn(message, args);
        }
        else if (this.level === 'warn' || this.level === 'info' || this.level === 'debug') {
            // eslint-disable-next-line no-console
            console.warn(formatMessage('warn', message, this.category), args);
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    error(message, ...args) {
        if (this.log4jsObj) {
            this.log4jsObj.error(message, args);
        }
        else if (this.level !== 'fatal') {
            // eslint-disable-next-line no-console
            console.error(formatMessage('error', message, this.category), args);
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types
    fatal(message, ...args) {
        if (this.log4jsObj) {
            this.log4jsObj.fatal(message, args);
        }
        else {
            // eslint-disable-next-line no-console
            console.error(formatMessage('fatal', message, this.category), args);
        }
    }
}
const isUseLog4js = baseConfig.get('isUseLog4js') || false;
const config = baseConfig.get('log4js');
if (isUseLog4js) {
    const { configure } = pkg;
    configure(baseConfig.get('log4js'));
}
const { getLogger } = pkg;
export const log = isUseLog4js
    ? new Logger(getLogger('api'))
    : new Logger(undefined, config.categories['api']?.level, 'api');
export const batchLog = isUseLog4js
    ? new Logger(getLogger('batch'))
    : new Logger(undefined, config.categories['batch']?.level, 'batch');
//# sourceMappingURL=logger.js.map