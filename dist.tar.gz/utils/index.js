/* eslint no-irregular-whitespace: ["error", {"skipRegExps": true}] */
/* eslint @typescript-eslint/explicit-module-boundary-types: ["off"] */
/* eslint @typescript-eslint/no-explicit-any: ["off"] */
import { isNumber, isFinite, templateSettings, template, omit, isObject, isEmpty as _isEmpty, isString, isArray, isDate, every, includes, get, } from 'lodash-es';
import { isBefore, format as dateFnsFormat, addSeconds, differenceInDays, differenceInMinutes } from 'date-fns';
import { formatInTimeZone } from 'date-fns-tz';
import { Define } from '../utils/define.js';
templateSettings.escape = /\{\{(.+?)\}\}/g;
/**
 * 半角と全角スペースをトリムする
 * @param target
 */
export function trim(target) {
    if (target == null) {
        return '';
    }
    else {
        return target.replace(/(^[\s　]+)|([\s　]+$)/g, '');
    }
}
/**
 * 左埋め実施
 * @param target 対象文字列
 * @param mark 左埋め実施する文字
 * @param length 埋め込み実施後の文字長
 */
export function lpad(target, mark, length) {
    if (mark == null || mark.length != 1) {
        throw new Error('埋め込みをする文字は1文字だけにしてください');
    }
    if (length <= 0) {
        throw new Error('埋め込み実施後の文字長は1以上にしてください');
    }
    let result = '';
    for (let i = 0; i < length; i++) {
        result = result + mark;
    }
    result = result + target;
    return result.slice(-length);
}
/**
 * 指定した桁数で、四捨五入を行う。
 * @param number 対象の数値
 * @param keta 桁
 */
export function round(number, keta = 0) {
    if (!isNumber(number)) {
        number = Number(number);
    }
    if (!isNumber(keta)) {
        keta = Number(keta);
    }
    if (keta > 0) {
        //ignore
    }
    else {
        keta = 0;
    }
    if (isFinite(number)) {
        const sign = number < 0 ? -1 : 1;
        const multi = Math.pow(10, keta);
        let target = number * multi * sign;
        target = Math.round(target);
        target = (target / multi) * sign;
        return target;
    }
    else {
        return NaN;
    }
}
/**
 * 掛け算を行う。
 * @param number1 対象の数値
 * @param number2 対象の数値
 */
export function multi(number1, number2) {
    if (!isNumber(number1)) {
        number1 = Number(number1);
    }
    if (!isNumber(number2)) {
        number2 = Number(number2);
    }
    if (isFinite(number1) && isFinite(number2)) {
        const multi1 = Math.pow(10, getDecimalPointLengh(number1));
        const multi2 = Math.pow(10, getDecimalPointLengh(number2));
        const target1 = Math.round(number1 * multi1);
        const target2 = Math.round(number2 * multi2);
        return (target1 * target2) / multi1 / multi2;
    }
    else {
        return NaN;
    }
}
/**
 * 指定した桁数で、切り上げを行う。
 * @param number 対象の数値
 * @param tax 税率(1.00以上、2.00未満)
 */
export function ceilTax(number, tax) {
    return Math.ceil(multi(number, tax));
}
function getDecimalPointLengh(number) {
    if (Number.isInteger(number)) {
        return 0;
    }
    const splitNumbers = String(number).split('.');
    if (splitNumbers.length === 2) {
        return splitNumbers[1].length;
    }
    return 0;
}
export function isEmpty(target) {
    return _isEmpty(target);
}
/**
 * オブジェクトのキー一覧を返却する(Object.keys()の返却をstring[]ではなく、型タイプに合致したものにする)
 * @param obj
 * @returns
 */
export function getKeys(obj) {
    return Object.keys(obj);
}
/**
 * 非同期処理によるsleep処理
 * @param waitSec ミリ秒
 */
export async function sleep(waitSec) {
    return new Promise(function (resolve) {
        setTimeout(function () {
            resolve();
        }, waitSec);
    });
}
/**
 * テンプレート文字列に対して、項目を動的に埋め込む処理を実施する
 * lodashのtemplateを利用している。
 * 動的埋め込み項目に対して、クロスサイトスクリプティング対策を実施する場合は{{ item }}といった形で埋め込みをする。
 * @param strTemplate テンプレート
 * @param params 動的埋め込み項目
 * @returns
 */
export function format(strTemplate, params) {
    const compile = template(strTemplate);
    return compile(params);
}
/**
 * 文字列を指定したmaxLenghでカットする。
 * @param target
 * @param maxLength
 * @returns
 */
export function cutStr(target, maxLength) {
    if (maxLength <= 0 || !target) {
        return '';
    }
    if (target.length > maxLength) {
        return target.substring(0, maxLength);
    }
    return target;
}
/**
 * 複数文字列を指定した区切り文字を利用してJoinする。
 * @param targets
 * @param separator
 * @param isAlwaysAddSeparator 結合対象文字列の指定がなくても、separotr文字を追加するかどうか(default: false)
 * @returns
 */
export function joinStr(targets, separator = '', isAlwaysAddSeparator = false) {
    let result = '';
    let isFirst = true;
    for (const target of targets) {
        if (target) {
            if (result) {
                result = result + separator;
            }
            result = result + target;
        }
        else {
            if (!isFirst && isAlwaysAddSeparator) {
                result = result + separator;
            }
        }
        isFirst = false;
    }
    return result;
}
/**
 * \n(LF)のみの改行コードを、\r\n(CRLF)にリプレースを実施する。
 * @param target
 */
export function replaceCRLF(target) {
    target = target.replace(/\r/g, '');
    return target.replace(/\n/g, '\r\n');
}
/**
 * \r\n(CRLF)改行コードを、\n(LF)にリプレースを実施する。
 * @param target
 */
export function replaceLF(target) {
    target = target.replace(/\r\n/g, '\n');
    return target;
}
/**
 * タイムゾーンの差を秒数として取得する。
 * 文字列指定されたhours, minutes, secondsから秒数を取得する。
 * @param timezone タイムゾーン(+09:00, -04:30 etc)
 * @returns タイムゾーンの差となる秒数
 */
export function getSeconds(timezone) {
    try {
        // コロンの位置から、時・分・秒を取り出す
        const [hours, minutes, seconds] = timezone.split(':');
        const hasMinus = hours.indexOf('-') === 0;
        let absResult = Math.abs(Number(hours)) * 3600 + Number(minutes) * 60;
        if (seconds && isFinite(Number(seconds))) {
            absResult = absResult + Number(seconds);
        }
        if (isFinite(absResult)) {
            return hasMinus && absResult > 0 ? absResult * -1 : absResult;
        }
        return 0;
    }
    catch (error) {
        return 0;
    }
}
/**
 * 注意！！getLocalDate()とは一緒に使わないこと！！
 * Dateオブジェクト情報を指定したフォーマット文字列に変換する。
 * 日付変換はシステムのタイムゾーンにおける日付として変換される。
 * 例.タイムゾーンが日本の場合は、2023-09-01 15:00:00Zは、2023-09-02判定となる。
 * @param date 対象のDateオブジェクトまたはタイムスタンプ
 * @param formatter
 * @returns
 */
export function formatDate(date, formatter = 'yyyy-MM-dd') {
    return dateFnsFormat(date, formatter);
}
/**
 * Dateオブジェクト情報を指定したフォーマット文字列(世界標準時)に変換する。タイムゾーンはUTC時刻(+00:00)となる。
 * @param date 対象のDateオブジェクトまたはタイムスタンプ
 * @param formatter
 * @returns
 */
export function formatDateTime(date, formatter = 'yyyy-MM-dd HH:mm:ssXXX') {
    return formatUtcDateTime(date, formatter);
}
/**
 * Dateオブジェクト情報を指定したフォーマット文字列に変換する。タイムゾーンはUTC時刻(+00:00)となる。
 * @param date 対象のDateオブジェクトまたはタイムスタンプ
 * @param formatter
 * @returns
 */
export function formatDateTimeMiliSecond(date, formatter = 'yyyy-MM-dd HH:mm:ss.SSSXXX') {
    return formatUtcDateTime(date, formatter);
}
/**
 * 指定したUTC時刻にタイムゾーン分だけ時間をシフトした、UTC時刻を返却する
 * @param utcDate
 * @param timezone
 * @returns
 */
export function getLocalDate(utcDate, timezone) {
    if (isString(utcDate)) {
        utcDate = new Date(utcDate);
    }
    return addSeconds(utcDate, getSeconds(timezone));
}
/**
 * 現地時間を比較して、日にちが+1となっていれば、+1を表示し、-1となっていれば、-1を表示する。
 * 日付に代わりがなければ何も表示しない
 * @param localStartDate
 * @param localEndDate
 * @returns
 */
export function showDifferentDateMark(localStartDate, localEndDate, addStrs) {
    const startStr = formatUtcDateTime(localStartDate, 'yyyy/MM/dd');
    const endStr = formatUtcDateTime(localEndDate, 'yyyy/MM/dd');
    if (startStr === endStr) {
        return '';
    }
    let result = addStrs?.before ? addStrs?.before : '';
    if (isBefore(localStartDate, localEndDate)) {
        result = result + '+' + differenceInDays(new Date(endStr), new Date(startStr));
    }
    else {
        result = result + differenceInDays(new Date(endStr), new Date(startStr)).toString();
    }
    if (addStrs?.after) {
        result = result + addStrs.after;
    }
    return result;
}
/**
 * Dateオブジェクト情報を指定したフォーマット文字列(世界標準時)に変換する。タイムゾーンはUTC時刻(+00:00)とする。
 * @param date 対象のDateオブジェクトまたはタイムスタンプ
 * @param formatter
 * @returns
 */
export function formatUtcDateTime(date, formatter = 'yyyy-MM-dd HH:mm:ssXXX') {
    return formatInTimeZone(date, 'UTC', formatter);
}
export function omitSecretRequestParameters(params, count = 0) {
    if (isObject(params)) {
        if (isArray(params)) {
            return params;
        }
        else if (count > 100) {
            return {};
        }
        try {
            const result = omit(params, Define.SECRET_DB_FIELDS);
            for (const key of Object.keys(result)) {
                if (isObject(result[key])) {
                    result[key] = omitSecretRequestParameters(result[key], count++);
                }
            }
            return result;
        }
        catch (error) {
            return {};
        }
    }
    else {
        return params;
    }
}
/**
 * 指定日付が現在日より前かを検証する。
 * 日にち判定基準となるタイムゾーンはシステムのタイムゾーンとなる。
 * @param date 日付
 * @returns 指定日付が現在日より前の場合はtrue
 */
export function isBeforeToday(date) {
    const now = new Date();
    const today = new Date(formatDate(now));
    const target = new Date(formatDate(date));
    return isBefore(target, today);
}
/**
 * 指定from日付が指定to日付日より前かを検証する
 * @param to 日付
 * @param from 日付
 * @returns 指定from日付が指定to日付日より前の場合はtrue
 */
export function isFromDateBeforeToDate(from, to) {
    return isBefore(new Date(formatDate(from)), new Date(formatDate(to)));
}
/**
 * 指定from日時が指定to日時より前かを検証する
 * @param to 日付
 * @param from 日付
 * @returns 指定from日付が指定to日付日より前の場合はtrue
 */
export function isFromDatetimeBeforeToDatetime(from, to) {
    return isBefore(from, to);
}
/**
 * getパラメータが数値かどうかを判断する。
 * @param target getパラメータの値。値が無い場合も、問題なし(true)判定とする
 * @param min 数値の最小値
 * @param max 数値の最大値
 */
export function checkGetParamsNumber(target, min = 1, max = 4294967295) {
    if (target === undefined || target === null || target === '') {
        return true;
    }
    const val = Number(target);
    if (isFinite(val)) {
        if (val >= min && val <= max) {
            return true;
        }
    }
    return false;
}
/**
 * getパラメータのkeywordを、半角・全角区切りで複数キーワードに分割する
 * @param keyword getパラメータのkeyword
 * @returns 分割されたキーワード
 */
export function splitKeyword(keyword) {
    if (!keyword && keyword !== ' ' && keyword !== '　') {
        return [];
    }
    // 半角、全角スペースでsplit実施
    const keywordsBase = keyword.split(/( |　)/);
    const keywords = [];
    for (const keyword of keywordsBase) {
        if (keyword && keyword !== ' ' && keyword !== '　') {
            keywords.push(keyword);
        }
    }
    return keywords;
}
export function getPageIndexAndMaxPage({ pageIndex, maxPage }) {
    let pageIndexNum = Number(pageIndex);
    let maxPageNum = Number(maxPage);
    if (!isFinite(pageIndexNum) || pageIndexNum <= 0) {
        pageIndexNum = 1;
    }
    if (!isFinite(maxPageNum) || maxPageNum <= 0) {
        maxPageNum = Define.SETTINGS.MAX_PAGE;
    }
    return { pageIndex: pageIndexNum, maxPage: maxPageNum };
}
/**
 * ファイル名の拡張子を抽出して返却する。拡張子が無い場合は、空白文字を返却する
 * @param fileName ファイル名
 */
export function getFileExp(fileName) {
    if (!fileName) {
        throw new Error('fileName is necessary.');
    }
    const dotIndex = fileName.lastIndexOf('.');
    if (dotIndex > 0) {
        return fileName.substring(dotIndex);
    }
    else {
        return '';
    }
}
/**
 * ファイル名を、ファイル名と拡張子とに分割して返却する。拡張子が無い場合は、拡張子は空白文字を返却する
 * @param fileName ファイル名
 */
export function divideFilenameToNameAndExp(fileName) {
    if (!fileName) {
        throw new Error('fileName is necessary.');
    }
    const dotIndex = fileName.lastIndexOf('.');
    if (dotIndex > 0) {
        return [fileName.substring(0, dotIndex), fileName.substring(dotIndex)];
    }
    else {
        return [fileName, ''];
    }
}
export function isJapanStaff(user) {
    if (user?.roles && user?.roles.includes(Define.SETTINGS.ROLES.FOREIGN_STAFF)) {
        return true;
    }
    return false;
}
export function isForeigntaff(user) {
    if (user?.roles && user?.roles.includes(Define.SETTINGS.ROLES.FOREIGN_STAFF)) {
        return true;
    }
    return false;
}
/**
 * 指定された文字列から、条件定義された文字列のみを抽出・取得する。
 *
 * @param targetStr 検索・抽出対象の文字列
 * @param conditions 検索・取得条件の配列。配列の数だけ、文字列の検索・抽出を繰り返す
 * @param conditionCount (利用しない)再帰関数側で利用。本関数を呼び出す最初の時は0となる。
 * @returns 検索・抽出された文字列を返却
 */
export function pickStrValue(targetStr, conditions, conditionCount = 0) {
    if (!targetStr) {
        return '';
    }
    const condition = conditions[conditionCount];
    if (!condition.keyword) {
        return '';
    }
    const startIndex = targetStr.indexOf(condition.keyword);
    if (startIndex < 0) {
        return '';
    }
    const keywordLength = condition.keyword.length;
    if (condition.endKeyword) {
        const searchEndKeywordStr = condition.count
            ? targetStr.substring(startIndex + keywordLength, startIndex + keywordLength + condition.count)
            : targetStr.substring(startIndex + keywordLength);
        const endIndex = searchEndKeywordStr.indexOf(condition.endKeyword);
        if (endIndex < 0) {
            return '';
        }
        const cutStr = searchEndKeywordStr.substring(0, endIndex);
        if (conditions.length - 1 > conditionCount) {
            return pickStrValue(cutStr, conditions, conditionCount + 1);
        }
        return cutStr;
    }
    else if (condition.count) {
        const cutStr = targetStr.substring(startIndex + keywordLength, startIndex + keywordLength + condition.count);
        if (conditions.length - 1 > conditionCount) {
            return pickStrValue(cutStr, conditions, conditionCount + 1);
        }
        return cutStr;
    }
    else {
        const cutStr = targetStr.substring(startIndex + keywordLength);
        if (conditions.length - 1 > conditionCount) {
            return pickStrValue(cutStr, conditions, conditionCount + 1);
        }
        return cutStr;
    }
}
export function strToBuf(target) {
    if (target) {
        const buffer = Buffer.from(target);
        return buffer;
    }
    return undefined;
}
export function bufToStr(buf) {
    if (buf) {
        return buf.toString();
    }
    return '';
}
/**
 * 配列をユニーク文字列をキーにしたオブジェクトに変換を実施する。
 * @param list 配列情報
 * @param name ユニークキーとなるフィールド名
 * @returns
 */
export function convertListToMapByUniqueKey(list, name) {
    const result = {};
    if (list && list.length > 0) {
        for (const item of list) {
            if (item[name]) {
                const fieldName = item[name];
                if (isString(fieldName)) {
                    result[fieldName] = item;
                }
            }
        }
    }
    return result;
}
export function convertAllNullToMark(target, mark = '-') {
    if (isDate(target)) {
        // ignore
    }
    else if (isArray(target)) {
        let count = 0;
        for (const child of target) {
            if (child == null || child === '') {
                target[count] = mark;
            }
            else if (isObject(child)) {
                convertAllNullToMark(child, mark);
            }
            count++;
        }
    }
    else if (isObject(target)) {
        const _target = target;
        for (const key of Object.keys(_target)) {
            if (_target[key] == null || _target[key] === '') {
                _target[key] = mark;
            }
            else if (isObject(_target[key])) {
                convertAllNullToMark(_target[key], mark);
            }
        }
    }
}
export function calcDifferenceInMinutes(target, compared, type, span = 1) {
    const result = differenceInMinutes(target, compared);
    if (result === 0) {
        return result;
    }
    else {
        if (type === 'ceil') {
            return Math.ceil(result / span) * span;
        }
        else {
            return Math.floor(result / span) * span;
        }
    }
}
/**
 * targets配列指定された値が全て、baseListの特定パスの値として存在するかをチェックする。
 * @param targetIds
 * @param baseList
 * @param key baseListの調査対象となるfield名
 * @returns
 */
export function isTargetsValueEveryContained(targets, baseList, path = 'id') {
    if (targets?.length <= 0) {
        return false;
    }
    const baseListTargets = baseList.map((item) => {
        return get(item, path);
    });
    return every(targets, (target) => includes(baseListTargets, target));
}
/**
 * targets配列指定された値が一つ以上、baseListの特定パスの値として存在するかをチェックする。
 * @param targetIds
 * @param baseList
 * @param key baseListの調査対象となるfield名
 * @returns
 */
export function isTargetsValueSomeContained(targets, baseList, path = 'id') {
    if (targets?.length <= 0) {
        return false;
    }
    const baseListTargets = baseList.map((item) => {
        return get(item, path);
    });
    return targets.some((target) => includes(baseListTargets, target));
}
export function getCountryOrCityName(city, lang = 'ja') {
    if (!city) {
        return '';
    }
    const isNoCity = ['-', '－', '', null, undefined].includes(city.city);
    if (lang === 'ja') {
        if (isNoCity) {
            return city.country || '';
        }
        else {
            return city.city || '';
        }
    }
    else {
        if (isNoCity) {
            return city.cityRoma || '';
        }
        else {
            return city.cityRoma || '';
        }
    }
}
//# sourceMappingURL=index.js.map