export {};
//# sourceMappingURL=interface.js.map