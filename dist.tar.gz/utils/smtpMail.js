import { createTransport } from 'nodemailer';
import baseConfig from 'config';
import { Define } from '../utils/define.js';
const TEST_MARK = '[test] ';
const mailSetupConfig = baseConfig.get('smtp.setup');
const defaultFrom = baseConfig.get('smtp.from');
const isStaging = process.env.NODE_ENV === 'staging';
const noExternalIntegration = Define.DEBUG.noExternalIntegration;
const sender = createTransport(mailSetupConfig);
export async function sendSmtpMail(log, mailOption) {
    try {
        const sendMailOption = {};
        sendMailOption.from = mailOption.from || defaultFrom;
        sendMailOption.to = mailOption.to;
        sendMailOption.cc = mailOption.cc;
        sendMailOption.bcc = mailOption.bcc;
        sendMailOption.subject = isStaging ? TEST_MARK + mailOption.title : mailOption.title;
        if (mailOption.isHtml) {
            sendMailOption.html = isStaging ? TEST_MARK + '\r\n\r\n' + mailOption.body : mailOption.body;
        }
        else {
            sendMailOption.text = isStaging ? TEST_MARK + '\r\n\r\n' + mailOption.body : mailOption.body;
        }
        return await send(log, sendMailOption);
    }
    catch (error) {
        log.error('send sendSmtpMail error.', error);
        return false;
    }
}
async function send(log, mailOption) {
    if (noExternalIntegration) {
        log.info('send smtp mail', mailOption);
        return true;
    }
    try {
        const result = await sender.sendMail(mailOption);
        if (result.messageId) {
            return true;
        }
        else {
            log.warn('smtp send mail failed.', result);
            return false;
        }
    }
    catch (error) {
        log.warn('smtp send mail error.', error);
        return false;
    }
}
//# sourceMappingURL=smtpMail.js.map