try {
  self["workbox:core:7.0.0"] && _();
} catch {
}
typeof registration < "u" && registration.scope;
function e() {
  self.addEventListener("activate", () => self.clients.claim());
}
self.skipWaiting();
e();
self.addEventListener("push", (i) => {
  if (i.data) {
    const t = i.data.json();
    t.data = { url: t.url }, i.waitUntil(self.registration.showNotification(t.title, t));
  }
});
self.addEventListener("notificationclick", (i) => {
  const t = i.notification.data.url;
  i.notification.close(), i.waitUntil(self.clients.openWindow(t));
});
